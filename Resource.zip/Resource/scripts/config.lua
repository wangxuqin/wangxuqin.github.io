kDeviceTypeIOS=0;
kDeviceTypeIPHONE = 1;
kDeviceTypeIPAD = 2;
kDeviceTypePC = 3;
kDeviceTypeANDROID = 4;
kDeviceTypeWIN7 = 5;

-- ResConfig is a global val to config res path and format for multi-platform.  
-- 指定将图片转换成下列贴图格式
-- kRGBA8888=0	缺省方式，支持透明，最占用内存，但显示画面效果最佳
-- kRGBA4444=1	比缺省方式节约一半内存，支持透明，画面效果差一些
-- kRGBA5551=2	
-- kRGB565=3	比缺省方式节约一半内存，不支持透明，画面效果差一些
-- kAddGrayScale=0x100	此标志可以与上面的4个值按位或（lua实现有点复杂），
-- 					包含此标志之后，res_create_image接口在创建一个【res位图】的同时，
-- 					附带创建一个【灰度res位图】（会占用更多内存），可以提供给【drawing位图】用来绘制灰色的效果。
-- 					引擎提供了3种灰度算法lightness、average、luminosity供选择，可参考：
-- 					调用sys_set_int(“grayscale_func”, 0或1或2)来选择其中一种算法，缺省是0。

ResConfig = {} 
ResConfig.Filter = kFilterLinear;
ResConfig.Path = nil 
ResConfig.FormatFileMap = {
	["bankrupt/img_chips.png"] = 0x100;
} 
ResConfig.FormatFolderMap = {} 

-- LanguageConfig is a global val to config language for multi-platform.  
LanguageConfig = {} 
LanguageConfig.isZhHant = true; 
