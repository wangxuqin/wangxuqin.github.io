-- stateMachine.lua
-- Author: Vicent Gong
-- Date: 2012-07-09
-- Last modification : 2013-05-30
-- Description: Implement a stateMachine to handle state changing in global

require("core/state");
require("core/anim");
require("core/constants");
require("statesConfig");


StateMachine = class();

StateMachine.getInstance = function()
	if not StateMachine.s_instance then
		StateMachine.s_instance = new(StateMachine);
	end
	
	return StateMachine.s_instance;
end

StateMachine.releaseInstance = function()
	delete(StateMachine.s_instance);
	StateMachine.s_instance = nil;
end

StateMachine.registerStyle = function(self, style, func)
	self.m_styleFuncMap[style] = func;
end

StateMachine.changeState = function(self, state, style, ...)	
	if not StateMachine.checkState(self,state) then
		return;
	end
		
	local newState,needLoad = StateMachine.getNewState(self,state,...);
	local lastState = table.remove(self.m_states,#self.m_states);

	--release all useless states
	for k,v in pairs(self.m_states) do
		StateMachine.cleanState(self,v);
	end

	--Insert new state
	self.m_states = {};
	self.m_states[#self.m_states+1] = newState;
	StateMachine.switchState(self,needLoad,false,lastState,true,style);
end

StateMachine.pushState = function(self, state, style, isPopupState, ...)
	if not StateMachine.checkState(self,state) then
		return;
	end
	
	local newState,needLoad = StateMachine.getNewState(self,state,...);
	local lastState = self.m_states[#self.m_states];

	self.m_states[#self.m_states+1] = newState;

	StateMachine.switchState(self,needLoad,isPopupState,lastState,false,style);
end

StateMachine.popState = function(self, style)
	if not StateMachine.canPop(self) then
		error("Error,no state in state stack\n");
	end
	
	local lastState = table.remove(self.m_states,#self.m_states);
	StateMachine.switchState(self,false,false,lastState,true,style);
end

---------------------------------private functions-----------------------------------------

StateMachine.ctor = function(self)
	self.m_states 			= {};
	self.m_lastState 		= nil;
	self.m_releaseLastState = false;
	
	self.m_loadingAnim		= nil;
	self.m_isNewStatePopup	= false;

	StateMachine.m_styleFuncMap = {};
end

--Check if the current state is the new state and clean unloaded states
StateMachine.checkState = function(self, state)
	delete(self.m_loadingAnim);
	self.m_loadingAnim = nil;
	
	local lastState = self.m_states[#self.m_states];
	if not lastState then
		return true;
	end
	if lastState.state == state then
		return false;
	end

	local lastStateObj = lastState.stateObj;
	if lastStateObj:getCurStatus() <= StateStatus.Loaded then
		StateMachine.cleanState(self,lastState);
		self.m_states[#self.m_states] = nil;
		return StateMachine.checkState(self,state);
	else
		return true;
	end
end

StateMachine.getNewState = function(self, state, ...)
	local nextStateIndex;
	for i,v in ipairs(self.m_states) do 
		if v.state == state then
			nextStateIndex = i;
			break;
		end
	end
	
	local nextState;
	if nextStateIndex then
		nextState = table.remove(self.m_states,nextStateIndex);
	else
		nextState = {};
		nextState.state = state;
		nextState.stateObj = new(StatesMap[state],...);
	end
	
	return nextState,(not nextStateIndex);
end

StateMachine.canPop = function(self)
	if #self.m_states < 2 then
		return false;
	else
		return true;
	end
end

StateMachine.switchState = function(self, needLoadNewState, isNewStatePopup,
										lastState, needReleaseLastState,
										style)	

	self.m_isNewStatePopup = isNewStatePopup;

	self.m_lastState = lastState;
	self.m_releaseLastState = needReleaseLastState;
	self.m_style = style;

	StateMachine.pauseState(self,self.m_lastState);
	
	if needLoadNewState then
		self.m_loadingAnim = new(AnimInt,kAnimRepeat,0,1,1);
		self.m_loadingAnim:setEvent(self,StateMachine.loadAndRun);
	else
		StateMachine.run(self);
	end
end

StateMachine.loadAndRun = function(self)
	local stateObj = self.m_states[#self.m_states].stateObj;
	if stateObj:load() then
		delete(self.m_loadingAnim);
		self.m_loadingAnim = nil;
		stateObj:setStatus(StateStatus.Loaded);
		StateMachine.run(self);
	end
end

StateMachine.run = function(self)
	StateMachine.runState(self,self.m_states[#self.m_states]);
	
	local newStateObj = self.m_states[#self.m_states].stateObj;
	if self.m_lastState and self.m_style and self.m_styleFuncMap[self.m_style] then	
		self.m_styleFuncMap[self.m_style](newStateObj,self.m_lastState.stateObj,self,StateMachine.onSwitchEnd);
	else
		StateMachine.onSwitchEnd(self);
	end
end

StateMachine.onSwitchEnd = function(self)
	if self.m_lastState then
		if self.m_releaseLastState then
			StateMachine.cleanState(self,self.m_lastState);
		elseif self.m_isNewStatePopup then
		
		else
			self.m_lastState.stateObj:stop();
		end
	end

	self.m_lastState = nil;
	self.m_releaseLastState = false;

	local newState = self.m_states[#self.m_states].stateObj;
	newState:resume();
end

StateMachine.cleanState = function(self, state)
	if not (state and state.stateObj) then
		return;
	end

	local obj = state.stateObj;
	for _,v in ipairs(State.s_releaseFuncMap[obj:getCurStatus()]) do
		obj[v](obj);
	end
	delete(obj);
end

StateMachine.runState = function(self, state)
	if not (state and state.stateObj) then
		return;
	end

	local obj = state.stateObj;
	if obj:getCurStatus() == StateStatus.Loaded 
		or obj:getCurStatus() == StateStatus.Stoped  then
		obj:run();
	end
end

StateMachine.pauseState = function(self, state)
	if not (state and state.stateObj) then
		return;
	end

	local obj = state.stateObj;
	if obj:getCurStatus() == StateStatus.Resumed then
		obj:pause();
	end
end

StateMachine.dtor = function(self)
	for i,v in pairs(self.m_states) do 
		StateMachine.cleanState(self,v);
	end
	
	self.m_states = {};
end
