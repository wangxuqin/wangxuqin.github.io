--支持动态值暂停，必须在main.lua中包含此文件，用于覆盖anim中的几个方法

require("core/anim");
AnimBase.s_animArray = {};
AnimBase.ctor = function(self)
	self.m_animID = anim_alloc_id();
	self.m_eventCallback = {};
	self.m_animArray = {};
	AnimBase.s_animArray[self.m_animID] = self;
end

AnimBase.dtor = function(self)
	AnimBase.s_animArray[self.m_animID] = nil;
	anim_free_id(self.m_animID);
end

AnimBase.setPause = function(self, pause)
	anim_set_pause(self.m_animID,pause);
end

AnimBase.setLockPause = function(self , lock)
	self.m_localPause = lock;
end

AnimBase.getLockPause = function(self)
	return self.m_localPause;
end