StateMachine.getCurrentState = function(self)
    return #self.m_states > 0 and self.m_states[#self.m_states].state or nil;
end

StateMachine.getCurrentController = function(self)
    return #self.m_states > 0 and self.m_states[#self.m_states].stateObj:getController() or nil;
end