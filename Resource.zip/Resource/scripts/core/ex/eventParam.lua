--[Comment]
--这个类用于简化,传参错误
EventParam = class()
EventParam.event = nil;
EventParam.cmd   = nil;
EventParam.obj   = nil;
EventParam.func  = nil;

EventParam.ctor = function(self, event, cmd, obj, func)
    if type(event) ~= "table" then
        error("event must be table!");  -- event一定是表类型，不能是event.s_event;
    end
    if type(cmd) ~= "number" then
        error("cmd must be number");    -- event.s_cmd.xxx;
    end
    if type(obj) ~= "table" then
        error("obj must be table");     -- 这个是函数的拥有者
    end
    if type(func) ~= "string" then
        error("func must be string");   -- func只能采用字符串
    end
    self.event  = event;
    self.cmd    = cmd;
    self.obj    = obj;
    self.func   = func;
end

EventParam.dtor = function(self)
end