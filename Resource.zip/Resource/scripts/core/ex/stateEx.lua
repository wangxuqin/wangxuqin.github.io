--region stateEx.lua
--Author : RugbbyLi
--Date   : 2015/1/29
--此文件由[BabeLua]插件自动生成
require("core/state");
State.ctor = function(self, ...)
    self.m_status = StateStatus.Unloaded;
    self.m_switchArgs = {...};
end

State.getNavigationArgs = function(self)
    return self.m_switchArgs;
end
--endregion
