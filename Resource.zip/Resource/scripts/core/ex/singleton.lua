--[Commet]
--��Ƶ������ģʽ
Singleton = {}
	
Singleton.__instances = {}; --������������

Singleton.getInstance = function(clazz)
    if clazz ~= nil then
        if Singleton.__instances [clazz] == nil then
		    Singleton.__instances[clazz] = new(clazz);
        end
    end
    return Singleton.__instances[clazz];
end

Singleton.releaseInstance = function(clazz)
    if clazz ~= nil then
        if Singleton.__instances [clazz] == nil then
		    delete(Singleton.__instances [clazz]);
            Singleton.__instances[clazz] = nil;
        end
    end
end