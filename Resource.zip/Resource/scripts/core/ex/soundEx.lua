require("core/sound");


Sound.preloadAllMusic = function(musicFileTab)
	if musicFileTab == nil or next(musicFileTab) == nil then
		return;
	end
	for i, fileName in pairs(musicFileTab) do
		if fileName ~= nil and string.len(fileName) > 0 then
			Sound.preloadMusic(fileName);
		end
	end
end

Sound.preloadAllEffect = function(effectFileTab)
	if effectFileTab == nil or next(effectFileTab) == nil then
		return;
	end
	for i, fileName in pairs(effectFileTab) do
		if fileName ~= nil and string.len(fileName) > 0 then
			Sound.preloadEffect(fileName);
		end
	end
end

Sound.unloadAllEffect = function(effectFileTab)
	if effectFileTab == nil or next(effectFileTab) == nil then
		return;
	end
	for i, fileName in pairs(effectFileTab) do
		if fileName ~= nil and string.len(fileName) > 0 then
			Sound.unloadEffect(fileName);
		end
	end
end
