--[Comment]
--联合主键
JointKey = class();
JointKey.__keyArray = {};

JointKey.ctor = function(self)
end

JointKey.dtor = function(self)
end

--[Comment]
--添加，注意key1, key2不能为空
JointKey.add = function(self, key1, key2)
    local canAdd = true;
    if #self.__keyArray > 0 and key1 and key2 then
        for i = 1, #self.__keyArray do
            local k1 = self.__keyArray[i][1];
            local k2 = self.__keyArray[i][2];
            if k1 == key1 and k2 == key2 then
                canAdd = false;
                break;
            end
        end
    end

    if canAdd then
        self.__keyArray[#self.__keyArray + 1] = {key1, key2};
    end
end

JointKey.arr = function(self)
    return self.__keyArray;
end