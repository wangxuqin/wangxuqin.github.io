--[Comment]
--联合主键
Set = class();
Set.__keyArray = {};

Set.ctor = function(self)
end

Set.dtor = function(self)
end

--[Comment]
--添加，注意key1, key2不能为空
Set.add = function(self, key1)
    local canAdd = (key1 ~= nil);
    if #self.__keyArray > 0 and key1 then
        for i = 1, #self.__keyArray do
            local k1 = self.__keyArray[i];
            if k1 == key1 then
                canAdd = false;
                break;
            end
        end
    end

    if canAdd then
        self.__keyArray[#self.__keyArray + 1] = key1;
    end
end

Set.arr = function(self)
    return self.__keyArray;
end