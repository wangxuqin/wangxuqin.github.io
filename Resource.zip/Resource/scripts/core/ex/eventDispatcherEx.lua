--[Comment]
--EventDispatcher扩展
require("core/ex/eventParam");
require("core/eventDispatcher");

if EventDispatcher ~= nil then
    EventDispatcher.TAG = "EventDispatcher";
    EventDispatcher.old_register      = EventDispatcher.register;
    EventDispatcher.old_unregister    = EventDispatcher.unregister;
    

    --[Comment]
    --事件监听 event, cmd, obj, func 
    EventDispatcher.register = function(self, param1, param2, param3, param4)
        if param1 == 1 then
            print_string(param1);
        end
        if param4 == nil then
            self:old_register(param1, param2, param3);
        else
            local event = param1;
            local cmd   = param2;
            local obj   = param3;
            local func  = param4;   --字符串
            self:__addEventListener(event, cmd, obj, func);
        end
    end

    --[Comment]
    --取消事件监听 event, cmd, obj, func
    EventDispatcher.unregister = function(self, param1, param2, param3, param4)
        if param4 == nil then
            self:old_unregister(param1, param2, param3);
        else
            local event = param1;
            local cmd   = param2;
            local obj   = param3;
            local func  = param4;   --字符串
            self:__removeEventListener(event, cmd, obj, func);
        end
    end
    
    --[Comment]
    --通过传入EventParam事件监听
    EventDispatcher.registerByParam = function(self, param)
        if not typeof(param, EventParam) then
            error("param'type must be EventParam!");--事件类型必须为EventParam
        end
        if not (param ~= nil and param.event ~= nil and param.cmd and param.obj ~= nil and param.func ~= nil) then
            error("param and param[event, cmd, obj, func] must not be nil!")
        end
        self:register(param.event, param.cmd, param.obj, param.func);
    end


    --[Comment]
    --通过传入EventParam取消事件监听
    EventDispatcher.unregisterByParam = function(self, param)
        if not typeof(param, EventParam) then
            error("param'type must be EventParam!");--事件类型必须为EventParam
        end
        if not (param ~= nil and param.event ~= nil and param.cmd and param.obj ~= nil and param.func ~= nil) then
            error("param and param[event, cmd, obj, func] must not be nil!")
        end
        self:unregister(param.event, param.cmd, param.obj, param.func);
    end


    --[Comment]
    --注册一组事件
    EventDispatcher.registerEventList = function(self, obj, arr)
        if obj ~= nil and arr ~= nil and #arr > 0 then
             for i = 1, #arr do
                local event = arr[i][1];
                local cmd   = arr[i][2];
                local func  = arr[i][3];
                self:register(event, cmd, obj, func);
             end
        end
    end

    EventDispatcher.__addEventListener = function(self, event, cmd, obj, func)
        self:__createCmdFuncMap(event, cmd, obj, func);
        self:__createDispatchFunc(event, obj);
    end

    EventDispatcher.__removeEventListener = function(self, event, cmd, obj, func)
         if obj and obj[event] and obj[event][cmd] then
            obj[event][cmd][func] = nil;
            obj["listener_count"] = obj["listener_count"] or 0;
            obj["listener_count"] = obj["listener_count"] - 1;
            if obj["listener_count"] == 0 then
                self:__destroyDispatchFunc(event, obj);
            end
         end
    end
    

    --创建事件与方法的映射
    EventDispatcher.__createCmdFuncMap = function(self, event, cmd, obj, func)
        if event and cmd and obj and func then
            if obj and obj[func] == nil then
                local TAG = obj.TAG or "obj";
                Log.e(TAG, " has not function ["..func.."]");
            end
            obj[event] = obj[event] or {};
            obj[event][cmd] = {};
            obj[event][cmd][func] = function(objKey, ...) obj[func](objKey, ...) end;
            if obj["listener_count"] == nil or obj["listener_count"] < 0 then
                obj["listener_count"] =  0;
            end
            obj["listener_count"] = obj["listener_count"] + 1;
        end
    end

    --创建分发处理函数
    EventDispatcher.__createDispatchFunc = function(self, event, obj)
        if obj and event then
            obj[event] = obj[event] or{}; 
            if obj[event]["map"] == nil then
                obj[event]["map"]  = function(_obj,_cmd,...)
	                if _obj[event][_cmd] then
     	                local functions = _obj[event][_cmd];
                        for key, func in pairs(functions) do
                            func(_obj,...);
                        end
                    end
	            end
                self:old_register(event.s_event, obj, obj[event]["map"]);
            end
        end
    end

    EventDispatcher.__destroyDispatchFunc = function(self, event, obj)
        if obj  and event and obj[event]["map"] ~= nil then
            self:unregister(event.s_event, obj, obj[event]["map"]);
            obj[event]["map"] = nil;
        end
    end
   

    --解除一组事件
    EventDispatcher.unregisterEventList = function(self, obj, arr)
        if obj ~= nil and arr ~= nil and #arr > 0 then
             for i = 1, #arr do
                local event = arr[i][1];
                local cmd   = arr[i][2];
                local func  = arr[i][3];
                self:__removeEventListener(event, cmd, obj, func);
            end
        end
    end

end