-- systemEx.lua
-- Author:MaxizMa
-- Date:2014.9.28
-- Modify Date:2014.9.28
-- Description: 系统扩展类，负责解析系统相关的参数

require("core/system");
require("common/native/nativeCMD");
require("service/nativeService");

System.setLayoutWidth = function(width)
	System.s_layoutWidth = width;
end

System.setLayoutHeight = function(height)
	System.s_layoutHeight = height;
end

System.getLayoutWidth = function(width)
	return System.s_layoutWidth or System.getScreenWidth();
end

System.getLayoutHeight = function(height)
	return System.s_layoutHeight or System.getScreenHeight();
end

System.getLayoutScale = function()
	if not System.s_layoutScale then
		local xScale = System.getScreenWidth() / System.getLayoutWidth();
		local yScale = System.getScreenHeight() / System.getLayoutHeight();
		System.s_layoutScale = xScale>yScale and yScale or xScale;
	end
	return System.s_layoutScale;
end

System.getScreenScaleWidth = function(self)
	if not System.s_screenScaleWidth then
		System.s_screenScaleWidth = System.getScreenWidth() / 
			System.getLayoutScale();
	end

	return System.s_screenScaleWidth;
end

System.getScreenScaleHeight = function(self)
	if not System.s_screenScaleHeight then
		System.s_screenScaleHeight = System.getScreenHeight() / 
			System.getLayoutScale();
	end

	return System.s_screenScaleHeight;
end

System.isPause = function(pause)
	return System.m_pause;
end

System.setPause = function(pause)
	pause = pause and pause or 0;
	System.m_pause = (pause == 0) and false or true;
	
	for i,v in pairs(AnimBase.s_animArray or {}) do
		local anim = AnimBase.s_animArray[i];
		if v then
			if not v:getLockPause() then
				v:setPause(pause);
			end
		end
	end
end

System.getStorageDictPath = function()
	return sys_get_string("storage_dic") or "";
end

System.getStorageLogPath = function()
	return sys_get_string("storage_log") or "";
end

System.getStorageUserPath = function()
	return sys_get_string("storage_user") or "";
end

System.getStorageImagePath = function()
	return sys_get_string("storage_images") or "";
end

System.getStorageScriptPath = function()
	return sys_get_string("storage_scripts") or "";
end

System.getStorageImagePath = function()
	return sys_get_string("storage_images") or "";
end

System.getStorageAudioPath = function()
	return sys_get_string("storage_audio") or "";
end

System.getStorageFontPath = function()
	return sys_get_string("storage_fonts") or "";
end

System.getStorageXmlPath = function()
	return sys_get_string("storage_xml") or "";
end

System.getStorageUpdatePath = function()
	return sys_get_string("storage_update") or "";
end

System.getStorageTempPath = function()
	return sys_get_string("storage_temp") or "";
end

System.getVersionName = function()
	return dict_get_string(kGetVersion,"versionName") or "";
end

System.getVersionCode = function()
	return dict_get_int(kGetVersion,"versionCode",0);
end

System.getMobileType = function()
	return dict_get_string(kSystemInfo,kSysNetType) or "none";
end

System.getPhoneImei = function()
	return dict_get_string(kSystemInfo,kSysImei) or "";
end

System.getChannelNo = function()
	return dict_get_string(kSystemInfo,kChannelNo) or "";
end

System.getClientID = function ()
	return dict_get_string(kSystemInfo, "getui_cid") or ""
end

System.getLongitude = function()
	local lon = dict_get_string(kSystemInfo,kLongitude); 

	if lon then
		lon = tonumber(lon);
	end

	return lon or 0;
end

System.getLatitude = function()
	local lat = dict_get_string(kSystemInfo,kLatitude); 

	if lat then
		lat = tonumber(lat)
	end

	return lat or 0;
end







--[Comment]
--iPoker过渡方法
System.getStageWidth = function()
	return System.getScreenWidth();
end

System.getStageHeight = function()
	return System.getScreenHeight();
end

System.isAndroid = function()
    return System.getPlatform() == kPlatformAndroid;
end

System.isIOS = function()
    return System.getPlatform() == kPlatformIOS;
end

System.isIOS7 = function()
    return false;
end

System.applicationStoragePath = function()
    return System.getStorageScriptPath();
end

System.os = function()
    return "Linux";
end

		
System.vibrate = function()
end

System.getMacAddress = function()
    return NativeService.getInstance():getMacAddress();
end

System.isNetworkAvailable = function()
    return true;
end

System.silentSwitch = function()
end
		
System.initialize = function()
end

System.initPushNotification = function()
end
		
System.sendLocalNotification = function(message, timestamp, title)
end
		
System.getDeviceId = function()
    return "";
end

System.getDeviceDesc = function()
    return "Android";
end


		
System.getDeviceIDFA = function()
    return ""
end
		
System.getDeviceName = function()
    return "";
end

		
System.getOpenUDID = function()
    return "09962c851b3c27dd398913897ee384360c227b2c";
end
		
System.openNativeDialog = function(title, message, button1Label, button2Label, handler)
end

System.getSystemInfo = function()
end