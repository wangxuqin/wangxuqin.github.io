-- global.lua
-- Author: Vicent Gong
-- Date: 2012-09-30
-- Last modification : 2013-05-30
-- Description: provide some global functions
require("common/log");

FwLog = function(logStr)
	-- print_string(logStr);
    Log.w(logStr);
end

Copy = function(t)
	if type(t) ~= "table" then
		return t;
	end

	local ret = {};
	for k,v in pairs(t) do 
		ret[Copy(k)] =Copy(v);
	end

    local mt = getmetatable(t);
    setmetatable(ret,Copy(mt));
	return ret;
end

MegerTables = function(...)
    local ret = {};
    local count = select("#",...);
    for i=1,count do
        local t = select(i,...);
        if type(t) == "table" then
            for _,v in pairs(t) do
                ret[#ret+1] = v;
            end
        end
    end
    return ret;
end

CombineTables = function(...)
    local ret = {};
    local count = select("#",...);
    for i=1,count do
        local t = select(i,...);
        if type(t) == "table" then
            for k,v in pairs(t) do
                ret[k] = v;
            end
        end
    end
    return ret;
end

CreateTable = function(weakOption)
    if not weakOption or (weakOption ~= "k" and weakOption ~= "v" and weakOption ~= "kv") then
        return {};
    end

    local ret = {};
    setmetatable(ret,{__mode = weakOption});
    return ret;
end

SubtractArray = function(arr1,arr2)
    local ret = {};

    kvRevertArr2 = {};
    for k,v in ipairs(arr2) do 
        kvRevertArr2[v] = kvRevertArr2[v] or 0;
        kvRevertArr2[v] = kvRevertArr2[v] + 1;
    end

    for k,v in ipairs(arr1) do 
        if not kvRevertArr2[v] then
            ret[#ret+1] = v;
        else
            kvRevertArr2[v] = kvRevertArr2[v] - 1;
            kvRevertArr2[v] = kvRevertArr2[v] > 0 and kvRevertArr2[v] or nil;
        end
    end
    return ret;
end

GetNumFromJsonTable = function(tb, key, default)
    local ret = default;
    if tb and tb[key] ~= nil then
        if tb[key]:get_value() ~= nil then
            ret = tonumber(tb[key]:get_value());
            if ret == nil then
                ret = default;
            end
        end
    end
    return ret;
end

GetStrFromJsonTable = function(tb, key, default)
    local ret = default;
    if tb and tb[key] ~= nil then
        if tb[key]:get_value() ~= nil then
            ret = tb[key]:get_value();
            if string.len(ret)  == 0 then
                ret = default;
            end
        end
    end
    return ret;
end

GetBlooeanFromJsonTable = function(tb, key, default)
    local ret = default;
    if tb and tb[key] ~= nil then
        if tb[key]:get_value() ~= nil then
            ret = tb[key]:get_value();
        end
    end
    return ret;
end

GetTableFromJsonTable = function(tb, key, default)
    local ret = default;
    if tb and tb[key] ~= nil then
        if tb[key]:get_value() ~= nil then
            ret = tb[key]:get_value();
            if type(ret) ~= "table" then
                ret = default;
            end
        end
    end
    return ret;
end

orderedPairs = function(t)
	local cmpMultitype = function(op1, op2)
		local type1, type2 = type(op1), type(op2)
		if type1 ~= type2 then --cmp by type
			return type1 < type2
		elseif type1 == "number" and type2 == "number"
			or type1 == "string" and type2 == "string" then
			return op1 < op2 --comp by default
		elseif type1 == "boolean" and type2 == "boolean" then
			return op1 == true
		else
			return tostring(op1) < tostring(op2) --cmp by address
		end
	end

	local genOrderedIndex = function(t)
		local orderedIndex = {}
		for key in pairs(t) do
			table.insert( orderedIndex, key )
		end
		table.sort( orderedIndex, cmpMultitype ) --### CANGE ###
		return orderedIndex
	end

    local orderedIndex = genOrderedIndex( t );
    local i = 0;
    return function(t)
        i = i + 1;
        if orderedIndex[i] then
            return orderedIndex[i],t[orderedIndex[i]];
        end
    end,t, nil;
end


Joins = function(t, mtkey)
    local str = PHPCMDConstants.KEY;
    if t == nil or type(t) == "boolean"  or type(t) == "byte" then
        return str;
    elseif type(t) == "number" or type(t) == "string" then
        str = string.format("%sT%s%s", str.."", mtkey, string.gsub(t, "[^a-zA-Z0-9]",""));
    elseif type(t) == "table" then

        if IsArray(t) then   -- 当为int数组时
            str = str .. JoinsArray(t,mtkey);
        else
            for k,v in orderedPairs(t) do
                str = string.format("%s%s=%s", str, tostring(k), Joins(v, mtkey));
            end
        end
    end
    return str;
end

JoinsArray = function(uids,mtkey)
    local tab = {};
    for i = 0,(#uids-1) do
        tab[i] = uids[i+1];
    end

    local marks = {};

    return DoJoinsArray(tab,marks,mtkey,0);
end

DoJoinsArray = function(uids,marks,mtkey,index)
    if index > #uids or marks[index] == true then
        return "";
    end

    local str = index.."="..Joins(uids[index],mtkey); 
    marks[index] = true;

    local tenTimesIndex = 10 * index;
    if tenTimesIndex > index and tenTimesIndex <= #uids and marks[tenTimesIndex] ~= true then
        local limit = tenTimesIndex + 9;
        for i = tenTimesIndex,limit do
            str = str..DoJoinsArray(uids,marks,mtkey,i);
        end
    end

    if index%10 < 9 then
        str = str..DoJoinsArray(uids,marks,mtkey,index+1);
    end

    return str;
end

IsArray = function(tab)
    if type(tab) ~= "table" then
        return false;
    end

    local n1 = 0;
    for _,v in pairs(tab) do
        n1 = n1+1;
    end
    
    local n2 = #tab;
    if n2 == 0 or n1 ~= n2 then
        return false;
    end
   
    return true;
end

----------------------普通格式的table------------------------------
getNumFromTable = function(tb,key,default)
    if not default then
        default = -1000000;
    end

    if nil == tb or not key or type(tb) ~= "table" then
        return default 
    end;
    local ret = default;
    if tb[key] ~= nil then
        ret = tonumber(tb[key]);
        if ret == nil then
            ret = default;
        end
    end
    return ret;
end

getStrFromTable = function(tb,key,default)
    if not default then
        default = "";
    end

    if nil == tb or not key or type(tb) ~= "table" then
        return default 
    end;

    local ret = default;
    if tb[key] ~= nil then
        ret = tb[key];
        if ret == nil or string.len(ret) == 0 then
            ret = default;
        end
    end
    return ret;
end

getBooleanFromTable = function(tb,key,default)
    if not default then
        default = false;
    end

    if nil == tb or not key or type(tb) ~= "table" then
        return default 
    end;
    local ret = default;
    if tb[key] ~= nil then
        ret = tb[key];
        if ret == nil then
            ret = default;
        end
    end

    if ret or ret == "true" then
        ret = true;
    else
        ret = false;
    end

    return ret;
end

getTabFromTable = function(tb,key,default)
    default = default or {};

    if nil == tb or not key or type(tb) ~= "table" then
        return default 
    end;
    return tb[key] or default;
end

--[Comment]
--这个方法用于Controller中内部方法代理，可以在里面加入各种处理。
ctrlDynProxy = function(obj, func)
     return function(...)
        --加上某些公共逻辑
        if type(func) == "string" then
            obj[func](...)
        else
            func(...);
        end
    end
end

--[Comment]
--这个方法用于ui中内部方法代理，可以在里面加入各种处理
uiDynProxy = function(obj, func)
    return function(...)
        --加上音效

        if type(func) == "string" then
            obj[func](...)
        else
            func(...);
        end
    end
end

--[Comment]
--这个方法用于控制器中，用于简化组件消息映射
ctrlCmd = function(index, ctrl, func)
    if ctrl ~= nil then
        ctrl.s_cmdConfig = ctrl.s_cmdConfig or {};
        ctrl.s_cmdConfig[index] = ctrlDynProxy(ctrl, func)
    end
    return index;
end

__interval = {};
__intervalIndex = 1;
--[Comment]
--设置重复延时调用
setInterval = function(func, obj, delay, data)
    local index = 0;
    if func ~= nil then
        index = tostring(__intervalIndex);
        local anim = new(AnimDouble, kAnimRepeat, 0, 0, delay, -1);
        __interval[index]           = {};
        __interval[index]["anim"]   = anim;
        __interval[index]["obj"]    = obj;
        __interval[index]["param"]  = data;
        __interval[index]["anim"]:setEvent(obj, function(...)
            local obj   = __interval[index]["obj"];
            local param = __interval[index]["param"];
            if obj ~= nil and param ~= nil then
                func(obj, param);
            elseif obj ~= nil and param == nil then
                func(obj);
            elseif obj == nil and param ~= nil then
                func(param);
            else
                func();
            end
        end);
    end
    __intervalIndex = __intervalIndex + 1;
    return tonumber(index);
end

--[Comment]
--取消重复延时调用
clearInterval = function(index)
    if index ~= nil then
        if __interval[tostring(index)] ~= nil then
            if __interval[tostring(index)]["anim"] ~= nil then
                __interval[tostring(index)]["anim"]:dtor();
                __interval[tostring(index)]["anim"] = nil;
            end
            __interval[tostring(index)]["obj"]      = nil;
            __interval[tostring(index)]["param"]    = nil;
            __interval[tostring(index)] = nil;
        end
    end
end

__timeOut = {};
__timeOutIndex = 1;
--[Comment]
--设置超时时间
setTimeout = function(func, obj, delay, data)
    local index = 0;
    if func ~= nil then
        index = tostring(__timeOutIndex);
        local anim = new(AnimDouble, kAnimNormal, 0, 0, delay, -1);
        __timeOut[index] = {};
        __timeOut[index]["anim"]     = anim;
        __timeOut[index]["obj"]      = obj;
        __timeOut[index]["param"]    = data;
        __timeOut[index]["anim"]:setEvent(obj, function(...)
            local obj   = __timeOut[index]["obj"];
            local param = __timeOut[index]["param"];
            if obj ~= nil and param ~= nil then
                func(obj, param);
            elseif obj ~= nil and param == nil then
                func(obj);
            elseif obj == nil and param ~= nil then
                func(param);
            else
                func();
            end

            if __timeOut[tostring(index)] ~= nil then
                if __timeOut[tostring(index)]["anim"] ~= nil then
                    __timeOut[tostring(index)]["anim"]:dtor();
                    __timeOut[tostring(index)]["anim"] = nil;
                end
                __timeOut[tostring(index)]["obj"]      = nil;
                __timeOut[tostring(index)]["param"]    = nil;
                __timeOut[tostring(index)] = nil;
            end
        end);
    end
    __timeOutIndex = __timeOutIndex + 1;
    return tonumber(index);
end

--[Comment]
--取消超时处理
clearTimeout = function(index)
    if index ~= nil and index > 0 then
        if __timeOut[tostring(index)] ~= nil then
            if __timeOut[tostring(index)]["anim"] ~= nil then
                __timeOut[tostring(index)]["anim"]:dtor();
                __timeOut[tostring(index)]["anim"] = nil;
            end
            __timeOut[tostring(index)]["obj"]      = nil;
            __timeOut[tostring(index)]["param"]    = nil;
            __timeOut[tostring(index)] = nil;
        end
    end
end

--[Commnet]
--获取当前CPU时钟周期
getTimer = function()
    return os.clock();
end