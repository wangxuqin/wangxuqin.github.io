-- constants.lua
-- Author: Vicent Gong
-- Date: 2012-09-21
-- Last modification : 2013-07-02
-- Description: Babe kernel Constants and Definition

---------------------------------------Anim---------------------------------------
kAnimNormal	= 0;
kAnimRepeat	= 1; -- 0.0、0.1、0.2......1.0；0.0、0.1、0.2......1.0；0.0、0.1、0.2......1.0.........无限循环下去
kAnimLoop	= 2; -- 0.0、0.1、0.2......1.0；0.9、0.8、0.7......0.0；0.0、0.1、0.2......1.0.........无限循环下去

----------------------------------------------------------------------------------

---------------------------------------Res----------------------------------------
--format
kRGBA8888	= 0;
kRGBA4444	= 1;
kRGBA5551	= 2;
kRGB565		= 3;
kRGBGray	= 0x100;

--filter
kFilterNearest	= 0;
kFilterLinear	= 1;
----------------------------------------------------------------------------------

---------------------------------------Prop---------------------------------------
--for rotate/scale
kNotCenter		= 0;
kCenterDrawing	= 1;
kCenterXY		= 2;
----------------------------------------------------------------------------------

--------------------------------------Align--------------------------------------
kAlignCenter		= 0;
kAlignTop			= 1;
kAlignTopRight		= 2;
kAlignRight			= 3;
kAlignBottomRight	= 4;
kAlignBottom		= 5;
kAlignBottomLeft	= 6;
kAlignLeft			= 7;
kAlignTopLeft		= 8;
---------------------------------------------------------------------------------

---------------------------------------Text---------------------------------------
--TextMulitLines
kTextSingleLine	= 0;
kTextMultiLines = 1;

kDefaultFontName	= ""
kDefaultFontSize 	= 24;

kDefaultTextColorR 	= 0;
kDefaultTextColorG 	= 0;
kDefaultTextColorB 	= 0;

-- 文字样式
	-- 粗体字
kTextTypeBold = 1; 
kTextTypePropBold = "typefacebold";
	-- 斜体
kTextTypeItalic = 1;
kTextTypePropItalic = "typefaceitalic";
    --下划线
kTextTypeLine = 1;
kTextTypeUnderLine = "typeunderline";
	-- 阴影效果
kTextTypePropShadow = "texttypeshadow";
kTextTypeKeyRadius = "textshadowradius";
kTextTypeKeyDx = "textshadowdx";
kTextTypeKeyDy = "textshadowdy";
kTextTypeKeyDr = "textshadowdr";
kTextTypeKeyDg = "textshadowdg";
kTextTypeKeyDb = "textshadowdb";

----------------------------------------------------------------------------------

---------------------------------------Touch--------------------------------------
kFingerDown		= 0;
kFingerMove		= 1;
kFingerUp		= 2;
kFingerCancel	= 3;
----------------------------------------------------------------------------------

---------------------------------------Focus--------------------------------------
kFocusIn 	= 0;
kFocusOut 	= 1;
----------------------------------------------------------------------------------

---------------------------------------Scroll-------------------------------------
kScrollerStatusStart	= 0;
kScrollerStatusMoving	= 1;
kScrollerStatusStop		= 2;
----------------------------------------------------------------------------------

---------------------------------------Socket-------------------------------------
--SocketProtocal
kProtocalVersion 	= 1;
kProtocalSubversion	= 1;
KClientVersionCode 	= 1024;

--SocketStatus
kSocketConnected 		= 1;
kSocketReconnecting		= 2;
kSocketConnectivity		= 3;
kSocketConnectFailed	= 4;
kSocketUserClose		= 5;
kSocketRecvPacket		= 9;

kCloseSocketAsycWithEvent 	= 0;
kCloseSocketAsyc 			= 1;
kCloseSocketSync 			= -1;

--Socket type
kSocketRoom = "room";
kSocketHall	= "hall";
----------------------------------------------------------------------------------

---------------------------------------Http---------------------------------------
--http get/post
kHttpGet		= 0;
kHttpPost		= 1;
kHttpReserved	= 0;
-----------------------------------------------------------------------------------

-------------------------------------Bool values-----------------------------------
kTrue 	= 1;
kFalse 	= 0;
kNone 	= -1;
-----------------------------------------------------------------------------------

-------------------------------------Button----------------------------------------
kButtonUpInside 	= 1;
kButtonUpOutside 	= 2;
kButtonUp 			= 3;

-----------------------------------------------------------------------------------

-------------------------------------Direction-------------------------------------
kHorizontal 	= 1;
kVertical 		= 2;
-----------------------------------------------------------------------------------

---------------------------------------Platform------------------------------------
--ios
kScreen480x320		= "480x320" -- ios/android
kScreen960x640		= "960x640"
kScreen1024x768		= "1024x768"
kScreen2048x1536	= "2048x1536"

--android
kScreen1280x720		= "1280x720"
kScreen1280x800		= "1280x800"
kScreen1024x600		= "1024x600"
kScreen960x540		= "960x540"
kScreen854x480		= "854x480"
kScreen800x480		= "800x480"

--platform
kPlatformIOS 		= "ios";
kPlatformAndroid 	= "android";
kPlatformWp8 		= "wp8";
kPlatformWin32 		= "win32";
-----------------------------------------------------------------------------------

---------------------------------------Custom Render-------------------------------
kRenderPoints 			= 1;
kRenderLineStrip 		= 2;
kRenderLineLoop 		= 3;
kRenderLines 			= 4;
kRenderTriangleStrip 	= 5;
kRenderTriangleFan 		= 6;
kRenderTriangles 		= 7;

kRenderDataDefault 		= 0;
kRenderDataTexture 		= 16;
kRenderDataColors 		= 32;
kRenderDataAll 			= 48;
-----------------------------------------------------------------------------------

---------------------------------------Custom Blend--------------------------------

kBlendSrcZero=0;
kBlendSrcOne=1;
kBlendSrcDstColor=2;
kBlendSrcOneMinusDstColor=3;
kBlendSrcSrcAlpha=4;
kBlendSrcOneMinusSrcAlpha=5;
kBlendSrcDstAlpha=6;
kBlendSrcOneMinusDstAlpha=7;
kBlendSrcSrcAlphaSaturate=8;

kBlendDstZero=0;
kBlendDstOne=1;
kBlendDstSrcColor=2;
kBlendDstOneMinusSrcColor=3;
kBlendDstSrcAlpha=4;
kBlendDstOneMinusSrcAlpha=5;
kBlendDstDstAlpha=6;
kBlendDstOneMinusDstAlpha=7;

----------------------------------------------------------------------------------

----------------------------------Input ------------------------------------------
kEditBoxInputModeAny  		= 0;
kEditBoxInputModeEmailAddr	= 1;
kEditBoxInputModeNumeric	= 2;
kEditBoxInputModePhoneNumber= 3;
kEditBoxInputModeUrl		= 4;
kEditBoxInputModeDecimal	= 5;
kEditBoxInputModeSingleLine	= 6;

kEditBoxInputFlagPassword					= 0;
kEditBoxInputFlagSensitive					= 1;
kEditBoxInputFlagInitialCapsWord			= 2;
kEditBoxInputFlagInitialCapsSentence		= 3;
kEditBoxInputFlagInitialCapsAllCharacters	= 4;


kKeyboardReturnTypeDefault = 0;
kKeyboardReturnTypeDone = 1;
kKeyboardReturnTypeSend = 2;
kKeyboardReturnTypeSearch = 3;
kKeyboardReturnTypeGo = 4;
----------------------------------------------------------------------------------

