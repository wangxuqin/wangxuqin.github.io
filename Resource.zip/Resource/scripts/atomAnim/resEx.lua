require("core/res")
require("libEffect/easing")
local easing = require('libEffect.easing')

--------------------------------------ResDoubleRase---------------------------------------------

---------------------------------------ResDoubleArraySin-----------------------------------------

--SinIn
ResDoubleArraySinIn = class(ResDoubleArray, false);

ResDoubleArraySinIn.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
    local arr = easing.getEaseArray("easeInSine", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArraySinIn.dtor = function(self)
end

ResDoubleArraySinIn.getLength = function(self)
	return self.m_arrayLength;
end 

--SinOut
ResDoubleArraySinOut = class(ResDoubleArray, false);

ResDoubleArraySinOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeOutSine", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArraySinOut.dtor = function(self)
end 

ResDoubleArraySinOut.getLength = function(self)
	return self.m_arrayLength;
end 

--SinInOut
ResDoubleArraySinInOut = class(ResDoubleArray, false);

ResDoubleArraySinInOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeInOutSine", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArraySinInOut.dtor = function(self)
end 

ResDoubleArraySinInOut.getLength = function(self)
	return self.m_arrayLength;
end

---------------------------------------ResDoubleArrayExp-----------------------------------------
--ExpIn
ResDoubleArrayExpIn = class(ResDoubleArray, false);

ResDoubleArrayExpIn.ctor = function(self,duration,startV,endV)
	endV = endV - startV;
    local arr = easing.getEaseArray("easeInExpo", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayExpIn.dtor = function(self)
end 

ResDoubleArrayExpIn.getLength = function(self)
	return self.m_arrayLength;
end 

--ExpOut
ResDoubleArrayExpOut = class(ResDoubleArray, false);

ResDoubleArrayExpOut.ctor = function(self,duration,startV,endV)
	endV = endV - startV;
    local arr = easing.getEaseArray("easeOutExpo", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayExpOut.dtor = function(self)
end 

ResDoubleArrayExpOut.getLength = function(self)
	return self.m_arrayLength;
end 

--ExpInOut
ResDoubleArrayExpInOut = class(ResDoubleArray, false);

ResDoubleArrayExpInOut.ctor = function(self,duration,startV,endV)
	endV = endV - startV;
    local arr = easing.getEaseArray("easeInOutExpo", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayExpInOut.dtor = function(self)
end 

ResDoubleArrayExpInOut.getLength = function(self)
	return self.m_arrayLength;
end 



---------------------------------------ResDoubleArrayElastic---------------------------------------
--ElasticIn
ResDoubleArrayElasticIn = class(ResDoubleArray, false);

ResDoubleArrayElasticIn.ctor = function(self,duration,startV,endV,period)
	endV = endV - startV;
    if period == nil or type(period) ~= "number" then
        period = 0.3;
    end
    
    local arr = easing.getEaseArray("easeInElastic", duration, startV, endV, period);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayElasticIn.dtor = function(self)
end 

ResDoubleArrayElasticIn.getLength = function(self)
	return self.m_arrayLength;
end 

--ElasticOut
ResDoubleArrayElasticOut = class(ResDoubleArray, false);

ResDoubleArrayElasticOut.ctor = function(self,duration,startV,endV,period)
	endV = endV - startV;
    if period == nil or type(period) ~= "number" then
        period = 0.3;
    end
    local arr = easing.getEaseArray("easeOutElastic", duration, startV, endV, period);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayElasticOut.dtor = function(self)
end 

ResDoubleArrayElasticOut.getLength = function(self)
	return self.m_arrayLength;
end 

--ElasticInOut
ResDoubleArrayElasticInOut = class(ResDoubleArray, false);

ResDoubleArrayElasticInOut.ctor = function(self,duration,startV,endV,period)
	endV = endV - startV;
    if period == nil or type(period) ~= "number" then
        period = 0.3;
    end
    local arr = easing.getEaseArray("easeInOutElastic", duration, startV, endV, period);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayElasticInOut.dtor = function(self)
end 

ResDoubleArrayElasticInOut.getLength = function(self)
	return self.m_arrayLength;
end 


-----------------------------------------ResDoubleArrayBounce-----------------------------
--BounceIn
ResDoubleArrayBounceIn = class(ResDoubleArray, false)

ResDoubleArrayBounceIn.ctor = function(self,duration,startV,endV)
	endV = endV - startV;
    local arr = easing.getEaseArray("easeInBounce", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayBounceIn.dtor = function(self)
end 

ResDoubleArrayBounceIn.getLength = function(self)
	return self.m_arrayLength;
end 

--BounceOut
ResDoubleArrayBounceOut = class(ResDoubleArray, false)

ResDoubleArrayBounceOut.ctor = function(self,duration,startV,endV)
	endV = endV - startV;
    local arr = easing.getEaseArray("easeOutBounce", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayBounceOut.dtor = function(self)
end 

ResDoubleArrayBounceOut.getLength = function(self)
	return self.m_arrayLength;
end


--BounceInOut
ResDoubleArrayBounceInOut = class(ResDoubleArray, false)

ResDoubleArrayBounceInOut.ctor = function(self,duration,startV,endV)
	endV = endV - startV;
    local arr = easing.getEaseArray("easeInOutBounce", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayBounceInOut.dtor = function(self)
end

ResDoubleArrayBounceInOut.getLength = function(self)
	return self.m_arrayLength;
end 

------------------------------------------ResDoubleArrayBack------------------------------------
--BackIn
ResDoubleArrayBackIn = class(ResDoubleArray, false)

ResDoubleArrayBackIn.ctor = function(self,duration,startV,endV)
	endV = endV - startV;
    local arr = easing.getEaseArray("easeInBack", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayBackIn.dtor = function(self)
end 

ResDoubleArrayBackIn.getLength = function(self)
	return self.m_arrayLength;
end 

--BackOut
ResDoubleArrayBackOut = class(ResDoubleArray, false)

ResDoubleArrayBackOut.ctor = function(self,duration,startV,endV)
	endV = endV - startV;
    local arr = easing.getEaseArray("easeOutBack", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayBackOut.dtor = function(self)
end 

ResDoubleArrayBackOut.getLength = function(self)
	return self.m_arrayLength;
end 

--backInOut
ResDoubleArrayBackInOut = class(ResDoubleArray, false)

ResDoubleArrayBackInOut.ctor = function(self,duration,startV,endV)
	endV = endV - startV;
    local arr = easing.getEaseArray("easeInOutBack", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayBackInOut.dtor = function(self)
end 

ResDoubleArrayBackInOut.getLength = function(self)
	return self.m_arrayLength;
end 

---------------------------------------ResDoubleArrayQuad-----------------------------------------

--QuadIn
ResDoubleArrayQuadIn = class(ResDoubleArray, false);

ResDoubleArrayQuadIn.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
    local arr = easing.getEaseArray("easeInQuad", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayQuadIn.dtor = function(self)
end

ResDoubleArrayQuadIn.getLength = function(self)
	return self.m_arrayLength;
end 

--QuadOut
ResDoubleArrayQuadOut = class(ResDoubleArray, false);

ResDoubleArrayQuadOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeOutQuad", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayQuadOut.dtor = function(self)
end 

ResDoubleArrayQuadOut.getLength = function(self)
	return self.m_arrayLength;
end 

--QuadInOut
ResDoubleArrayQuadInOut = class(ResDoubleArray, false);

ResDoubleArrayQuadInOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeInOutQuad", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayQuadInOut.dtor = function(self)
end 

ResDoubleArrayQuadInOut.getLength = function(self)
	return self.m_arrayLength;
end

---------------------------------------ResDoubleArrayCubic-----------------------------------------

--CubicIn
ResDoubleArrayCubicIn = class(ResDoubleArray, false);

ResDoubleArrayCubicIn.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
    local arr = easing.getEaseArray("easeInCubic", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayCubicIn.dtor = function(self)
end

ResDoubleArrayCubicIn.getLength = function(self)
	return self.m_arrayLength;
end 

--CubicOut
ResDoubleArrayCubicOut = class(ResDoubleArray, false);

ResDoubleArrayCubicOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeOutCubic", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayCubicOut.dtor = function(self)
end 

ResDoubleArrayCubicOut.getLength = function(self)
	return self.m_arrayLength;
end 

--CubicInOut
ResDoubleArrayCubicInOut = class(ResDoubleArray, false);

ResDoubleArrayCubicInOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeInOutCubic", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayCubicInOut.dtor = function(self)
end 

ResDoubleArrayCubicInOut.getLength = function(self)
	return self.m_arrayLength;
end
---------------------------------------ResDoubleArrayQuart-----------------------------------------

--QuartIn
ResDoubleArrayQuartIn = class(ResDoubleArray, false);

ResDoubleArrayQuartIn.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
    local arr = easing.getEaseArray("easeInQuart", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayQuartIn.dtor = function(self)
end

ResDoubleArrayQuartIn.getLength = function(self)
	return self.m_arrayLength;
end

--QuartOut
ResDoubleArrayQuartOut = class(ResDoubleArray, false);

ResDoubleArrayQuartOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeOutQuart", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayQuartOut.dtor = function(self)
end 

ResDoubleArrayQuartOut.getLength = function(self)
	return self.m_arrayLength;
end 

--QuartInOut
ResDoubleArrayQuartInOut = class(ResDoubleArray, false);

ResDoubleArrayQuartInOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeInOutQuart", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayQuartInOut.dtor = function(self)
end 

ResDoubleArrayQuartInOut.getLength = function(self)
	return self.m_arrayLength;
end 

---------------------------------------ResDoubleArrayQuint-----------------------------------------

--QuintIn
ResDoubleArrayQuintIn = class(ResDoubleArray, false);

ResDoubleArrayQuintIn.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
    local arr = easing.getEaseArray("easeInQuint", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayQuintIn.dtor = function(self)
end

ResDoubleArrayQuintIn.getLength = function(self)
	return self.m_arrayLength;
end 

--QuintOut
ResDoubleArrayQuintOut = class(ResDoubleArray, false);

ResDoubleArrayQuintOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeOutQuint", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayQuintOut.dtor = function(self)
end 

ResDoubleArrayQuintOut.getLength = function(self)
	return self.m_arrayLength;
end 

--QuintInOut
ResDoubleArrayQuintInOut = class(ResDoubleArray, false);

ResDoubleArrayQuintInOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeInOutQuint", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayQuintInOut.dtor = function(self)
end 

ResDoubleArrayQuintInOut.getLength = function(self)
	return self.m_arrayLength;
end 

---------------------------------------ResDoubleArrayCirc-----------------------------------------

--CircIn
ResDoubleArrayCircIn = class(ResDoubleArray, false);

ResDoubleArrayCircIn.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
    local arr = easing.getEaseArray("easeInCirc", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayCircIn.dtor = function(self)
end

ResDoubleArrayCircIn.getLength = function(self)
	return self.m_arrayLength;
end

--CircOut
ResDoubleArrayCircOut = class(ResDoubleArray, false);

ResDoubleArrayCircOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeOutCirc", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end 

ResDoubleArrayCircOut.dtor = function(self)
end 

ResDoubleArrayCircOut.getLength = function(self)
	return self.m_arrayLength;
end 

--CircInOut
ResDoubleArrayCircInOut = class(ResDoubleArray, false);

ResDoubleArrayCircInOut.ctor = function(self,duration,startV,endV)
    endV = endV - startV;
	local arr = easing.getEaseArray("easeInOutCirc", duration, startV, endV);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayCircInOut.dtor = function(self)
end

ResDoubleArrayCircInOut.getLength = function(self)
	return self.m_arrayLength;
end 

------------------------------------------ResDoubleExtra----------------------------------------

ResDoubleArrayCurve = class(ResBase)

ResDoubleArrayCurve.ctor = function(self,duration,startV,endV,control)
	self.m_arrayLength = math.floor(60 * duration / 1000);
	res_create_double_array_curve(0,self.m_resID,self.m_arrayLength,startV,endV,control);
end 

ResDoubleArrayCurve.getLength = function(self)
	return self.m_arrayLength;
end 

ResDoubleArrayCurve.dtor = function(self)
	res_delete(self.m_resID);
end

ResDoubleArrayEllipseX = class(ResBase);

ResDoubleArrayEllipseX.ctor = function(self,duration,centerX,axisX,startAngle,endAngle)
	self.m_arrayLength = math.floor(60 * duration / 1000);
	res_create_double_array_ellipseX(0,self.m_resID,self.m_arrayLength,centerX,axisX,startAngle,endAngle);
end 

ResDoubleArrayEllipseX.getLength = function(self)
	return self.m_arrayLength;
end 

ResDoubleArrayEllipseX.dtor = function(self)
	res_delete(self.m_resID);
end 

ResDoubleArrayEllipseY = class(ResBase);

ResDoubleArrayEllipseY.ctor = function(self,duration,centerY,axisY,startAngle,endAngle)
	self.m_arrayLength = math.floor(60 * duration / 1000);
	res_create_double_array_ellipseY(0,self.m_resID,self.m_arrayLength,centerY,axisY,startAngle,endAngle);
end 

ResDoubleArrayEllipseY.getLength = function(self)
	return self.m_arrayLength;
end 

ResDoubleArrayEllipseY.dtor = function(self)
	res_delete(self.m_resID);
end 

ResDoubleArrayJumpX = class(ResBase);

ResDoubleArrayJumpX.ctor = function(self,duration,startX,endX,times,height)
	self.m_arrayLength = math.floor(60 * duration / 1000);
	res_create_double_array_jumpX(0,self.m_resID,self.m_arrayLength,startX,endX, times, height);
end 

ResDoubleArrayJumpX.getLength = function(self)
	return self.m_arrayLength;
end 

ResDoubleArrayJumpX.dtor = function(self)
	res_delete(self.m_resID);
end 

ResDoubleArrayJumpY = class(ResBase);

ResDoubleArrayJumpY.ctor = function(self,duration,startY,endY,times,height)
	self.m_arrayLength = math.floor(60 * duration / 1000);
	res_create_double_array_jumpY(0,self.m_resID,self.m_arrayLength,startY,endY,times,height);
end 

ResDoubleArrayJumpY.getLength = function(self)
	return self.m_arrayLength;
end 

ResDoubleArrayJumpY.dtor = function(self)
	res_delete(self.m_resID);
end 


--[Comment]
--����������
ResDoubleArrayBezier = class(ResDoubleArray, false);
ResDoubleArrayBezier.ctor  = function(self, duration, allPoints, ease)
    ease = ease or "";
    local easeType = EaseNameMap[ease] or "linear";
    local easeArr = easing.getEaseArray(easeType, duration, 0, 1);
    local arr   = self:__createBezier(allPoints, easeArr);
    self.m_arrayLength = #arr;
    super(self, arr);
end

ResDoubleArrayBezier.dtor = function(self)
	res_delete(self.m_resID);
end 

ResDoubleArrayBezier.getLength = function(self)
	return self.m_arrayLength;
end 

ResDoubleArrayBezier.__createBezier = function(self, allPoints, easeArr)
    local ret = {};
    for i = 1, #easeArr do
        local value = self:__bezier(allPoints, easeArr[i]);
        table.insert(ret, value);
    end
    return ret;
end

ResDoubleArrayBezier.__bezier = function(self, allPoints, t)
	local n = #allPoints - 1;
    local ret = 0;
    for i=0,n do
		local C = MathKit.combine(n, i);
		local A = math.pow(1-t, n-i) * math.pow(t, i);
		ret = ret + allPoints[i+1] * C * A;
	end
	return ret;
end

--------------------------EaseType����---------------------
--[Comment]
--��������
EaseType = {};

EaseType.Nil              = "Nil";
EaseType.SinIn            = "SinIn";
EaseType.SinOut           = "SinOut";
EaseType.SinInOut         = "SinInOut";
EaseType.ExpIn            = "ExpIn";
EaseType.ExpOut           = "ExpOut";
EaseType.ExpInOut         = "ExpInOut";
EaseType.ElasticIn        = "ElasticIn";
EaseType.ElasticOut       = "ElasticOut";
EaseType.ElasticInOut     = "ElasticInOut";
EaseType.BounceIn         = "BounceIn";
EaseType.BounceOut        = "BounceOut";
EaseType.BounceInOut      = "BounceInOut";
EaseType.BackIn           = "BackIn";
EaseType.BackOut          = "BackOut";
EaseType.BackInOut        = "BackInOut";
EaseType.CircIn           = "CircIn";
EaseType.CircOut          = "CircOut";
EaseType.CircInOut        = "CircInOut";
EaseType.CubicIn          = "CubicIn";
EaseType.CubicOut         = "CubicOut";
EaseType.CubicInOut       = "CubicInOut";
EaseType.QuadIn           = "QuadIn";
EaseType.QuadOut          = "QuadOut";
EaseType.QuadInOut        = "QuadInOut";
EaseType.QuartIn          = "QuartIn";
EaseType.QuartOut         = "QuartOut";
EaseType.QuartInOut       = "QuartInOut";
EaseType.QuintIn          = "QuintIn";
EaseType.QuintOut         = "QuintOut";
EaseType.QuintInOut       = "QuintInOut";


EaseTypeMap = {};
EaseTypeMap[EaseType.Nil]                  = nil;
EaseTypeMap[EaseType.SinIn]                = ResDoubleArraySinIn;
EaseTypeMap[EaseType.SinOut]               = ResDoubleArraySinOut;
EaseTypeMap[EaseType.SinInOut]             = ResDoubleArraySinInOut;
EaseTypeMap[EaseType.ExpIn]                = ResDoubleArrayExpIn;
EaseTypeMap[EaseType.ExpOut]               = ResDoubleArrayExpOut;
EaseTypeMap[EaseType.ExpInOut]             = ResDoubleArrayExpInOut;
EaseTypeMap[EaseType.ElasticIn]            = ResDoubleArrayElasticIn;
EaseTypeMap[EaseType.ElasticOut]           = ResDoubleArrayElasticOut;
EaseTypeMap[EaseType.ElasticInOut]         = ResDoubleArrayElasticInOut;
EaseTypeMap[EaseType.BounceIn]             = ResDoubleArrayBounceIn;
EaseTypeMap[EaseType.BounceOut]            = ResDoubleArrayBounceOut;
EaseTypeMap[EaseType.BounceInOut]          = ResDoubleArrayBounceInOut;
EaseTypeMap[EaseType.BackIn]               = ResDoubleArrayBackIn;
EaseTypeMap[EaseType.BackOut]              = ResDoubleArrayBackOut;
EaseTypeMap[EaseType.BackInOut]            = ResDoubleArrayBackInOut;
EaseTypeMap[EaseType.CircIn]               = ResDoubleArrayCircIn;
EaseTypeMap[EaseType.CircOut]              = ResDoubleArrayCircOut;
EaseTypeMap[EaseType.CircInOut]            = ResDoubleArrayCircInOut;
EaseTypeMap[EaseType.CubicIn]              = ResDoubleArrayCubicIn;
EaseTypeMap[EaseType.CubicOut]             = ResDoubleArrayCubicOut;
EaseTypeMap[EaseType.CubicInOut]           = ResDoubleArrayCubicInOut;
EaseTypeMap[EaseType.QuadIn]               = ResDoubleArrayQuadIn;
EaseTypeMap[EaseType.QuadOut]              = ResDoubleArrayQuadOut;
EaseTypeMap[EaseType.QuadInOut]            = ResDoubleArrayQuadInOut;
EaseTypeMap[EaseType.QuartIn]              = ResDoubleArrayQuartIn;
EaseTypeMap[EaseType.QuartOut]             = ResDoubleArrayQuartOut;
EaseTypeMap[EaseType.QuartInOut]           = ResDoubleArrayQuartInOut;
EaseTypeMap[EaseType.QuintIn]              = ResDoubleArrayQuintIn;
EaseTypeMap[EaseType.QuintOut]             = ResDoubleArrayQuintOut;
EaseTypeMap[EaseType.QuintInOut]           = ResDoubleArrayQuintInOut;


EaseNameMap = {};
EaseNameMap[EaseType.Nil]                  = "linear";
EaseNameMap[EaseType.SinIn]                = "easeInSine";
EaseNameMap[EaseType.SinOut]               = "easeOutSine";
EaseNameMap[EaseType.SinInOut]             = "easeInOutSine";
EaseNameMap[EaseType.ExpIn]                = "easeInExpo";
EaseNameMap[EaseType.ExpOut]               = "easeOutExpo";
EaseNameMap[EaseType.ExpInOut]             = "easeInOutExpo";
EaseNameMap[EaseType.ElasticIn]            = "easeInElastic";
EaseNameMap[EaseType.ElasticOut]           = "easeOutElastic";
EaseNameMap[EaseType.ElasticInOut]         = "easeInOutElastic";
EaseNameMap[EaseType.BounceIn]             = "easeInBounce";
EaseNameMap[EaseType.BounceOut]            = "easeOutBounce";
EaseNameMap[EaseType.BounceInOut]          = "easeInOutBounce";
EaseNameMap[EaseType.BackIn]               = "easeInBack";
EaseNameMap[EaseType.BackOut]              = "easeOutBack";
EaseNameMap[EaseType.BackInOut]            = "easeInOutBack";
EaseNameMap[EaseType.CircIn]               = "easeInCirc";
EaseNameMap[EaseType.CircOut]              = "easeOutCirc";
EaseNameMap[EaseType.CircInOut]            = "easeInOutCirc";
EaseNameMap[EaseType.CubicIn]              = "easeInCubic";
EaseNameMap[EaseType.CubicOut]             = "easeOutCubic";
EaseNameMap[EaseType.CubicInOut]           = "easeInOutCubic";
EaseNameMap[EaseType.QuadIn]               = "easeInQuad";
EaseNameMap[EaseType.QuadOut]              = "easeOutQuad";
EaseNameMap[EaseType.QuadInOut]            = "easeInOutQuad";
EaseNameMap[EaseType.QuartIn]              = "easeInQuart";
EaseNameMap[EaseType.QuartOut]             = "easeOutQuart";
EaseNameMap[EaseType.QuartInOut]           = "easeInOutQuart";
EaseNameMap[EaseType.QuintIn]              = "easeInQuint";
EaseNameMap[EaseType.QuintOut]             = "easeOutQuint";
EaseNameMap[EaseType.QuintInOut]           = "easeInOutQuint";