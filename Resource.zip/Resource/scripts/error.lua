require("core/object");
require("core/dict");
require("core/stateMachine");
require("core/sound");
require("core/gameString");
require("config");

function event_load ( width, height )
	print_string("------发生Lua错误------");
	
	socket_close("room",-1);
	
	--删除全部4类对象
	res_delete_group(-1);
	anim_delete_group(-1);
	prop_delete_group(-1);
	drawing_delete_all();
	
	--关闭音乐
	Sound.pauseMusic();
	
	local dictIdentity = new(Dict, "errorIdentity");
	dictIdentity:load();
	dictIdentity:setBoolean("errored", true);
	dictIdentity:save();
	to_lua("main.lua");
end

function event_touch_raw ( finger_action, x, y, drawing_id)	  
 
end

function event_anim ( anim_type, anim_id, repeat_or_loop_num )
end

function event_pause()
end

function event_resume()
end

function event_backpressed()    
end

function dtor()
	-- delete(errorScene);
end