local PROGRAM_DATA_TYPE_ATTRIB = 1;
local PROGRAM_DATA_TYPE_UNIFORM = 2;
local PROGRAM_DATA_TYPE_TEXTURE = 3;
local PROGRAM_DATA_TYPE_INDEX = 4;

local function createEdgeDetection ()

    program_create("edgeDetection");

    local vsEdgeDetection = [=[
        uniform   mat4 u_mvp_matrix;
        attribute vec3 a_position;
        attribute vec2 a_tex_coord;
        varying   vec2 vtexcoord;
        varying   vec2 tcOffset[9];

        void main()
        {
            gl_Position = u_mvp_matrix * vec4(a_position, 1.0);

            vtexcoord = a_tex_coord ;
            float width = 340.0;
            float height = 142.0;
            float dis = 1.0;
            tcOffset[0] = vtexcoord + vec2( 0.0,          dis/height);
            tcOffset[1] = vtexcoord + vec2( 0.0,         -dis/height);
            tcOffset[2] = vtexcoord + vec2( dis/width,   0.0);
            tcOffset[3] = vtexcoord + vec2(-dis/width,   0.0);
            tcOffset[4] = vtexcoord + vec2( 0.0,          0.0);
            tcOffset[5] = vtexcoord + vec2( dis/width,   dis/height);
            tcOffset[6] = vtexcoord + vec2( dis/width,  -dis/height);
            tcOffset[7] = vtexcoord + vec2(-dis/width,   dis/height);
            tcOffset[8] = vtexcoord + vec2(-dis/width,  -dis/height);
        }
    ]=];

    local fsEdgeDetection = [=[
        precision mediump float;
        uniform sampler2D texture0;
        uniform vec4 u_color;
        uniform float time; 
        varying vec2 vtexcoord;
        varying vec2 tcOffset[9];

        void main()
        {   
            vec2 p = 2.0 * vtexcoord - 1.0;
            float tau = 3.1415926535*2.0;
            float a = atan(p.x,p.y);
            float r = length(p)*0.75;
            vec2 uv = vec2(a/tau,r);

            float xCol = (uv.x - (time / 3.0)) * 3.0;
            xCol = mod(xCol, 3.0);
            vec3 horColour = vec3(1.0,1.0,1.0);

            if (xCol < 1.0) {
	            horColour.r += 1.0 - xCol;
	            horColour.g += xCol;
            } else if (xCol < 2.0) {
	            xCol -= 1.0;
	            horColour.g += 1.0 - xCol;
	            horColour.b += xCol;
            } else {
	            xCol -= 2.0;
	            horColour.b += 1.0 - xCol;
	            horColour.r += xCol;
            }

            vec4 sampler[9];
            for (int i = 0; i < 9; ++i)
            {
                sampler[i] = texture2D(texture0, tcOffset[i]);
            }
            vec4 color = texture2D(texture0, vtexcoord);        
            //gl_FragColor = color * u_color;

            /*gl_FragColor = color*cos(time)+
                           ((16.0 * sampler[4]) - (sampler[0] + sampler[1] + sampler[2]
                        + sampler[3] + sampler[5] + sampler[6] + sampler[7] + sampler[8]))*sin(time)*vec4(horColour,1.0);*/

            vec4 edgeColor = (8.0 * sampler[4]) - (sampler[0] + sampler[1] + sampler[2]
            + sampler[3] + sampler[5] + sampler[6] + sampler[7] + sampler[8]);

            float gray = dot(edgeColor.rgb, vec3(0.299, 0.587, 0.114));

            gl_FragColor = vec4(gray,gray,gray,1.0);
        }
    ]=];

    program_set_shader_source("edgeDetection", vsEdgeDetection, fsEdgeDetection);

    program_add_parameter("edgeDetection", PROGRAM_DATA_TYPE_UNIFORM, 44, "u_mvp_matrix");
    program_add_parameter("edgeDetection", PROGRAM_DATA_TYPE_ATTRIB, 3, "a_position");
    program_add_parameter("edgeDetection", PROGRAM_DATA_TYPE_TEXTURE, 0, "texture0");
    program_add_parameter("edgeDetection", PROGRAM_DATA_TYPE_ATTRIB, 2, "a_tex_coord");
    program_add_parameter("edgeDetection", PROGRAM_DATA_TYPE_UNIFORM, 4, "u_color");
    program_add_parameter("edgeDetection", PROGRAM_DATA_TYPE_INDEX, 2, "index");
    program_add_parameter("edgeDetection", PROGRAM_DATA_TYPE_UNIFORM, 1, "time");
end

local function createBlink ()

    program_create("blinkShader");

    local vsBlink = [=[
        uniform   mat4 u_mvp_matrix;
        attribute vec3 a_position;
        attribute vec2 a_tex_coord;
        varying   vec2 vtexcoord;

        void main()
        {
            gl_Position = u_mvp_matrix * vec4(a_position, 1.0);
            vtexcoord = a_tex_coord ;
        }
    ]=];

    local fsBlink = [=[
        precision mediump float;
        uniform sampler2D texture0;
        uniform vec4 u_color;  
        uniform float time;
        varying vec2 vtexcoord;

        float ball (vec3 ballPos, float ratio, float coordX, float coordY)
        {
            vec3 ballColor = vec3(ballPos.x+time, ballPos.y * ratio, ballPos.z);
            float sum = ballColor.z/distance(ballColor.xy,vec2(coordX,coordY));      
            return sum;
        }

        void main()
        {     
            float ratio =  142.0/340.0;
	        float divider = float(1.0 / 340.0 * 10.0) + 1.0;
	        float intensity = float(100.0 / 142.0 * 10.0) + 1.0;

	        float coordX = vtexcoord.x;
	        float coordY = vtexcoord.y * 142.0/340.0;
	
	        float sum = 0.0;
	        sum = ball(vec3(0.0,0.1,0.2), ratio, coordX, coordY);
            sum = pow(sum / intensity, divider);

	        vec4 colorBack = texture2D(texture0, vtexcoord);
	        gl_FragColor = vec4((vec3(sum * 1.0, sum * 1.0, sum * 1.0)+colorBack.xyz*0.1) ,sum);                    
        }
    ]=];

    program_set_shader_source("blinkShader", vsBlink, fsBlink);

    program_add_parameter("blinkShader", PROGRAM_DATA_TYPE_UNIFORM, 44, "u_mvp_matrix");
    program_add_parameter("blinkShader", PROGRAM_DATA_TYPE_ATTRIB, 3, "a_position");
    program_add_parameter("blinkShader", PROGRAM_DATA_TYPE_TEXTURE, 0, "texture0");
    program_add_parameter("blinkShader", PROGRAM_DATA_TYPE_ATTRIB, 2, "a_tex_coord");
    program_add_parameter("blinkShader", PROGRAM_DATA_TYPE_UNIFORM, 4, "u_color");
    program_add_parameter("blinkShader", PROGRAM_DATA_TYPE_INDEX, 2, "index");
    program_add_parameter("blinkShader", PROGRAM_DATA_TYPE_UNIFORM, 1, "time");
end


local function createNormalMap ()

    program_create("normalMap");

    local vsNormalMap = [=[
        uniform   mat4 u_mvp_matrix;
        attribute vec3 a_position;
        attribute vec2 a_tex_coord;
        varying   vec2 vtexcoord;

        void main()
        {
            gl_Position = u_mvp_matrix * vec4(a_position, 1.0);
            vtexcoord = a_tex_coord ;
        }
    ]=];

    local fsNormalMap = [=[
        precision mediump float;
        uniform sampler2D texture0;
        uniform vec4 u_color;  
        uniform float time;
        varying vec2 vtexcoord;

        vec3 sample(float x, float y,vec2 fragCoord)
        {
	        vec2 uv = fragCoord * vec2(340.0, 142.0);
	        uv = (uv + vec2(x, y))/ vec2(340.0, 142.0);
	        return texture2D(texture0, uv).xyz;
        }

        float luminance(vec3 c)
        {
	        return dot(c, vec3(0.2126, 0.7152, 0.0722));
        }

        vec3 normal(vec2 fragCoord)
        {   
	        float R = abs(luminance(sample( 1.0,0.0,fragCoord)));
	        float L = abs(luminance(sample(-1.0,0.0,fragCoord)));
	        float D = abs(luminance(sample(0.0, 1.0,fragCoord)));
	        float U = abs(luminance(sample(0.0,-1.0,fragCoord)));
				 
	        float X = (L-R) * 0.5;
	        float Y = (U-D) * 0.5;

	        return normalize(vec3(X, Y, 1.0 / 2.0));
        }


        void main()
        {   

            
            vec3 normalColor = normal(vec2(vtexcoord.x, vtexcoord.y));


            vec3 ep = vec3(320.0 * 0.5, 142.0 * 0.5, 500.0);
	        vec3 lp = vec3((vec2(0.0, 0.5) + vec2(time, 0.0)) * vec2(340.0, 142.0), 200.0);
	        vec3 sp = vec3(vtexcoord * vec2(340.0, 142.0), 0.0);
	        float e = 64.0;
	
	        vec3 c = sample(0.0, 0.0, vtexcoord) * dot(normalColor, normalize(lp - sp));

            c = c+ pow(clamp(dot(normalize(reflect(lp - sp, normalColor)), normalize(sp - ep)), 0.0, 1.0), e);

            vec4 color = texture2D(texture0, vtexcoord);           
            gl_FragColor = vec4(c,color.a) + color*0.5 * u_color;
        }
    ]=];

    program_set_shader_source("normalMap", vsNormalMap, fsNormalMap);

    program_add_parameter("normalMap", PROGRAM_DATA_TYPE_UNIFORM, 44, "u_mvp_matrix");
    program_add_parameter("normalMap", PROGRAM_DATA_TYPE_ATTRIB, 3, "a_position");
    program_add_parameter("normalMap", PROGRAM_DATA_TYPE_TEXTURE, 0, "texture0");
    program_add_parameter("normalMap", PROGRAM_DATA_TYPE_ATTRIB, 2, "a_tex_coord");
    program_add_parameter("normalMap", PROGRAM_DATA_TYPE_UNIFORM, 4, "u_color");
    program_add_parameter("normalMap", PROGRAM_DATA_TYPE_INDEX, 2, "index");
    program_add_parameter("normalMap", PROGRAM_DATA_TYPE_UNIFORM, 1, "time");
end

local function createChipMaskShader()
    program_create("chipMaskShader");

    local vsChipMask=[=[
        uniform   mat4 u_mvp_matrix;
        attribute vec3 a_position;
        attribute vec2 a_tex_coord;
        varying vec2 vtexcoord;

        void main()
        {
            gl_Position = u_mvp_matrix * vec4(a_position,1.0);
            vtexcoord = a_tex_coord ;
        }
    ]=];

    local fsChipMask=[=[
        precision mediump float;
        uniform sampler2D texture0;
        uniform sampler2D texture1;
        uniform sampler2D texture2;
        uniform vec4 u_color;
        uniform float time;
        uniform vec3 direction;
        uniform vec4 color;
        varying vec2 vtexcoord;

        void main()
        {   
            
            /* vec4 k = texture2D(texture0, vtexcoord);
            vec2 blinkUv = (vtexcoord - vec2(time,time)) * 2.0;
           
            mat2 rotMat;
        
            rotMat[0][0] = 0.866; 
            rotMat[0][1] = 0.5;
            rotMat[1][0] = -0.5;
            rotMat[1][1] = 0.866;

            blinkUv = rotMat * blinkUv;
            
            float rgba = mix(1.0, 0.0, abs(blinkUv.y));
            rgba = clamp(rgba,0.0,1.0);
            k +=  vec4(rgba, rgba, rgba, 1.0);*/



                               
            vec3 dir = normalize(vec3(-direction.x,-direction.y,0.0));
            dir = dir * 1.7 ;
                      
            vec2 flashUV = ((vtexcoord)*2.0-1.0) * 0.5;
          
            flashUV = flashUV + dir.xy * time;
            vec4 colorSampler = texture2D(texture1,(flashUV*0.5+0.5));
            vec4 colorBack = texture2D(texture0,vtexcoord);
            vec4 colorBack2 = texture2D(texture2,vtexcoord);
            colorBack2 = vec4(colorBack2.x*colorSampler.a*colorBack2.a, colorBack2.y*colorSampler.a*colorBack2.a, colorBack2.z*colorSampler.a*colorBack2.a, colorSampler.a)* 2.0;
            gl_FragColor = vec4((colorBack.xyz+colorBack2.xyz)*u_color*colorBack.a, colorBack.a);
            //gl_FragColor = k;
        }
    ]=];

    program_set_shader_source("chipMaskShader", vsChipMask, fsChipMask );
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_UNIFORM, 44,"u_mvp_matrix");
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_ATTRIB, 3,"a_position");
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_TEXTURE, 0,"texture0");
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_TEXTURE, 0,"texture1");
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_TEXTURE, 0,"texture2");
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_ATTRIB, 2,"a_tex_coord");
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_UNIFORM, 4,"u_color");
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_INDEX, 2,"index");
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_UNIFORM, 1,"time");
    program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_UNIFORM, 3,"direction");
    --program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_UNIFORM, 4,"color");
    --program_add_parameter("chipMaskShader", PROGRAM_DATA_TYPE_UNIFORM, 2,"pos");
end

local function createQuaterMaskShader()

    program_create("quaterMask");

    local vsQuaterMask = [=[
        uniform   mat4 u_mvp_matrix;
        attribute vec3 a_position;
        attribute vec2 a_tex_coord;
        varying   vec2 vtexcoord;

        void main()
        {
            gl_Position = u_mvp_matrix * vec4(a_position, 1.0);
            vtexcoord = a_tex_coord ;
        }
    ]=];

    local fsQuaterMask = [=[
        precision mediump float;
        uniform sampler2D texture0;      
        uniform vec4 u_color;
        varying vec2 vtexcoord;
        uniform float time;
        uniform float maskType;
        uniform float posX;
        uniform float posY;
        uniform float colorTimer;

        void main()
        {   
            vec4 colorbg = texture2D(texture0, vec2(vtexcoord.x,vtexcoord.y)); 
            vec2 uv = vtexcoord * 2.0 - 1.0;
            uv += vec2(posX,posY);
            float angle  = 6.284*(-sin(time)+0.5); 
   
            float color = -maskType * sign(angle - atan(uv.x, uv.y));

            //gl_FragColor = vec4(0.0,color * colorbg.a,0.0,color * colorbg.a) * u_color;
            gl_FragColor = vec4(color*abs(sin(colorTimer))* colorbg.a,color*abs(cos(colorTimer))* colorbg.a,0.0,color * colorbg.a) * u_color;
        }
    ]=];

    program_set_shader_source("quaterMask", vsQuaterMask, fsQuaterMask);

    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_UNIFORM, 44, "u_mvp_matrix");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_ATTRIB, 3, "a_position");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_TEXTURE, 0, "texture0");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_ATTRIB, 2, "a_tex_coord");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_UNIFORM, 4, "u_color");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_INDEX, 2, "index");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "time");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "maskType");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "posX");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "posY");
    program_add_parameter("quaterMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "colorTimer");
end


local function createHorizontalMaskShader()

    program_create("horizontalMask");

    local vsHorizontalMask = [=[
        uniform   mat4 u_mvp_matrix;
        attribute vec3 a_position;
        attribute vec2 a_tex_coord;
        varying   vec2 vtexcoord;

        void main()
        {
            gl_Position = u_mvp_matrix * vec4(a_position, 1.0);
            vtexcoord = a_tex_coord ;
        }
    ]=];

    local fsHorizontalMask = [=[
        precision mediump float;
        uniform sampler2D texture0;      
        uniform vec4 u_color;
        varying vec2 vtexcoord;
        uniform float time;
        uniform float maskType;
        uniform float dirValue1;
        uniform float dirValue2;
        uniform float colorTimer;

        void main()
        {                                   	          
            vec4 colorbg = texture2D(texture0, vtexcoord); 
            float color =  maskType * sign(time + dirValue1 * vtexcoord.x + dirValue2);
	        //gl_FragColor = vec4(0.0,color * colorbg.a,0.0,color * colorbg.a) * u_color;
            gl_FragColor = vec4(color*abs(sin(colorTimer))* colorbg.a,color*abs(cos(colorTimer))* colorbg.a,0.0,color * colorbg.a) * u_color;
        }
    ]=];

    program_set_shader_source("horizontalMask", vsHorizontalMask, fsHorizontalMask);

    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_UNIFORM, 44, "u_mvp_matrix");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_ATTRIB, 3, "a_position");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_TEXTURE, 0, "texture0");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_ATTRIB, 2, "a_tex_coord");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_UNIFORM, 4, "u_color");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_INDEX, 2, "index");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "time");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "maskType");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "dirValue1");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "dirValue2");
    program_add_parameter("horizontalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "colorTimer");
end

local function createVerticalMaskShader()

    program_create("verticalMask");

    local vsVerticalMask = [=[
        uniform   mat4 u_mvp_matrix;
        attribute vec3 a_position;
        attribute vec2 a_tex_coord;
        varying   vec2 vtexcoord;

        void main()
        {
            gl_Position = u_mvp_matrix * vec4(a_position, 1.0);
            vtexcoord = a_tex_coord ;
        }
    ]=];

    local fsVerticalMask = [=[
        precision mediump float;
        uniform sampler2D texture0;      
        uniform vec4 u_color;
        varying vec2 vtexcoord;
        uniform float time;
        uniform float maskType;
        uniform float dirValue1;
        uniform float dirValue2;
        uniform float colorTimer;

        void main()
        {                                   	          
            vec4 colorbg = texture2D(texture0, vtexcoord); 
            float color =  maskType * sign(time + dirValue1 * vtexcoord.y + dirValue2);
	        //gl_FragColor = vec4(0.0,color * colorbg.a,0.0,color * colorbg.a) * u_color;
            gl_FragColor = vec4(color*abs(sin(colorTimer))* colorbg.a,color*abs(cos(colorTimer))* colorbg.a,0.0,color * colorbg.a) * u_color;
        }
    ]=];

    program_set_shader_source("verticalMask", vsVerticalMask, fsVerticalMask);

    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_UNIFORM, 44, "u_mvp_matrix");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_ATTRIB, 3, "a_position");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_TEXTURE, 0, "texture0");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_ATTRIB, 2, "a_tex_coord");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_UNIFORM, 4, "u_color");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_INDEX, 2, "index");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "time");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "maskType");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "dirValue1");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "dirValue2");
    program_add_parameter("verticalMask", PROGRAM_DATA_TYPE_UNIFORM, 1, "colorTimer");
end

local function createLoadingShader()

    program_create("loading");

    local vsloading = [=[
        uniform   mat4 u_mvp_matrix;
        attribute vec3 a_position;
        attribute vec2 a_tex_coord;
        varying   vec2 vtexcoord;

        void main()
        {
            gl_Position = u_mvp_matrix * vec4(a_position, 1.0);
            vtexcoord = a_tex_coord ;
        }
    ]=];

    local fsloading = [=[
        precision mediump float;
        uniform sampler2D texture0;      
        uniform vec4 u_color;
        varying vec2 vtexcoord;
        uniform float time;

        void main()
        {                                   	          
            vec2 uv = vtexcoord * 2.0 - 1.0;
           
           // vec2 halfuv = uv * 0.5;    
          //  float rx = mod(halfuv.x, 0.4); 
           // float ry = mod(halfuv.y, 0.4);     
          //  float mx = step(0.4, abs(halfuv.x)); 
          //  float my = step(0.4, abs(halfuv.y));  
          //  float filletAlpha = 1.0 - mx * my * step(0.1, length(vec2(rx,ry))); 

            
            float angle  = 6.284*(-sin(time)+0.5); 
            vec4 colorbg = texture2D(texture0, vtexcoord); 
            float color = (sign(angle - atan(uv.x, uv.y)));
	        gl_FragColor = vec4(color*abs(sin(time))* colorbg.a,color*abs(cos(time))* colorbg.a,0.0,color * colorbg.a) * u_color;
        }
    ]=];

    program_set_shader_source("loading", vsloading, fsloading);

    program_add_parameter("loading", PROGRAM_DATA_TYPE_UNIFORM, 44, "u_mvp_matrix");
    program_add_parameter("loading", PROGRAM_DATA_TYPE_ATTRIB, 3, "a_position");
    program_add_parameter("loading", PROGRAM_DATA_TYPE_TEXTURE, 0, "texture0");
    program_add_parameter("loading", PROGRAM_DATA_TYPE_ATTRIB, 2, "a_tex_coord");
    program_add_parameter("loading", PROGRAM_DATA_TYPE_UNIFORM, 4, "u_color");
    program_add_parameter("loading", PROGRAM_DATA_TYPE_INDEX, 2, "index");
    program_add_parameter("loading", PROGRAM_DATA_TYPE_UNIFORM, 1, "time");
end



return function ()
    createEdgeDetection ();
	createBlink ();
	createNormalMap ();
	createChipMaskShader();
    createLoadingShader();
    createHorizontalMaskShader();
    createQuaterMaskShader();
    createVerticalMaskShader();
end 