require("gameBase/gameController");
require("core/global");
require("game/event/eventConfig");

SngHallModule = class(GameController);

local ID = ToolKit.getIndex();

SngHallModule.s_cmd = 
{
    toStore         = ctrlCmd(ID(), SngHallModule, "toStore");
	toComingSoon    = ctrlCmd(ID(), SngHallModule, "toComingSoon");
};

SngHallModule.ctor = function(self, state, viewClass, viewConfig,...)

end

SngHallModule.resume = function(self)
    GameController.resume(self);
    
end

SngHallModule.pause = function(self)
    GameController.pause(self);
    
end

SngHallModule.dtor = function(self)

end

SngHallModule.toStore = function (self)
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG);
end

SngHallModule.toComingSoon = function (self)
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_COMINGSOON_PAGE);
end


