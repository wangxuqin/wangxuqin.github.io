require("game/scene/comp/activity/taskReporter");

--[Comment]
--活动模块

--[[
    -- 新年活动大转盘   
    -- 兑换码
    -- 序列号兑换奖励
    -- 玩偶收集
--]]
ActivityModule = {};

ActivityModule.ACT_LIST = {WheelActivity};--活动列表
ActivityModule.m_actList = {};

ActivityModule.m_dailyFirstInNeedTriggerFlag = false;

ActivityModule.__eventList = {
    {CommandEvent, CommandEvent.s_cmd.USER_LOGGED_IN,           "onUserLoggedIn"};
    {CommandEvnet, CommandEvent.s_cmd.OPEN_ACTIVITY_RANKING,    "onOpenActivityRanking"};
    {CommandEvent, CommandEvent.s_cmd.DAY_PASSED,               "onDayPassed"};
}

ActivityModule.initialize = function()
    for i = 1, #ActivityModule.ACT_LIST do
        table.insert(self.m_actList, ActivityModule.ACT_LIST[i].getInstance());
    end
    EventDispatcher.getInstance():registerEventList(ActivityModule, ActivityModule.__eventList);
end


ActivityModule.onUserLoggedIn = function(self, data)
	local userData = Model.getData(ModelKeys.USER_DATA);
    self.m_loading = false;
    self.m_dailyFirstInNeedTriggerFlag = false;
	Model.clearData(ModelKeys.ACT_LIST);
	Model.clearData(ModelKeys.ACT_LIST_DISPLAYING);

    if userData ~= nil and userData["firstin"] == "1" then
		if userData.loginRewardStep ~= 0 then
			Model.setData(ModelKeys.USER_RECEIVED_TUTORIAL_REWARD, false);
			if userData.newCourse ~= nil then
				--new StartTutoriaPopup(new NewRegisterRewardPopUp(userData.loginRewardStep, checkDailyFirstInNeedTrigger).show).showStartTutoriaPopup();
			else
				--new NewRegisterRewardPopUp(userData.loginRewardStep, checkDailyFirstInNeedTrigger).show();
			end
		else 
			if userData.newCourse ~= nil then
				--new StartTutoriaPopup(checkDailyFirstInNeedTrigger).showStartTutoriaPopup();
			else
				self:checkDailyFirstInNeedTrigger();
			end
		end
	else 
		if userData.loginRewardStep>0 and  userData.loginRewardStep < 4 then 
			--new NewRegisterRewardPopUp(userData.loginRewardStep, checkDailyFirstInNeedTrigger).show();
		else
			self:checkDailyFirstInNeedTrigger();
		end
    end
		
    for i = 1, #self.m_actList do
        self.m_actList[i]:userLoggedIn(data);
    end	
	
    TaskReporter.getInstance():userLoggedIn();
			
	if not Model.getData(ModelKeys.ACT_LIST_IN_MAIN_PAGE) then
		local actListInMain = {};
        for i = 1, #self.m_actList do
            local vo = self.m_actList[i]:getInMainVO(userData.freeChipList);
            if vo ~= nil then
                table.insert(actListInMain, vo);
            end
        end
		Model.setData(ModelKeys.ACT_LIST_IN_MAIN_PAGE, actListInMain);
	end
end

ActivityModule.checkDailyFirstInNeedTrigger = function(self)
    if self.m_actList ~= nil then
        for i = 1, #self.m_actList do
            self.m_actList[i]:checkDailyFirstInNeedTrigger();
        end
    end
end


ActivityModule.onOpenActivityRanking = function(self, data)
--	var activityRanking:ActivityRankingPopUp = new ActivityRankingPopUp();
--	activityRanking.title = (data as ActivityNewestVO).rankTitle;
--	PopUpManager.addPopUp(activityRanking);
			
	HttpService.post({
        ["mod"]  = "actRank", 
        ["act"]  = "topthirty", 
        ["type"] = data.rankFlag}, 
        self, self.getActivityRankingCallback, self.getActivityRankingCallback, self.getActivityRankingCallback);
end
		
ActivityModule.getActivityRankingCallback = function(self, data)
	if data ~= nil then
		local flag, jsonObj = JsonKit.decode(data)
	    if flag then
		    if jsonObj ~= nil then
			    local rankingArray = {}
			    for i = 1, i < #rankingArray do
				    local ranking = new(ActivityRankingVO);
				    ranking.m_rank    = i;
				    ranking.m_name    = json[i].nick;
				    ranking.m_number  = json[i].number;
				    ranking.m_uid     = json[i].uid;
				    ranking.m_picUrl  = json[i].s_picture;
				    rankingArray[i]   = ranking;
			    end
			    model.setData(ModelKeys.ACTIVITY_RANKING_DATA, rankingArray);
            end
		else
            Log.d(self.TAG, "getActivityRankingCallback", "decode json has an error occurred!");--解析Json发生错误
        end
	end
end

ActivityModule.onDayPassed = function(self)
    TaskReporter.getInstance():dayPassed();
    if self.m_actList ~= nil then
        for i = 1, #self.m_actList do
            self.m_actList[i]:onDayPassed();
        end
    end
end