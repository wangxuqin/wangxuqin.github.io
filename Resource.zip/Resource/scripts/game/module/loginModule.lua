require("game/model/model");
require("game/model/modelKeys");
require("game/event/eventConfig");
require("game/module/login/loginFBService");
require("game/module/login/loginEmailService");
require("game/module/login/loginGuestService");
require("service/nativeService");

LoginModule = {}

LoginModule.__eventList = {    --外部事件处理
    {CommandEvent, CommandEvent.s_cmd.LOGIN_RESULT,     "onLoginResultHandle"} ;    --登录结果处理 
    {CommandEvent, CommandEvent.s_cmd.DO_LOGIN,         "doLogin"};                 --登录
    {CommandEvent, CommandEvent.s_cmd.LOGOUT,           "doLoginOut"};              --登出
}

--[Comment]
--初始化
LoginModule.initialize = function()
    EventDispatcher.getInstance():registerEventList(LoginModule, LoginModule.__eventList);
end

--[Comment]
--登录
LoginModule.doLogin = function(self, data)
    if not NativeService.getInstance():isNetworkAvailable() then
        --弹出提示框，确定后退出程序
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,{
            message=STR_COMMON_NETWORK_PROBLEM, 
			confirm=STR_COMMON_NETWORK_TO_SET, 
			obj = LoginModule,
            callback = LoginModule.onSetNetwork
		});
        return;
    end
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_LOGIN_LOADING);  --播放loading动画
    if data == LoginTypes.LOGIN_TYPE_FACEBOOK then
        CookieService.setString(CookieKeys.LOGIN_TYPE, LoginTypes.LOGIN_TYPE_FACEBOOK);
        LoginFBService.doLogin();
    elseif data == LoginTypes.LOGIN_TYPE_BY then
        LoginEmailService.doLogin();

    elseif data == LoginTypes.LOGIN_TYPE_GUEST then
        LoginGuestService.doLogin();
    end
end

--[Comment]
--登出
LoginModule.doLoginOut = function(self, data)
    LoginCommon.doLoginOut(data);
end

--[Comment]
--登录结果处理 
LoginModule.onLoginResultHandle = function(self, data)
    local loginResultType = data;   --登录结果类型
    if loginResultType == LoginResultTypes.SUCCESS then
        self:onLoginSuccess();
    else
        self:onLoginFail(loginResultType);
    end
end

--[Comment]
--登录操作成功后相关处理
LoginModule.onLoginSuccess = function(self)
    --记录上次登录类型
	--CookieService.setString(CookieKeys.LOGIN_TYPE, loginType);
	--初始化推送消息
	--nativeService.initPushNotification();
			
    local userData = Model.getData(ModelKeys.USER_DATA);

	--检测当前帐号是否在本机器登录过，登录过的uid不需要重新校验fb登录密码
	local uidList = CookieService.getString(CookieKeys.LOGINED_UID_LIST, "");
	local uidArray = (uidList ~= "" and  uidList.split(",") or {});
	local logined = false;
	if  ArrayKit.indexOf(tostring(userData.uid)) < 0 then
		logined = false;
	else
		logined = true;
	end

	if (userData.fbPwdBit ~= nil and userData.fbPwdBit == 1 and logined == false) then
		self.m_loadTimes = 3;
		--checkFbPwd();
        EventDispatcher.getInstance():dispatch(
            UIEvent.s_event, 
            UIEvent.s_cmd.HIDE_LOGIN_LOADING
        );
	else
		
        TaskKit.schedule(100, nil, function()
            EventDispatcher.getInstance():dispatch(
                SceneNavEvent.s_event, 
                SceneNavEvent.s_cmd.LOGIN_2_HOME
            );  --发送跳转命令

            EventDispatcher.getInstance():dispatch(
                CommandEvent.s_event, 
                CommandEvent.s_cmd.USER_LOGGED_IN
           );

	        EventDispatcher.getInstance():dispatch(
               UIEvent.s_event, 
               UIEvent.s_cmd.ENTER_MAIN_PAGE
            );
        end);
	end
end

--[Comment]
--登录操作失败后相关处理
LoginModule.onLoginFail = function(self, loginResultType)
    local tip = STR_COMMON_BAD_NETWORK;
	if self.LoginFailResultMap[loginResultType] ~= nil then
        tip = self.LoginFailResultMap[loginResultType];
    end

    if loginResultType == LoginResultTypes.PASSWORD_ERROR then
        CookieService.clearProperty(CookieKeys.LOGIN_BY_PASSWORD);

	elseif loginResultType == LoginResultTypes.RESET_PASSWORD_SUCC then
        model.setData(ModelKeys.NEED_RESET_PASSWORD, true);

	else	
		CookieService.clearProperty(CookieKeys.LOGIN_OAUTH_DATA_QQ);
        CookieService.clearProperty(CookieKeys.LOGIN_OAUTH_DATA_RENREN);
		CookieService.clearProperty(CookieKeys.LOGIN_OAUTH_DATA_SINA_WEIBO);
	end
    
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_LOGIN_LOADING);
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, tip);	
end

--[Comment]
--登录错误提示说明表
LoginModule.LoginFailResultMap = {
    [LoginResultTypes.RESET_PASSWORD_TIMES_UPPER_LIMIT] = STR_LOGIN_RESET_PASSWORD_TIME_UPPER_LIMIT;
    [LoginResultTypes.SERVER_STOP]                      = HIDE_LOGIN_LOADING;
    [LoginResultTypes.EMAIL_ERROR]                      = STR_LOGIN_LOGIN_EMAIL_ERROR;
    [LoginResultTypes.PASSWORD_ERROR]                   = STR_LOGIN_LOGIN_PASSWORD_ERROR;
    [LoginResultTypes.RESET_PASSWORD_SUCC]              = STR_LOGIN_RESET_PASSWORD_SUCC;
    [LoginResultTypes.RESET_PASSWORD_ERROR]             = STR_LOGIN_RESET_PASSWORD_ERROR;
}

LoginModule.onSetNetwork = function ()
    NativeService.getInstance():setNetWork();
end