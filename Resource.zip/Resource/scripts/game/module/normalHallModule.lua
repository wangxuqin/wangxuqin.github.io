require("gameBase/gameController");
require("core/global");
require("game/event/eventConfig");

NormalHallModule = {}

NormalHallModule.m_bringGroupsTeen = false;
NormalHallModule.m_advancedTeen = false;
		
NormalHallModule.FIELD_2 = 2;
NormalHallModule.FIELD_3 = 3; --中级场
NormalHallModule.FIELD_4 = 4; --高级场

NormalHallModule.FlAG_1 = 1;  --快速场
NormalHallModule.FlAG_2 = 2;  --非快速场
		
NormalHallModule.m_groupsInfoArrPrimary	 = {};--初级场和中级场集合信息 
NormalHallModule.m_groupsInfoArrMid		 = {};
NormalHallModule.m_traceFriendsArr		 = {};--追踪好友的信息列表 
NormalHallModule.m_onlineAll_1			 = {};--在线人数
NormalHallModule.m_onlineAll_2			 = 0;
NormalHallModule.m_onlineAll_3			 = 0;
NormalHallModule.m_advancedTablesArr	 = {};--高级场的桌子信息
NormalHallModule.m_currentField		 = {};--场次标志：初级场、中级场、高级场、快速场（2、3、4)
NormalHallModule.m_curAdvancedFilterType	= 1;	--1 全部 2，未满，3好友
NormalHallModule.m_curAdvancedFilterPlayNum = 5; 	--5人桌还是9人桌

NormalHallModule.m_dataValidArray = {};
NormalHallModule.m_newHallData = nil	--新大厅数据;


NormalHallModule.__eventList = {
	{CommandEvent, CommandEvent.s_cmd.REQUEST_BRING_GROUPS_INFO, "onRequstGroupTablesInfo"};	--请求桌子信息
	{CommandEvent, CommandEvent.s_cmd.REQUEST_TRACE_FRIENDS_DATA, "onRequstTraceFriendsData"};	--请求追踪好友消息
	{UIEvent, 	   UIEvent.s_cmd.NEW_HALL_FILTER_TABLE_INFO, "onFilterAdvanedPlayerData"};
	{UIEvent, 	   UIEvent.s_cmd.NEW_HALL_FILTER_PlAYER_INFO, "onFilterAdvanedTableData"};
};

NormalHallModule.initialize = function()
    EventDispatcher.getInstance():registerEventList(NormalHallModule, NormalHallModule.__eventList);
end

		
--[Comment]
--清除数据
NormalHallModule.clearData = function(self)
	for i = 1, #self.m_dataValidArray do
		self.m_dataValidArray[i] = false;
	end
end
		

		
NormalHallModule.onRequstGroupTablesInfo = function(self, data)
	if data ~= nil then
		self.m_currentField = tonumber(data);
		if self.m_dataValidArray[self.m_currentField] ~= false then
			--干掉老的请求
			--httpService.cancelRequest("tableInfo");
			local postData = {["mod"]="table", ["act"]="tableInfo", ["field"]=data};
			HttpService.post(postData, self, self.onRespondGroupTablesInfo);
		end
	end
end

NormalHallModule.onRespondGroupTablesInfo  = function(self, data)
	local param = nil;
    self.m_newHallData = self.m_newHallData or new(NewNormalHallData)
    if	data ~= nil then
		local obj = json.decode(data);
        if obj.field == self.FIELD_2 then
			self.m_onlineAll_1 = obj.allonline;
			self.m_groupsInfoArrPrimary = self:integrateData(obj.tablelist, obj.field);	
			param = {
                ["field"]   = self.m_currentField,
                ["data"]    = Copy(self.m_groupsInfoArrPrimary),
                ["online"]  = self.m_onlineAll_1
            };
		
        elseif obj.field == self.FIELD_3 then
			self.m_onlineAll_2 = obj.allonline;
			self.m_groupsInfoArrMid = self:integrateData(obj.tablelist,obj.field);
			param = {
                ["field"]   = self.m_currentField,
                ["data"]    = Copy(self.m_groupsInfoArrMid);
                ["online"]  = self.m_onlineAll_2
            };
		
        elseif obj.field == self.FIELD_4 then
			self.m_onlineAll_3          = obj.allonline;
			self.m_advancedTablesArr    = obj.tablelist;
			local filterArr = self:filterAdvancedData(self.m_curAdvancedFilterType,self.m_curAdvancedFilterPlayNum);
			param = {
                ["field"]=self.m_currentField,
                ["data"]=filterArr,
                ["online"]=self.m_onlineAll_3
            }
			--self.m_dataValidArray[obj.field] = true;
		end
	else
		if self.m_currentField == self.FIELD_2 then
			param = {
                ["field"]   = self.m_currentField,
                ["data"]    = Copy(self.m_groupsInfoArrPrimary),
                ["online"]  = self.m_onlineAll_1
            };
		
        elseif self.m_currentField == self.FIELD_3 then
			param = {
                ["field"]   = self.m_currentField,
                ["data"]    = Copy(self.m_groupsInfoArrMid),
                ["online"]  = self.m_onlineAll_2
            };
		
        else
			local filterArr = self:filterAdvancedData(self.m_curAdvancedFilterType,self.m_curAdvancedFilterPlayNum);
			param = {
                ["field"]   = self.m_currentField,
                ["data"]    = filterArr,
                ["online"]  = self.m_onlineAll_3};
		end
	end
    if param ~= nil then
        self.m_newHallData:setCurrentMatchData(param);
    end
end

			
		
NormalHallModule.invalidData = function(self)
	--self.m_dataValidArray[arguments[0]] = false;
end
		
--把field整合到集合数据中 
NormalHallModule.integrateData = function(self, list, field)
	if list ~= nil and #list > 0 then
		for i = 1, #list do
			 list[i].field = field or {};
		end
	end
	return list;
end
		
NormalHallModule.onRequstTraceFriendsData = function(self, data)
	local postData = {["mod"]="table", ["act"]="traceFriendsInfo", ["field"]=data.field,["minbuyin"]=data.minbuyin};
	HttpService.post(postData,self, self.onRespondTraceFriendsData)
end

NormalHallModule.onRespondTraceFriendsData = function(self, data)
	if data ~= nil then
		local param = json.decode(data);
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TRACE_FRIEND_POPUP, param);
	end
end

		
NormalHallModule.showTraceFriendsPanel = function(self, friends)
	 --panel:TraceFriendsPanel = new TraceFriendsPanel();
	 --PopUpManager.addPopUp(panel);
	 --panel.setList(friends);
end
		
--[Comment]
--过滤分类数据 
NormalHallModule.filterAdvancedData = function(self, types,playerNum)
	types = types or 1;
	playerNum = playerNum or 5;
    local filerListArr = {};
	if self.m_advancedTablesArr ~= nil and #self.m_advancedTablesArr > 0 then
		local arr = {};
		for i = 1, #self.m_advancedTablesArr do
			if self.m_advancedTablesArr[i].tables ~= nil then
				local obj = {};
				obj.setId  = self.m_advancedTablesArr[i].setId
				obj.sb     = self.m_advancedTablesArr[i].sb;
				obj.bb     = self.m_advancedTablesArr[i].bb;
				obj.minb   = self.m_advancedTablesArr[i].minb;
				obj.maxb   = self.m_advancedTablesArr[i].maxb;

				local tables = self.m_advancedTablesArr[i].tables;
				local filterTableArr = {};
				if tables ~= nil and #tables > 0 then
					for n = 1, #tables do
						if types == 1 then
							if	tables[n].all == playerNum then
								table.insert(filterTableArr,tables[n]);
							end
						elseif types == 2 then--未满
							if(tables[n].pc < tables[n].all and tables[n].all == playerNum) then
								table.insert(filterTableArr, tables[n]);
							end
						elseif types == 3 then--好友
							if tables[n].players and #tables[n].players >0 and tables[n].all == playerNum then
								for k = 1, #(tables[n].player) do
									local player = tables[n].players[k];
									if(player.friendsFlag == 1) then
										table.insert(filterTableArr, tables[n]);
										break;
									end
								end
							end
						end
					end
				end
				obj.tables = filterTableArr;
				table.insert(filerListArr, obj);
            end
		end
	end
	return filerListArr;
end

--过滤5或9人桌 
NormalHallModule.onFilterAdvanedTableData = function(self, data)
	local filterArr = self:filterAdvancedData(self.m_curAdvancedFilterType,tonumber(data));
	if self:checkHasTables(filterArr) then
		self.m_newHallData:setCurrentMatchData({["field"]=4,["data"]=filterArr,["online"]=self.m_onlineAll_3});
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_NEW_HALL_NO_TABLES_TIPS);--该分类下没有桌子
	end
    self.m_curAdvancedFilterPlayNum = tonumber(data);
end

--过滤满/未满/好友分类 
NormalHallModule.onFilterAdvanedPlayerData = function(self, data)
	local filterArr = self:filterAdvancedData(tonumber(data),self.m_curAdvancedFilterPlayNum);	
	if self:checkHasTables(filterArr) then
		self.m_newHallData:setCurrentMatchData({["field"]=4,["data"]=filterArr,["online"]=self.m_onlineAll_3});
		self.m_curAdvancedFilterType = tonumber(data);
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_NEW_HALL_NO_TABLES_TIPS);
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.NEW_HALL_NO_TABLES, self.m_curAdvancedFilterType);
	end
end

--[Comment]
--检测有没桌子 
NormalHallModule.checkHasTables = function(self, arr)
	local ret = false;
	if arr ~= nil then
		for i = 1, #arr do
			if arr[i].tables and #arr[i].tables > 0 then --有桌子
				ret = true;
				break;
			end
		end
	end
	return ret
end