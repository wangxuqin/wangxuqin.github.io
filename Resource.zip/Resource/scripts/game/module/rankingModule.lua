--[Comment]
--排行榜模块
RankingModule = {};
RankingModule.TAG                       = "RankingModule"

RankingModule.SORT_BY_MONEY             = "SORT_BY_MONEY";
RankingModule.SORT_BY_EXP               = "SORT_BY_EXP";
RankingModule.SORT_BY_LEVEL             = "SORT_BY_LEVEL";

RankingModule.m_page                    = nil;
RankingModule.m_moneyRankList           = {};
RankingModule.m_moneyRanking            = "";
RankingModule.m_moneyRankingDesc        = "";
RankingModule.m_expRankList             = {};
RankingModule.m_expRanking              = "";
RankingModule.m_expRankingDesc          = "";
RankingModule.m_achiRankList            = {};
RankingModule.m_achiRanking             = "";
RankingModule.m_achiRankingDesc         = "";
		
RankingModule.m_friendMoneyRankList     = {};
RankingModule.m_friendExpRankList       = {};
RankingModule.m_friendAchiRankList      = {};
RankingModule.m_myMoneyOfFriendRanking  = ""
RankingModule.m_myMoneyOfFriendDesc     = "";
RankingModule.m_myExpOfFriendRanking    = "";
RankingModule.m_myExpOfFriendDesc       = "";
RankingModule.m_myAchiOfFriendRanking   = "";
RankingModule.m_myAchiOfFriendDesc      = "";
		
RankingModule.m_myAchiData              = 0;
RankingModule.m_myCompAchiData          = nil;
RankingModule.m_currentTabIndex         = 0;
		
RankingModule.__eventList = {
    {CommandEvent, CommandEvent.s_cmd.USER_LOGGED_IN,               "onUserLoggedIn"};
    {CommandEvent, CommandEvent.s_cmd.OPEN_RANKING_POP_UP,          "openRankingPopUp"};
    {CommandEvent, CommandEvent.s_cmd.RANKING_PAGE_TAB_CHANGE,      "rankingTabChangeHandler"};
    {CommandEvent, CommandEvent.s_cmd.RANKING_PAGE_TOP_TAB_CHANGE,  "rankingTopTabChangeHandler"};
}
	
RankingModule.initialize = function()
	RankingModule.m_moneyRankList        = {};
	RankingModule.m_expRankList          = {};
	RankingModule.m_achiRankList         = {};
	RankingModule.m_friendMoneyRankList  = {};
	RankingModule.m_friendExpRankList    = {};
	RankingModule.m_friendAchiRankList   = {};		
    EventDispatcher.getInstance():registerEventList(RankingModule, RankingModule.__eventList);
end
		
RankingModule.cacheFriendList = function(self)
	HttpService.post({["mod"] = "friend",["act"] = "getOnlineFriends"},self, self.cacheFriendListResult);
end
		
RankingModule.defaultErrorHandler = function(self, arg1, arg2)
	Model.setData(ModelKeys.RANKING_LIST_DISPLAY, STR_COMMON_PHP_REQUEST_ERROR_MSG);
end
		
RankingModule.cacheFriendListResult = function(self, data)
	local flag, jsonObj = JsonKit.decode(data);
	if flag then
        local rankingVO = nil;
	    local list      = {};
	    local uidList   = {};
	    for _, item in pairs(jsonObj) do
		    rankingVO = new(RankingVO, item);
		    table.insert(list, rankingVO);
		    table.insert(uidList, rankingVO.uid);
	    end
	    --加入自己再排序
	    self:addSelfAndSort(list);
	    Model.setData(ModelKeys.FRIEND_UID_LIST, uidList);
	    Model.setData(ModelKeys.RANKING_LIST_INITIAL_FRIEND, list);
	    Model.setData(ModelKeys.FRIEND_LIST, jsonObj);
    else
        Log.e(self.TAG, "cacheFriendListResult", "decode json has an error occurred!");
    end
end
		
RankingModule.addSelfAndSort = function(self, list,sortType)
	local userData            = Model.getData(ModelKeys.USER_DATA);
    local rankingVO           = new(RankingVO);
	rankingVO.m_chipTotal     = userData.money;
	rankingVO.m_img           = userData.s_picture;
	rankingVO.m_level         = userData.level;
	rankingVO.m_nick          = userData.nick;
	rankingVO.m_levelName     = userData.title;
	rankingVO.m_siteid        = tostring(userData.siteuid);
	rankingVO.m_uid           = tostring(userData.uid);
	rankingVO.m_winPercent    = tonumber(string.format("%d", (userData.win * 100 / (userData.win + userData.lose))));
	rankingVO.m_ach           = self.m_myAchiData;
	
    if sortType == "" or sortType == self.SORT_BY_MONEY then
		rankingVO.m_chipTotal = userData.money;

	elseif sortType == self.SORT_BY_EXP then
		rankingVO.m_chipTotal = userData.level;

	elseif sortType == self.SORT_BY_LEVEL then
		rankingVO.m_chipTotal = myAchiData;
	end

    self.m_rankingVO = rankingVO;
			
	--把自己加进去
    table.insert(list, rankingVO);
    
	self.m_sortType = (sortType == "") and  self.SORT_BY_MONEY or sortType;

	--进行一下排序
    list =  AlgorithmKit.quickSort(list, self, self.__sortFunc);
			
	--找到自己的位置
	local retData = nil;
    local found = false;
	for i = 1, #list do
		list[i].friendRanking = i;
		if not found and list[i] == self.m_rankingVO then
			found = true;
			if sortType == "" or self.m_sortType == self.SORT_BY_MONEY then
				self.m_myMoneyOfFriendRanking = tostring(i);
            
			elseif sortType == self.SORT_BY_EXP then
				self.m_myExpOfFriendRanking = tostring(i);
			
            elseif sortType == self.SORT_BY_LEVEL then
				self.m_myAchiOfFriendRanking = tostring(i);
			end

			if i > 30 then          
				retData = list[30];-- 三十名开外，跟30

			elseif i == 1 then 
				retData = list[1];-- 第一名返回自己
			else
				retData = list[i]; --否则返回前一名
			end
		end
	end
			
	list[31] = nil;
	return retData;
end

RankingModule.__sortFunc = function(self, obj1, obj2)
	local ret = 0;
    local sub = 0; 
	if self.m_sortType == self.SORT_BY_MONEY then
		sub = obj1.chipTotal - obj2.chipTotal;

	elseif self.m_sortType == self.SORT_BY_EXP then
		sub = obj1.level - obj2.level;
	
	elseif self.m_sortType == self.SORT_BY_LEVEL then
		sub = obj1.ach - obj2.ach;
	end

	if sub == 0 then
		--当遇到与自己筹码数目相等的，把自己放到前面
		if obj1.uid == self.m_rankingVO.uid then
			ret = - 1;
		elseif obj2.uid == self.m_rankingVO.uid then
            ret = 1;
		else
			ret = 0;
		end
	elseif sub > 0 then
		ret = -1;
	else
		ret = 1;
	end
end
		
RankingModule.onUserLoggedIn = function(self, data)
	Model.clearData(ModelKeys.RANKING_LIST_DISPLAY);
	Model.setData(ModelKeys.RANKING_LIST_DISPLAY,nil);
	Model.clearData(ModelKeys.RANKING_LIST_INITIAL_FRIEND);
	Model.clearData(ModelKeys.FRIEND_LIST);
	self:refreshAllRankingData();
	self:cacheFriendList();
end
		
RankingModule.refreshFriendRankingData = function(self)
	Model.setData(ModelKeys.RANKING_LIST_DISPLAY,nil);
	HttpService.post({["mod"] = "friend",["act"] = "list"}, self, self.refreshFriendListResult, self.defaultErrorHandler);
end
		
RankingModule.refreshFriendListResult = function(self, data)
	local userData = Model.getData(ModelKeys.USER_DATA);
    local flag, jsonObj = JsonKit.decode(data);
	local rankingVO = nil;
	self.m_friendMoneyRankList  = {};
	self.m_friendExpRankList    = {};
	self.m_friendAchiRankList   = {};
	
    for _, obj in ipairs(jsonObj) do 
		rankingVO = new(RankingVO, obj);
		table.insert(self.m_friendMoneyRankList, rankingVO);
	end

	for _, obj in ipairs(jsonObj) do
		rankingVO = new(RankingVO, obj, 1);
		table.insert(self.m_friendExpRankList, rankingVO);
	end

	for _, obj in ipairs(jsonObj) do
		rankingVO = new(RankingVO, obj, 2);
		table.insert(self.m_friendAchiRankList, rankingVO);
	end
			
	if not Model.hasData(ModelKeys.RANKING_LIST_INITIAL_FRIEND) then
		Model.setData(ModelKeys.RANKING_LIST_INITIAL_FRIEND, ArrayKit.slice(self.m_friendMoneyRankList, 1));
	end

	--加入自己再排序（资产排序）
	rankingVO = self:addSelfAndSort(self.m_friendMoneyRankList, self.SORT_BY_MONEY);
	
    --比较得出升降
	self:compareWithInitialFriend(self.m_friendMoneyRankList);
	self.m_myMoneyOfFriendDesc = self:formateEnc(
        Formatter.formatNumberWithSplit(rankingVO.chipTotal - userData.money), 
        rankingVO.friendRanking, 
        (rankingVO.uid == tostring(userData.uid)) and 1 or rankingVO.friendRanking , 0, 1);
			
	--加入自己再排序（等级排序）
	rankingVO = self:addSelfAndSort(self.friendExpRankList, self.SORT_BY_EXP);
	
    --比较得出升降
	self:compareWithInitialFriend(self.m_friendExpRankList);
	self.m_myExpOfFriendDesc = self:formateEnc(
        Formatter.formatNumberWithSplit(rankingVO.level - userData.level), 
        rankingVO.friendRanking, 
        (rankingVO.uid == tostring(userData.uid)) and 1 or rankingVO.friendRanking, 1, 1);
			
	--加入自己再排序（成就排序）
	rankingVO = self:addSelfAndSort(self.m_friendAchiRankList, self.SORT_BY_LEVEL);
	
    --比较得出升降
	self:compareWithInitialFriend(self.m_friendAchiRankList);
	self.m_myCompAchiData = rankingVO;
	self.m_myAchiOfFriendDesc = self:formateEnc(
        Formatter.formatNumberWithSplit(rankingVO.ach - self.m_myAchiData), 
        rankingVO.friendRanking, 
        (rankingVO.uid == tostring(userData.uid)) and 1 or rankingVO.friendRanking, 2, 1);
end
		
RankingModule.compareWithInitialFriend = function(self, list)
	local initArr = Model.getData(ModelKeys.RANKING_LIST_INITIAL_FRIEND);
	if initArr ~= nil and list ~= nil then 
		local src  = nil;
        local desc = nil;
        local found = false;
		for i = 1, #list do
			src = list[i];
			for j = 1, #initArr do
				desc = initArr[j];
				if src.uid == desc.uid then
					found = true;
					src.upOrDown = (i < j) and "up" or (i > j and "down" or "");
					break;
				end
			end
			--找不到证明之前没上榜，这次为上升
			if not found then
				src.upOrDown = "up";
			end
		end
	end
end
		
--[Comment]
-- mainTab 0:筹码，1：经验， 2：等级
-- 新版全服排行榜的鼓励文字
RankingModule.formateEnc = function(self, value, comRank, myRank, mainTab, viceTab)
	local comRankText = tostring(comRank);
	local text = nil;
	if myRank == 1 then
		if mainTab == 0 then
			text = STR_RANKING_RANKING_FORMAT_RESOURCE[(viceTab == 0) and 1 or 2];
        elseif mainTab == 1 then
			text = STR_RANKING_RANKING_FORMAT_RESOURCE[(viceTab == 0) and 3 or 4];
        else 
			text = STR_RANKING_RANKING_FORMAT_RESOURCE[(viceTab == 0) and 5 or 6];
		end

	elseif comRank == 1 then
		if mainTab == 0 then
			text = StringKit.substitute(STR_RANKING_RANKING_FORMAT_RESOURCE[7], value, comRankText);

		elseif mainTab == 1 then
			text = StringKit.substitute(STR_RANKING_RANKING_FORMAT_RESOURCE[8], value, comRankText);

		else 
			text = StringKit.substitute(STR_RANKING_RANKING_FORMAT_RESOURCE[9], value, comRankText);
		end

	else
		if mainTab == 0 then
			text = StringKit.substitute(STR_RANKING_RANKING_FORMAT_RESOURCE[10], value, comRankText);

		elseif mainTab == 1 then
			text = StringKit.substitute(STR_RANKING_RANKING_FORMAT_RESOURCE[11], value, comRankText);

		elseif mainTab == 2 then
			text = StringKit.substitute(STR_RANKING_RANKING_FORMAT_RESOURCE[12], value, comRankText);
		else 
			text = "";
		end
	end

    return text;
end

--[Comment]
--打开排行榜对话框
RankingModule.openRankingPopUp = function(self, data)
	self:refreshAllRankingData();
	self:refreshFriendRankingData();
    UIControl:show(UserInfoDialog, PopupDialog.kPopupStyleFade, data);
end
		
RankingModule.m_topTabIndex = 0;

RankingModule.rankingTabChangeHandler = function(self, data)
	local userData = Model.getData(ModelKeys.USER_DATA);
    if data then
		self.m_currentTabIndex = data.leftToggle;
		self.m_topTabIndex = data.topToggle;
	end
	if self.m_currentTabIndex == 0 then -- 资产排名
		if self.m_topTabIndex == 0 then
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_display", self.m_moneyRanking);
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_desc_display", self.m_moneyRankingDesc);
			Model.setData(ModelKeys.RANKING_LIST_DISPLAY, self.m_moneyRankList);

		elseif self.m_topTabIndex == 1 then
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_display", self.m_moneyRanking);
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_desc_display", self.m_myMoneyOfFriendDesc);
			Model.setData(ModelKeys.RANKING_LIST_DISPLAY, self.m_friendMoneyRankList);
        end

	elseif self.m_currentTabIndex == 1 then -- 等级排名
		if self.m_topTabIndex == 0 then
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_display", self.m_expRanking);
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_desc_display", self.m_expRankingDesc);
			Model.setData(ModelKeys.RANKING_LIST_DISPLAY, self.m_expRankList);
		
        elseif self.m_topTabIndex == 1 then
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_display", self.m_myExpOfFriendRanking);
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_desc_display", self.m_myExpOfFriendDesc);
			Model.setData(ModelKeys.RANKING_LIST_DISPLAY, self.m_friendExpRankList);
		end

	elseif self.m_currentTabIndex == 2 then --成就排名
		if self.m_topTabIndex == 0 then
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_display", self.m_achiRanking);
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_desc_display", self.m_achiRankingDesc);
			Model.setData(ModelKeys.RANKING_LIST_DISPLAY, self.m_achiRankList);
		
        elseif self.m_topTabIndex == 1 then
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_display", self.m_myAchiOfFriendRanking);
            Model.setProperty(ModelKeys.USER_DATA, "my_ranking_desc_display", self.m_myAchiOfFriendDesc);
			Model.setData(ModelKeys.RANKING_LIST_DISPLAY, self.m_friendAchiRankList);
        end
	end
end
		
RankingModule.rankingTopTabChangeHandler = function(self, data)
	if data ~= nil then
		self.m_topTabIndex = data;
	end
	self:rankingTabChangeHandler();
end
		
RankingModule.refreshAllRankingData = function(self)
	Model.setData(ModelKeys.RANKING_LIST_DISPLAY,nil);
    Model.setProperty(ModelKeys.USER_DATA, "my_ranking_display", "");
    Model.setProperty(ModelKeys.USER_DATA, "my_ranking_desc_display", "");
	HttpService.post({["mod"] = "rank", ["act"] = "main"}, self, self.onRefreshRankingDataResult, self.defaultErrorHandler);
end
		
RankingModule.onRefreshRankingDataResult = function(self, data)
    local userData = Model.getData(ModelKeys.USER_DATA);
    local flag, jsonObj = JsonKit.decode(daeta);
    if flag then
	    if jsonObj ~= nil then
		    local rankingVO = nil;
            if jsonObj.money ~= nil then
			    self.m_moneyRankList = {};
			    for _, obj in pairs(jsonObjmoney.list) do
				    rankingVO = new(RankingVO, obj);
				    table.insert(self.m_moneyRankList, rankingVO);
			    end

			    if self.m_moneyRankList and #self.m_moneyRankList > 0 then
				    self.m_moneyRanking = (jsonObj.money.rank ~= nil and tonumber(jsonObj.money.rank) <= 10000) and jsonObj.money.rank or ">10000";
				    self.m_moneyRankingDesc = self:formateEnc(
                        Formatter.formatNumberWithSplit(jsonObj.money.c_d - jsonObj.money.data), 
                        jsonObj.money.c_r, 
                        jsonObj.money.rank, 0, 0);
			    end
		    end
				
		    if jsonObj.exp  ~= nil then
			    self.m_expRankList = {};
			    for _, obj in pairs(jsonObj.exp.list) do
				    rankingVO = new(RankingVO, obj);
				    table.insert(expRankList, rankingVO);
			    end

			    if self.m_expRankList ~= nil and #self.m_expRankList > 0 then
				    self.m_expRanking = (jsonObj.exp.rank ~= nil and tonumber(jsonObj.exp.rank) <= 10000) and jsonObj.exp.rank or ">10000";
				    self.m_expRankingDesc = self:formateEnc(
                        Formatter.formatNumberWithSplit(jsonObj.exp.c_d - jsonObj.exp.data), jsonObj.exp.c_r, jsonObj.exp.rank, 1, 0);
			    end
		    end
				
		    if jsonObj.achi ~= nil then
			    self.m_achiRankList = {};
			    for _, obj in pairs(jsonObj.achi.list) do
				    self.m_rankingVO = new(RankingVO, obj);
				    table.insert(achiRankList, rankingVO);
			    end

			    if self.m_achiRankList ~= nil and #achiRankList > 0 then
				    self.m_achiRanking = (jsonObj.achi.rank ~= nil and tonumber(jsonObj.achi.rank) <= 10000) and json.achi.rank or ">10000";
				    self.m_achiRankingDesc = self:formateEnc(
                        Formatter.formatNumberWithSplit(jsonObj.achi.c_d - jsonObj.achi.data), 
                        jsonObj.achi.c_r, 
                        jsonObj.achi.rank, 2, 0);
				    
                    self.m_myAchiData = jsonObj.achi.data;
				    
                    if self.m_myCompAchiData ~= nil then
					    self.m_myAchiOfFriendDesc = self:formateEnc(
                            Formatter.formatNumberWithSplit(self.m_myCompAchiData.ach - self.m_myAchiData), 
                            self.m_myCompAchiData.friendRanking, 
                            (self.m_myCompAchiData.uid == tonumber(userData.uid)) and 1 or self.m_myCompAchiData.friendRanking, 2, 1);
				    end
		        end
            end
		    self:rankingTabChangeHandler();
		    self:rankingTopTabChangeHandler();
        end
	else
        Log.e(self.TAG, "onRefreshRankingDataResult", "decode json has an error occurred!");
    end
end