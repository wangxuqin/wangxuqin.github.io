require("service/httpService");
require("libs/json");
require("game/model/model");
require("game/model/modelKeys");
require("service/login/loginResultTypes");
require("service/login/loginTypes");
require("libs/zzBase64");
LoginUtil = {};

LoginUtil.m_loginType = nil; --当前登录类型

LoginUtil.setLoginType = function(loginType)
    LoginUtil.m_loginType = loginType;
end

LoginUtil.doLoginOut = function(data)
    CookieService.clearProperty(CookieKeys.LOGIN_TYPE);
	--清除用户数据
	Model.clearData(ModelKeys.USER_DATA);
	--HttpService.cancelAllRequest(false);
	HttpService.clearDefaultParams();
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.REMOVE_ALL_POPUP);
	StateMachine.getInstance():changeState(States.Login);
	EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.USER_LOGGED_OUT);
end

LoginUtil.onLoginResult = function(data)
    local userObj = nil;
	if data ~= nil then
	    userObj = json.decode(data);
	    if userObj.uid > 0 then
		    if userObj.nick ~= nil then
			    if System.isAndroid() then
				    userObj.nick = "Android "..userObj.uid;
	            else
				    userObj.nick = "iPhone "..userObj.uid;
			    end
		    end
				
		    --游客登录记录玩家昵称
		    if LoginUtil.m_loginType == LoginTypes.LOGIN_TYPE_GUEST then
			    CookieService.setString(CookieKeys.USER_NICK,userObj.nick);
		    end
				
		    local bankMoney = (userObj.bank_money ~= nil) and tonumber(userObj.bank_money) or 0;
		    userObj.totalMoney = userObj.money + bankMoney;
		
            if userObj.itemDiscount == nil then
			    userObj.itemDiscount = {};
            end
				
		    HttpService.addDefaultParams("mtkey", userObj.mtkey);
		    HttpService.addDefaultParams("skey", userObj.skey);
		    HttpService.addDefaultParams("uid", userObj.uid);
		    HttpService.addDefaultParams("version", System.getVersionCode());
		    HttpService.addDefaultParams("device", System.getDeviceDesc());
		    HttpService.addDefaultParams("channel", userObj.channel);
		    HttpService.addDefaultParams("mac", System.getMacAddress());
		    HttpService.addDefaultParams("openUDID", System.getOpenUDID());
		    HttpService.defaultURL = userObj.CGI_ROOT;
				
            Model.setData(ModelKeys.USER_DATA, userObj, true);
		    --FrameworkGlobal.context.dispatchEventWith(CommandEventNames.LOGIN_RESULT, false, LoginResultTypes.SUCCESS);
            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGIN_RESULT,LoginResultTypes.SUCCESS);
        		
		    if userObj.token ~= nil then
			    --Utils.proxyDecrypt(userObj.mtkey, userObj.token, userObj.token_array);
		    elseif (userObj.proxyip ~= nil) and (userObj.proxyport ~= nil) then
			    ProxyKit.proxyIp = userObj.proxyip;
			    ProxyKit.proxyPort = userObj.proxyport;
		    end
				
	    elseif userObj.uid == -101 then
		    --FrameworkGlobal.context.dispatchEventWith(CommandEventNames.LOGIN_RESULT, false, LoginResultTypes.RESET_PASSWORD_TIMES_UPPER_LIMIT);
	        EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGIN_RESULT,LoginResultTypes.RESET_PASSWORD_TIMES_UPPER_LIMIT);
        elseif userObj.uid == -100 then
		    --FrameworkGlobal.context.dispatchEventWith(CommandEventNames.LOGIN_RESULT, false, LoginResultTypes.SERVER_STOP);
            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGIN_RESULT,LoginResultTypes.SERVER_STOP);
	    elseif userObj.uid == -99 then
		    --FrameworkGlobal.context.dispatchEventWith(CommandEventNames.LOGIN_RESULT, false, LoginResultTypes.PASSWORD_ERROR);
            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGIN_RESULT,LoginResultTypes.PASSWORD_ERROR);
	    elseif userObj.uid == -98 then
		    --FrameworkGlobal.context.dispatchEventWith(CommandEventNames.LOGIN_RESULT, false, LoginResultTypes.EMAIL_ERROR);
            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGIN_RESULT,LoginResultTypes.EMAIL_ERROR);
	    elseif userObj.uid == -97 then
		    --FrameworkGlobal.context.dispatchEventWith(CommandEventNames.LOGIN_RESULT, false, LoginResultTypes.RESET_PASSWORD_ERROR);
            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGIN_RESULT,LoginResultTypes.RESET_PASSWORD_ERROR);
	    elseif userObj.uid == -96 then
		    --FrameworkGlobal.context.dispatchEventWith(CommandEventNames.LOGIN_RESULT, false, LoginResultTypes.RESET_PASSWORD_SUCC);
            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGIN_RESULT,LoginResultTypes.RESET_PASSWORD_SUCC);
	    else
    --			onServerLoginError();
    --			LoginErrorTypeReport(-4,LoginResultTypes.SERVER_ERROR);
    --			FrameworkGlobal.context.dispatchEventWith(CommandEventNames.LOGIN_RESULT, false, LoginResultTypes.SERVER_ERROR);
             EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGIN_RESULT,LoginResultTypes.SERVER_ERROR);
	    end
    end
end

LoginUtil.loginCGI = function()
--var currentLocaleId:String = Localization.currentLocaleId;
--	if(loginNum >= urlLength)
--	{
--		loginURL = urlList[0].(@lang==currentLocaleId).text();

--	}
--	else
--	{
--		loginURL = urlList[loginNum].(@lang==currentLocaleId).text();
--	}
--	logger.debug("trying login url:", loginURL + "mobile.php");
--	if (_loginType == LoginTypes.LOGIN_TYPE_QQ || _loginType == LoginTypes.LOGIN_TYPE_QQ_WEIBO)
--	{
--		return loginURL + "m_qq.php";
--	}
--	else
--	{
--		return loginURL + "mobile.php";
--	}
    return "https://ipk-demo-1.boyaa.com/mobile.php";
end

LoginUtil.loginFailReportUrl = function()
    return "https://ipk-demo-1.boyaa.com/m.php"
end

LoginUtil.LoginErrorTypeReport = function(ret,data)
    --ret -1,-2,-3,-4 没有传过来数据 ,没数据超时,数据解析不全,其他原因
	--登录错误进行上报
    local openUDID = System.getOpenUDID();
	HttpService.postUrl(loginFailReportUrl, {
        ["mod"]         ="tj",
        ["act"]         ="loginErr",
        ["platform"]    = System.getPlatform(),
		["osVersion"]   = System.getOSVersion(),
		["mac"]         = System.getMacAddress(),
		["openUDID"]    = openUDID and zzBase64.encode(openUDID+"_"+encKey) or openUDID,
		["deviceId"]    = System.getDeviceId(),
		["deviceName"]  = System.getDeviceName(),
		["device"]      = System.device(),
		["version"]     = System.getVersionCode,
		["pay"]         = GameConfig.getPlay(),
		["ret"]         = ret or -4,
		["data"]        = data or "",
		["sign"]        = ToolKit.md5(ToolKit.md5(System.getVersionCode() + "|wd30dafd#@%$^^32df2vzvaf2|" + System.getDeviceDesc()))}
    );
end