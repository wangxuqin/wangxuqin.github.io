--[Commont]
--邮箱登录
LoginEmailService = {};

LoginEmailService.doLogin = function()
    CookieService.setString(CookieKeys.LOGIN_TYPE, LoginTypes.LOGIN_TYPE_BY);
end