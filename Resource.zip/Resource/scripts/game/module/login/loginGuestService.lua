require("service/httpService");

require("game/model/model");
require("game/model/modelKeys");
require("game/module/login/loginCommon")
require("game/module/login/loginTypes")


--[Comment]
--�ο͵�¼
LoginGuestService = {};

LoginGuestService.doLogin = function()
    CookieService.setString(CookieKeys.LOGIN_TYPE, LoginTypes.LOGIN_TYPE_GUEST);
    LoginCommon.setLoginType(LoginTypes.LOGIN_TYPE_GUEST);
    local params = {
        device = (System.getPlatform() == "win32") and "android" or "IOS",
        deviceId = System.getDeviceId(),
        deviceName = System.getDeviceName(),	
        mac = System.getMacAddress(),
        mobile_request = ToolKit.base64_encode(System.getMacAddress().."_"..GameConfig.getEncKey(LocalService.currentLocaleId())),
        openUDID = System.getOpenUDID(),
        osVersion = "",	
        pay = GameConfig.getPlay(LocalService.currentLocaleId()),	
        platform = (System.getPlatform() == "win32") and "android" or "IOS",
        systemInfo = "",	
        version = "2.0.0",	
    }
   HttpService.postUrl(LoginCommon.loginCGI(), params, nil, LoginCommon.onLoginResult);
end