--[Comment]
--FB登录
LoginFBService = {};

LoginFBService.doLogin = function()    
    CookieService.setString(CookieKeys.LOGIN_TYPE, LoginTypes.LOGIN_TYPE_FACEBOOK);
end