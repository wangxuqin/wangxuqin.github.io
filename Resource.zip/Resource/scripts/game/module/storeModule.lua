package com.by.itexaspro.module
{
	import com.by.framework.core.FrameworkGlobal;
	import com.by.framework.core.localization.Localization;
	import com.by.framework.core.model.Model;
	import com.by.framework.core.module.IModule;
	import com.by.framework.core.module.ModuleBase;
	import com.by.framework.core.service.ServiceLocator;
	import com.by.framework.core.task.TaskExecutor;
	import com.by.itexaspro.events.CommandEventNames;
	import com.by.itexaspro.events.UIEventNames;
	import com.by.itexaspro.model.ChipsProductVO;
	import com.by.itexaspro.model.CoalaaProductVO;
	import com.by.itexaspro.model.ModelKeys;
	import com.by.itexaspro.model.PayRecordVO;
	import com.by.itexaspro.model.ProductVO;
	import com.by.itexaspro.model.PropsProductVO;
	import com.by.itexaspro.module.store.IPurchaseService;
	import com.by.itexaspro.module.store.MimopayAndroidPurchaseService;
	import com.by.itexaspro.screens.component.WebWindow;
	import com.by.itexaspro.screens.component.common.DialogCallback;
	import com.by.itexaspro.screens.component.main.PageTabGroupData;
	import com.by.itexaspro.screens.component.store.StorePopUp;
	import com.by.itexaspro.screens.component.store.StorePopUpAccountInputPage;
	import com.by.itexaspro.util.AnalysisEventIds;
	import com.by.itexaspro.util.AnalysisUtil;
	import com.by.itexaspro.util.Formatter;
	
	import flash.net.URLRequest;
	import flash.net.navigateToURL;
	import flash.utils.clearTimeout;
	import flash.utils.getDefinitionByName;
	import flash.utils.setTimeout;
	
	import starling.display.DisplayObjectContainer;
	import starling.events.Event;
	
	public class StoreModule extends ModuleBase implements IModule
	{
		private var storePopup:StorePopUp;
		
		private var CommonUtils:*;
		
		private var page:DisplayObjectContainer;
		private var currentTabIndex:int = -1;
		private var loading:Boolean = false;
		private var isProductLoaded:Boolean = false;
		private var monitorTimes:int;
		private var monitorMoney:Number;
		private var monitorCoalaa:Number;
		private var timeoutId:uint;
		
		public function StoreModule()
		{
			super();
		}
		
		public function initialize():void
		{
			var tabGroupDataV:Vector.<PageTabGroupData> = new Vector.<PageTabGroupData>(2);
			
			tabGroupDataV[0] = new PageTabGroupData(null, Localization.getArray("STORE.PRODUCT_CATEGORY_ITEM"));
			tabGroupDataV[1] = new PageTabGroupData(Localization.getText("STORE.ACCOUNT_MANAGE"), Localization.getArray("STORE.ACCOUNT_MANAGE_ITEM"));
			storePopup = new StorePopUp(Localization.getText("STORE.STORE_POP_UP_TITLE"), tabGroupDataV);
			storePopup.addEventListener(Event.REMOVED_FROM_STAGE,storePageRemoveFromStage);
			
			context.addEventListener(CommandEventNames.USER_LOGGED_IN, onUserLoggedIn);
			context.addEventListener(CommandEventNames.USER_LOGGED_OUT, onUserLoggedOut);
			context.addEventListener(CommandEventNames.STORE_MAKE_PURCHASE, onMakePurchase);
			context.addEventListener(CommandEventNames.MONITOR_MONEY_BY_CHANGE, onMonitorMoneyCoalaaChange);
			context.addEventListener(CommandEventNames.OPEN_STORE_POPUP, onOpenStorePopup);
			FrameworkGlobal.context.addEventListener(CommandEventNames.STORE_PAGE_ADD_STAGE_CHECK_LOAD,checkStoreLoad);
			
			model.watchData(ModelKeys.ROOM_USER_PROP_DATA, getUserPropData, false);
			model.watchProperty(ModelKeys.USER_DATA, "itemDiscount", getPurchaseDiscount, false);
			model.watchData(ModelKeys.USER_CASH_DISCOUNT_DATA, getPurchaseDiscount, false);
			
			try {
				CommonUtils = getDefinitionByName("com.coalaa.ane.common_utils.CommonUtils") as Class;
			} catch(err:Error) {
				logger.debug("ane CommonUtils not found");
			}
			
			getPurchaseService();
		}
		
		private function getPurchaseDiscount(val:* = null):void
		{
			var userData:Object = Model.instance.getData(ModelKeys.USER_DATA);
			var discount:int = 0;
			if(userData && userData.hasOwnProperty("itemDiscount"))
			{
				var itemDiscount:Object = userData["itemDiscount"];
				for each (var value:int in itemDiscount)
				{
					if (value > discount)
					{
						discount = value;
					}
				}
			}
			if (userData && userData.hasOwnProperty("localpayoff") && userData["localpayoff"] > discount)
			{
				discount = userData["localpayoff"];
			}
			
			if(Model.instance.getData(ModelKeys.USER_CASH_DISCOUNT_DATA) && Model.instance.getData(ModelKeys.USER_CASH_DISCOUNT_DATA).discount > discount)
			{
				discount = Model.instance.getData(ModelKeys.USER_CASH_DISCOUNT_DATA).discount;
			}
			model.setData(ModelKeys.STORE_DISCOUNT, discount);
		}
		
		private function getUserPropData(data:*):void
		{
			//互动道具分类
			logger.debug(JSON.stringify(data));
			for (var i:int = 0; i < data.length; i++)
			{
				switch (int(data[i].a))
				{
					case 1:
						if (data[i] && data[i].hasOwnProperty("a") && data[i].d)
						{
							setPropsOwnInfo(["1", "6", "7", "8"], Localization.getText("ROOM.PROP_REMAIN", data[i].b, data[i].c));
						} else {
							setPropsOwnInfo(["1", "6", "7", "8"], Localization.getText("ROOM.PROP_REMAIN", 0, data[i].c));
						}
						break;
					case 2:
						if (data[i] && data[i].hasOwnProperty("a") && data[i].d)
						{
							setPropsOwnInfo(["20", "21", "24", "27"], Localization.getText("ROOM.PROP_REMAIN", data[i].b, data[i].c));
						} else {
							setPropsOwnInfo(["20", "21", "24", "27"], Localization.getText("ROOM.PROP_REMAIN", 0, data[i].c));
						}
						break;
					case 30:
						if (data[i] && data[i].hasOwnProperty("a") && data[i].d)
						{
							setPropsOwnInfo(["31"], Localization.getText("ROOM.PROP_REMAIN", data[i].b, data[i].c));
						} else {
							setPropsOwnInfo(["31"], Localization.getText("ROOM.PROP_REMAIN", 0, data[i].c));
						}
						break;
					case 32:
						if (data[i] && data[i].hasOwnProperty("a") && data[i].d)
						{
							setPropsOwnInfo(["33"], Localization.getText("ROOM.PROP_REMAIN", data[i].b, data[i].c));
						} else {
							setPropsOwnInfo(["33"], Localization.getText("ROOM.PROP_REMAIN", 0, data[i].c));
						}
						break;
					case 77:
						if (data[i] && data[i].hasOwnProperty("a") && data[i].d)
						{
							setPropsOwnInfo(["77"], Localization.getText("ROOM.PROP_REMAIN", data[i].b, data[i].c));
						} else {
							setPropsOwnInfo(["77"], Localization.getText("ROOM.PROP_REMAIN", 0, data[i].c));
						}
						break;
				}
			}
			//			model.notifyDataChange(ModelKeys.STORE_PRODUCT_LIST_PROPS);
		}
		
		private function setPropsOwnInfo(ids:Array, text:String):void
		{
			var arr:Array = model.getData(ModelKeys.STORE_PRODUCT_LIST_PROPS);
			if(arr && arr.length > 0)
			{
				for(var i:int = 0; i < arr.length; i++)
				{
					var props:PropsProductVO = arr[i];
					if(props && ids.indexOf(props.id) != -1)
					{
						props.ownInfo = text;
					}
				}
			}
		}
		
		private function onUserLoggedOut():void
		{
			postCounts = 4;
		}
		
		private function storePageRemoveFromStage():void
		{
			clearTimeout(timeoutNum);
		}
		
		private var timeoutNum:int = 0;
		private function onOpenStorePopup(evt:Event):void
		{
			if(evt.data is String)
			{
				storePopup.setSubPage(evt.data as String);
			}
			else if(evt.data is Object && evt.data.hasOwnProperty("page") && evt.data.page && evt.data.hasOwnProperty("type") && evt.data.type)
			{
				storePopup.setSubPage(evt.data.page);
				storePopup.setLocalPayType(evt.data);
			}
			storePopup.show();
			
			loadUserBuyHistory();
			
			loadPropsConfig();
			
			loadPayConfig();
			
			// if product list loaded, get props number
			context.dispatchEventWith(CommandEventNames.ROOM_GET_USER_PROPS);
		}
		
		private function checkStoreLoad(evt:Event):void
		{
			if(!isProductLoaded && Model.instance.getData(ModelKeys.USER_DATA).islocalpay == "1" && Localization.currentLocaleId != "th_TH")
			{
				FrameworkGlobal.context.dispatchEventWith(CommandEventNames.STORE_PAGE_LOAD_LOCALPAY,false,evt.data);
			}
		}
		
		private function onMonitorMoneyCoalaaChange(evt:Event):void
		{
			monitorTimes = 30;
			
			if(timeoutId > 0)
			{
				clearTimeout(timeoutId);
				timeoutId = 0;
			}
			
			monitorMoney = userData.money;
			monitorCoalaa = userData.coalaa;
			
			doMonitor();
		}
		
		private function doMonitor(data:* = null):void
		{
			if(monitorTimes-- > 0)
			{
				logger.info("monitor money or coalaa change, left times:", monitorTimes);
				httpService.POST({"mod":"user","act":"getUserProperty"}, function(ret:String):void{
					var json:Object;
					try {
						if(ret == "0")
						{
							monitorTimes = 0;
							if(timeoutId > 0)
							{
								clearTimeout(timeoutId);
								timeoutId = 0;
							}
						} else {
							json = JSON.parse(ret);
							if(json.money == monitorMoney && (isNaN(monitorCoalaa) || json.coalaa == monitorCoalaa))
							{
								logger.info("monitor money or coalaa, no change, sleep 3000ms");
								//查询的结果没变化继续重试
								if(timeoutId > 0)
								{
									clearTimeout(timeoutId);
									timeoutId = 0;
								}
								timeoutId = setTimeout(doMonitor, 3000);
							} else {
								//有变化，则通知更新，终止监视
								if(json.money != undefined && !isNaN(json.money) && json.money != monitorMoney)
								{
									logger.info("monitor notify money change -> ", json.money);
									userData.money = json.money;
								}
								if(json.coalaa != undefined && !isNaN(json.coalaa) && json.coalaa != monitorCoalaa)
								{
									logger.info("monitor notify coalaa change -> ", json.money);
									userData.coalaa = json.coalaa;
								}
								if(timeoutId > 0)
								{
									clearTimeout(timeoutId);
									timeoutId = 0;
								}
							}
						}
					} catch(err:Error) {
						logger.debug("getUserProperty error:", err);
						if(timeoutId > 0)
						{
							clearTimeout(timeoutId);
							timeoutId = 0;
						}
						timeoutId = setTimeout(doMonitor, 3000);
					}
				}, function():void{
					if(timeoutId > 0)
					{
						clearTimeout(timeoutId);
						timeoutId = 0;
					}
					timeoutId = setTimeout(doMonitor, 3000);
				}, function():void{
					if(timeoutId > 0)
					{
						clearTimeout(timeoutId);
						timeoutId = 0;
					}
					timeoutId = setTimeout(doMonitor, 3000);
				});
			}
		}
		
		private var product:ProductVO;
		private function onMakePurchase(evt:Event):void
		{
			product = evt.data as ProductVO;
			
			var oid:String = (product && product.orderid != "")?product.orderid:"";
			
			if(product)
			{
				//本地支付，充值卡支付
				if(product.localPayData && product.localPayData.hasOwnProperty("payType") && product.localPayData.payType == "1")
				{
					//特殊卡支付
					if(product.isSpecialLocalPay)
					{
						if(product is ChipsProductVO)
						{
							ServiceLocator.httpService.POST({"mod":"morePay", "act":"url","tab":product.localPayData.tab, "payType":product.localPayData.payType, "type":"1","stab":product.localPayData.stab,"id":parseInt(product.id),"price":0,"oid":oid}, localPayCallback, localPayCallback, localPayCallback);
						}
						else
						{
							ServiceLocator.httpService.POST({"mod":"morePay", "act":"url","tab":product.localPayData.tab, "payType":product.localPayData.payType, "type":"2","stab":product.localPayData.stab,"id":parseInt(product.id),"price":0,"oid":oid}, localPayCallback, localPayCallback, localPayCallback);
						}
					}
						//手机短信支付
					else if(product.isSmslocalPay)
					{
						smsPayFunction();
					}
						//普通卡支付
					else
					{
						if(product is ChipsProductVO)
						{
							ServiceLocator.httpService.POST({"mod":"morePay", "act":"url","tab":product.localPayData.tab, "payType":product.localPayData.payType, "type":"1","stab":product.localPayData.stab,"id":parseInt(product.id),"price":product.localPayPrice,"oid":oid}, localPayCallback, localPayCallback, localPayCallback);
						}
						else
						{
							ServiceLocator.httpService.POST({"mod":"morePay", "act":"url","tab":product.localPayData.tab, "payType":product.localPayData.payType, "type":"2","stab":product.localPayData.stab,"id":parseInt(product.id),"price":product.localPayPrice,"oid":oid}, localPayCallback, localPayCallback, localPayCallback);
						}
					}
				}
				else if(product.localPayData && product.localPayData.hasOwnProperty("payType") && product.localPayData.payType == "2" && product.localPayData.hasOwnProperty("stab") && product.localPayData.stab == "zingPay" && product.isSmslocalPay)
				{
					smsPayFunction();
				}
					//本地支付，账号支付
				else if(product.localPayData && product.localPayData.hasOwnProperty("payType") && product.localPayData.payType == "2" && !product.localPayData.hasOwnProperty("isMimopay"))
				{
					//账号支付
					if(product is ChipsProductVO)
					{
						ServiceLocator.httpService.POST({"mod":"morePay", "act":"url","tab":product.localPayData.tab, "payType":product.localPayData.payType, "type":"1","stab":product.localPayData.stab,"id":parseInt(product.id),"price":product.localPayPrice,"oid":oid}, localPayCallback, localPayCallback, localPayCallback);
					}
					else
					{
						ServiceLocator.httpService.POST({"mod":"morePay", "act":"url","tab":product.localPayData.tab, "payType":product.localPayData.payType, "type":"2","stab":product.localPayData.stab,"id":parseInt(product.id),"price":product.localPayPrice,"oid":oid}, localPayCallback, localPayCallback, localPayCallback);
					}
				}
				else if(product.localPayData && product.localPayData.hasOwnProperty("isMimopay") && product.localPayData.isMimopay)
				{
					if(product is ChipsProductVO)
					{
						ServiceLocator.httpService.POST({"mod":"mimopay","act":"getOrderId","payType":1,"oid":oid},mimopayCallback,badNetworkHandler,badNetworkHandler);
						
					}else if((product is PropsProductVO)&&(storePopup.getTab()!=0)&&(storePopup.getTab()==3))
					{
						ServiceLocator.httpService.POST({"mod":"mimopay","act":"getOrderId","payType":3,"oid":oid},mimopayCallback,badNetworkHandler,badNetworkHandler);
						
					}else if((product is PropsProductVO)&&(storePopup.getTab()!=0)&&(storePopup.getTab()==4))
					{
						ServiceLocator.httpService.POST({"mod":"mimopay","act":"getOrderId","payType":4,"oid":oid},mimopayCallback,badNetworkHandler,badNetworkHandler);
					}
					else
					{
						ServiceLocator.httpService.POST({"mod":"mimopay","act":"getOrderId","payType":2,"oid":oid},mimopayCallback,badNetworkHandler,badNetworkHandler);
					}
				}
					//普通支付
				else {
					// 泰语本地支付
					if(product.id == "TH_LOCAL" && userData.islocalpay == "1" && Localization.currentLocaleId == "th_TH")
					{
						AnalysisUtil.onEvent(AnalysisEventIds.EVT_PURCHASE_WEB, product.pid);
						var url:String = "http://web-ipoker.snsplus.com/mobilemorepay.php?paytype=";
						if(product is ChipsProductVO)
						{
							url += "1";
						} else {
							url += "2";
						}
						var params:Object = httpService.getDefaultParams();
						for(var name:String in params)
						{
							url += "&" + name + "=" + params[name];
						}
						WebWindow.instance.openAndGo(url, true);
					}
					else
					{
						AnalysisUtil.onEvent(AnalysisEventIds.EVT_PURCHASE, product.pid);
						getPurchaseService().makePurchase(product, function(isSuccess:Boolean, message:String):void{
							logger.info("purchase result isSuccess:", isSuccess, ", message:", message);
							if(!isSuccess)
							{
								AnalysisUtil.onEvent(AnalysisEventIds.EVT_PURCHASE_FAILED, product.pid);
							}
							FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP, false, message);
							if(product is PropsProductVO)
							{
								context.dispatchEventWith(CommandEventNames.ROOM_GET_USER_PROPS);
							}
						});
					}
				}
			}
		}
		
		private function localPayCallback(value:String):void
		{
			if(value)
			{
				AnalysisUtil.onEvent(AnalysisEventIds.EVT_PURCHASE_WEB, product.pid);
				var data:Object = JSON.parse(value) as Object;
				if(Localization.currentLocaleId == "de_DE")
				{
					navigateToURL(new URLRequest(data.url));
				}
				else
				{
					WebWindow.instance.openAndGo(data.url, false,NaN,NaN,null,null,false);
				}
			}
		}
		
		private function smsPayFunction():void
		{
			if(isBusy)
			{
				FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP, false, {"message" : Localization.getMap("STORE.BUY_RESULT_MSG")["-95"].getText()});
			}
			else
			{
				var discount:Number = product.localPayDis != -1 ? product.localPayDis : 0;
				var chips:String;
				if(product is ChipsProductVO)
				{
					chips = Localization.getText("STORE.STORE_POPUP_CHIPS_TEXT",Formatter.formatNumberWithSplit(Math.floor(product.num * (1 + discount / 100))));
				}else if(product is CoalaaProductVO)
				{
					chips = Localization.getText("STORE.STORE_POPUP_BY_TEXT",Formatter.formatNumberWithSplit(Math.ceil(product.num * (1 + discount / 100))));
				}
				else if((product is PropsProductVO)&&(storePopup.getTab()!=0)&&(storePopup.getTab()==3))
				{
					chips = product.displayName;
				}
				else if((product is PropsProductVO)&&(storePopup.getTab()!=0)&&(storePopup.getTab()==4))
				{
					chips = product.displayName;
				}
				var price:String;
				if(product.localPayData.stab == "zingPay")
				{
					price = product.localPayPrice;
					FrameworkGlobal.context.dispatchEventWith(UIEventNames.OPEN_DIALOG,false,{
						message:Localization.getText("STORE.STORE_LOCAL_PAY_CONFIRM_SEND_SMS",(Number(price) + Number(price)*0.1).toString() + product.localPayUnit,chips), 
						confirm:Localization.getText("COMMON.CONFIRM"),
						cancel:Localization.getText("COMMON.CANCEL"),
						callback:confirmReturn
					});
				}
				else
				{
					price = product.price;
					FrameworkGlobal.context.dispatchEventWith(UIEventNames.OPEN_DIALOG,false,{
						message:Localization.getText("STORE.STORE_LOCAL_PAY_CONFIRM_SEND_SMS",price,chips), 
						confirm:Localization.getText("COMMON.CONFIRM"),
						cancel:Localization.getText("COMMON.CANCEL"),
						callback:confirmReturn
					});
				}
			}
		}
		
		private function confirmReturn(type:String):void
		{
			if(type == DialogCallback.CONFIRM)
			{
				var oid:String = (product && product.orderid != "")?product.orderid:"";
				
				if(product is ChipsProductVO)
				{
					if(Localization.currentLocaleId == "vn_VN")
					{
						ServiceLocator.httpService.POST({"mod":"vmgPay", "act":"getOrderId","payType":"1","stab":product.localPayData.stab,"id":product.smsLocalPayPhoneNum,"oid":oid}, vmgPayCallback, vmgPayCallback, vmgPayCallback);
					}
					else if(Localization.currentLocaleId == "id_ID")
					{
						ServiceLocator.httpService.POST({"mod":"zingPay", "act":"getOrderId","payType":"1","stab":product.localPayData.stab,"id":product.smsLocalPayPhoneNum,"oid":oid}, vmgPayCallback, vmgPayCallback, vmgPayCallback);
					}
				}else if((product is PropsProductVO)&&(storePopup.getTab()!=0)&&(storePopup.getTab()==3))
				{
					if(Localization.currentLocaleId == "vn_VN")
					{
						ServiceLocator.httpService.POST({"mod":"vmgPay", "act":"getOrderId","payType":"3","stab":product.localPayData.stab,"id":product.smsLocalPayPhoneNum,"oid":oid}, vmgPayCallback, vmgPayCallback, vmgPayCallback);
					}
					else if(Localization.currentLocaleId == "id_ID")
					{
						ServiceLocator.httpService.POST({"mod":"zingPay", "act":"getOrderId","payType":"3","stab":product.localPayData.stab,"id":product.smsLocalPayPhoneNum,"oid":oid}, vmgPayCallback, vmgPayCallback, vmgPayCallback);
					}
					
				}else if((product is PropsProductVO)&&(storePopup.getTab()!=0)&&(storePopup.getTab()==4))
				{
					if(Localization.currentLocaleId == "vn_VN")
					{
						ServiceLocator.httpService.POST({"mod":"vmgPay", "act":"getOrderId","payType":"4","stab":product.localPayData.stab,"id":product.smsLocalPayPhoneNum,"oid":oid}, vmgPayCallback, vmgPayCallback, vmgPayCallback);
					}
					else if(Localization.currentLocaleId == "id_ID")
					{
						ServiceLocator.httpService.POST({"mod":"zingPay", "act":"getOrderId","payType":"4","stab":product.localPayData.stab,"id":product.smsLocalPayPhoneNum,"oid":oid}, vmgPayCallback, vmgPayCallback, vmgPayCallback);
					}
				}
				else
				{
					if(Localization.currentLocaleId == "vn_VN")
					{
						ServiceLocator.httpService.POST({"mod":"vmgPay", "act":"getOrderId","payType":"2","stab":product.localPayData.stab,"id":product.smsLocalPayPhoneNum,"oid":oid}, vmgPayCallback, vmgPayCallback, vmgPayCallback);
					}
					else if(Localization.currentLocaleId == "id_ID")
					{
						ServiceLocator.httpService.POST({"mod":"zingPay", "act":"getOrderId","payType":"2","stab":product.localPayData.stab,"id":product.smsLocalPayPhoneNum,"oid":oid}, vmgPayCallback, vmgPayCallback, vmgPayCallback);
					}
				}
			}
		}
		
		private var isBusy:Boolean = false;
		private var vmgPayData:Object;
		private var timeOutNum:int = -1;
		private function vmgPayCallback(value:String):void
		{
			try
			{
				vmgPayData = JSON.parse(value) as Object;
			}
			catch (err:Error)
			{
				FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP, false, {"message" : Localization.getText("STORE.STORE_LOCAL_PAY_SMS_SEND_FAILE")});
			}
			if(vmgPayData && vmgPayData.hasOwnProperty("ret") && vmgPayData.ret == 0)
			{
				if(isBusy)
				{
					FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP, false, {"message" : Localization.getMap("STORE.BUY_RESULT_MSG")["-95"].getText()});
				}
				else
				{
					sendSMSFun();
				}
			}
			else
			{
				FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP, false, {"message" : Localization.getText("STORE.STORE_LOCAL_PAY_SMS_SEND_FAILE")});
			}
		}
		
		private function sendSMSFun():void
		{
			//发送短信
			logger.info("send sms to 106588992 with content(", vmgPayData.Message, ") length:", vmgPayData.Message.length);
			FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP, false, {"message" : Localization.getText("STORE.STORE_LOCAL_PAY_SMS_SENDING")});
			if(CommonUtils)
			{
				isBusy = true;
				CommonUtils.instance.sendSmsDirectly(vmgPayData.sid, vmgPayData.Message, smsSendCallback);
				vmgPayData = null;
				timeOutNum = setTimeout(function():void{
					if(isBusy)
					{
						isBusy = false;
					}
				},5000);
			}
		}
		
		private function smsSendCallback(success:Boolean):void
		{
			isBusy = false;
			clearTimeout(timeOutNum);
			if(success)
			{
				FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP, false, Localization.getText("STORE.STORE_LOCAL_PAY_SMS_SEND_SUCC"));
			}
			else
			{
				FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP, false, Localization.getText("STORE.STORE_LOCAL_PAY_SMS_SEND_FAILE"));
			}
		}
		
		//mimopay支付
		private var textInputPage:StorePopUpAccountInputPage = new StorePopUpAccountInputPage();
		private function mimopayCallback(value:String):void
		{
			var data:Object;
			try
			{
				data = JSON.parse(value) as Object;
			}
			catch(err:Error) {
				logger.info("mimopay_getOrderId error");
			}
			if(data && data.ret == 0 && product)
			{
				FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP,false,{"message" : Localization.getMap("STORE.BUY_RESULT_MSG")["-95"].getText()});
				var userdata:Object = Model.instance.getData(ModelKeys.USER_DATA);
				MimopayAndroidPurchaseService.instance.initialize(userdata.uid,product.localPayPrice,data.orderId,product.localPayUnit);
				MimopayAndroidPurchaseService.instance.enableLog(true);
				MimopayAndroidPurchaseService.instance.enableGateway(true);
				if(product.localPayData && product.localPayData.stab == "upoint")
				{
					textInputPage.show(product);
				}
				else if(product.localPayData && product.localPayData.stab == "atm_bca")
				{
					TaskExecutor.instance.callLater(function():void {
						MimopayAndroidPurchaseService.instance.executeATMs(product.localPayData.stab,product.localPayPrice);
					}, 10);
				}
				else if(product.localPayData && product.localPayData.stab == "atm_bersama")
				{
					TaskExecutor.instance.callLater(function():void {
						MimopayAndroidPurchaseService.instance.executeATMs(product.localPayData.stab,product.localPayPrice);
					}, 10);
				}
				else
				{
					TaskExecutor.instance.callLater(function():void {
						MimopayAndroidPurchaseService.instance.executeTopup(product.localPayData.stab);
					}, 10);
				}
			}
		}
		
		private function onUserLoggedIn(evt:Event):void
		{
			loading = false;
			isProductLoaded = false;
			isBusy = false;
			model.clearData(ModelKeys.STORE_BUY_HISTORY);
			model.clearData(ModelKeys.STORE_PRODUCT_LIST_CHIPS);
			model.clearData(ModelKeys.STORE_PRODUCT_LIST_BY);
			model.clearData(ModelKeys.STORE_PRODUCT_LIST_PROPS);
			model.clearData(ModelKeys.STORE_PRODUCT_LIST_VIPS);
			
			loadPropsConfig();
			
			setTimeout(loadPayConfig, 500);
			getPurchaseDiscount();
			
			var postData:Object = {"mod": "break", "act": "getInfo"};
			ServiceLocator.httpService.POST(postData, userCrashCallback);
		}
		
		private var postCounts:int = 4;
		private function userCrashCallback(data:String):void
		{
			if(data)
			{
				var returnObj:Object = JSON.parse(data) as Object;
				if(returnObj.ret < 0)//返回错误
				{
					postCounts--;
					if(postCounts <= 0)
					{
						return;
					}
					Model.instance.setData(ModelKeys.USER_CASH_DISCOUNT_DATA,null);
					var postData:Object = {"mod": "break", "act": "getInfo"};
					ServiceLocator.httpService.POST(postData, userCrashCallback);
				}
				else if(returnObj.ret == 1) //有优惠
				{
					Model.instance.setData(ModelKeys.USER_CASH_DISCOUNT_DATA,returnObj.info);
				}
				else if(returnObj.ret == 0)
				{
					Model.instance.setData(ModelKeys.USER_CASH_DISCOUNT_DATA,null);
				}
			}
		}
		
		private function loadPayConfig():void
		{
			if(!loading && !isProductLoaded && userData)
			{
				loading = true;
				var payConfigUrl:String;
				if (userData["channel"] == "ios_appota")
				{
					payConfigUrl = userData["APPOTA_CONF"];
				}
				else
				{
					payConfigUrl = userData["PAY_CONF"];
				}
				remoteCacheService.cacheXML(payConfigUrl, parsePayConfig, function(err:* = null):void {
					loading = false;
					model.setData(ModelKeys.STORE_PRODUCT_LIST_CHIPS, Localization.getText("COMMON.PHP_REQUEST_ERROR_MSG"));
					model.setData(ModelKeys.STORE_PRODUCT_LIST_BY, Localization.getText("COMMON.PHP_REQUEST_ERROR_MSG"));
					model.setData(ModelKeys.STORE_PRODUCT_LIST_PROPS, Localization.getText("COMMON.PHP_REQUEST_ERROR_MSG"));
					model.setData(ModelKeys.STORE_PRODUCT_LIST_VIPS, Localization.getText("COMMON.PHP_REQUEST_ERROR_MSG"));
				});
			}
		}
		
		private function parsePayConfig(xml:XML):void
		{
			var propList:XMLList = xml.props.prop;
			var chipList:XMLList = xml.chips.chip;
			var coalaaList:XMLList = xml.coalaas.coalaa;
			var vipList:XMLList = xml.cards.card;
			var tmp:XML;
			
			var propsArr:Array = [];
			var chipArr:Array = [];
			var coalaaArr:Array = [];
			var vipArr:Array = [];
			
			var purchaseService:IPurchaseService = getPurchaseService();
			
			for each(tmp in propList)
			{
				if(tmp.id[0] > 0)
				{
					var props:PropsProductVO = new PropsProductVO();
					props.fromXML(tmp);
					purchaseService.postProductConstruct(props, tmp);
					propsArr.push(props);
				} else {
					logger.info("ignore product => ", tmp.id[0]);
				}
			}
			
			for each(tmp in chipList)
			{
				if(tmp.id[0] > 0)
				{
					var chips:ChipsProductVO = new ChipsProductVO();
					chips.fromXML(tmp);
					purchaseService.postProductConstruct(chips, tmp);
					chipArr.push(chips);
				} else {
					logger.info("ignore product => ", tmp.id[0]);
				}
			}
			
			for each(tmp in coalaaList)
			{
				if(tmp.id[0] > 0)
				{
					var coalaa:CoalaaProductVO = new CoalaaProductVO();
					coalaa.fromXML(tmp);
					purchaseService.postProductConstruct(coalaa, tmp);
					coalaaArr.push(coalaa);
				} else {
					logger.info("ignore product => ", tmp.id[0]);
				}
			}
			
			for each(tmp in vipList)
			{
				if(tmp.id[0] > 0)
				{
					var vip:PropsProductVO = new PropsProductVO();
					vip.fromXML(tmp);
					purchaseService.postProductConstruct(vip, tmp);
					vipArr.push(vip);
				} else {
					logger.info("ignore product => ", tmp.id[0]);
				}
			}
			
			purchaseService.postProductConfigLoaded(chipArr, coalaaArr, propsArr, vipArr, function():void {
				loading = false;
				logger.info("显示商城信息", chipArr);
				model.setData(ModelKeys.STORE_PRODUCT_LIST_CHIPS, chipArr);
				model.setData(ModelKeys.STORE_PRODUCT_LIST_BY, coalaaArr);
				model.setData(ModelKeys.STORE_PRODUCT_LIST_PROPS, propsArr);
				model.setData(ModelKeys.STORE_PRODUCT_LIST_VIPS, vipArr.length > 0 ? vipArr : Localization.getText("HALL.CAN_NOT_FIND_MATCH"));
				isProductLoaded = true;
				context.dispatchEventWith(CommandEventNames.ROOM_GET_USER_PROPS);
			});
		}
		
		private function loadPropsConfig():void
		{
			remoteCacheService.cacheXML(userData["PROPS_ROOT"], parsePropsConfig,null);
		}
		
		private function parsePropsConfig(xml:XML):void
		{
			model.setData(ModelKeys.STORE_PRODUCT_LIST_PROPS_ALL, xml);
		}
		
		private function loadUserBuyHistory():void
		{
			model.clearData(ModelKeys.STORE_BUY_HISTORY);
			
			httpService.POST({"mod":"user","act":"getpay", "channel" : userData.channel}, function(data:String):void {
				var json:Object = JSON.parse(data);
				var payRecordArr:Array = [];
				var payRecord:PayRecordVO;
				for each(var obj:Object in json) {
					payRecord = new PayRecordVO(obj);
					payRecordArr.push(payRecord);
				}
				
				model.setData(ModelKeys.STORE_BUY_HISTORY, payRecordArr);
			}, function(arg:* = null):void {
				model.setData(ModelKeys.STORE_BUY_HISTORY, Localization.getText("COMMON.PHP_REQUEST_ERROR_MSG"));
			});
		}
		
		private function getPurchaseService():IPurchaseService
		{
			return ServiceLocator.findService(IPurchaseService)[0] as IPurchaseService;
		}
	}
}


