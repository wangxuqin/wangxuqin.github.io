--[Comment]
--常用函数
CommonFunction = {};

CommonFunction.getEnterRoomData = function()
    CommonFunction.enterRoomData = CommonFunction.enterRoomData or 
        {["playNow"] = false, ["enterFrom"] = 1, ["roomInfo"] = nil};
    return CommonFunction.enterRoomData;
end
		
CommonFunction.enterRoom = function()
	EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.PREPARE_LOGIN_ROOM, CommonFunction.getEnterRoomData());
end

--[Comment]
--跳转场景
CommonFunction.gotoScene = function(destState, delay)
    delay = delay or 0;
	if StateMachine.getInstance():getCurrentState() ~= destState then
	    local srcState = StateMachine.getInstance():getCurrentState();
	    local sceneCmd = StateService.sceneMap[StateService.key(srcState, destState)];
        if sceneCmd ~= nil then
            if delay > 0 then
		        TaskKit.schedule(delay,nil,function()
			        EventDispatcher.getInstance():dispatch(SceneNavEvent.s_event, sceneCmd);
		        end);
	        else
		        EventDispatcher.getInstance():dispatch(SceneNavEvent.s_event, sceneCmd);
	        end
        end
    end
end
		
		
CommonFunction.playNow = function(enterFrom)
    enterFrom = enterFrom or -1;
	if StateMachine.getInstance():getCurrentState() == States.Room then
		local controller = StateMachine.getInstance():getCurrentController();
        controller.m_view:playNow(enterFrom);
	else
		UIControl:removeAllPopup();
		CommonFunction.directPlayNow(enterFrom);
	end
end
		
CommonFunction.directPlayNow = function(enterFrom)
    enterFrom = enterFrom or -1;
	enterFrom = (enterFrom > 0) and enterFrom or CommonFunction.getEnterFrom();
	CommonFunction.gotoScene(States.Room, 200);
	EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.PREPARE_LOGIN_ROOM, {["playNow"] = true, ["enterFrom"]= enterFrom});
end
		
CommonFunction.getEnterFrom = function(state)
	state = (state ~= nil) and state or StateMachine.getInstance():getCurrentState();
    local ret = RequestLoginData.MAIN_PAGE;
	if state == States.NormalHall then
        ret = RequestLoginData.NormalHall;
    end
    return ret;
end