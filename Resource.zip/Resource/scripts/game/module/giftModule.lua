--[Comment]
--礼物模块
GiftModule = {}
GiftModule.TAG = "GiftModule";
GiftModule.s_eventList = {
    {CommandEvent, CommandEvent.s_cmd.OPEN_GIFT_POPUP,               "onOpenGiftPopup"};
	{CommandEvent, CommandEvent.s_cmd.USER_LOGGED_IN,                "onUserLoggedIn"};
	{CommandEvent, CommandEvent.s_cmd.GIFT_USE,                      "onGiftUse"};
	{CommandEvent, CommandEvent.s_cmd.GIFT_BUY_FOR_SELF,             "onBuyGiftForSelf"};
	{CommandEvent, CommandEvent.s_cmd.GIFT_BUY_FOR_PERSON,           "onBuyGiftForPerson"};
	{CommandEvent, CommandEvent.s_cmd.GIFT_BUY_FOR_TABLE,            "onBuyGiftForTable"};
	{CommandEvent, CommandEvent.s_cmd.SALE_OVERDUE_GIFT,             "onSaleOverdueGift"};
	{CommandEvent, CommandEvent.s_cmd.QUICKLY_SALE_ALL_OVERDUE_GIFT, "qucikSaleAllDueGift"};
    {CommandEvent, CommandEvent.s_cmd.GIFT_CATEGORY_TAG_CHANGE,      "onCategoryTagChange"};
    {CommandEvent, CommandEvent.s_cmd.GIFT_DIALPG_ON_POPUP_END,      "onGiftDialogPopupEnd"};
};


GiftModule.initialize = function()
	GiftModule.m_giftIdFileMapping = {};
	Model.setData(ModelKeys.GIFT_ID_FILE_MAPPING, GiftModule.m_giftIdFileMapping);	
	EventDispatcher.getInstance():registerEventList(GiftModule, GiftModule.s_eventList);
    GiftModule.m_selectedCategory     = "bychip"; -- 上边第一个选项 -> 筹码礼物
    GiftModule.m_myGiftSelectedTag    = "0";      -- 左边第一个选项 - > 全部(我的礼物)
    GiftModule.m_selectedTag          = "0";      -- 左边第一个选项 - > 全部 
end
		
		
--[Comment]
--销售礼物	
GiftModule.onSaleOverdueGift = function(self, data)
	self.m_giftId   = data["id"];
	local giftType  = data["type"];
	local info      = self.m_giftId .. ":" .. giftType;
	local postData  = {["mod"] = "shop",["act"] = "sell", ["id"] = info};
	HttpService.post(postData,self, self.resultCallback,self.errorCallback, self.errorCallback);
end

--[Comment]		
--一键出售所有礼物
GiftModule.qucikSaleAllDueGift = function(self)
	local array         = Model.getData(ModelKeys.GIFT_ALL_DATA);
	self.m_dueGiftlist  = Model.getData(ModelKeys.GIFT_LIST_OWNED);	
	if array ~= nil and self.m_dueGiftlist ~= nil then
	    for i = 1, #array do
			for j = 1, #self.m_dueGiftlist do
				if array[i]["type"] == "1" and self.m_dueGiftlist[j].giftType == "2" then     --找出即使筹码购买的而且是过期的礼物 giftVO中字段type 改为 types
					if array[i].id == self.m_dueGiftlist[j].id then	                        -- 根据过期的礼物id找出与之对应的礼物id的价格
						self.m_salePrice = self.m_salePrice + math.floor((array[i].price) * 30 / 100);
					end	
					
                elseif array[i]["type"]== "2" and self.m_dueGiftlist[j].giftType=="2" then   --找出即使卡拉比购买的而且是过期的礼物
					if array[i].id == self.m_dueGiftlist[j].id then                                --根据过期的礼物id找出与之对应的礼物id的价格
						local current = tonumber(STR_COMMON_CURRENCY_MULTIPLE);
						self.m_salePrice = self.m_salePrice + math.floor( (array[i].price) * 30/100 * current * 2000);
					end
				end
			end
         end
	end
			
	EventDispatcher.getInstance():dispatch(
        UIEvent.s_event,
        UIEvent.s_cmd.OPEN_DIALOG, {
		    ["message"]     = StringKit.substitute(STR_GIFT_SALE_ALL_DUE_GIFT_PRICE_PROMPT ,Formatter.formatBigNumber(self.m_salePrice)), 
		    ["confirm"]     = STR_COMMON_CONFIRM,
            ["obj"]         = self,
		    ["callback"]    = self.qucikSaleAllDueGiftCallback,
	});
end

GiftModule.qucikSaleAllDueGiftCallback = function(self, types)
	if types == DialogCallback.CONFIRM then
		local infoArray = {};
		for i = 1 , #self.m_dueGiftlist do
			if self.m_dueGiftlist[i].giftType == "2" then
                ArrayKit.push(infoArray, self.m_dueGiftlist[i].id .. ":" .. self.m_dueGiftlist[i]["type"]);
			end
		end
		local info = StringKit.join(infoArray, ",");
		local postData = {["mod"] = "shop", ["act"] = "sell", ["id"] = info};
		self.m_salePrice = 0;
		HttpService.post(postData, self, self.resultDueGiftCallback, self.errorCallback, self.errorCallback);
	else
		self.m_salePrice = 0;  -- 取消弹框时候将 价格从新置为0;
	end
end

GiftModule.resultDueGiftCallback = function(self, data)
	if data ~= nil then
		local flag, saleDueGiftData = JsonKit.decode(data);
		if flag then
			if saleDueGiftData.ret == 1 then
				EventDispatcher.getInstance():dispatch(
                    UIEvent.s_event,
                    UIEvent.s_cmd.SHOW_TOP_TIP,
                    STR_GIFT_GIFT_SALE_SUCCEED);
						
				for i = 1, #self.m_dueGiftlist do
					if self.m_dueGiftlist.giftType == "2" then    --找出过期礼物
                        ArrayKit.splice(self.m_dueGiftlist, i, 1);
					end
				end
				Model.setData(ModelKeys.GIFT_LIST_OWNED, self.m_dueGiftlist);
				self:onCategoryTagChange();
		    else
				EventDispatcher.getInstance():dispatch(
                     UIEvent.s_event,
                     UIEvent.s_cmd.SHOW_TOP_TIP,
                     STR_GIFT_GIFT_SALE_FAIL);
			end	
	    else
			Log.e(self.TAG, "resultDueGiftCallback", "decode json has an error occurred!");
		end
	else
		EventDispatcher.getInstance():dispatch(
            UIEvent.s_event,
            UIEvent.s_cmd.SHOW_TOP_TIP, 
            STR_GIFT.GIFT_SALE_FAIL);
	end
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_GIFT_DIALOG);
end
		
GiftModule.errorCallback = function(self)
	TopTipKit.badNetworkHandler();
end
		
GiftModule.resultCallback = function(self, data)
	if data ~= nil then
        local flag, saleGiftData = JsonKit.decode(data);
		if flag then
			if saleGiftData.ret == 1 then
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP,STR_GIFT_GIFT_SALE_SUCCEED);
				local giftlist = Model.getData(ModelKeys.GIFT_LIST_OWNED);
				for i = 1, #giftlist do
					if giftlist[i].id == self.m_giftId then
                        ArrayKit.splice(giftlist, i, 1);
					end
				end
				Model.setData(ModelKeys.GIFT_LIST_OWNED, giftlist);
				self:onCategoryTagChange();
			else
				EventDispatcher.getInstance():dispatch(
                    UIEvent.s_event,
                    UIEvent.s_cmd.SHOW_TOP_TIP, STR_GIFT_GIFT_SALE_FAIL);
			end		
		else
			Log.e(self.TAG, "resultCallback", "decode json has an error occurred!");
		end
	else
		EventDispatcher.getInstance():dispatch(
            UIEvent.s_event, 
            UIEvent.s_cmd.SHOW_TOP_TIP,
            STR_GIFT_GIFT_SALE_FAIL);
	end	
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_GIFT_DIALOG);
end
		
--[Comment]
--弹出礼物窗口
GiftModule.onOpenGiftPopup = function(self, data)
    local params = {};
	params.isInRoom = data.isInRoom;
	params.userId = data.uid;
	params.seatId = data.seatId;
	params.userNick = data.userNick;
    if data["tabId"] ~= nil then
        params.tabId = data["tabId"];
    end
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_GIFT_DIALOG, params);
end

--[Comment]
--礼物窗口弹出后，开始初始化礼物数据(为了解耦这样做。。。)
GiftModule.onGiftDialogPopupEnd = function(self)
    self:cacheGiftXML();
	self:setMyGiftDisplayingData();
end
		
--[Comment]
--用户登录处理，清理前一个用户的数据，及状态，
GiftModule.onUserLoggedIn = function(self, data)
	self.m_buzy = false;
    self.m_loadDueBuzy = false;
	self.m_loadOwnBuzy = false;
	Model.clearData(ModelKeys.GIFT_LIST_DISPLAYING);
	Model.clearData(ModelKeys.GIFT_LIST_OWNED);
	self:cacheGiftXML();
end
		
--[Comment]
--使用礼物
GiftModule.onGiftUse = function(self, data)
	local giftId     = data.giftId;
	local showTips   = data.showTips or false;
	local postData   = {["mod"] =  "shop", ["act"] =  "setHeadGift", ["id"] = giftId};
	HttpService.post(postData, _, function (ret)
        if showTips and ret then
		    EventDispatcher.getInstance():dispatch(
                UIEvent.s_event,
                UIEvent.s_cmd.SHOW_TOP_TIP, STR_GIFT_USE_GIFT_RESULT_MSG[ret]);
	    end
        
	    if ret == "1" then
            Model.getData(ModelKeys.USER_DATA).user_gift = giftId;
		    EventDispatcher.getInstance():dispatch(
                CommandEvent.s_event, 
                CommandEvent.s_cmd.GIFT_NOTIFY_GIFT_USED, self.m_giftId);
	    end
    end , TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_GIFT_DIALOG);
end
		
--[Comment]
-- 给自己买礼物
GiftModule.onBuyGiftForSelf = function(self, data)
	--如果是新手引导，不处理购买礼物事件
	if TutotiaKit.isTutotia then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_GIFT_DIALOG);
		return;
	end
    local giftId    = data;
	local postData  = {["mod"] =  "shop", ["act"] = "pay", ["id"] = giftId};
	HttpService.post(postData, _, function (ret)
        local flag, jsonObj = JsonKit.decode(ret);
	    if flag then
            if jsonObj then
			    if jsonObj.ret == "1" then
				    EventDispatcher.getInstance():dispatch(
                        CommandEvent.s_event,
                        CommandEvent.s_cmd.GIFT_USE, {["giftId"] = giftId, ["showTips"] = false});
			    end
			    EventDispatcher.getInstance():dispatch(
                UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_GIFT_BUY_GIFT_RESULT_MSG[jsonObj.ret]);
			    self:loadOwnGift();
			    self:setDisplayingData();
		    end
	    else
            Log.e(self.TAG, "onBuyGiftForSelf", "decode json has an error occurred!");
        end
    end, TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_GIFT_DIALOG);
end

		
--[Comment]
--赠送一个人礼物
GiftModule.onBuyGiftForPerson = function(self, data)
	--如果是新手引导，不处理购买礼物事件
	if TutotiaKit.isTutotia then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_GIFT_DIALOG);
		return;
	end
	local selfSeatId = SeatManager.selfSeatId;
	if selfSeatId == -1 and data.is_in_room then    --如果在房间里，并且没有坐下不能赠送礼物
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_GIFT_GIFT_MSG_ARR[0]);
		return;
	end
	local giftId = data.id;
	local toPersonId = data.uid;	
	local toSeatId = data.seatId;
	local postData = {["mod"] = "shop", ["act"] = "present", ["list"] = toPersonId, ["id"] = giftId};
	HttpService.post(postData, _, function(ret)
        local flag, jsonObj = JsonKit.decode(ret);
	    if flag then
            if jsonObj then
			    if jsonObj.ret == "1" then
				    EventDispatcher.getInstance():dispatch(
                        CommandEvent.s_event,
                        CommandEvent.s_cmd.GIFT_NOTIFY_GIFT_FOR_TABLE, {["giftId"] = giftId, ["userIds"] = {toPersonId}, ["seatIds"] = {toSeatId}});
			    end
			    EventDispatcher.getInstance():dispatch(
                UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_GIFT_BUY_GIFT_TO_TABLE_RESULT_MSG[jsonObj.ret]);
		    end
	    else
            Log.e(self.TAG, "onBuyGiftForPerson", "decode json has an error occurred!");
        end 
    end, TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_GIFT_DIALOG);
end
		
--[Comment]
--给桌上的人买礼物
GiftModule.onBuyGiftForTable = function(self, data)
	--如果是新手引导，不处理购买礼物事件
	if TutotiaKit.isTutotia then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_GIFT_DIALOG);
		return;
	end
	local sitDowUsers = Model.getData(ModelKeys.ROOM_SIT_DOWN_USERS);
	local userIds = {};
	local seatIds = {};
	local giftId = data;
	local foundSelf = false;
	if sitDowUsers then
        for i, seat in ipairs(sitDowUsers) do
            ArrayKit.push(userIds, seat.seatData.uid);
            ArrayKit.push(seatIds, seat.seatId);
            if seat.seatData.uid == Model.getData(ModelKeys.USER_DATA).uid then
                foundSelf = true;
            end
        end
	end
	if not foundSelf then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_GIFT_GIFT_MSG_ARR[0]);
		return;
	end
	local postData = {["mod"] = "shop", ["act"] = "present", ["list"] = StringKit.join(userIds, ","), ["id"] = giftId};
	HttpService.post(postData, _, function(ret) 
        local flag, jsonObj = JsonKit.decode(ret);
	    if flag then
            if jsonObj then
			    if jsonObj.ret == "1" then
				    EventDispatcher.getInstance():dispatch(
                        CommandEvent.s_event,
                        CommandEvent.s_cmd.GIFT_NOTIFY_GIFT_FOR_TABLE, {["giftId"] = giftId, ["userIds"] = userIds, ["seatIds"] = seatIds});
			    end
			    EventDispatcher.getInstance():dispatch(
                UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_GIFT_BUY_GIFT_TO_TABLE_RESULT_MSG[jsonObj.ret]);
		    end
            if ArrayKit.indexOf(userIds, Model.getData(ModelKeys.USER_DATA).uid) ~= -1 then
                EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.GIFT_USE, {["giftId"] = giftId, ["showTips"] = false});
                self:loadOwnGift();
			    self:setDisplayingData();
            end
	    else
            Log.e(self.TAG, "onBuyGiftForTable", "decode json has an error occurred!");
        end 
	end, TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_GIFT_DIALOG);
end

--[Comment]
--当前显示的Tab或分类改变处理，取对应类型的数据，放到显示礼物列表中	"bychip","bycoalaa","mygift"
GiftModule.onCategoryTagChange = function(self, data)
    if data == nil then
        return;
    end
    if data.selectedCategory then
        self.m_selectedCategory = data.selectedCategory;
    end
    if data.myGiftSelectedTag then
        self.m_myGiftSelectedTag = data.myGiftSelectedTag;
    end
    if data.selectedTag then
        self.m_selectedTag = data.selectedTag;
    end
	if not self.m_buzy then
		if self.m_selectedCategory == "mygift" then
			self:setMyGiftDisplayingData();
		elseif ArrayKit.indexOf({"bychip", "bycoalaa"}, self.m_selectedCategory) ~= -1 then
			if not self:getGiftData() or self:getGiftData() == STR_COMMON_PHP_REQUEST_ERROR_MSG then
				self:cacheGiftXML();
			end
		end
	end	
	self:setDisplayingData();
end
		
		
GiftModule.setMyGiftDisplayingData = function(self)
	if self.m_myGiftSelectedTag == "0" then
		self:loadOwnGift();
        EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.GIFT_SALE_BUTTON_STATUS_CHANGE_DARK);
	elseif self.m_myGiftSelectedTag =="1" then
		self:loadDueGift();
	end
end
		
GiftModule.setDisplayingData = function(self)
	local category  = self.m_selectedCategory;
	local tag       = self.m_selectedTag;
    local giftData  = self:getGiftData();	
	if category == "bychip" then
		if giftData == nil then
			Model.clearData(ModelKeys.GIFT_LIST_DISPLAYING);
		elseif type(giftData) == "string" then 
			Model.setData(ModelKeys.GIFT_LIST_DISPLAYING, giftData);
		elseif not giftData["bychip"][tag] or type(giftData["bychip"][tag]) == "table" and #giftData["bychip"][tag] == 0 then
			Model.setData(ModelKeys.GIFT_LIST_DISPLAYING, STR_GIFT_NO_GIFT_INFO_HINT);
		else
			Model.setData(ModelKeys.GIFT_LIST_DISPLAYING, giftData["bychip"][tag]);
		end
	elseif category == "bycoalaa" then
		if giftData == nil then
			Model.clearData(ModelKeys.GIFT_LIST_DISPLAYING);
		elseif type(giftData) == "string" then 
			Model.setData(ModelKeys.GIFT_LIST_DISPLAYING, giftData);
        elseif not giftData["bycoalaa"][tag] or type(giftData["bycoalaa"][tag]) == "table" and #giftData["bycoalaa"][tag] == 0 then
			Model.setData(ModelKeys.GIFT_LIST_DISPLAYING, STR_GIFT_NO_GIFT_INFO_HINT);
		else
			Model.setData(ModelKeys.GIFT_LIST_DISPLAYING, giftData["bycoalaa"][tag]);
        end
	elseif category == "mygift" then
		Model.setData(ModelKeys.GIFT_LIST_DISPLAYING, self:getMyGiftList());
	end
end
			
GiftModule.getGiftData = function(self)
	return Model.getData(ModelKeys.GIFT_DATA);
end
		
GiftModule.getMyGiftList = function(self)
	return Model.getData(ModelKeys.GIFT_LIST_OWNED);
end
	
--[Comment]
--xml需要转换成lua，还没做    	
GiftModule.cacheGiftXML = function (self)
	--XML类别 1 精品 2 礼物 3 节日 4 其他 5娱乐
	--可供选择的类别 0 全部 1 精品 2 节日 3 娱乐 4 其他
	local tagMapping = {["1"] = "1", ["2"] = "4", ["3"] = "2", ["4"] = "4", ["5"] = "3"};--类型映射
	if not self.m_buzy then
		if not Model.hasData(ModelKeys.GIFT_DATA) then
			    --self.m_buzy = true;
				self.m_buzy = false;
				local bychip = {};
				local bycoalaa = {};
				local gift = {};
				local array = {};
                local GIFT_CONFIG = require("cache/gift");
				for key, tmp in ipairs(GIFT_CONFIG) do
                    gift = new(GiftVO, tmp);
                    ArrayKit.push(array, gift);
					if tmp.i == nil or string.len(tmp.i) == 0 then
						GiftModule.m_giftIdFileMapping[gift.id] = gift.id;
					else
						GiftModule.m_giftIdFileMapping[gift.id] = tmp.i;
					end
					if gift["type"] == "1" and gift.price ~=0 then
						if not bychip[tagMapping[gift.tag]] then
                            if tagMapping[gift.tag] then
                                bychip[tagMapping[gift.tag]] = {gift};
                            end
						else
                            ArrayKit.push(bychip[tagMapping[gift.tag]], gift);
						end
						if not bychip["0"] then
							bychip["0"] = {gift};
						else
                            ArrayKit.push(bychip["0"], gift);
						end
					elseif (gift["type"] == "2") and (gift.price ~= 0) then
						if not bycoalaa[tagMapping[gift.tag]] then
							bycoalaa[tagMapping[gift.tag]] = {gift};
						else
                            ArrayKit.push(bycoalaa[tagMapping[gift.tag]], gift);
						end
						if not bycoalaa["0"] then
							bycoalaa["0"] = {gift};
						else
                            ArrayKit.push(bycoalaa["0"], gift);
						end
					end
				end
				Model.setData(ModelKeys.GIFT_ALL_DATA,array);
				Model.setData(ModelKeys.GIFT_DATA, {["bychip"] = bychip, ["bycoalaa"] = bycoalaa});
				self:setDisplayingData();
		end
	end
end
		
GiftModule.loadDueGift = function (self)
	Model.clearData(ModelKeys.GIFT_LIST_OWNED);
	if not self.m_loadDueBuzy then
		self.m_loadDueBuzy = true;
		HttpService.post({["mod"] = "user", ["act"] = "getUserGiftNew"}, _, function(ret)
			loadDueBuzy = false;
			if self.m_myGiftSelectedTag == "1" then
				if ret ~= "0" then
                    local flag, jsonObj = JsonKit.decode(ret);
                    if flag then
                        local list = {};
                        if jsonObj.c then
                            for key, obj2 in ipairs(jsonObj.c) do
                                local giftVO = {};
							    giftVO.expire   = obj2.expire;
							    giftVO.name     = obj2.desc;
							    giftVO.id       = obj2.id;
							    giftVO["type"]  = obj2["type"];
							    giftVO.time     = obj2.time;
							    giftVO.isOwn    = true;
							    giftVO.giftType = "2";
                                ArrayKit.push(list, giftVO);
                            end
                        end
                        if #list == 0 then
                            Model.setData(ModelKeys.GIFT_LIST_OWNED, STR_GIFT_NO_OWN_DUE_GIFT_HINT);
                            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.GIFT_SALE_BUTTON_STATUS_CHANGE_DARK);
                        else
                            Model.setData(ModelKeys.GIFT_LIST_OWNED, list);
                            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.GIFT_SALE_BUTTON_STATUS_CHANGE_LIGHT);
                        end
                        self:setDisplayingData();
                        return;
                    else
                        Log.e(self.TAG, "loadDueGift", "decode json has an error occurred!");
                    end
				end
			end
		end, self.loadDueGiftErrorHandler, self.loadDueGiftErrorHandler);
	end
end
		
GiftModule.loadOwnGift = function(self)
	Model.clearData(ModelKeys.GIFT_LIST_OWNED);
	if not self.m_loadOwnBuzy then
		self.m_loadOwnBuzy = true;
		HttpService.post({["mod"] = "user", ["act"] = "getUserGiftNew"}, _, function(ret)
			self.m_loadOwnBuzy = false;
			if self.m_myGiftSelectedTag == "0" then
				if ret ~= "0" then
                    local flag, jsonObj = JsonKit.decode(ret);
                    if flag then
                        local list = {};
                        if jsonObj.a then
                            for key, obj in ipairs(jsonObj.a) do
                                if obj.expire > jsonObj.time then
                                    local giftVO = {};
							        giftVO.expire   = obj.expire;
							        giftVO.name     = obj.desc;
							        giftVO.id       = obj.id;
							        giftVO["type"]  = obj["type"];
							        giftVO.time     = obj.time;
							        giftVO.isOwn    = true;
							        giftVO.giftType = "0";
                                    ArrayKit.push(list, giftVO);
                                end
                            end
                        end
                        if jsonObj.b then
                            for key, obj in ipairs(jsonObj.b) do
                                local giftVO = {};
							    giftVO.expire   = obj.expire;
							    giftVO.name     = obj.desc;
							    giftVO.id       = obj.id;
							    giftVO["type"]  = obj["type"];
							    giftVO.time     = obj.time;
							    giftVO.isOwn    = true;
							    giftVO.giftType = "1";
                                ArrayKit.push(list, giftVO);
                            end
                        end
                        if jsonObj.c then
                            for key, obj in ipairs(jsonObj.c) do
                                local giftVO = {};
							    giftVO.expire   = obj.expire;
							    giftVO.name     = obj.desc;
							    giftVO.id       = obj.id;
							    giftVO["type"]  = obj["type"];
							    giftVO.time     = obj.time;
							    giftVO.isOwn    = true;
							    giftVO.giftType = "2";
                                ArrayKit.push(list, giftVO);
                            end
                        end
                        if #list == 0 then
                            Model.setData(ModelKeys.GIFT_LIST_OWNED, STR_GIFT_NO_OWN_DUE_GIFT_HINT);
                        else
                            Model.setData(ModelKeys.GIFT_LIST_OWNED, list);
                        end
                        self:setDisplayingData();
                        return;
                    else
                        Log.e(self.TAG, "loadOwnGift", "decode json has an error occurred!");
                    end 
				end
			end
		end, self.loadOwnGiftErrorHandler, self.loadOwnGiftErrorHandler);
	end
end
		
GiftModule.defaultErrorHandler = function(self, arg1, arg2)
	self.m_buzy = false;
	Model.setData(ModelKeys.GIFT_DATA, STR_COMMON_PHP_REQUEST_ERROR_MSG);
	self:setDisplayingData();
end
		
GiftModule.loadDueGiftErrorHandler = function(self, arg1, arg2)
	self.m_loadDueBuzy = false;
	Model.setData(ModelKeys.GIFT_LIST_OWNED, STR_COMMON_PHP_REQUEST_ERROR_MSG);
	self:setDisplayingData();
end
		
GiftModule.loadOwnGiftErrorHandler = function(self, arg1, arg2)
	self.m_loadOwnBuzy = false;
	Model.setData(ModelKeys.GIFT_LIST_OWNED, STR_COMMON_PHP_REQUEST_ERROR_MSG);
	self:setDisplayingData();
end


--[[

remoteCacheService.cacheXML(Model.getData(ModelKeys.USER_DATA)["GIFT_ROOT"], function(xml) 
				self.m_buzy = false;
				local bychip = {};
				local bycoalaa = {};
				local gift = {};
				local array = {};
				for key, tmp in ipairs(xml.a) do
					gift = tmp;
                    ArrayKit.push(array, gift);
					if #tmp.i == 0 then
						GiftModule.m_giftIdFileMapping[gift.id] = gift.id;
					else
						GiftModule.m_giftIdFileMapping[gift.id] = tmp.i;
					end
					if gift["type"] == "1" and gift.price ~=0 then
						if not bychip[tagMapping[gift.tag]]--[[ then
							bychip[tagMapping[gift.tag]]--[[ = {gift};
						else
                            ArrayKit.push(bychip[tagMapping[gift.tag]]--[[, gift);
						end
						if not bychip["0"] then
							bychip["0"] = {gift};
						else
                            ArrayKit.push(bychip["0"], gift);
						end
					elseif (gift["type"] == "2") and (gift.price ~= 0) then
						if not bycoalaa[tagMapping[gift.tag]] --[[then
							bycoalaa[tagMapping[gift.tag]] --[[= {gift};
						else
                            ArrayKit.push(bycoalaa[tagMapping[gift.tag]]--[[, gift);
						end
						if not bycoalaa["0"] then
							bycoalaa["0"] = {gift};
						else
                            ArrayKit.push(bycoalaa["0"], gift);
						end
					end
				end
				Model.setData(ModelKeys.GIFT_ALL_DATA,array);
				Model.setData(ModelKeys.GIFT_DATA, {["bychip"] = bychip, ["bycoalaa"] = bycoalaa});
				setDisplayingData();
			end, self.defaultErrorHandler);

--]]