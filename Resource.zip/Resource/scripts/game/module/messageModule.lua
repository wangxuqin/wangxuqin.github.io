
		
		private var currentTabIndex:int = 0;
		private var unreadMessageNum:int = 0;
		private var messageType:int = 0;
		
		private var newMessage:NewMessagePopUp;
		
		private var msgVo:MessageVO;

		public function MessageModule()
		{
			super();
		}
		
		public function initialize():void
		{
			var tabGroup:Vector.<PageTabGroupData> = new Vector.<PageTabGroupData>();
			var pageData:PageTabGroupData = new PageTabGroupData(null,Localization.getArray("MESSAGE.MESSAGE_TAB_ITEM"));
			tabGroup.push(pageData);
			
			newMessage=new NewMessagePopUp();
			
			context.addEventListener(CommandEventNames.USER_LOGGED_IN, onUserLoggedIn);
			context.addEventListener(CommandEventNames.MESSAGE_DELETE, onMessageDelete);
			context.addEventListener(CommandEventNames.MESSAGE_I_KNOW, onMessageIKnow);
			context.addEventListener(CommandEventNames.MESSAGE_SEND_DOLL,onSendDoll);
			context.addEventListener(CommandEventNames.NEW_DOSH_BOARD_MESSAGE_NOTICE,loadDoshBoardMessageList);
			context.addEventListener(CommandEventNames.NEW_MESSAGE_NOTICE,loadUserMessageList);
			
			//new message
			context.addEventListener(CommandEventNames.MESSAGE_POP_UP_OPENED,openMessagePopUp);
			
			FrameworkGlobal.context.addEventListener(CommandEventNames.MESSAGE_POP_UP_TOGGLE_CHANGE,toggleGroupChange)
		}
		
		private function onMessageIKnow(evt:Event):void
		{
			var msg:MessageVO = evt.data as MessageVO;
			msg.hasReaded = true;
			model.notifyDataChange(ModelKeys.USER_MESSAGE_DISPLAYING);
			httpService.POST({"mod":"user","act":"readmsg","id":msg.id});
		}
		
		private function onSendDoll(evt:Event):void
		{
			var DollMsg:MessageVO= evt.data as MessageVO;
			DollMsg.hasReaded = true;
			model.notifyDataChange(ModelKeys.USER_MESSAGE_DISPLAYING);
			httpService.POST({"mod":"user","act":"readmsg","id":DollMsg.id});
			httpService.POST({"mod":"doll","act":"get","suid":DollMsg.UserId,"dollid":DollMsg.dollId},getDollCallBack);

		}
		
		private function getDollCallBack(data:*):void
		{
			if(!data||data=="")
			{
				return
			}
			
			if(data=="1")
			{
				FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP,false,Localization.getText("ACTIVITY.ACT_DOLL_COLLECT_PRESENT_DOLL_SUCCEED"));
				
				
			}else if(data=="0")
			{
				FrameworkGlobal.context.dispatchEventWith(UIEventNames.SHOW_TOP_TIP,false,Localization.getText("ACTIVITY.ACT_DOLL_COLLECT_PRESENT_DOLL_INSUFFICIENT_QUANTITY"));
				
			}else
			{
				Utils.badNetworkHandler();
			}
			
		}
		
		private function onMessageDelete(evt:Event):void
		{
			var msg:MessageVO = evt.data as MessageVO;
			var friendMsgList:Array = model.getData(ModelKeys.USER_MESSAGE_LIST_FRIEND);
			var systemMsgList:Array = model.getData(ModelKeys.USER_MESSAGE_LIST_SYSTEM);
			var allMsgList:Array = model.getData(ModelKeys.USER_MESSAGE_LIST_ALL);
			var doshBoardList:Array=model.getData(ModelKeys.DOSH_BOARD_MESSAGE_LIST);
			
			if(friendMsgList && (friendMsgList.indexOf(msg) != -1))
			{
				friendMsgList.splice(friendMsgList.indexOf(msg), 1);
			}
			if(systemMsgList && (systemMsgList.indexOf(msg) != -1))
			{
				systemMsgList.splice(systemMsgList.indexOf(msg), 1);
			}
			if(allMsgList && (allMsgList.indexOf(msg) != -1))
			{
				allMsgList.splice(allMsgList.indexOf(msg), 1);
			}
			if(doshBoardList && (doshBoardList.indexOf(msg)!=-1))
			{
				doshBoardList.splice(doshBoardList.indexOf(msg),1);
			}
			model.notifyDataChange(ModelKeys.USER_MESSAGE_DISPLAYING);
			httpService.POST({"mod":"user", "act":"deletemsg", "id":msg.id,"type":msg.messageType});
		}
		
		private function setDisplayingData():void
		{
			switch(currentTabIndex)
			{
				case 0:
					if(model.hasData(ModelKeys.USER_MESSAGE_LIST_SYSTEM))
					{
						model.setData(ModelKeys.USER_MESSAGE_DISPLAYING, model.getData(ModelKeys.USER_MESSAGE_LIST_SYSTEM));
					}
					break;
				case 1:
					if(model.hasData(ModelKeys.USER_MESSAGE_LIST_FRIEND))
					{
						model.setData(ModelKeys.USER_MESSAGE_DISPLAYING, model.getData(ModelKeys.USER_MESSAGE_LIST_FRIEND));
					}
					break;
				case 2:
					if(model.hasData(ModelKeys.DOSH_BOARD_MESSAGE_LIST))
					{
						model.setData(ModelKeys.USER_MESSAGE_DISPLAYING,model.getData(ModelKeys.DOSH_BOARD_MESSAGE_LIST));
					}
					break;
			}
		}
		
		private function onUserLoggedIn(evt:Event):void
		{
			loading = false;
			doshBoradLoading=false;
			
			model.clearData(ModelKeys.MESSAGE_TEMPLATE);
			model.clearData(ModelKeys.USER_MESSAGE_LIST_ALL);
			model.clearData(ModelKeys.USER_MESSAGE_LIST_FRIEND);
			model.clearData(ModelKeys.USER_MESSAGE_LIST_SYSTEM);
			model.clearData(ModelKeys.USER_MESSAGE_DISPLAYING);
			
			model.clearData(ModelKeys.DOSH_BOARD_MESSAGE_TEMPLATE);
			model.clearData(ModelKeys.DOSH_BOARD_MESSAGE_LIST);
			
			firstLoad = true;
			loadMessageTemplate();
		}
		
		private var doshBoradLoading:Boolean=false;
		private var loading:Boolean = false;
		private var firstLoad:Boolean = false;
		private function loadMessageTemplate():void
		{
			if(!loading)
			{
				if(!model.hasData(ModelKeys.MESSAGE_TEMPLATE))
				{
					loading = true;
					if(userData.hasOwnProperty("MSGTPL_ROOT"))
					{
						remoteCacheService.cacheXML(userData["MSGTPL_ROOT"], function(xml:XML):void {
							loading = false;
							model.setData(ModelKeys.MESSAGE_TEMPLATE, xml);
							
							loadUserMessageList();
						}, defaultErrorHandler);
					}
				} else {
					loadUserMessageList();
				}
			}
			
			if(!doshBoradLoading)
			{
				if(!model.hasData(ModelKeys.DOSH_BOARD_MESSAGE_TEMPLATE))
				{
					doshBoradLoading=true;
					if(userData.hasOwnProperty("mobileDashboardMsg_XML"))
					{
						remoteCacheService.cacheXML(userData["mobileDashboardMsg_XML"],function(xml:XML):void{
							doshBoradLoading = false;
							model.setData(ModelKeys.DOSH_BOARD_MESSAGE_TEMPLATE, xml);
							
							loadDoshBoardMessageList();
						},defaultErrorHandler);
					}
				}else
				{
					loadDoshBoardMessageList();
				}
				
			}
		}
		
		private function loadDoshBoardMessageList():void
		{
			if(doshBoradLoading)
			{
				return;
			}
			
			model.clearData(ModelKeys.DOSH_BOARD_MESSAGE_LIST);
			doshBoradLoading=true;
			httpService.POST({"mod":"msg","act":"dashboard"},function(data:String):void{
				doshBoradLoading=false;
				var doshBoradDate:Object=null;
				try
				{
					doshBoradDate=JSON.parse(data) as Array;
					
				}catch(err:Error)
				{
					logger.error("loadDoshBoard err");
				}
				
				var doshBoardTemplate:XML = model.getData(ModelKeys.DOSH_BOARD_MESSAGE_TEMPLATE);
				var doshBoardMsgList:Array = [];
				
				if(doshBoradDate&&doshBoradDate.length)
				{
					for(var i:int=0;i<doshBoradDate.length;i++)
					{
						var msgData:Object = doshBoradDate[i];
						if(msgData)
						{
							msgVo= new MessageVO();
							msgVo.id = msgData.a;
							msgVo.img=msgData.d;
							msgVo.date = new Date(msgData.b * 1000);
							msgVo.messageType="1";      //注意!这里是为了删除消息开辟的字段
							
							var currentDueDate:Number=ServiceLocator.cookieService.readNumber(CookieKeys.RECORD_CURRENT_MESSAGE_DATE+Model.instance.getData(ModelKeys.USER_DATA).uid)
							if(msgVo.date.getTime()>currentDueDate)
							{
								unreadMessageNum=1;
								ServiceLocator.cookieService.writeBoolean(CookieKeys.RECORD_MESSAGE_READ_STATUS+Model.instance.getData(ModelKeys.USER_DATA).uid,true);
							}
							doshBoardMsgList.push(msgVo);
							
							if(doshBoardTemplate)
							{
								for each( var tmp:XML in doshBoardTemplate.item)
								{
									if(tmp.id==msgData.e)
									{
										msgVo.message = parseMessage(tmp.msg,msgData.c);
									}
								}
							}
							
						}
					}
				}
				model.setData(ModelKeys.DOSH_BOARD_MESSAGE_LIST, doshBoardMsgList);
			});
			
		}
		
		private function loadUserMessageList():void
		{
			if(loading)
			{
				return;
			}
			loading = true;
			model.clearData(ModelKeys.USER_MESSAGE_LIST_ALL);
			model.clearData(ModelKeys.USER_MESSAGE_LIST_FRIEND);
			model.clearData(ModelKeys.USER_MESSAGE_LIST_SYSTEM);
			model.clearData(ModelKeys.USER_MESSAGE_DISPLAYING);
			
			unreadMessageNum = 0;
			httpService.POST({"mod":"user","act":"getmsg"}, function(data:String):void {
//				CONFIG::DEBUG
//				{
//					data = '[{"a":135063390965144,"b":101,"c":1,"d":1350633909,"e":"<#nick##Yi Hunag#>","f":3,"g":1017344070,"h":"","i":"93842","img":"https:\/\/graph.facebook.com\/1017344070\/picture"},{"a":135063390965144,"b":101,"c":0,"d":1350633909,"e":"<#nick##Yi Hunag#>","f":3,"g":1017344070,"h":"","i":"93842","img":"https:\/\/graph.facebook.com\/1017344070\/picture"}]';
//				}
				loading = false;
				var json:Object = null;
				try {
					json = JSON.parse(data);
				} catch(err:Error) {
					logger.error("json parse error:", err, " data:", data);
				}
				var template:XML = model.getData(ModelKeys.MESSAGE_TEMPLATE);
				var friendMsgList:Array = [];
				var systemMsgList:Array = []
				var allMsgList:Array = [];
				messageType = 0;
				if(json && json.length)
				{
					for(var i:int = 0; i < json.length; i++)
					{
						var msg:Object = json[i];
						if(msg)
						{
							msgVo= new MessageVO();
							msgVo.id = msg.a;
							msgVo.img = msg.img;
							msgVo.date = new Date(msg.d * 1000);
							msgVo.hasReaded = (msg.c == 1);
							msgVo.dollId=msg.h;
							msgVo.UserId=msg.i;
							msgVo.messageType="0";
							
							var currentDueDate:Number=ServiceLocator.cookieService.readNumber(CookieKeys.RECORD_CURRENT_MESSAGE_DATE+Model.instance.getData(ModelKeys.USER_DATA).uid)
							if(msgVo.date.getTime()>currentDueDate)
							{
								unreadMessageNum=1;
								ServiceLocator.cookieService.writeBoolean(CookieKeys.RECORD_MESSAGE_READ_STATUS+Model.instance.getData(ModelKeys.USER_DATA).uid,true);
							}
							msgVo.message = parseMessage(template.msgtype.(@id== msg.b).a.(@id== msg.f).b.text(), msg.e);
							if(msg.b==103)
							{
								msgVo.type="103";
								friendMsgList.push(msgVo);
							}
							else if(msg.b==302)
							{
								msgVo.type="302";
								systemMsgList.push(msgVo);
							}
							else if(msg.b > 200) 
							{
								//系统消息
								msgVo.type = "1";
								systemMsgList.push(msgVo);
							}
							else 
							{
								//好友消息
								msgVo.type = "2";
								friendMsgList.push(msgVo);
							}
							allMsgList.push(msgVo);
						}
					}
					
					var byDateDesc:Function = function(obj1:*, obj2:*):int {
						var val1:uint = 0;
						var val2:uint = 0;
						if(obj1 && obj1.date)
						{
							val1 = obj1.date.time;
						}
						if(obj2 && obj2.date)
						{
							val2 = obj2.date.time;
						}
						return val2 - val1; //逆序
					};
					// 数组大爷要求屏蔽
//					friendMsgList.sort(byDateDesc);
//					systemMsgList.sort(byDateDesc);
				}
				model.setData(ModelKeys.USER_MESSAGE_LIST_FRIEND, friendMsgList);
				model.setData(ModelKeys.USER_MESSAGE_LIST_SYSTEM, systemMsgList);
				model.setData(ModelKeys.USER_MESSAGE_LIST_ALL, allMsgList);
				if (firstLoad)
				{
					firstLoad = false;
					model.setData(ModelKeys.LATEST_NOT_READED_NUMBER, unreadMessageNum);
				}
				
				setDisplayingData();
			}, defaultErrorHandler, defaultErrorHandler);
		}
		
		private function defaultErrorHandler(arg1:* = null, arg2:* = null):void
		{
			loading = false;
			model.setData(ModelKeys.USER_MESSAGE_DISPLAYING, Localization.getText("COMMON.PHP_REQUEST_ERROR_MSG"));
		}
		
		private function parseMessage( tpl:String, str:String ):String
		{
			var reg:RegExp = /<#([^#]+)##([^#]+)#>/g;
			var m:Array = null;
			while (  (m = reg.exec( str )) != null)
			{
				var key:String   = m[1];
				var value:String = m[2];
				tpl = tpl.replace( '{' + key + '}', value );
			}
			return tpl;
		}
		
		private function openMessagePopUp(evt:Event):void
		{
			loadMessageTemplate();
			newMessage.show();
			var currDate:Date=new Date();
			ServiceLocator.cookieService.writeNumber(CookieKeys.RECORD_CURRENT_MESSAGE_DATE+Model.instance.getData(ModelKeys.USER_DATA).uid,currDate.getTime());
			ServiceLocator.cookieService.writeBoolean(CookieKeys.RECORD_MESSAGE_READ_STATUS+Model.instance.getData(ModelKeys.USER_DATA).uid,false);
			FrameworkGlobal.context.dispatchEventWith(CommandEventNames.MESSAGE_RED_POINT_ICON,false);
		}
		
		private function toggleGroupChange(evt:Event):void
		{
			currentTabIndex = evt.data as int;
			setDisplayingData();
		}
	}
}