require("common/kit/tableLimit");
require("service/room/roomSocketDataProvider");
require("service/room/labaSocketDataProvider");
require("service/room/slotSocketDataProvider");

--[Comment]
--房间服务管理【单例】,不可继承，这个类请不要直接调用。
--这个类是用于管理一些RoomController不能管理的事情，由于RoomController的生命周期与场景息息相关，所以场景切换的时候，
--RoomController里面的功能就不能使用，所以需要把一些常驻功能交于RoomModule处理。

RoomModule = {};
RoomModule.TAG = "RoomModule";
RoomModule._requestLoginData   = nil;  --RequestLoginData;
RoomModule._sendGiftsData      = nil;  --SendGiftsData
RoomModule._needReconnect      = false;
RoomModule._addFriendUid       = nil;
RoomModule._isSuspend          = false;
RoomModule._matchUserOutData   = nil;
RoomModule._gameReviewPopUp    = nil;   --牌局回顾
		
RoomModule._tournamentRewardRetryTimes = 0;

RoomModule._enable = false;   --使能

RoomModule._requestLoginData = {};

RoomModule.__eventList = {
    {CommandEvent, CommandEvent.s_cmd.USER_LOGGED_IN,                   "userLoginHandler"};
	{CommandEvent, CommandEvent.s_cmd.USER_LOGGED_OUT,                  "userLogoutHandler"};
	{CommandEvent, CommandEvent.s_cmd.PREPARE_LOGIN_ROOM,               "prepareLoginRoom"};--准备登录房间
	{CommandEvent, CommandEvent.s_cmd.REQUEST_BRING_GROUPS_ENTER_ROOM,  "prepareLoginBringGroupsRoom"};
	{CommandEvent, CommandEvent.s_cmd.LEAVE_GAME_ROOM,                  "leaveGameRoom"};
	{CommandEvent, CommandEvent.s_cmd.PLAY_CARD_OPERATION,              "playCardOperation"};
	{CommandEvent, CommandEvent.s_cmd.USER_STAND_UP,                    "userStandUp"};
	{CommandEvent, CommandEvent.s_cmd.USER_BUY_IN,                      "userBuyIn"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_CHAT_SEND_EXPRESSION,        "onChatSendExpression"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_CHAT_SEND_MESSAGE,           "onChatSendMessage"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_CHAT_SMALL_LABA,             "onChatSmallLaba"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_CHAT_BIG_LABA,               "onChatBigLaba"};
	{CommandEvent, CommandEvent.s_cmd.USER_PLAY_SLOT,                   "playSlot"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_SOCKET_ERROR,                "badNetworkLeaveRoomHandler"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_DETERMINE_ROOM_SOCKET,       "determineRoomSocket"};
	{CommandEvent, CommandEvent.s_cmd.GIFT_NOTIFY_GIFT_FOR_TABLE,       "sendGift"};
	{CommandEvent, CommandEvent.s_cmd.GET_USER_HDDJ_NUMBER,             "getHddjNumber"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_BROADCAST_SEND_HDDJ,         "broadcastSendHddj"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_BROADCAST_ADD_FRIEND,        "broadcastAddFriend"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_REQUEST_ADD_FRIEND,          "requestAddFriend"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_BROADCAST_SEND_CHIP,         "broadcastSendChip"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_BROADCAST_SEND_DEALER_CHIP,  "broadcastSendDealerChip"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_GET_USER_PROPS,              "getUserProps"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_GET_USER_RANKING,            "getUserRanking"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_USE_EXP_CARD,                "useExpCard"};
	{CommandEvent, CommandEvent.s_cmd.USER_CALCULATE_POKER,             "userCalculatePoker"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_SET_MAX_AWARD,               "setMaxAward"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_SET_BEST_POKER,              "setBestPoker"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_SHOW_HAND_CARD,              "requestShowHandCard"};
	{CommandEvent, CommandEvent.s_cmd.ROOM_DEALER_CHANGE_CONFIRM,       "setMyDealer"};
	{CommandEvent, CommandEvent.s_cmd.SEND_DEALER_CHIP_FAIL,            "sendDealerChipFail"};
	{CommandEvent, CommandEvent.s_cmd.USER_LOGIN_RETRY,                 "userLoginRetry"};
	{CommandEvent, CommandEvent.s_cmd.SUPER_LOTTO_BUY_NEXT,             "superLottoBuyNext"};
	{CommandEvent, CommandEvent.s_cmd.SUPER_LOTTO_AUTO_BUY,             "superLottoAutoBuy"};
	{CommandEvent, CommandEvent.s_cmd.SUPER_LOTTO_DELAY_AUTO_BUY,       "superLottoDelayAutoBuy"};
	{CommandEvent, CommandEvent.s_cmd.SUPER_LOTTO_CANCEL_AUTO_BUY,      "superLottoCancelAutoBuy"};
	{CommandEvent, CommandEvent.s_cmd.SEND_INVITE_FRIENDS_MESSAGE,      "inviteFriendsMessage"};--邀请好友打牌
	{CommandEvent, CommandEvent.s_cmd.SEND_INVITE_OFFLINE_FRIENDS_MESSAGE, "inviteOfflineFriendsMessage"};--邀请好友打牌
	{CommandEvent, CommandEvent.s_cmd.REQUEST_NEXT_STAND_UP,            "nextStandUp"};--在游戏中接受好友邀请
	{CommandEvent, CommandEvent.s_cmd.ROOM_REQUEST_BACK_SEAT,           "userBackSeat"};
	--{context.addEventListener(UIEventNames.SHOW_INVITE_FRIENDS_DIALOG, "showInviteFriendsDialog"};--显示邀请好友对话框
	{CommandEvent, CommandEvent.s_cmd.TOURNAMENT_SEND_EMAIL_DATA,       "tournamentSendEmailData"};
--	{CommandEvent, CommandEvent.s_cmd.OPEN_GAME_REVIEW_POP_UP,          "openGameReviewPopUp"};--打开牌局回顾
    {CommandEvent, CommandEvent.s_cmd.BACK_TO_HALL,                     "backToHall"};
			
	--NativeApplication.nativeApplication.addEventListener(flash.events.Event.ACTIVATE, appActivateHandler};--程序激活
	--NativeApplication.nativeApplication.addEventListener(flash.events.Event.SUSPEND, appSuspendHandler};--程序切至后台（不执行代码）
	--NativeApplication.nativeApplication.addEventListener(flash.events.Event.DEACTIVATE, appDeactivateHandler};--程序暂停（测试用）
};

RoomModule.watchDataList = function(self)
    if self.__watchDataList == nil then
        self.__watchDataList = {
            {ModelKeys.ROOM_CHAT_DATA,      self, self.getRoomChatData,         true};
	        {ModelKeys.ROOM_LOGIN_FAIL_DATA,self, self.roomLoginFailHandler,    false};
	        {ModelKeys.ROOM_LOGIN_SUCC_DATA,self, self.loginSuccHandler,        false};
	        {ModelKeys.ROOM_GAME_START_DATA,self, self.gameStartHandler,        false};
	        {ModelKeys.ROOM_GAME_OVER_DATA, self, self.gameOverHandler,         false};
	        {ModelKeys.LOTTO_BUY_FAIL,      self, self.lottoBuyFailHandler,     false};
	        {ModelKeys.LOTTO_REWARD,        self, self.lottoReward,             false};
	        {ModelKeys.ROOM_USER_OUT_T,     self, self.userOutT,                false};
        };
    end
    Model.watchDataList(self.__watchDataList);
end

RoomModule.unwatchDataList = function(self)
    if self.__watchDataList ~= nil then
        Model.unwatchDataList(self.__watchDataList);
    end
end

RoomModule.initialize = function()
    RoomModule._requestLoginData = {};
    RoomModule._requestLoginData.playNow = true;
    RoomModule._requestLoginData.enterFrom = RequestLoginData.MAIN_PAGE;
    EventDispatcher.getInstance():registerEventList(RoomModule, RoomModule.__eventList);
    RoomModule._enable = true;
    RoomSocketDataProvider.initialize();
    LabaSocketDataProvider.initialize();
    SlotSocketDataProvider.initialize();
end

--[Comment]
--控制房间控制器是否开启
RoomModule.enable = function(flag)
    flag = (flag ~= false);
    if RoomModule._enable ~= flag then
        if flag then
            EventDispatcher.getInstance():registerEventList(RoomModule, RoomModule.__eventList);
        else
            EventDispatcher.getInstance():unregisterEventList(RoomModule, RoomModule.__eventList);
        end
        RoomModule._enable = flag;
    end
end

--[Comment]
--用户登录或者切换用户重连广播server 
RoomModule.userLoginHandler = function(self)
	if LabaSocketDataProvider:connected() then
		LabaSocketDataProvider:closeSocket();
	end
	LabaSocketDataProvider:startConnect();
	--拉取荷官数据
	self.regetTimes = 5;
	self:getDealerData();
	self:getHddjNumber();
end

RoomModule.userLogoutHandler = function(self)
	Log.d(self.TAG, "userLogoutHandler");
    LabaSocketDataProvider:closeSocket();
end

--[Comment]
--登录登录房间
RoomModule.prepareLoginRoom = function(self, data)
    local userData = Model.getData(ModelKeys.USER_DATA);
    self._requestLoginData = {}; --重置
	self._requestLoginData.playNow      = data.playNow;
	self._requestLoginData.enterFrom    = data.enterFrom;
    
    if data ~= nil then
        --设置场景切换
	    self.m_sceceNavEventCmdData = {sceneNavEventCmd = data.sceneNavEventCmd};
    end

    if data.roomInfo ~= nil then
        self:__enterRoomByCmd(data);
		self._requestLoginData.tid      = data.roomInfo.tid;
		self._requestLoginData.ip       = data.roomInfo.ip;
		self._requestLoginData.port     = data.roomInfo.port;
		self._requestLoginData.password = data.roomInfo.password;
		if data.roomInfo.roomStyle ~= nil then
			self._requestLoginData.roomStyle = data.roomInfo.roomStyle;
		end
				
		self._requestLoginData.uid = userData.uid;
		self._requestLoginData.mtkey = userData.mtkey;
		self._requestLoginData.imgUrl = userData.s_picture;
		self._requestLoginData.giftId = userData.user_gift;

		--连接server
		RoomSocketDataProvider:requestLoginData(self._requestLoginData);
	else
		local postData = {["mod"] = "table", ["act"] = "quickIn"};
		if data.field ~= nil then
			postData["field"] = data["field"];
		end
		HttpService.post(postData, self, self.quickInHandler, self.badNetworkLeaveRoomHandler, self.badNetworkLeaveRoomHandler);
	end

    
			
	if SlotSocketDataProvider:connected() then   --老虎机socket
		SlotSocketDataProvider:startConnect();
	end
end

RoomModule.__enterRoomByCmd = function(self, data)
    if data ~= nil and data.sceneNavEventCmd ~= nil then
        EventDispatcher.getInstance():dispatch(SceneNavEvent.s_event, data.sceneNavEventCmd);
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_LOGIN_LOADING, STR_ROOM_ENTER_GAME);
        data.sceneNavEventCmd = nil;
    end
end

RoomModule.__badNetworkLeaveRoomHandler = function(self, data)
    EventDispatcher.getInstance():dispatch(
            UIEvent.s_event,
            UIEvent.s_cmd.OPEN_DIALOG, {
			message = STR_COMMON_CONNECT_ROOM_FAIL,
			confirm = STR_COMMON_RETRY, 
			cancel  = STR_COMMON_RETURN, 
            obj     = self,
			callback= self.__badNetworkConfirmHandler,
            cancelSP=true
        });
end

RoomModule.__badNetworkConfirmHandler = function(self, types)
	if (types == DialogCallback.CONFIRM) then
		--RoomSocketDataProvider:requestLoginData = self._requestLoginData;--重连
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM);--强制清理房间ui，离开房间
	end
end
		
RoomModule.userBackSeat = function()
	RoomSocketDataProvider:requestBackSeat();
end
		
RoomModule.tournamentSendEmailData = function(self, data)
    data.mod = "match";
    data.act = "email";
    --HttpService.post(data, sendEmailCallBack, TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
end
		
RoomModule.sendEmailCallBack = function(data)
	local code = tonumber(data);
	if (code == 1) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.TOURNAMENT_SEND_EMAIL_SUCC);
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, Localization.getText("ACTIVITY.ACT_WHEEL_REWARD_MESSAGE_SUBMIT_SUCCED"));
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, Localization.getText("ROOM.TOURNAMENT_RESULT_CONTACT_CONFIRM"));
	end
end
		
RoomModule.userOutT = function(self, value) --MatchUserOutData
	self._matchUserOutData = value;
	local tournament = Model.getData(ModelKeys.ROOM_TOURNAMENT_DATA);
	if (tournament)then
		self._tournamentRewardRetryTimes = 3;
		local postData = {["mod"] = "match", ["act"] = "reward", ["mid"] = tournament.mid, ["time"] = tournament.time, ["rank"] = self._matchUserOutData.ranking};
		HttpService.post(postData, self, self.getTournamentRewardCallBack, self.getTournamentRewardCallBack, self.getTournamentRewardCallBack);
	end
end
		
RoomModule.getTournamentRewardCallBack = function(self, data)
	if data ~= nil then
		local obj = json.decode(data);
		if obj then
			if obj.desc ~= nil then
				self._matchUserOutData.reward   = obj.desc;
				self._matchUserOutData.hasGoods = (obj.goods_reward ~= 0);
				if(self._matchUserOutData.hasGoods) then
					self._matchUserOutData.reward = obj.goods_rwd_desc.." + "..self._matchUserOutData.reward;
					self._matchUserOutData.email = obj.email;
			    end
				if obj.props ~= nil then
					self._matchUserOutData.propsId = obj.props;
				end
			end
			Model.setData(ModelKeys.ROOM_TOURNAMENT_OUT_RESULT, self._matchUserOutData);
		end
	elseif (self._tournamentRewardRetryTimes >= 0) then
		local tournament = Model.getData(ModelKeys.ROOM_TOURNAMENT_DATA);
		if tournament ~= nil then
			local postData = {["mod"]="match", ["act"]="reward", ["mid"]=tournament.mid, ["time"]=tournament.time, ["rank"]=self._matchUserOutData.ranking};
			HttpService.post(postData, self, self.getTournamentRewardCallBack, self.getTournamentRewardCallBack, self.getTournamentRewardCallBack);
			self._tournamentRewardRetryTimes = self._tournamentRewardRetryTimes + 1;
		end
	else
		--TopTipKit.badNetworkHandler();
	end
end
		
RoomModule.onChatBigLaba = function(self, data)
	local postData = {["mod"]="lb", ["act"]="speak", ["type"]=ServerCommand.LB_SVR_TYPE_BIG_LABA, ["content"]=data};
	HttpService.post(postData, self.sendLabaCallBack, self.getDealerCallback, self.getDealerCallback);
end
		
RoomModule.onChatSmallLaba = function(self, data)
	local postData = {["mod"]="lb", ["act"]="speak", ["type"]=ServerCommand.LB_SVR_TYPE_SMALL_LABA, ["content"]=data};
	HttpService.post(postData, self, self.sendLabaCallBack, TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
end
		
RoomModule.sendLabaCallBack = function(self, data)
	if data ~= nil then
	    local obj = json.decode(data);
	    if (obj["ret"] ~= 0) then
		    ToolKit.badNetworkHandler();
	    else
		    TaskReporter.getInstance():reportSmallLaba();
	    end
    end
end
		
RoomModule.regetTimes = 5;

RoomModule.getDealerData = function(self)
	--拉取荷官描述文件
	local postData = {["mod"]="changeDeinger", ["act"]="DeingerList"};
	HttpService.post(postData, self, self.getDealerCallback, self.getDealerCallback, self.getDealerCallback);
	self.regetTimes = self.regetTimes - 1;
end
		
RoomModule.getDealerCallback = function(self, data)
	if data then
	    local dealerData = nil;
        local flag = pcall(function()dealerData = json.decode(data) end);
        if flag then
		    Model.setData(ModelKeys.ROOM_DEALER_DATA, dealerData);
        else
            if (self.regetTimes >= 0) then
			    self:getDealerData();
		    end
        end
	elseif (self.regetTimes >= 0) then
		self:getDealerData();
	end
end
		
RoomModule.setMyDealer = function(self,data)
	--设置荷官id
	self.m_dealerId = tonumber(data);
	local postData = {["mod"]="changeDeinger", ["act"]="signChange", ["deingerId"]=self.m_dealerId};
	HttpService.post(postData, self, self.__setMyDealerCallBack, self.__setMyDealerCallBack, self.__setMyDealerCallBack);
end

RoomModule.__setMyDealerCallBack = function(self, data)
	if data == "0" then
        Model.setProperty(ModelKeys.USER_DATA, "defaultHeguan", self.m_dealerId);
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.CONFIRM_DEALER_INFO, self.m_dealerId);
		if SeatManager.selfInSeat then
			local seatData = SeatManager:getSelfSeat():getSeatData();
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_DEALER_ACTION, {["seatId"]= seatData.seatId , ["userName"]= seatData.name, ["textIndex"]= 3});
		end
	else
		--TopTipKit.badNetworkHandler();
	end
end
		
RoomModule.sendDealerChipFail = function(self)
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_DEALER_NO_MONEY);
end
		
RoomModule.setBestPoker = function(self, data)
--	local valueStr:String  = data.cardType.toString(16);
--	for ( local i:int = 0; i < 5; i++ )
--	{
--		valueStr = valueStr..data.cards[i];
--	}
--	userData.bestpoker = valueStr;

--	--上报给php
--	local postData = {["mod"]="user", ["act"]="setMostStat", ["bestpoker"]=valueStr};
--	HttpService.post(postData);
end

RoomModule.requestShowHandCard = function(self)
    RoomSocketDataProvider:requestShowHandCard();
end
		
RoomModule.setMaxAward = function(self, data)
	--上报给php
	local postData = {["mod"]="user", ["act"]="setMostStat", ["maxaward"]=data};
    Model.setProperty(ModelKeys.USER_DATA, "maxaward", data);
	HttpService.post(postData);
end
		
RoomModule.userCalculatePoker = function(self, cards)
	if #cards > 0 then
		SlotSocketDataProvider:requestCalculate(#cards, cards);
	end
end
		
RoomModule.useExpCard = function(self, data)
	local postData = {["mod"]="user", ["act"]="useprops", ["id"]=data};
	HttpService.post(postData, self, self.userExpCardHandler);
end
		
RoomModule.userExpCardHandler = function(self, data)
	local retObj = json.decode(data);
	Model.setData(ModelKeys.ROOM_USE_EXP_CARD_DATA, retObj);
end
		
RoomModule.getUserRanking = function(self, data)
	local postData = {["mod"]="user", ["act"]="othermain", ["puid"]=data};
	HttpService.post(postData, self, self.userRankingHandler);
end
		
RoomModule.userRankingHandler = function(self, data)
	if data then
		Model.setData(ModelKeys.ROOM_USER_RANKING_DATA, json.decode(data));
	end
end
		
RoomModule.getUserProps = function(self)
	postData = {["mod"]="user", ["act"]="getUserProps"};
	HttpService.post(postData, self, self.userPropsHandler);
end
		
RoomModule.userPropsHandler = function(self, data)
--	if data then
--		local propArr = json.decode(data);
--		for(local i:int = 0; i < propArr.length; i++)
--
--			if(propArr[i].a != 1 and propArr[i].a != 2 and propArr[i].a != 3 and propArr[i].a != 6 and propArr[i].a != 7 and propArr[i].a != 8 and propArr[i].a != 30 and propArr[i].a != 32 and propArr[i].a != 77)
--	
--				propArr.splice(i,1);
--				i--;
--	end
--end
--		Model.setData(ModelKeys.ROOM_USER_PROP_DATA, propArr);
--	end

    if (type(data) == "string") then
		local propArr = json.decode(data);
        local i = 1;
        while(i <= #propArr) do
			if(propArr[i].a ~= 1 and
				propArr[i].a ~= 2 and
				propArr[i].a ~= 3 and
				propArr[i].a ~= 6 and
				propArr[i].a ~= 7 and
				propArr[i].a ~= 8 and
				propArr[i].a ~= 30 and
				propArr[i].a ~= 32 and
				propArr[i].a ~= 77 and
				propArr[i].a ~= 100) then
                As3Kit.deleteAt(propArr, i);
				i = i - 1;
			end
            i = i + 1;
		end
		Model.setData(ModelKeys.ROOM_USER_PROP_DATA, propArr);
	end
end
		
RoomModule.broadcastSendChip = function(self, data)
    RoomSocketDataProvider:requestSendChips(data);
end
		
RoomModule.broadcastSendDealerChip = function(self, data)
    RoomSocketDataProvider:requestSendDealer();
end
		
RoomModule.requestAddFriend = function(self, data)
	--请求php加为好友
	self._addFriendUid = tostring(data);
	local postData = {["mod"]="friend", ["act"]="setPoker", ["fuid"] = data};
	HttpService.post(postData, self, self.addFriendHandler);
end
		
RoomModule.addFriendHandler = function(self, data)
	if data ~= nil and data == "1" then
		local friendList = Model.getData(ModelKeys.FRIEND_UID_LIST);
		if friendList then
			table.insert(friendList, self._addFriendUid);
		end
        Model.setData(ModelKeys.FRIEND_UID_LIST, friendList);
	end
end
		
--请求加为好友 
--@param evt
--@param data	
RoomModule.broadcastAddFriend = function(self, data)
	RoomSocketDataProvider:requestAddFriend(data.sendSeatId, data.receiveSeatId);
end

--[Commnet]	
--请求广播发送互动道具 
--这里直接请求PHP，由PHP通知Server发送广播;
RoomModule.broadcastSendHddj = function(self, data)
	if not TutotiaKit.isTutotia() then
	    --请求php扣除并广播
	    local postData = {["mod"]="user", ["act"]="useUserFun", ["hddjId"]=data.hddjId, ["selfSeatId"]=(data.sendSeatId - 1), ["receiverSeatId"]=(data.sendedSeatId - 1)};
	    HttpService.post(postData);
    end
end
		
RoomModule.getHddjNumber = function(self)
    local postData = {["mod"]="user", ["act"]="getUserFun"};
    HttpService.post(postData, self, self.getUserHddjNumber, TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
end
		
RoomModule.getUserHddjNumber = function(self, data)
    if data then
		local hddjNumber = tonumber(data);
		Model.setData(ModelKeys.USER_HDDJ_NUMBER, hddjNumber);
	end
 end
		
--激活程序 
RoomModule.appActivateHandler = function(self, e)
	Model.setData(ModelKeys.APP_DEACTIVATE, false);
    local userData = Model.getData(ModelKeys.USER_DATA);
	if (self._isSuspend and userData) then
		local postData = {
			["mod"]="tj",
			["act"]="loginNineOne",
			["platform"]= runtimeInfo.isIOS and "ios" or runtimeInfo.isAndroid and  "android" or "desktop",
			["device"]=runtimeInfo.device,
			["version"]=runtimeInfo.getConfigText("version")
        };
		HttpService.post(postData);
	end
	
    self._isSuspend = false;

	if (userData ~= nil and not LabaSocketDataProvider.connected) then--确保用户已经登陆 
		LabaSocketDataProvider:startConnect();
	end
	
    --判断是否需要重连
	if (self._needReconnect) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM, true);--强制清理房间ui，但不离开房间
		RoomSocketDataProvider:requestLoginData(self._requestLoginData);
		self._needReconnect = false;
	end
			
	--请求服务器判断是否收到邀请
	if userData ~= nil and userData.uid ~= nil then
		local postData1 = {["mod"] = "token", ["act"]= "active"};
		HttpService.post(postData1, self, self.inviteFriendHandler, self.inviteFriendHandler, self.inviteFriendHandler);
	end
end

--[Comment]
--[[程序切入后台 
	@param data 
    data.tid 牌桌id
	data.ip; 
	data.port;
	data.nick; 邀请者姓名
]]	
RoomModule.inviteFriendHandler = function(self, data)
	if(data ~= nil) then
		local obj = json.decode(data);
		if obj ~= nil and obj.ret == 1 then
			local str = "";--返回成功
			--显示好友邀请提示
			if(FrameworkGlobal.screenNavigator.activeScreenID == ScreenNames.GAME_ROOM and SeatManager.selfInGame) then
				--在游戏中
				str = Localization.getText("FRIEND.INGAME_INVITE_TIP",userData.name);
			else
				--不在游戏中
				str = Localization.getText("FRIEND.OUTGAME_INVITE_TIP",userData.name);
			end
			local roomData = {};
			roomData.tid = obj.tid;
			roomData.ip = obj.ip;
			roomData.port = obj.port;
			PopUpManager.addPopUp(new(TopTipWithButton(str,
				function ()
                    local activeScreenID = FrameworkGlobal.screenNavigator.activeScreenID
					if activeScreenID == ScreenNames.NORMAL_HALL then
							FrameworkGlobal.screenNavigator.activeScreen.dispatchEventWith(ScreenNavEventNames.NORMAL_HALL_2_GAME_ROOM);
							context.dispatchEventWith(CommandEventNames.PREPARE_LOGIN_ROOM, {["playNow"]=false, ["enterFrom"]=RequestLoginData.NORMAL_HALL, ["roomInfo"]=roomData});
				    elseif activeScreenID ==  ScreenNames.MATCH_HALL then
							FrameworkGlobal.screenNavigator.activeScreen.dispatchEventWith(ScreenNavEventNames.MATCH_HALL_2_GAME_ROOM);
							context.dispatchEventWith(CommandEventNames.PREPARE_LOGIN_ROOM, {["playNow"]=false, ["enterFrom"]=RequestLoginData.MATCH_HALL, ["roomInfo"]=roomData});
					elseif ScreenNames.MAIN_PAGE then
							FrameworkGlobal.screenNavigator.activeScreen.dispatchEventWith(ScreenNavEventNames.MAIN_PAGE_2_GAME_ROOM);
							context.dispatchEventWith(CommandEventNames.PREPARE_LOGIN_ROOM, {["playNow"]=false, ["enterFrom"]=RequestLoginData.MAIN_PAGE, ["roomInfo"]=roomData});
					elseif ScreenNames.GAME_ROOM then --另作处理
							FrameworkGlobal.screenNavigator.activeScreen.dispatchEventWith(UIEventNames.ACCEPT_FRIENDS_INVITE,false,roomData);
					end
				end
				),STR_ACCEPT_TIP,false,false));
		else
			--返回失败
		end
	end
end
		
--[Comment]
--程序切入后台 
RoomModule.appSuspendHandler = function(self, data)
	self._isSuspend = true;
	if (Model.getData(ModelKeys.USER_IN_ROOM) and 
        Model.getData(ModelKeys.USER_DATA) and 
        (Model.getData(ModelKeys.USER_IN_TUTOTIA) == nil or not Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart)) then
		self._needReconnect = true;
	end
	RoomSocketDataProvider:closeSocket();
	LabaSocketDataProvider:closeSocket();
end
		
RoomModule.appDeactivateHandler = function(self, data)
	Model.setData(ModelKeys.APP_DEACTIVATE, true);
end
		
RoomModule.getRoomChatData = function(self, chatData)
	if chatData then
		local list = Model.getData(ModelKeys.ROOM_CHAT_HISTORY);
        list = list or {};
		table.insert(list, {["senderName"]=chatData.senderName, ["message"]=chatData.message, ["type"]=1});--type为1是普通聊天，2是小喇叭
		Model.setData(ModelKeys.ROOM_CHAT_HISTORY, list);
	end
end
		
RoomModule.roomLoginFailHandler = function(self, data)
	--错误的mtkey
	if data == LoginSuccData.ERROR_LOGIN_MTKEY then
		Log.d(self.TAG, "错误的mtkey");
		self:reloginRoom();
				
	--重连进入不同桌子
	elseif data == LoginSuccData.ERROR_LOGIN_RECONN_ROOM then
		Log.d(self.TAG, "重连进入不同桌子");
		self:reloginRoom();
				
	--停服
	elseif data == LoginSuccData.ERROR_LOGIN_SERVER_STOP then
			Log.d(self.TAG, "停服");
		--弹出提示框，确定后退出程序
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,{
            message=STR_ROOM.LEAVE_TABLE_CONFIRM, 
			confirm=STR_COMMON_CONFIRM, 
			obj = self,
            callback=self.confirmLeaveRoom
		});
				
	--错误的桌子信息
	elseif data == LoginSuccData.ERROR_LOGIN_TABLE_ERR then
		Log.d(self.TAG,"错误的桌子信息");
		self:doubleLoginRoomError();

	--被别人登录
	elseif data == LoginSuccData.ERROR_LOGIN_OTHER_RELOGIN then
		Log.d(self.TAG,"被别人登录");
		self:doubleLoginRoomError();

	--帐号被封
	elseif data == LoginSuccData.ERROR_LOGIN_USER_DISABLE then
		Log.d(self.TAG,"帐号被封");
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,{
            message=STR_COMMON_USER_FORBIDDEN, 
			confirm=STR_COMMON_CONFIRM,
            obj = self, 
			callback=self.confirmLeaveRoom
		});
				
	--被房主踢出
	elseif data == LoginSuccData.ERROR_LOGIN_KICKOUT then
		Log.d(self.TAG,"被房主踢出");
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,{
			message=STR_ROOM_AGAIN_ENTER_ROOM_FAIL,
            obj = self,
			callback = self.confirmLeaveRoom
						
		});
				
	--房间旁观人数到达上限
	elseif data == LoginSuccData.ERROR_LOGIN_ROOM_FULL then
		Log.d(self.TAG,"房间旁观人数到达上限");
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,{
            message=STR_COMMON_ROOM_FULL, 
			confirm=STR_COMMON.CONFIRM,
            obj = self, 
			callback = self.confirmLeaveRoom
		});
		    
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {
			message=STR_COMMON_CONNECT_ROOM_FAIL, 
			confirm=STR_COMMON_CONFIRM, 
			obj = self,
            callback=self.confirmLeaveRoom
		});
	end
end

RoomModule.loginSuccHandler = function(self, value) --LoginSuccData
--	if(userData and SuperLottoEntry:checkEnabled(value) and model.getData(ModelKeys.LOTTO_IS_AUTO_BUY)
--		_roomSocketDataProvider.requestDelayAutoBuyLotto();
--	end
--	Model.setData(ModelKeys.LOTTO_IS_NEXT_BUY, false);
--	Model.setData(ModelKeys.LOTTO_IS_CURRENT_BUY, false);
end
		
RoomModule.gameStartHandler = function(self, value) --GameStartData
	Model.setData(ModelKeys.LOTTO_IS_NEXT_BUY, false);
end
		
RoomModule.gameOverHandler = function(self, value) --GameOverData
end
		
RoomModule.lottoBuyFailHandler = function(self, value)
	local code = tonumber(value);
	if code ==  SuperLottoEntry.ERROR_CODE_MOENY_NOT_ENOUGH then
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_LOTTO_MOENY_NOT_ENOUGH);
    elseif code == SuperLottoEntry.ERROR_CODE_NOT_IN_SEAT then
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_LOTTO_NOT_IN_SEAT);
	elseif code == SuperLottoEntry.ERROR_CODE_SYSTEM_ERROR then
    else
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_LOTTO_SYSTEM_ERROR);
	end
end
		
RoomModule.lottoReward = function(self, value)
	local userData = Model.getData(ModelKeys.USER_DATA);
    if(value ~= nil and value.uid == userData.uid) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_SUPER_LOTTO_REWARD, value);
		Model.clearData(ModelKeys.LOTTO_REWARD);
	end
end
		
RoomModule.confirmLeaveRoom = function(self, types)
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM);
end
		
--[Comment]
--重复登录房间错误 	
RoomModule.doubleLoginRoomError = function()
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM, true);--强制清理房间ui，不离开房间
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {
		message=STR_COMMON_DOUBLE_LOGIN_ERROR, 
		confirm=STR_COMMON_RELOGIN_ROOM,
        obj=self, 
		callback=self.doubleLoginConfirmHandler
	});
end
		
RoomModule.doubleLoginConfirmHandler = function(self, types)
	if (types == DialogCallback.CONFIRM) then
		self:reloginRoom();
	elseif (types == DialogCallback.CLOSE) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM);--强制清理房间ui，离开房间，退至登录界面
		RoomSocketDataProvider:closeSocket();
		LabaSocketDataProvider:closeSocket();
		setTimeout(self.doubleLoginConfirmHandlerTimeout, self, 1000);
	end
end

RoomModule.doubleLoginConfirmHandlerTimeout = function(self)
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGOUT);
end
		
RoomModule.sendGift = function(self, data)
	if (not self._sendGiftsData) then
		self._sendGiftsData = new(SendGiftsData);
	end
	self._sendGiftsData.giftId = data.giftId;
	self._sendGiftsData.sendSeatId = model.getData(ModelKeys.USER_SELF_SEAT_ID);
	
    local arrLength = #data.userIds
	self._sendGiftsData.userArr = {};
	for i = 1, i < arrLength do
		self._sendGiftsData.userArr[i] = {}
		self._sendGiftsData.userArr[i].seatId = data.seatIds[i]
		self._sendGiftsData.userArr[i].seatUid =data.userIds[i]
	end
	RoomSocketDataProvider:requestSendGift(self._sendGiftsData);
end
		
--[Comment]
--确定房间socket是否连接 
RoomModule.determineRoomSocket = function(self)
	RoomSocketDataProvider:requestSendHd(-1, RoomSocketDataProvider.BIG_HDDJ_ID, -1);
end
		
RoomModule.reloginRoom = function(self)
	local postData = {["mod"]="user", ["act"]="setmtkey"};
	HttpService.post(postData, self, self.resetMtkey, self.badNetworkLeaveRoomHandler, self.badNetworkLeaveRoomHandler);
end
		
RoomModule.badNetworkLeaveRoomHandler = function(self)
	--提示重连
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {
		message=STR_COMMON_CONNECT_ROOM_FAIL, 
		confirm=STR_COMMON_RETRY, 
		cancel=STR_COMMON_RETURN,
        obj=self,
		callback=self.badNetworkConfirmHandler,
		cancelSP=true
	});
end
		
RoomModule.badNetworkConfirmHandler = function(self, types)
	if (types == DialogCallback.CONFIRM) then
		RoomSocketDataProvider:requestLoginData(self._requestLoginData);--重连
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM);--强制清理房间ui，离开房间
	end
end
		
RoomModule.userLoginRetry = function(self)
    RoomSocketDataProvider:requestLoginData(self._requestLoginData);--重连
end
		
RoomModule.superLottoBuyNext = function(self)
	Model.setData(ModelKeys.LOTTO_IS_NEXT_BUY, true);
	RoomSocketDataProvider:requestBuyNextLotto();
end
		
RoomModule.superLottoAutoBuy = function(self)
	Model.setData(ModelKeys.LOTTO_IS_AUTO_BUY, true);
	RoomSocketDataProvider:requestAutoBuyLotto();
end		
		
RoomModule.superLottoDelayAutoBuy = function(self)
	Model.setData(ModelKeys.LOTTO_IS_AUTO_BUY, true);
	RoomSocketDataProvider:requestDelayAutoBuyLotto();
end
		
RoomModule.superLottoCancelAutoBuy = function(self)
	Model.setData(ModelKeys.LOTTO_IS_AUTO_BUY, false);
	RoomSocketDataProvider:requestCancelAutoBuyLotto();
end

--[Comment]
--重新获取mtkey，重连房间 
--@param data		
--[Comment]
--重新获取mtkey，重连房间 
--@param data
RoomModule.resetMtkey = function(self, data)
	if data then
		local obj = nil;
		local flag = pcall(function() obj = json.decode(data) end);
		if flag then
			local userData = model.getData(ModelKeys.USER_DATA);
			if (obj.mtkey ~= nil) then
				userData.mtkey = obj.mtkey;
				userData.skey  = obj.skey;
				HttpService.addDefaultParams("mtkey", obj.mtkey);
				HttpService.addDefaultParams("skey", obj.skey);
				Model.setPreporty(ModelKeys.USER_DATA, "mtkey", userData.mtkey);
				Model.setPreporty(ModelKeys.USER_DATA, "skey", userData.skey);
				self._requestLoginData.mtkey = obj.mtkey;
				if obj.tid ~= 0 then
					self._requestLoginData.ip   = obj.ip;
					self._requestLoginData.port = obj.port;
					self._requestLoginData.tid  = obj.tid;
				end
				RoomSocketDataProvider:requestLoginData(self._requestLoginData);
			end
		else
			self:badNetworkLeaveRoomHandler();
		end
	end
end
		
RoomModule.playSlot = function(self, data)
    SlotSocketDataProvider:requestPlaySlot(tonumber(data));
end
		
RoomModule.onChatSendMessage = function(self, data)
	local message = tostring(data);
	RoomSocketDataProvider:requestSendMessage(MessageKit.dirtyWordFilter(message));
end
		
RoomModule.onChatSendExpression = function(self, data)
	RoomSocketDataProvider:requestSendEmotion(data);
end
		
RoomModule.userBuyIn = function(self, data)
	local loginSuccData = Model.getData(ModelKeys.ROOM_LOGIN_SUCC_DATA);
	if  not ((loginSuccData ~= nil and not 
        (TableLimit.checkSitDown(loginSuccData.tableLevel, loginSuccData.roomType, true)))) then
	    RoomSocketDataProvider:requestBuyIn(data);
	    if CookieService.getBoolean(CookieKeys.AUTO_BUY_IN, true) then
		    RoomSocketDataProvider:requestAutoBuyIn();
	    end
    end
end
		
RoomModule.userStandUp = function(self)
    RoomSocketDataProvider:requestStand(self);
end
		
RoomModule.playCardOperation = function(self, data)
    RoomSocketDataProvider:requestOperation(data);
end
		
RoomModule.leaveGameRoom = function(self)
    RoomSocketDataProvider:requestLeave();
end

RoomModule.prepareLoginBringGroupsRoom = function(self, data)
	self._requestLoginData.playNow = data.playNow;
	self._requestLoginData.enterFrom = data.enterFrom;
	local postData = {["mod"]= "table", ["act"]= "quickIn", ["field"]=data.field,["sb"]=data.sb,["flag"]=data.flag};
	self.m_sceceNavEventCmdData = {sceneNavEventCmd = SceneNavEvent.s_cmd.NORMAL_HALL_2_ROOM};
    HttpService.post(postData,self, self.quickInHandler, self.badNetworkLeaveRoomHandler, self.badNetworkLeaveRoomHandler);
			
	if not SlotSocketDataProvider:connected() then
		SlotSocketDataProvider:startConnect();
	end
end

RoomModule.quickInHandler = function(self, data)
	local userData = Model.getData(ModelKeys.USER_DATA);
    local roomInfo = nil;
    local flag = pcall(function() roomInfo = json.decode(data) end);
    
    if flag then
        if self.m_sceceNavEventCmdData ~= nil then
            self:__enterRoomByCmd(self.m_sceceNavEventCmdData);	
        end
	    self._requestLoginData.tid      = roomInfo.tid;
	    self._requestLoginData.ip       = roomInfo.ip;
	    self._requestLoginData.port     = roomInfo.port;
	    self._requestLoginData.password = nil;
        	
	    self._requestLoginData.uid      = userData.uid;
	    self._requestLoginData.mtkey    = userData.mtkey;
	    self._requestLoginData.imgUrl   = userData.s_picture;
	    self._requestLoginData.giftId   = userData.user_gift;
				
	    --连接server
	    RoomSocketDataProvider:requestLoginData(self._requestLoginData);
	else
	    self:badNetworkLeaveRoomHandler();
    end
end

--邀请好友
RoomModule.inviteFriendsMessage = function(self, data)
	LabaSocketDataProvider:getInvitePlayGame(data);
end
		
RoomModule.inviteOfflineFriendsMessage = function(self, data)
	local obj = data
	if(LocalService.currentLocaleId() == "th_TH") then
		--HttpService.post_URL("http:--www.coalaa.com/m/web-ipoker/push.php",{"mod":"invite","act":"friend","fuid":obj.fuid},friendCallBack,TopTipKit.badNetworkHandler,TopTipKit.badNetworkHandler);
	else
		HttpService.post({["mod"]="invite",["act"]="friend",["fuid"]=obj.fuid},self.friendCallBack,TopTipKit.badNetworkHandler);
	end
end
		
RoomModule.friendCallBack = function(self, value)
	if value then
		local data = json.decode(value);
		if data then
			if data.ret == 0 then
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP,STR_FRIEND_FRIEND_POPUP_INVITE_SUCC);
			else
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP,STR_FRIEND_FRIEND_POPUP_CALLBACK_FAILE);
			end
		end
	end
end
		
--在游戏中接受好友邀请
RoomModule.nextStandUp = function(self)
	RoomSocketDataProvider:requestNextStandup();
end
		
RoomModule.showInviteFriendsDialog = function()
	if self.inviteFriendsPage == nil then
		self.inviteFriendsPage = new(RoomInviteFriendsPage);
	end
	self.inviteFriendsPage:showPopUp();
end
		
RoomModule.openGameReviewPopUp = function(self)
	if( not self._gameReviewPopUp and GameReviewPopUp) then
		self._gameReviewPopUp = new(GameReviewPopUp);
	end
    if(self._gameReviewPopUp) then
	    self._gameReviewPopUp.show();
    end
end

RoomModule.backToHall = function(self)
    StateMachine.getInstance():changeState(States.NormalHall);
end

RoomModule.badNetworkHandler = function(self)
end
