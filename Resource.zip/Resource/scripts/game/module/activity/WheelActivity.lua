--[Comment]
--幸运转转
WheelActivity = class(ActivityBase); 

WheelActivity.getInstance = function()
	if not ActivityBase.s_instance then
		WheelActivity.s_instance = new(WheelActivity);
	end
	return WheelActivity.s_instance;
end

WheelActivity.releaseInstance = function()
	delete(WheelActivity.s_instance);
	WheelActivity.s_instance = nil;
end

WheelActivity.ctor = function(self)
    super(1, true);
    self.m_vo.title            = STR_ACTIVITY_ACT_WHEEL_TITLE;
    self.m_vo.isShowInManPage  = true;
    self.m_vo.isSpecial        = true;

    self.m_vo.iconFactory = function()
	    if self.m_vo.m_icon == nil then
		    self.m_vo.m_icon = new(WheelIcon);
		    self.m_vo.m_icon:setScale(0.8)
        end
	    return self.m_vo.m_icon;
    end
end

WheelActivity.onUserLoggedIn = function(self, data)
    if self.m_vo ~= nil then
        self.m_vo.iconFactory();
	    if self.m_vo.m_icon ~= nil then
		    self.m_vo.m_icon:setCompleted(true);
		    HttpService.post({
                ["mod"] = "dazhuanpan", 
                ["act"] = "GetCanPlayTimes"}, self, self.getWheelCallBack, self.getWheelErrorCallBack);
	    end
    end
end