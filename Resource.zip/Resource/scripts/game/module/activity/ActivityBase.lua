--[Comment]
--活动基类
ActivityBase = class(); 

ActivityBase.getInstance = function()
	if not ActivityBase.s_instance then
		ActivityBase.s_instance = new(ActivityBase);
	end
	return ActivityBase.s_instance;
end

ActivityBase.releaseInstance = function()
	delete(ActivityBase.s_instance);
	ActivityBase.s_instance = nil;
end

ActivityBase.ctor = function(self, id, inMain)
    self.m_vo           = new(ActivityVO);
    self.m_vo.m_id      = id or -1;
    self.m_vo.inMain    = inMain or true;
end

ActivityBase.onUserLoggedIn = function(self, data)
end

ActivityBase.getVO = function(self)
    return self.m_vo;
end

ActivityBase.getId = function(self)
    local ret = -1;
    if self.m_vo ~= nil then
        ret = self.m_vo.id;
    end 
    return ret;
end

ActivityBase.isInMain = function(self)
    local ret = false;
    if self.m_vo == nil then
		ret = self.m_vo.inMain;
    end
    return ret;
end

ActivityBase.getInMainVO = function(self, freeChipList)
    local vo = self.m_vo;
    if self.m_vo ~= nil then
        if freeChipList ~= nil then
            for i = 1, #freeChipList do
                if self.m_vo.id == freeChipList[i] then
                    vo = self.m_vo;
                end
	        end
        end
    end
    return vo;
end

ActivityBase.checkDailyFirstInNeedTrigger = function(self)
end