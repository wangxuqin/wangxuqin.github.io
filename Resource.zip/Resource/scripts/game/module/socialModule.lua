--[Comment]
--社交分享模块
SocialModule = {};
SocialModule.TAG = "SocialModule";

SocialModule.__eventList = {
    {CommandEvent, CommandEvent.s_cmd.SOCIAL_SHARE,     "onSocialShare"};
    {CommandEvent, CommandEvent.s_cmd.USER_LOGGED_IN,   "onUserLogin"};
}
		
SocialModule.initialize = function()   
	EventDispatcher.getInstance():registerEventList(SocialModule, SocialModule.__eventList)
	Model.setData(ModelKeys.SOCIAL_SHARE_ENABLED, true);
	Model.setData(ModelKeys.SOCIAL_SHARE_BUSY, false);
end
		
SocialModule.onUserLogin = function(self)
	local userData = Model.getData(ModelKeys.USER_DATA);
    --每天第一次登录，发OG
	if userData.dailyFirstin == 1 then
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.SOCIAL_OG, {["type"] = "game"});
	end
end
		
SocialModule.onSocialShare = function(self, data)
    if data ~= nil and not Model.getData(ModelKeys.SOCIAL_SHARE_BUSY) then
		for _, platform in pairs(data.platforms) do
			if platform == SharePlatforms.FACEBOOK then
					EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FACEBOOK_FEED, data);
					break;
			end
		end
	end
end
		
SocialModule.onOpenGraph = function(self, data)
	if CookieService.readString(CookieKeys.LOGIN_TYPE) == LoginTypes.LOGIN_TYPE_FACEBOOK then
		data["mod"] = "autofeed";
		data["act"] = "backparam";
		HttpService.post(data, self, self.onBackParam);
	end
end
		
SocialModule.onBackParam = function(self, data)
	if data ~= nil then
		local flag, retObj = JsonKit.decode(data);
	    if flag then
		    if retObj ~= nil and retObj.ret == 0 then
			    EventDispatcher.getInstance():dispatch(
                    CommandEvent.s_event, 
                    CommandEvent.s_cmd.FACEBOOK_OPEN_GRAPH, retObj);
		    end
        else
            Log.e(self.TAG, "onBackParam", "decode json has an error occurred!");
        end
	end
end