FriendModule = {};
FriendModule.TAG = "FriendModule";

FriendModule.s_eventList = {
    -- 外部事件处理
    { CommandEvent, CommandEvent.s_cmd.FRIEND_REQUEST_REFRESH,  "requestRefresh" };
    { CommandEvent, CommandEvent.s_cmd.OPEN_FRIEND_POP_UP,      "openFriendPopUp" };
    { CommandEvent, CommandEvent.s_cmd.LOGOUT,                  "userLogoutHandler" };
    { CommandEvent, CommandEvent.s_cmd.USER_LOGGED_IN,          "requestRefresh" };
}

FriendModule.initialize = function()
    EventDispatcher.getInstance():registerEventList(FriendModule, FriendModule.s_eventList);
end

FriendModule.requestRefresh = function()
    local params = { };
    params.mod = "friend";
    params.act = "list";
    HttpService.post(params, FriendModule, FriendModule.getCallback, FriendModule.getCallback, FriendModule.getCallback);
end

FriendModule.userLogoutHandler = function()
    Log.d(FriendModule.TAG, "userLogoutHandler, do nothing");
end


FriendModule.getCallback = function(obj, data)
    Log.d(FriendModule.TAG, "getCallback");
    local json_data = json.decode(data);
    local friendList = {};
    local i = 1;
    for i = 1, #json_data do
        local vo = new(FriendVO);
        vo:parse(json_data[i]);
        friendList[i] = vo;
    end
    Model.setData(ModelKeys.FRIEND_LIST_NEW, friendList);
end

FriendModule.openFriendPopUp = function()
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FRIEND_REQUEST_REFRESH);
    local friendList = Model.getData(ModelKeys.FRIEND_LIST_NEW);
    if ((friendList and #friendList > 0) 
    or (ArrayKit.indexOf(Model.getData(ModelKeys.SUPPORTED_LOGIN_TYPE), LoginTypes.LOGIN_TYPE_FACEBOOK) ~= -1 and LocalService.currentLocaleId() ~= "zh_Hans") 
    or (System.isAndroid() and LocalService.currentLocaleId() ~= "zh_Hans")) then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_FRIEND_DIALOG);
    else
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, 
        { message = STR_FRIEND_FRIEND_POPUP_NO_FRIEND_TIPS, confirm = STR_COMMON_KNOW, cancel = STR_COMMON_CANCEL });
    end
end