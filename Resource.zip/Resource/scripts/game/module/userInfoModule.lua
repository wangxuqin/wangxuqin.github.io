--[Comment]
--用户信息模块
UserInfoModule = {};
UserInfoModule.TAG = "UserInfoModule";

UserInfoModule.__eventList = {
    {CommandEvent, CommandEvent.s_cmd.OPEN_GLORY_POP_UP,     "openGloryPopUpHandler"};
}
		
UserInfoModule.initialize = function()   
	EventDispatcher.getInstance():registerEventList(UserInfoModule, UserInfoModule.__eventList);
end
		
UserInfoModule.openGloryPopUpHandler = function(self)       
	self:__loadGloryIfNeeded();
	self:__loadStatIfNeeded();	
end

UserInfoModule.__loadGloryIfNeeded = function(self)       
    Model.clearData(ModelKeys.USER_GLORY_INFO);
	Model.clearData(ModelKeys.USER_GLORY_LIST);
	HttpService.post({["mod"] = "user",["act"] = "GetUserChengJiu"}, self,self.__loadUserGloryCallback, self.__defaultGloryErrorHandler);	
end

UserInfoModule.__loadStatIfNeeded = function(self)       
		
end

UserInfoModule.__loadUserGloryCallback = function(self,ret)  
    Log.d("server resturned glory:", ret);  
    local serverReturnedGlory = json.decode(ret);   
		
end

UserInfoModule.__defaultGloryErrorHandler = function(self)       
		
end
