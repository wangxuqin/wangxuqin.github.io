--[Comment]
--房间服务管理【单例】,不可继承，这个类请不要直接调用。
--这个类是用于管理一些HomeController不能管理的事情，由于HomeController的生命周期与场景息息相关，所以场景切换的时候，
--HomeController里面的功能就不能使用，所以需要把一些常驻功能交于HomeModule处理。
HomeModule = {};
HomeModule.m_bankRetryTimes = 0;
HomeModule.TAG = "HomeModule";
HomeModule.m_bankData = {["mod"] = "mobileBank",    ["act"] = "bankClick"};   --请求保险箱
HomeModule.m_rankData = {["mod"] = "rank",          ["act"] = "mfmoney"};     --请求排行版
HomeModule.__eventList = {
    {CommandEvent, CommandEvent.s_cmd.USER_LOGGED_IN,   "onLoggedIn"};
    {CommandEvent, CommandEvent.s_cmd.GET_RANKING_LIST, "onGetRanking"};
};

HomeModule.initialize = function()
    EventDispatcher.getInstance():registerEventList(HomeModule, HomeModule.__eventList);
end

HomeModule.onLoggedIn = function(self, data)
	HomeModule.m_bankRetryTimes = 0;
	HttpService.post(self.m_bankData, self.getBankCallback, self.getBankCallback, self.getBankCallback);
	if CookieService.getString(CookieKeys.LOGIN_TYPE) ~= LoginTypes.LOGIN_TYPE_GUEST then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_HOME_ACCOUNT_BUTTON);
	end
end

HomeModule.getBankCallback = function(self, data)
	if data ~= nil then
        local bankData = nil;
		local flag = pcall(function() bankData = json.decode(data) end);
        
        if flag then	
			Model.setProperty(ModelKeys.USER_DATA, "bank_money", tonumber(bankData.bankmoney));
			Model.setProperty(ModelKeys.USER_DATA, "bank_password", (bankData.tag==1));
			Model.setProperty(ModelKeys.USER_DATA, "bank_token", bankData.token);
		else
            self.m_bankRetryTimes = self.m_bankRetryTimes + 1;
			if self.m_bankRetryTimes < 3 then
				HttpService.postData(self.m_bankData, self, self.getBankCallback, self.getBankCallback, self.getBankCallback);
			end
			Log.e(self.TAG, "bankClick error, data: ", data, ", err:", err);
		end
	end
end
		
HomeModule.onGetRanking = function(self, data)
    HttpService.post(self.m_rankData, self, self.getRankingCallback, self.getRankingCallback, self.getRankingCallback);
end
		
HomeModule.getRankingCallback = function(self, data)
    if data ~= nil then 
        local rankData = nil;
        local flag = pcall(function() rankData = json.decode(data) end);
        if flag then
            Model.setData(ModelKeys.MHOME_RANKING_DATA,rankData);
        else
			Log.e(self.TAG, "rankData error, data: ", data, ", err:", err);
		end
     end
end