SystemModule = {};
SystemModule.Tag = "SystemModule";
SystemModule.initialize = function()
	EventDispatcher.getInstance():registerEventList(SystemModule, SystemModule.__eventList);
    EventDispatcher.getInstance():register(Event.Call, self, SystemModule.event_opengallery);  
end

SystemModule.__eventList = {
    {CommandEvent, CommandEvent.s_cmd.SEND_USER_FEEDBACK,   "onSendUserFeedback"};
};

SystemModule.onSendUserFeedback = function(self,data)
    if data ~=nil then
        if data.bitmapData and jpegData then
                    
        else
            local params = {
                ["mod"] = "feedback";
                ["act"] = "setNew";
                ["type"] = data.type;
                ["content"] = data.content;
        
            };
            HttpService.post(params,self,self.resultHandler, self.resultHandler, self.resultHandler);
        end

        local feedback = new(FeedbackVO);
        local feedbackList = Model.getData(ModelKeys.USER_FEEDBACK_LIST) or {};
        feedback.sendDate = os.time();
        feedback.userFeedback = data.content;
        table.insert(feedbackList,feedback);
        Model.setData(ModelKeys.USER_FEEDBACK_LIST,feedbackList);
    end
end

SystemModule.resultHandler = function(self,data)
    Log.d("feedback",data);
    if data~= nil then
        local feedObject = json.decode(data);
        if feedObject.ret == 0 then
             EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_SETTING_FEEDBACK_SUCCEED);
        else
             EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_SETTING_FEEDBACK_FAIL);
        end            
    end
end

SystemModule.event_opengallery = function(obj, callParam ,result, json_data)
    if callParam == kOpenGallery then
        local path = json_data.path:get_value();
        Log.d("test", "path:" .. "   " .. path);
        local params = {};
        params.mod = "feedback";
        params.act = "setNew";
        params.type = 1;
        params = HttpService.getPostData(params);
        Log.d("test", "params:" .. "   " .. params);
        local url = HttpService.defaultURL;
        Log.d("test", "url:" .. "   " .. url);
        url = url .."?"..params;
        Log.d("test", "urlstr:" .. "   " .. url);
        local content = "游戏玩起来很好玩，厉害啊，抓紧开发，不然打屁屁！！";
        NativeService.getInstance():uploadFeedbackImage(url, path, content);
    elseif callParam == kUploadFeedbackImage  then
--         result == true json_data.result._value == 0
--         json.decode_node
    end
end