require("ui/node");
require("ui/text")
require("ui/image")
require("view/hall/layout_mtt_start_time");

MttStartTime = class(Node);

MttStartTime.m_remainStartTime = 0;
MttStartTime.s_TIME_START_ANIMATION = 20 * 60 * 1000;--初始化时，如果距离开赛时间30分钟内开始启动计时器用于倒计时5分钟
MttStartTime.s_TIME_TEN_MINITE  = 10 * 60 * 1000;--距离开赛10分钟请求刷新一次列表
MttStartTime.m_needFresh = false;--是否已经主动请求刷新过列表
MttStartTime.m_interval = 0;--计时器
MttStartTime.m_currentTime = nil;--记录当前时间
MttStartTime.s_TIME_FIVE_MINITE = 5 * 60 * 1000; --距离开赛5分钟开始显示倒计时界面

MttStartTime.ctor = function (self,width)
    self:setSize(width,34);
    self:init()
end

MttStartTime.dtor = function (self)
    self:__stopInterval();      
end

MttStartTime.init = function (self)   
    self.m_root = SceneLoader.load(layout_mtt_start_time);
    self:addChild(self.m_root);

    self.m_txtMinute = self.m_root:getNodeByName("dynamicContainer.img_bg1.txt_minute");
    self.m_txtSecond = self.m_root:getNodeByName("dynamicContainer.img_bg2.txt_second");
    self.m_txtStatic = self.m_root:getNodeByName("staticContainer.txt_static");

    self.m_dynamicContainer = self.m_root:getNodeByName("dynamicContainer");
    self.m_staticContainer  = self.m_root:getNodeByName("staticContainer");
end

MttStartTime.update = function (self,value)
   self.m_data = value;
   self.m_remainStartTime = self.m_data.remainStartTime or 0;
   if self.m_remainStartTime<=MttStartTime.s_TIME_START_ANIMATION  and self.m_remainStartTime >0 then
       --第一次跑到10分钟才需要刷新一次列表 未报名的玩家不刷新列表
       if self.m_remainStartTime>= MttStartTime.s_TIME_TEN_MINITE and self.m_data.status ~= 0 then
           self.m_needFresh = true;
       else  
           self.m_needFresh = false;
           self:__startInterval();
       end 
   else
       self:__stopInterval();
       self:__showStaticTxt();
   end       
end

MttStartTime.__startInterval = function(self)
    self:__stopInterval();
    --self.m_currentTime = os.time();
    self.m_interval = setInterval(self.__intervalHandler,self,1000);

end

MttStartTime.__intervalHandler = function(self)
    --self.m_remainStartTime = self.m_remainStartTime - ( os.time() - self.m_currentTime );
    self.m_remainStartTime = self.m_remainStartTime - 1000;
	--self.m_currentTime = os.time();
			
	--开赛前10分钟入场 请求刷新一次列表
	if(self.m_needFresh and self.m_remainStartTime <= MttStartTime.s_TIME_TEN_MINITE) then
		self.m_needFresh = false;
         EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.MTTHALL_REFRESH_LIST);
         --FrameworkGlobal.context.dispatchEventWith(CommandEventNames.MTTHALL_REFRESH_LIST);
	end
			
	--大于5分钟 显示开赛时间
	if(self.m_remainStartTime > MttStartTime.s_TIME_FIVE_MINITE) then
		self:__showStaticTxt(self.m_data);
	elseif self.m_remainStartTime <= MttStartTime.s_TIME_FIVE_MINITE then
		self:__showDynamicTxt();
	end
						
	if self.m_remainStartTime < 0 then
		self.m_remainStartTime = 0;
		self:__stopInterval();
		self:__showStaticTxt(self.m_data);
        EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.MTTHALL_REFRESH_LIST);
		--FrameworkGlobal.context.dispatchEventWith(CommandEventNames.MTTHALL_REFRESH_LIST);
	end     
end

MttStartTime.__stopInterval = function(self)
    if self.m_interval~=0 then
         clearInterval(self.m_interval);
         self.m_interval = 0;
    end   
end

MttStartTime.__showStaticTxt = function (self)
    self.m_dynamicContainer:setVisible(false);
    self.m_staticContainer:setVisible(true);
    self.m_txtStatic:setText(self.m_data.startTime);        
end

MttStartTime.__showDynamicTxt = function (self)
    self.m_dynamicContainer:setVisible(true);
    self.m_staticContainer:setVisible(false);
    local minute = math.modf(self.m_remainStartTime/1000/60);
    local second = math.modf(self.m_remainStartTime/1000)%60;
    local minuteStr = (minute < 10 and "0" or "")..minute
    local secondStr = (second < 10 and "0" or "")..second;

    self.m_txtMinute:setText(minuteStr); 
    self.m_txtSecond:setText(secondStr);        
end
