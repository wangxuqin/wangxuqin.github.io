require("ui/node");
require("ui/text")
require("ui/image")
require("ui/ex/circleImage");

MttHeadlItem = class(Node)
MttHeadlItem.s_defaultWidth     = 100;
MttHeadlItem.s_defaultHeight = 100;
MttHeadlItem.m_data = {};

MttHeadlItem.ctor = function (self,width,height,isShowName)
    self.m_photoWidth = width +20 or MttHeadlItem.s_defaultWidth;
    self.m_photoHeight = height  or MttHeadlItem.s_defaultHeight;
    self:setSize(self.m_photoWidth,self.m_photoHeight)  

    self.m_isShowName = isShowName or true;
    self:init();
end

MttHeadlItem.dtor = function (self)
      
end

MttHeadlItem.init = function (self)    
    
    self.m_photoLoader = new(CircleImage,"home/userHeadImages/defaultface.png", self.m_data.url);
    self.m_photoLoader:setPos(10,13);
    self.m_photoLoader:setRadius((self.m_photoWidth-20)/2);
    self.m_photoLoader:hideSide();   
    self:addChild(self.m_photoLoader);
    
    self.m_imgCrown = new(Image,"hall/mtt/headCrown_1.png");
    self:addChild(self.m_imgCrown);

    self.m_txtName = new(Text,"",self.m_photoWidth-20,30,kAlignCenter,nil,18,102,102,102);
    self.m_txtName:setPos(10,91);
    self:addChild(self.m_txtName);

    if self.m_isShowName then
        self.m_txtName:setVisible(true);
    else
        self.m_txtName:setVisible(false);
    end

end

MttHeadlItem.setData = function (self,data)
    if data == nil then return end;
    self.m_data = data;
    self.m_crownType = self.m_data.type or 1;
    self.m_imgCrown:setFile("hall/mtt/headCrown_"..tostring(self.m_crownType)..".png");
    self.m_photoLoader:setFile(self.m_data.url);
    self.m_txtName:setText(self.m_data.name or ""); 
end



