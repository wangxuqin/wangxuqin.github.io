require("ui/node");
require("ui/text")
require("ui/image")
require("view/hall/layout_mtt_list_over_item");
require("game/scene/comp/mttHall/mttHeadItem");
MttListOverItem = class(Node)

MttListOverItem.ctor = function (self,data)
    self:init(data)
end

MttListOverItem.dtor = function (self)
    
end

MttListOverItem.init = function (self,data)
    if not data or type(data)~="table" then
        return
    end

    self.m_data = data;
    self:setSize(358+27,186+30);
   
    self.m_root = SceneLoader.load(layout_mtt_list_over_item);
    self:addChild(self.m_root);

    self.txt_startTime = self.m_root:getNodeByName("bg.txt_start_time");
    self.txt_startTime:setText(self.m_data.startTime..STR_MTTHALL_MTTHALL_OVER);

    self.m_playerContainer = new(ScrollView2,30,45,358,186,true);
    self.m_playerContainer:setDirection(kHorizontal);
    self.m_root:addChild(self.m_playerContainer);

    self:updateContainer();
end


MttListOverItem.updateContainer = function (self)
    self.m_playerArr = self.m_data.playerArr;
    if not self.m_playerArr or type(self.m_playerArr)~="table" then
        return
    end

    for i=1, #self.m_playerArr do
        self.m_playerArr[i].type = i;
        local mttHeadItem = new(MttHeadlItem,80,80); 
        mttHeadItem:setData(self.m_playerArr[i]); 
        self.m_playerContainer:addChild(mttHeadItem);  
    end
end


