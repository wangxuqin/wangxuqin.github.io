require("ui/node");
require("ui/text");
require("game/scene/comp/mttHall/mttListNormalItem");
require("game/scene/comp/mttHall/mttListOverItem");
require("view/hall/layout_mtt_assist");

require("ui2/compat/editTextView2")

MttListContainer = class(Node);

MttListContainer.ctor = function(self)
    self:setSize(1185,565);
    self:init();
end

MttListContainer.dtor = function(self)

end


MttListContainer.init = function(self)    
    self.m_list = new(ListView2,95,155,1185,565,true);					  											
   	self.m_list:setScrollBarWidth(0);													
	self.m_list:setOnItemClick(self,self.onItemClick);		
	self.m_list:setOnScroll(self,self.onScroll);				
    self:addChild(self.m_list);
   
    self.m_txtTips = new(Text,STR_HALL_CAN_NOT_FIND_MATCH,50,30,kAlignCenter,nil,28,255,255,255);
    self.m_txtTips:setAlign(kAlignCenter);
    self.m_txtTips:setVisible(false);
    self.m_list:addChild(self.m_txtTips);
    
    self.m_assistContainer = new(ScrollView2,30,155,95,565,true);
    self.m_assistContainer:setDirection(kVertical);
    self:addChild(self.m_assistContainer);       
end

MttListContainer.setData = function(self,data,playAni) 
    self.m_data = data;  

    if data.status == 2 then
        self.m_adapter = new(CacheAdapter,MttListOverItem,data);
    else
        self.m_adapter = new(CacheAdapter,MttListNormalItem,data);
    end
    
    self.m_list:setAdapter(self.m_adapter);   
    self:__updateAssistContainer(data);
end

MttListContainer.playAnim = function(self)
    for i=1,self.m_adapter:getCount() do
        local node = self.m_adapter:getView(i);
        KTween.to(node, 1000, {startAlpha = 0, alpha = 1, delay = (i <= 3) and 500 or 800});
    end
end

MttListContainer.addTip = function(self)
    self.m_txtTips:setVisible(true);
end

MttListContainer.removeTip = function(self)
    self.m_txtTips:setVisible(false);
end

MttListContainer.onScroll = function(self)
    self:__updateAssistContainer(self.m_data);  
end

MttListContainer.__updateAssistContainer =  function (self,value)
	self.m_assistContainer:removeAllChildren();
    self.m_assist = SceneLoader.load(layout_mtt_assist);
    self.m_assistContainer:addChild(self.m_assist);

    self.m_imgSun = self.m_assist:getNodeByName("img_sun");
    self.m_imgSun:setVisible(false);
    self.m_imgMoon = self.m_assist:getNodeByName("img_moon");
    self.m_imgMoon:setVisible(false);
    self.m_imgYellowLine = self.m_assist:getNodeByName("img_sun..img_yellow_line");
    self.m_imgBlueLine = self.m_assist:getNodeByName("img_moon..img_blue_line");
	if #value == 0 then return end;
    local currentTypeNode = nil;
    local lastTypeNode = nil;

    for i=1,#value,3 do         
         local data = value[i].time;
         local hour = tonumber(os.date("%H", data));
         if hour>8 and hour<20 then                       
             self.m_imgSun:setVisible(true);             
             currentTypeNode = self.m_imgYellowLine;
             self:__addLineLength(currentTypeNode,156);             
         else
             self.m_imgMoon:setVisible(true);            
             currentTypeNode = self.m_imgBlueLine;
             self:__addLineLength(currentTypeNode,156); 
             
         end   
         if currentTypeNode == lastTypeNode then
             self:__addLineLength(currentTypeNode,40);
         else
             local item = self.m_adapter:getView(i);
             local _,y = item:getPos();
             currentTypeNode:getParent():setPos(0,y);               
         end
         lastTypeNode = currentTypeNode;
        
    end
end

MttListContainer.__addLineLength =  function (self,node,addLength)
    local width,height = node:getSize();
    node:setSize(width,height+addLength);	
end