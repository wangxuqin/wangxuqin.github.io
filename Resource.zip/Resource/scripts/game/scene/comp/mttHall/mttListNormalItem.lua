require("ui/node");
require("ui/text")
require("ui/image")
require("view/hall/layout_mtt_list_normal_item");
require("game/scene/comp/mttHall/mttStartTime");
MttListNormalItem = class(Node)

MttListNormalItem.ctor = function (self,data)
    self:setSize(358+27,186+30);
    self:init(data)
end

MttListNormalItem.dtor = function (self)
      
end


MttListNormalItem.init = function (self,data)
    if not data or type(data)~="table" then
        return
    end
    self.m_data = data;  
      
    self.m_root = SceneLoader.load(layout_mtt_list_normal_item);
    self:addChild(self.m_root);

    self.m_txtJoin = self.m_root:getNodeByName("bg.img_join.txt_join");
    self.m_txtTitle = self.m_root:getNodeByName("bg.txt_title");
    self.m_imgReward = self.m_root:getNodeByName("bg.img_reward");
    self.m_imgBorder = self.m_root:getNodeByName("bg.img_border");
    self.m_btnLogo = self.m_root:getNodeByName("bg.btn_logo");
    self.m_txtLogo = self.m_root:getNodeByName("bg.btn_logo.txt_logo");
    self.m_imgSign = self.m_root:getNodeByName("bg.img_sign");
    self.m_txtSign = self.m_root:getNodeByName("bg.img_sign.txt_sign");

    local imgRewardWidth = self.m_imgReward:getSize();

    self.m_mttStartTime = new(MttStartTime,imgRewardWidth);
    self.m_mttStartTime:update(self.m_data);
	self.m_mttStartTime:setPos(29,29);
	self:addChild(self.m_mttStartTime);

    self:update();
end

MttListNormalItem.update = function (self)
    self:__updateLogo();
	self:__updateReward();
	self:__updateTitle();
	self:__updateJoinBtn();
	self:__updateStartTime();
	self:__updateRebuyAndAddon();
	self:__updateSignBtn();
	self:__updateBorder();      
end

--[Comment]��������
MttListNormalItem.__updateLogo= function (self)
    if self.m_data.matchType == 2 then
		self.m_btnLogo:setFile("hall/mtt/mttList-logo-month.png");
		self.m_txtLogo:setText(STR_MTTHALL_MTTHALL_MONTH_MATCH);
		self.m_btnLogo:setVisible(true);
	elseif self.m_data.matchType == 1 then
        self.m_btnLogo:setFile("hall/mtt/mttList-logo-week.png");
		self.m_txtLogo:setText(STR_MTTHALL_MTTHALL_WEEK_MATCH);
		self.m_btnLogo:setVisible(true);
    else
        self.m_btnLogo:setVisible(false);    
	end
end

--[Comment]����ͼ
MttListNormalItem.__updateReward= function (self)
    local id = self.m_data.iConId;
	if id < 1 or  id > 5 then
		id = 1;
    end
	local rewardStr = "hall/mtt/mttList-reward-".. id .. ".png";
	self.m_imgReward:setFile(rewardStr);
end

--[Comment]��������
MttListNormalItem.__updateTitle= function (self)
    self.m_txtTitle:setText(self.m_data.reward);
end

--[Comment]��������
MttListNormalItem.__updateJoinBtn= function (self)
    self.m_txtJoin:setText(tostring(self.m_data.allNumber or 0 ));
end


--[Comment]����ʱ��
MttListNormalItem.__updateStartTime= function (self)  
   self.m_mttStartTime:update(self.m_data);
end


MttListNormalItem.__updateRebuyAndAddon= function (self)
end

MttListNormalItem.__updateSignBtn= function (self)
    if self.m_data.status == 3  then-- ������ �ɹ�ս
		self.m_imgSign:setFile("hall/mtt/mttList-fightting-icon.png");
		self.m_txtSign:setText(STR_MTTHALL_MTTHALL_MATCHING);
	elseif self.m_data.status == 1 or  self.m_data.status == 4 then --�ѱ���
        self.m_imgSign:setFile("hall/mtt/mttList-signed-icon.png");
		self.m_txtSign:setText(STR_MTTHALL_MTTHALL_SIGNED);		
	elseif(self.m_data.status == 0) then --�ɱ���
        if self.m_data.buyInType == 0 then --���
            self.m_txtSign:setText(STR_MTTHALL_MTTHALL_SIGN_FREE);    
        elseif self.m_data.buyInType == 1 then --����
             self.m_imgSign:setFile("hall/mtt/mttList-chip-icon.png");
		     self.m_txtSign:setText(Formatter.formatBigNumber(self.m_data.chipBuyIn));
        elseif self.m_data.buyInType == 3 then--����
            self.m_imgSign:setFile("hall/mtt/mttList-point-icon.png");
		    self.m_txtSign:setText(self.m_data.scoreBuyIn);
        elseif self.m_data.buyInType == 10 then
            self.m_imgSign:setFile("hall/mtt/emttList-tickt-icon.png");
		    self.m_txtSign:setText(self.m_data.ticketBuyIn);
        else
             self.m_imgSign:setFile("hall/mtt/mttList-chip-icon.png");
		     self.m_txtSign:setText(Formatter.formatBigNumber(self.m_data.chipBuyIn));
        end
	end
end


--[Comment] ���±߿�
MttListNormalItem.__updateBorder= function (self)  
	if self.m_data.status == 3 then --��ս
		self.m_imgBorder:setFile("mttHall/mttList-bg-yellow.png");		
	elseif self.m_data.status == 1 or self.m_data.status == 4  then--�ѱ��� �볡
		self.m_imgBorder:setFile("mttHall/mttList-bg-blue.png");	
	end
end