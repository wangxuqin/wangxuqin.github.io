-- example: local test = new(SeatTimer,node);       
--          test:start();
--          test:stop();
require("game/scene/comp/room/quadLine");
require("game/scene/comp/room/circleLine");
SeatTimer = class(Node);

SeatTimer.ctor = function (self,node)
    node:addChild(self);

    self.m_intestiy = 5;

    self.m_animIndex = {};

    for i = 1,20 do 
        self.m_animIndex[i] = 90/20*i;
    end

    self.isRunning = false;
    
    self:setPos(2,2);

    self:setVisible(false);

    self.m_width    = 124*System.getLayoutScale();
    self.m_height   = 178*System.getLayoutScale();
    self.m_cirWidth = 8*System.getLayoutScale(); 
    

    --time 
    self.m_duration = 15000 ;
    self.m_weightAll = self.m_cirWidth * 2 * math.pi + (self.m_width-3*self.m_cirWidth) * 2 + (self.m_height-3*self.m_cirWidth) * 2;
    self.m_TBWeight = (self.m_width-3*self.m_cirWidth) / self.m_weightAll;
    self.m_circleWeight = (self.m_cirWidth * 2 * math.pi / 4) / self.m_weightAll;
    self.m_LRWeight = (self.m_height-3*self.m_cirWidth) / self.m_weightAll;

end

SeatTimer.start = function (self)
    self.isRunning = true;

    self:setVisible(true);
    
    self.m_index = 0;

    self.m_stage = 1;

    self.m_quadTopL = new(QuadLine, 3/2*self.m_cirWidth, 0, (self.m_width-3*self.m_cirWidth)/2, self.m_cirWidth, kQuadType.leftToRight);
    self.m_quadTopR = new(QuadLine, self.m_width/2, 0, (self.m_width-3*self.m_cirWidth)/2, self.m_cirWidth, kQuadType.leftToRight);
    self.m_quadRight = new(QuadLine, self.m_width-self.m_cirWidth, 3/2*self.m_cirWidth, self.m_cirWidth, self.m_height-3*self.m_cirWidth, kQuadType.upToDown);
    self.m_quadBot = new(QuadLine,3/2*self.m_cirWidth, self.m_height-self.m_cirWidth, self.m_width-3*self.m_cirWidth, self.m_cirWidth,kQuadType.rightToLeft);
    self.m_quadLeft = new(QuadLine,0, 3/2*self.m_cirWidth, self.m_cirWidth, self.m_height-3*self.m_cirWidth,kQuadType.downToUp);
    self.m_circle1 = new(CircleLine, self.m_width-3/2*self.m_cirWidth, 3/2*self.m_cirWidth, 0, 90, 3/2*self.m_cirWidth, self.m_cirWidth/2,self.m_intestiy);
    self.m_circle2 = new(CircleLine, self.m_width-3/2*self.m_cirWidth, self.m_height-3/2*self.m_cirWidth, 90, 90, 3/2*self.m_cirWidth, self.m_cirWidth/2,self.m_intestiy);
    self.m_circle3 = new(CircleLine, 3/2*self.m_cirWidth, self.m_height-3/2*self.m_cirWidth, 180, 90, 3/2*self.m_cirWidth, self.m_cirWidth/2,self.m_intestiy);
    self.m_circle4 = new(CircleLine, 3/2*self.m_cirWidth, 3/2*self.m_cirWidth, 270, 90, 3/2*self.m_cirWidth, self.m_cirWidth/2,self.m_intestiy);

    self:addChild(self.m_quadTopL);
    self:addChild(self.m_quadTopR);
    self:addChild(self.m_quadLeft);
    self:addChild(self.m_quadRight);
    self:addChild(self.m_quadBot);
    self:addChild(self.m_circle1);
    self:addChild(self.m_circle2);
    self:addChild(self.m_circle3);
    self:addChild(self.m_circle4);

    self.m_mainAnim = new(AnimInt,kAnimRepeat,0,1,self.m_duration * self.m_circleWeight /20 ,0);
    self.m_mainAnim:setEvent(self,self.update);

    self.m_animColor = new(AnimDouble,kAnimNormal,1.5,0,self.m_duration,0);

    self.m_animStage = {};

    self.m_animStage[1] = new(AnimDouble,kAnimNormal,0,(self.m_width-3*self.m_cirWidth)/2,self.m_duration * self.m_TBWeight/2,0);
    self.m_animStage[1]:setEvent(self,self.onStageEnd);   
end

SeatTimer.stop = function (self)
    self:setVisible(false);

    if self.isRunning == true then
        self.m_mainAnim:dtor();
        self.m_mainAnim = nil;

        self.m_animColor:dtor();
        self.m_animColor = nil;


        for k,v in pairs(self.m_animStage) do
            v:dtor();
        end   
    
        self.m_quadTopL:release();
        self.m_quadTopR:release();
        self.m_quadRight:release();
        self.m_quadBot:release();
        self.m_quadLeft:release();
        self.m_circle1:release();
        self.m_circle2:release();
        self.m_circle3:release();
        self.m_circle4:release();

        self.isRunning = false; 
    end
end

SeatTimer.setCountdown = function (self,duration)
    self.m_duration = duration;
end

SeatTimer.hide = function (self)
    self:setVisible(false);
end

SeatTimer.circleUpdate = function (self,circle)
    if self.m_index < #self.m_animIndex then
            self.m_index = self.m_index + 1;       
            step = self.m_animIndex[self.m_index];
            circle:circleVertexUpdate(step);
        else
            self.m_index = 0;
            self:onStageEnd();
        end
end

SeatTimer.colorsUpdate = function (self)
    local color = self.m_animColor:getCurValue();
    
    self.m_quadTopL:setColor(1.5-color,color,0.0);
    self.m_quadTopR:setColor(1.5-color,color,0.0);
    self.m_quadRight:setColor(1.5-color,color,0.0);
    self.m_quadLeft:setColor(1.5-color,color,0.0);
    self.m_quadBot:setColor(1.5-color,color,0.0);
    self.m_circle1:setColor(1.5-color,color,0.0);
    self.m_circle2:setColor(1.5-color,color,0.0);
    self.m_circle3:setColor(1.5-color,color,0.0);
    self.m_circle4:setColor(1.5-color,color,0.0);
end

SeatTimer.update = function (self)
    if self.isRunning == true then
        local step = 0;
        if self.m_stage == 1 then
            step = self.m_animStage[1]:getCurValue();
            self.m_quadTopR:quadVertexUpdate(step);       
        elseif self.m_stage == 2 then  
            self:circleUpdate(self.m_circle1);
        elseif self.m_stage == 3 then       
            step = self.m_animStage[3]:getCurValue();
            self.m_quadRight:quadVertexUpdate(step);
        elseif self.m_stage == 4 then       
            self:circleUpdate(self.m_circle2);
        elseif self.m_stage == 5 then       
            step = self.m_animStage[5]:getCurValue();
            self.m_quadBot:quadVertexUpdate(step);
        elseif self.m_stage == 6 then       
            self:circleUpdate(self.m_circle3);
        elseif self.m_stage == 7 then       
            step = self.m_animStage[7]:getCurValue();
            self.m_quadLeft:quadVertexUpdate(step);
        elseif self.m_stage == 8 then       
            self:circleUpdate(self.m_circle4);
        elseif self.m_stage == 9 then       
            step = self.m_animStage[9]:getCurValue();
            self.m_quadTopL:quadVertexUpdate(step);
        end

        self:colorsUpdate();
    end

end

SeatTimer.onStageEnd = function (self)
    if self.isRunning == true then
    
        if self.m_stage == 1 then
            self.m_stage = 2;
            self.m_quadTopR:setVisible(false);
        elseif self.m_stage == 2 then
            self.m_index = 0;
            self.m_stage = 3;
            self.m_animStage[3] = new(AnimDouble,kAnimNormal,0,self.m_height-3*self.m_cirWidth,self.m_duration * self.m_LRWeight,0);
            self.m_animStage[3]:setEvent(self,self.onStageEnd);

        elseif self.m_stage == 3 then
            self.m_stage = 4;
            self.m_quadRight:setVisible(false);
        elseif self.m_stage == 4 then
            self.m_index = 0;
            self.m_stage = 5;
            self.m_animStage[5] = new(AnimDouble,kAnimNormal,0,self.m_width-3*self.m_cirWidth,self.m_duration * self.m_TBWeight,0);
            self.m_animStage[5]:setEvent(self,self.onStageEnd);

        elseif self.m_stage == 5 then
            self.m_stage = 6;
            self.m_quadBot:setVisible(false);
        elseif self.m_stage == 6 then
            self.m_index = 0;
            self.m_stage = 7;
            self.m_animStage[7] = new(AnimDouble,kAnimNormal,0,self.m_height-3*self.m_cirWidth,self.m_duration * self.m_LRWeight,0);
            self.m_animStage[7]:setEvent(self,self.onStageEnd);

        elseif self.m_stage == 7 then
            self.m_stage = 8;
            self.m_quadLeft:setVisible(false);
        elseif self.m_stage == 8 then
            self.m_index = 0;
            self.m_stage = 9;
            self.m_animStage[9] = new(AnimDouble,kAnimNormal,0,(self.m_width-3*self.m_cirWidth)/2,self.m_duration * self.m_TBWeight / 2,0);
            self.m_animStage[9]:setEvent(self,self.onStageEnd);
        elseif self.m_stage == 9 then
                self.m_quadTopL:setVisible(false);
                self.m_mainAnim:dtor();
                self.m_mainAnim = nil;

                self.m_animColor:dtor();
                self.m_animColor = nil;

                for i = 0,4 do 
                    self.m_animStage[i*2+1]:dtor();
                    self.m_animStage[i*2+1] = nil;
                end

                self.isRunning = false;
        
        end

    end
    
end