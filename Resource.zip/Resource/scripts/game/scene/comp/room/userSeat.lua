require("view/room/layout_userseat");
require("game/scene/comp/room/handCard");
require("game/scene/comp/room/expSprite");
require("ui/rect");

UserSeat = class(Node, false);
UserSeat.TAG = "UserSeat";
UserSeat.SEAT_WIDTH                 = 0;
UserSeat.SEAT_HEIGHT                = 0;
UserSeat.HELPER_POINT               = {x=0,y=0};
UserSeat.m_seatData                 = nil;
UserSeat.m_seatId                   = -1; --座位ID（1-9）服务端那里从0开始，一直到8
UserSeat.m_positionId               = -1; --位置ID（1-9），-1表示座位无玩家
UserSeat.m_cardType                 = 0;--玩家牌型
UserSeat.m_inGame                   = false;--是否游戏中，有效期是游戏开始（包）至游戏结束（包）
UserSeat.m_isStanded                = true;--是否站起过，有效期是游戏开始（包）至游戏刷新
UserSeat.m_showedHandCard           = false;--是否已经亮出手牌
UserSeat.m_compulsoryShowHandCard   = false;--是否系统强制必须亮出手牌

UserSeat.m_atlas                    = nil;
UserSeat.m_sitdownContainer         = nil;
UserSeat.m_contentContaier          = nil;
UserSeat.m_statusContainer          = nil;
UserSeat.m_animationContainer       = nil;
UserSeat.m_giftContainer            = nil;

UserSeat.m_photoLoader              = nil;
UserSeat.m_btnSitdown               = nil;
UserSeat.m_nameLabel                = nil;
UserSeat.m_chipLabel                = nil;
UserSeat.m_statusLabel              = nil;
UserSeat.m_vipIcon                  = nil;
UserSeat.m_giftButton               = nil;--礼物按钮
UserSeat.m_giftSprite               = nil;--礼物容器
UserSeat.m_handCard                 = nil;--手牌
UserSeat.m_photoOverlay             = nil;
UserSeat.m_winAnimation             = nil;
UserSeat.m_seatTimer                = nil;
UserSeat.m_inviteFriendsIconTexture = nil;
UserSeat.m_defaultMalePhoto          = "room/room-default-male-photo.png";
UserSeat.m_defaultFemalePhoto        = "room/room-default-female-photo.png";
UserSeat.SEAT_WIDTH = 108;
UserSeat.SEAT_HEIGHT = 164;

UserSeat.ctor = function(self, id)
	super(self);
	self.m_seatData = new(TableUserData);
	self.m_positionId = id;
    self.m_seatId = id;
    self:initialize();
end

UserSeat.dtor = function(self, id)
end

UserSeat.initialize = function(self)
    self.m_skin     = SceneLoader.load(layout_userseat);
	self:addChild(self.m_skin);
    self.m_skin:setEventTouch(self, self.__userSeatTouchHandler);
    self.m_skin:setPickable(true);
    --self.m_contentContaier =  self.m_skin:getNodeByName("bg");
	
    self.m_backGround       = self.m_skin:getNodeByName("bg");--背景
    
    self.m_seatTimerContainer = self.m_skin:getNodeByName("bg.view_seat_timer");
    self.m_seatTimer = new(SeatTimer,self.m_seatTimerContainer);
    self.m_seatTimer:setAlign(kAlignTopLeft);
    self.m_seatTimer:setVisible(false);
    
    
    self.m_photoOverlay     = self.m_skin:getNodeByName("bg.img_photo_overlay")--头像overlay
    self.m_photoOverlay:setPickable(false);
    
    self.m_sitdownContainer = self.m_skin:getNodeByName("bg.view_sitdown_container");--动画层，表现坐下站起
	self.m_photoLoader      = self.m_skin:getNodeByName("bg.view_sitdown_container.img_photo_loader");--坐下
    self.m_btnSitdown       = self.m_skin:getNodeByName("bg.view_sitdown_container.btn_sitdown");
    

    local w,h = self.m_photoLoader:getSize();
    local x,y = self.m_photoLoader:getPos();
    self.m_photoLoader:setClip(true,0, 0, w, h);
    self.m_sitdownContainer:setPickable(true);
    self.m_photoLoader:setVisible(false);
    self.m_btnSitdown:setPickable(true);
    self.m_btnSitdown:setClip(true,0, 0, w, h);
--    self.m_btnSitdown:setEventTouch(self, self.onSitdownHandle);
	self.m_backGround:setEventTouch(self, self.onSitdownHandle);

    self.m_statusContainer  = self.m_skin:getNodeByName("bg.view_status_container");--状态层，与打牌相关
	self.m_statusContainer:setPickable(false);

    if(System.isIOS7() and System.getLanguage() == "th_TH") then --名字
		self.m_nameLabel = new(EditText, "", 100, nil, kTextAlignCenter, nil, 20, 0xc5, 0xc5, 0xc5);
        self.m_nameLabel:setEnable(false);
	else
		self.m_nameLabel = self.m_skin:getNodeByName("bg.view_status_container.txt_name_label");
	end
    self.m_chipLabel = self.m_skin:getNodeByName("bg.view_status_container.txt_chip_label");--筹码
	self.m_statusLabel = self.m_skin:getNodeByName("bg.view_status_container.txt_status_label");

    self.m_nameLabel:setText("");
    self.m_chipLabel:setText("");
    self.m_statusLabel:setText("");

	self.m_vipIcon = self.m_skin:getNodeByName("bg.view_status_container.img_vip_icon");
    self.m_vipIcon:setPickable(false);
    self.m_vipIcon:setVisible(false);
	self.m_animationContainer = self.m_skin:getNodeByName("bg.view_animation_container");--动画容器
    self.m_animationContainer:setPickable(false);

    self.m_cardContainer = self.m_skin:getNodeByName("bg.view_card_container");
	self.m_handCard = new(HandCard);--手牌
	self.m_handCard:setPos(UserSeat.SEAT_WIDTH * 0.5, UserSeat.SEAT_HEIGHT * 0.5 + 23);
	self.m_handCard.m_handCard[1]:setVisible(false);
	self.m_handCard.m_handCard[2]:setVisible(false);
	self.m_handCard:setPickable(false);
	self.m_cardContainer:addChild(self.m_handCard);

	self.m_giftContainer    = self.m_skin:getNodeByName("bg.view_gift_container");--礼物
	self.m_giftButton       = self.m_skin:getNodeByName("bg.view_gift_container.btn_gift");
    self.m_giftContainer:setVisible(false);
--m    self.m_giftButton:setEventTouch(self, self.onTouch);

	if (self.m_positionId == 1 or self.m_positionId == 2 or self.m_positionId == 3 or self.m_positionId == 5 or self.m_positionId == 6) then
        self.m_giftContainer:setPos(- UserSeat.SEAT_WIDTH * 0.6);
	else
        self.m_giftContainer:setPos(UserSeat.SEAT_WIDTH - UserSeat.SEAT_WIDTH * 0.4);
	end

	self.m_btnInviteFriends = self.m_skin:getNodeByName("bg.btn_invite_friend");
    self.m_btnInviteFriends:setVisible(false);

    self.m_mask = self.m_skin:getNodeByName("bg.img_sitdown_container_mask");
    self.m_mask:setVisible(false);

    self.m_expSprite    = new(ExpSprite);
    self.m_expContainer = self.m_skin:getNodeByName("bg.view_exp_container");
    self.m_expContainer:addChild(self.m_expSprite);
    self.m_expContainer:setVisible(false);
end

UserSeat.onSitdownHandle = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
	TouchHelper.catch(self, finger_action, x, y);
	if(TouchHelper.isClick(self)) then
	    if self.m_sitdownCallback ~= nil then
	        local obj = self.m_sitdownCallback.obj;
	        local func = self.m_sitdownCallback.func;
	        if obj ~= nil and func ~= nil then
	            func(obj, self);
	        end
	    end
	end
end

--[Comment]
--设置坐下回调
UserSeat.setSitdownCallback = function(self, obj, func)
    self.m_sitdownCallback = {};
    self.m_sitdownCallback.obj = obj;
    self.m_sitdownCallback.func = func;
end

--[Comment]
--设置默认图片
UserSeat.setDefaultPhoto = function(self, seatData)
    if seatData.gender == "m" then
		self.m_photoLoader:setFile(self.m_defaultMalePhoto);
	else
		self.m_photoLoader:setFile(self.m_defaultFemalePhoto);
	end
end

--[Comment]
--改变用户头像
UserSeat.__onChangePhoto = function(self, url)
    local userData = Model.getData(ModelKeys.USER_DATA);
	self.m_seatData.photoUrl = userData.m_picture;
	if string.len(self.m_seatData.photoUrl.length) <= 5 then
        local guestPhotoTexture = PhotoKit.getDefaultPhotoUrl(self.m_seatData.photoUrl);
		if guestPhotoTexture ~= nil then
            self.m_photoLoader:setFile(guestPhotoTexture);--获取游客头像
			self:setUserPhotoTexture();
		else
			self:setDefaultPhoto(self.m_seatData);
		end
	else
        self.m_photoLoader.data = {["key"]=self.m_seatData.uid.."_100", ["url"]=self.m_seatData.photoUrl};
        self.m_photoLoader:setFile(self.m_seatData.photoUrl);
	end
end




UserSeat.setUserPhotoTexture = function(self)
	if self.m_seatData.uid ~= -1 then
	    if self.m_photoLoader.m_res == nil then
		    self:setDefaultPhoto(self.m_seatData);
	    end
    end
end

UserSeat.onTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)--private
    if(finger_action == kFingerUp) then
        SoundManager.playButtonClickSound();
--		AnalysisUtil.onEvent(AnalysisEventIds.ROOM_GIFT);
		--新手引导屏蔽礼物按钮
        local isListenerOfGiftClick = Model.getData(ModelKeys.USER_IN_TUTOTIA).isListenerOfGiftClick;
		if not (TutotiaKit.isTutotia() and not isListenerOfGiftClick) then
		    --单机游戏屏蔽礼物按钮
            local userData = Model.getData(ModelKeys.USER_DATA);
		    if userData ~= nil and userData.uid ~= nil then
		        EventDispatcher.getInstance():dispatch(
                    CommandEvent.s_event, CommandEvent.s_cmd.OPEN_GIFT_POPUP, {
                        ["isInRoom"]    = true, 
                        ["uid"]         = userData.uid, 
                        ["seatId"]      = self.m_seatId, 
                        ["userNick"]    = self.m_seatData.name
                });
	        end
        end
    end
end
		
UserSeat.fadeSeat = function(self)
	self.m_photoOverlay:setVisible(true);
end

UserSeat.cancelFadeSeat = function(self)
    self.m_photoOverlay:setVisible(false);
end

--[Comment]
--判断是否自己
UserSeat.isSelf = function(self)
    local ret = false;
    local userData = Model.getData(ModelKeys.USER_DATA);
	if  userData == nil or TutotiaKit.isTutotia() then
		ret = (self.m_seatData.seatId == 5);
	else
        ret = (self.m_seatData.uid == userData.uid);
    end
    return ret;
end

--[Comment]
--展示状态 
-- @param status
UserSeat.showStatu = function(self, status)
	self.m_statusLabel:setVisible(true);
	self.m_nameLabel:setVisible(false);
	self.m_statusLabel:setText(status);
end

--[Comment]
--展示姓名
UserSeat.showName = function(self)
	self.m_statusLabel:setVisible(false);
	self.m_nameLabel:setVisible(true);
end

--[Comment]
--设置座位筹码
UserSeat.setSeatChips = function(self, value)
	if value >= 0 then
		self.m_chipLabel:setText(STR_COMMON_NUMBER_CURRENCY_LABEL .. Formatter.formatBigNumber(value, false));
		self.m_seatData.seatChips = value;
	end
end

--[Comment]
--座位的赢牌动画
UserSeat.playWinAnimation = function(self)
	--赢牌牌型
	if (self.m_cardType >= 2 and self.m_cardType <= 11) then
		self:showStatu(STR_ROOM_CARD_TYPE[self.m_cardType]);
	else
		self:showStatu(STR_ROOM_WIN);
	end

    if self.m_winAnimation ~= nil then
        self.m_winAnimation:dtor();
        self.m_winAnimation = nil;
    end
	self.m_winAnimation = AtomAnimManager:playAnim("atomAnimTable/room/anim_small_win", self.m_animationContainer);
end

--[Comment]
--座位的自动买入动画
UserSeat.playBuyinAnimation = function(self, buyInChips)
	local appStatus = Model.getData(ModelKeys.APP_DEACTIVATE);
    if appStatus ~= true then
	    local buyInBackground = new(Image, "room/buyin-action-yellowbackground.png");
        local width,height = buyInBackground:getSize();
        buyInBackground:setPos(self.m_chipLabel:getPos(), UserSeat.SEAT_HEIGHT - height);
	    self.m_animationContainer:addChild(buyInBackground);
	    buyInBackground:setTransparency(0);
        buyInBackground:addPropTransparency(0, kAnimNormal, 700, 0, 0, 1);
        local anim = buyInBackground:addPropTransparency(1, kAnimNormal, 1300, 700, 1, 0);
        anim:setEvent(buyInBackground, onComplete);

	    local sprite = new(Node);
	    self.m_animationContainer:addChild(sprite);

	    local buyInIcon = new(Image, "buyin-action-icon.png");
        local width,heightBuyInIcon = buyInIcon:getSize();
	    sprite:addChild(buyInIcon);

        --Text.ctor = function(self, str, width, height, align, fontName, fontSize, r, g, b, fontBold,radius,dx,dy,dr,dg,db,fontItalic)
	    local buyInLabel = new(Text, STR_COMMON_NUMBER_CURRENCY_LABEL .. Formatter.formatBigNumber(buyInChips, false), nil, nil, kTextAlignCenter, nil, 24, 0xec, 0xce, 0x0b);
	    sprite:addChild(buyInLabel);
    --	buyInLabel.validate();
        local width,height = buyInLabel:getSize();
        buyInLabel:setPos(width + 2, (heightBuyInIcon - height) * 0.5);

        sprite:setPos((UserSeat.SEAT_WIDTH - As3Kit.getNodeWidth(sprite)) * 0.5, As3Kit.getNodeY(buyInBackground) - 20);
        sprite:addPropTransparency(0, kAnimNormal, 2000, 0, 1, 0.75);
        local anim = sprite:addPropTranslate(1, kAnimNormal, 2000,0, nil,nil, 0, As3Kit.getNodeY(self.m_photoOverlay)-As3Kit.getNodeY(sprite));
        anim:setEvent(sprite, function(sp) sp:removeFromParent(true); end);
    end
end

--
--座位的播放表情扣钱动画
--
UserSeat.playExpressionMinusMoneyAnimation = function(self, moneyNum)
	if (Model.getData(ModelKeys.APP_DEACTIVATE)) then
		return;
	end
	local sprite = new(Node);
	self.m_animationContainer:addChild(sprite);

	local minusMoneyIcon = new(Image, "play-expression-minus-money-icon.png");
	sprite:addChild(minusMoneyIcon);

    --Text.ctor = function(self, str, width, height, align, fontName, fontSize, r, g, b, fontBold,radius,dx,dy,dr,dg,db,fontItalic)
	local minusMoneyLabel = new(Text, STR_COMMON_NUMBER_CURRENCY_LABEL .. Formatter.formatBigNumber(moneyNum, false),
                                nil, nil, kTextAlignCenter, nil, 24, 0xec, 0xce, 0x0b);
	sprite:addChild(minusMoneyLabel);

--	minusMoneyLabel.validate();
    minusMoneyLabel:setPos(As3Kit.getNodeWidth(minusMoneyIcon) + 4);

    minusMoneyIcon:setPos(nil, (As3Kit.getNodeHeight(sprite) - As3Kit.getNodeHeight(minusMoneyIcon)) / 2);

    sprite:setPos((UserSeat.SEAT_WIDTH - As3Kit.getNodeWidth(sprite)) * 0.5, 32);
    sprite:addPropTransparency(0, kAnimNormal, 2000, 0, 1, 0.7);
    local anim = sprite:addPropTranslate(1, kAnimNormal, 2000, 0, nil,nil, 0, UserSeat.SEAT_HEIGHT - As3Kit.getNodeHeight(sprite) - As3Kit.getNodeY(sprite));
    anim:setEvent(sprite, function(sp) sp:removeFromParent(true); end);
end

UserSeat.stopWinAnimation = function(self)
	--展示姓名
	self:showName();
    self.m_winAnimation = nil;
end

UserSeat.addGift = function(self, giftId, sendSeatId)
    sendSeatId = sendSeatId or -1;
	if (giftId ~= 0) then
		self.m_seatData.giftId = giftId;
		self.m_giftContainer:addChild(self.m_giftSprite);
        local arrChild = self.m_giftSprite:getChildren();
        if(arrChild and arrChild[1]) then
            self.m_giftSprite:removeChild(arrChild[1]);
        end
--??		GiftLoader.loadAndSetGift(_giftSprite, String(self.m_seatData.giftId));
		if (sendSeatId ~= -1) then
			local fromSeat = SeatManager.getUserSeat(sendSeatId);
			local globalPoint =
            {
                x = SeatManager.seatPositionV[fromSeat.positionId].x + UserSeat.SEAT_WIDTH * 0.5 - 28,
				y = SeatManager.seatPositionV[fromSeat.positionId].y + UserSeat.SEAT_HEIGHT * 0.5 - 28,
            };
--			self:globalToLocal(globalPoint, HELPER_POINT);
--			TweenLite.from(_giftSprite, 1, {x:HELPER_POINT.x, y:HELPER_POINT.y});
            UserSeat.HELPER_POINT.x,UserSeat.HELPER_POINT.y = self:convertSurfacePointToView(globalPoint.x, globalPoint.y);
            local x,y = self.m_giftSprite:getPos();
            self.m_giftSprite:addPropTranslate(0, kAnimNormal, 1000, 0, 0,UserSeat.HELPER_POINT.x-x, 0,UserSeat.HELPER_POINT.y-y);
		end
	else
		self.m_giftContainer:addChild(self.m_giftButton);
	end
end

UserSeat.sitDownAnimation = function(self, duration)
    duration = duration or 0.5;
    KTween.remove(self.m_photoLoader);
    self.m_sitdownContainer:setVisible(true);
	self.m_animationContainer:setVisible(true);
	self.m_giftContainer:setVisible(true);

	self.m_statusContainer:setVisible(true);
    self.m_btnInviteFriends:setVisible(false);

	if duration == 0 then
        self.m_photoLoader:setPos(nil, 0);
		self:sitdownCompleteHandler();
	else
        self.m_photoLoader:setPos(nil, 0);
        KTween.to(self.m_photoLoader, duration * 1200, {startY = - 100, y = 0, easeType=EaseType.BackOut, obj = self, onComplete = self.sitdownCompleteHandler});
	end
end

UserSeat.sitdownCompleteHandler = function(self)
	self:showPhoto(true);
    self.m_vipIcon:setVisible(false);
	--vip标识
	if self.m_seatData.vip > 0  then
        self.m_vipIcon:setVisible(true);
		self.m_vipIcon:setFile("vip_icon_" .. self.m_seatData.vip .. ".png");
	end
	self:setUserPhotoTexture();
end

UserSeat.standUpAnimation = function(self)
	self:showPhoto(false);
    KTween.remove(self.m_btnSitdown);
    KTween.to(self.m_btnSitdown, 600, {startY = 100, y = 0, easeType = EaseType.BackOut, obj = self, onComplete = self.standUpCompleteHandler});
end

UserSeat.standUpCompleteHandler = function(self)
    local visible = ((SeatManager.selfSeatId == -1) and not LoginSuccData.isMatch(SeatManager.roomType) and Model.getData(ModelKeys.USER_LOGINED_ROOM));
	self:setVisible(visible);
end

UserSeat.showHandCard = function(self, data)
	self.m_handCard:visibleHandCard();
	self.m_handCard:setHandCard(data.card1, data.card2);
	self.m_handCard:setHandCardShowingPosition();
	local showHandCardAnimationData = SeatManager.showHandCardAnimationDataV[self.m_positionId];
	self.m_handCard:addPropRotateSolid(0, showHandCardAnimationData.rotation, kCenterDrawing, 0, 0);

    local anim = self.m_handCard:addPropScale(0, kAnimNormal, 100, 0, 0.6,0.8, 0.6,0.8, kCenterDrawing, 0, 0);
    local function onScaleEnd(self)
        self.m_handCard:removeProp(0);
        self.m_handCard:addPropScale(0, kAnimNormal, 250, 0, 0.8,0.5, 0.8,0.5, kCenterDrawing, 0, 0);
    end
    anim:setEvent(self, onScaleEnd);
    local x,y = self.m_handCard:getPos();
    self.m_handCard:addPropTranslate(1, kAnimNormal, 350, 0, 0,showHandCardAnimationData.destX-x, 0,showHandCardAnimationData.destY-y);
    local x,y = self.m_handCard.handCardV[0]:getPos();
    self.m_handCard.handCardV[0]:addPropTranslate(0, kAnimNormal, 250, 100, 0,-36-x);
    local x,y = self.m_handCard.handCardV[1]:getPos();
    self.m_handCard.handCardV[1]:addPropTranslate(0, kAnimNormal, 250, 100, 0,76-x);
	
    SoundManager.playSound("ShowHandCard");
	self.m_showedHandCard = true;
end

--[Comment]
--显示邀请好友图标
UserSeat.showInviteFriends = function(self)
    self.m_btnInviteFriends:setVisible(true);
    self.m_btnSitdown:setVisible(false);
end
		
--改变坐下图标
UserSeat.changeSitdownIconTexture = function(self)
    self.m_btnInviteFriends:setVisible(false);
	self.m_btnSitdown:setVisible(true);
end

--[Comment]
--得到正在显示的是坐下图标还是邀请好友图标,是坐下图标返回flase
UserSeat.isShowInviteFriends = function(self)
    return self.m_btnInviteFriends:getVisible();
end

UserSeat.startTimer = function(self)
    self.m_seatTimer:start();
    self.m_seatTimer:setVisible(true);
    local userData = Model.getData(ModelKeys.USER_DATA);

    if self:isSelf() and userData ~= nil then
		self.m_seatTimer.isRunning = false;
	else
		self.m_seatTimer.isRunning = true;
	end

	if self:isSelf() and TutotiaKit.isTutotia() then
		self.m_seatTimer.isRunning = false;
	end
end

UserSeat.stopTimer = function(self)
	self.m_seatTimer:setVisible(false);
    self.m_seatTimer:stop();
end

--[Comment]
-- 刷新	
UserSeat.refresh = function(self)
	if not self:isSelf() and self.m_showedHandCard then
		self.m_handCard:resetHandCardPosition();
		self.m_showedHandCard = false;
	end
	self.m_handCard:refresh();
	self.m_seatData.operationStatus = TableUserData.SEAT_READY;
	self:stopWinAnimation();
end

--[Comment]
--清理
UserSeat.cleanUp = function(self)
	self:refresh();
	if self:isSelf() then
		self.m_handCard:resetHandCardPosition();
	end
	self.m_inGame = false;
	self.m_isStanded = true;
	self.m_seatData.uid = -1;
	self.m_giftContainer:setVisible(false);
	self.m_vipIcon:setVisible(false);
	self.m_statusContainer:setVisible(false);
	self.m_photoLoader:setVisible(false);
	Model.unwatchProperty(ModelKeys.USER_DATA, "m_picture", self, self.__onChangePhoto);
			
	self.m_btnSitdown:setVisible(true);
end


UserSeat.get_handCard = function(self)
	return self.m_handCard;
end

UserSeat.get_seatData = function(self)
	return self.m_seatData;
end

--[Comment]
--设置座位数据
UserSeat.setSeatData = function(self, value)
	local userData = Model.getData(ModelKeys.USER_DATA);
    self.m_seatData = value;
	if self:isSelf() then
		Model.watchProperty(ModelKeys.USER_DATA, "m_picture", self, self.__onChangePhoto, false);
	end
			
	--处理名字和筹码
	if System.isIOS7() and LocalService.currentLocaleId() == "th_TH" then
		self.m_nameLabel:setText(self.m_seatData.name);
	else
		self.m_nameLabel:setText(self.m_seatData.name);     --这里需要加上名字长度缩短逻辑
	end
	self.m_chipLabel:setText(STR_COMMON_NUMBER_CURRENCY_LABEL..Formatter.formatBigNumber(self.m_seatData.seatChips, false));
			
	--处理礼物
	if self:isSelf() then
		self.m_seatData.giftId = userData.user_gift;
    end
	
    if self.m_seatData.giftId then
		self.m_giftButton:setVisible(false);
		--GiftLoader.loadAndSetGift(_giftSprite, String(self.m_seatData.giftId));
	end
			
	--处理头像
	--if (PhotoCache.instance.hasCache(self.m_seatData.uid + "_100"))
	--{
		--_photoLoader.data = PhotoCache.instance.getCache(self.m_seatData.uid + "_100");
	--}
    self:showPhoto(true);
	if string.len(self.m_seatData.photoUrl) <= 5 then
		local photoUrl = PhotoKit.getDefaultPhotoUrl(self.m_seatData.photoUrl);
        if photoUrl ~= nil then
			self.m_photoLoader:setFile(photoUrl);--获取游客头像
		else
			self:setDefaultPhoto();
		end
	end
end


UserSeat.getInGame = function(self)
	return self.m_inGame;
end

UserSeat.setInGame = function(self, value)
	self.m_inGame = value;
end

UserSeat.getCardType = function(self)
	return self.m_cardType;
end

UserSeat.setCardType = function(self, value)
	self.m_cardType = value;
end

UserSeat.getSeatId = function(self)
	return self.m_seatId;
end

UserSeat.getPositionId = function(self)
	return self.m_positionId;
end

UserSeat.setPositionId = function(self, value)
	self.m_positionId = value;
--    if(self.m_seatId == self.m_positionId) then
--        Log.d("test", "error");
--    end
	--位置改变，礼物框也相应改变
--	if (self:isInitialized) then
--		if (self.m_positionId == 1 or self.m_positionId == 2 or self.m_positionId == 3 or self.m_positionId == 5 or self.m_positionId == 6) then
--            local w,h = self.m_giftButton:getSize();
--            self.m_giftSprite:setPos(-w*0.6);
--            self.m_giftButton:setPos(-w*0.6);
--		else
--            local w,h = self.m_giftButton:getSize();
--			self.m_giftSprite:setPos(UserSeat.SEAT_WIDTH - w * 0.4);
--            self.m_giftButton:setPos(UserSeat.SEAT_WIDTH - w * 0.4);
--		end
--        local x,y = self.m_giftButton:getPos();
--		self.m_giftSprite:setPos(nil, y);
--	end
end
		
UserSeat.getShowedHandCard = function(self)
	return self.m_showedHandCard;
end
		
UserSeat.isStanded = function(self)
	return self.m_isStanded;
end

UserSeat.setStanded = function(self, value)
	self.m_isStanded = value;
end

UserSeat.getCompulsoryShowHandCard = function(self)
	return self.m_compulsoryShowHandCard;
end

UserSeat.setCompulsoryShowHandCard = function(self, value)
	self.m_compulsoryShowHandCard = value;
end

UserSeat.getHandCard = function(self)
   return self.m_handCard;
end

--[Comment]
--获取用户数据
UserSeat.getSeatData = function(self)
    return self.m_seatData
end

--[Comment]
--获取用户座位Id
UserSeat.getSeatId = function(self)
    return self.m_seatId;
end

--[Comment]
--显示头像，如果显示头像则隐藏坐下按钮，反之如果显示坐下按钮，则显示头像
UserSeat.showPhoto = function(self, value)
    if value == nil then
        value = true;
    end
    self.m_photoLoader:setVisible(value);
    self.m_photoOverlay:setVisible(value);
    self.m_btnSitdown:setVisible(not value);
end

UserSeat.playExpAnim = function(self, exp)
    if self.m_expSprite ~= nil then
        self.m_expSprite:setExp(exp);
    end
end