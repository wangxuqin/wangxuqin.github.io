QuadLine = class(Node);

kQuadType = {
    leftToRight = 1;
    rightToLeft = 2;
    upToDown    = 3;
    downToUp    = 4;
}

QuadLine.ctor = function (self,x,y,w,h,quadType)
    self.m_quadType = quadType;

    self.m_vertexId = res_alloc_id();
    self.m_indexId  = res_alloc_id();
    self.m_colorId  = res_alloc_id();
    
    self:createQuadVertexData(x,y,w,h);

    res_create_double_array(0,self.m_vertexId,self.m_vertex);
    res_create_ushort_array(0,self.m_indexId,self.m_index);
    res_create_double_array(0,self.m_colorId,self.m_color);

    drawing_set_node_renderable(self.m_drawingID,0x0005,0x20)
    drawing_set_node_vertex(self.m_drawingID,self.m_vertexId,self.m_indexId);
    drawing_set_node_colors(self.m_drawingID,self.m_colorId )

end

QuadLine.createQuadVertexData = function (self,x,y,w,h)
    self.m_vertex = {x,   y,
                     x+w, y,
                     x+w, y+h,
                     x,   y+h};

    self.m_index = {0, 1, 2,
                    0, 2, 3};

    self.m_color = {0.0, 1.0, 0.0,1.0,
                    0.0, 1.0, 0.0,1.0,
                    0.0, 1.0, 0.0,1.0,
                    0.0, 1.0, 0.0,1.0
                    };
end

QuadLine.quadVertexUpdate = function (self,steps) 
    local currentVertex = {};
    for i = 1, 8 do
        currentVertex[i] = self.m_vertex[i];
    end
    
    if self.m_quadType == kQuadType.leftToRight then
        currentVertex[1] = self.m_vertex[1]+steps;
        currentVertex[7] = self.m_vertex[7]+steps;
    elseif self.m_quadType == kQuadType.rightToLeft then
        currentVertex[3] = self.m_vertex[3]-steps;
        currentVertex[5] = self.m_vertex[5]-steps;
    elseif self.m_quadType == kQuadType.upToDown then
        currentVertex[2] = self.m_vertex[2]+steps;
        currentVertex[4] = self.m_vertex[4]+steps;
    elseif self.m_quadType == kQuadType.downToUp then
        currentVertex[6] = self.m_vertex[6]-steps;
        currentVertex[8] = self.m_vertex[8]-steps;
    end
    res_set_double_array(self.m_vertexId,currentVertex);
end

QuadLine.setColor = function (self,r,g,b)
    self.m_color = {
                    r,g,b,1.0,
                    r,g,b,1.0,
                    r,g,b,1.0,
                    r,g,b,1.0
    }
    res_set_double_array(self.m_colorId,self.m_color);
end

QuadLine.release = function (self)
    res_delete(self.m_vertexId);
    res_delete(self.m_indexId);
    res_delete(self.m_colorId);
end
