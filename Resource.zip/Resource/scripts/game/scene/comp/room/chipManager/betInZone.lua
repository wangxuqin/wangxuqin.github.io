---------------------------------------------------------------

BetInZone = class(Node);

BetInZone.m_chipLabel = nil;
BetInZone.whiteChipBitmapFontTextFormat = nil;
BetInZone.yellowChipBitmapFontTextFormat = nil;

BetInZone.init = function(self)
	BetInZone.yellowChipBitmapFontTextFormat = nil;
	BetInZone.whiteChipBitmapFontTextFormat = nil;
end

BetInZone.ctor = function(self, labelColor)
	local background = new(Image, "chip/room_bet_chip_bg.png");
	self:addChild(background);

    local r = 0;
    local g = 0;
    local b = 0;
    if (labelColor == "w") then
--		self.m_chipLabel.textRendererProperties.textFormat = whiteChipBitmapFontTextFormat;
        r = 255;
        g = 255;
        b = 255;
	else
--		self.m_chipLabel.textRendererProperties.textFormat = yellowChipBitmapFontTextFormat;
        r = 231;
        g = 188;
        b = 0;
	end
    local w,h = background:getSize();
	self.m_chipLabel = new(Text, "0", nil, nil, nil, nil, 24, r, g, b);
	self.m_chipLabel:setPos(0, 0);
    self.m_chipLabel:setAlign(kAlignCenter);
	self:addChild(self.m_chipLabel);
    self:setPickable(false);
    self:setSize(w, h);
end

BetInZone.setChipLabel = function(self, value)
	self.m_chipLabel:setText(Formatter.formatBigNumber(value, false));
end
