-------------------------------------------------------------
require("game/scene/comp/room/chipManager/chipInfo");
require("game/scene/comp/room/chipManager/userChip");
require("game/scene/comp/room/chipManager/potChip");
require("game/scene/comp/room/chipManager/betInZone");
require("game/scene/comp/room/biggestCardTypeTip");

ChipManager = class();

ChipManager.CHIP_THICK = 4;--ÿ������ĺ��
ChipManager.POP_CHIP_DURATION = 0.4;--��ע���붯��ʱ��
ChipManager.MOVE_DELAY_DURATION = 0.075;--������м��ʱ��
ChipManager.MOVE_POT_DURATION = 0.6;--�ƶ����ض���ʱ��
ChipManager.SPLIT_POTS_DURATION = 2;--�������طֽ���ʱ��

ChipManager.HELPER_POINT = new(Point);
ChipManager.GLOBAL_POINT = new(Point);
ChipManager.CARD_TYPE_KEY = {"highCard", "onePair", "twoPair", "threeKind", "straight", "flush", "fullHouse", "fourKind", "straightFlush", "royalFlush"};
ChipManager.m_stageWidth = 0;
ChipManager.m_quadBatchOffsetY = 0;
ChipManager.m_screen = nil;
ChipManager.m_container = nil;
ChipManager.m_userChipV = {};
ChipManager.m_betZoneSpriteV = {};
ChipManager.m_betZoneQuadBatchV = {};
ChipManager.m_potChipV = {};
ChipManager.m_potZoneSpriteV = {};
ChipManager.m_potZoneQuadBatchV = {};
ChipManager.m_chip1 = nil;--1�ų��룬��ɫ����ֵ1������λ
ChipManager.m_chip2 = nil;--2�ų��룬��ɫ����ֵ1��ż��λ
ChipManager.m_chip3 = nil;--3�ų��룬��ɫ����ֵ2������λ
ChipManager.m_chip4 = nil;--4�ų��룬��ɫ����ֵ2��ż��λ
ChipManager.m_chip5 = nil;--5�ų��룬��ɫ����ֵ5������λ
ChipManager.m_chip6 = nil;--6�ų��룬��ɫ����ֵ5��ż��λ
ChipManager.m_chipInfoPool = nil;
ChipManager.m_potsInfo = {};--������Ϣ����
ChipManager.m_dealPoolId = 0;--��ǰ���ڴ����Ľ���id
ChipManager.m_biggestCardTypeTip = nil;  --���������ʾ
ChipManager.m_splitTimer = nil;
ChipManager.m_timeout1 = 0;
ChipManager.m_timeout2 = 0;
ChipManager.m_timeout3 = 0;
ChipManager.m_timeout4 = 0;

ChipManager.initialize = function(self, screen, childrenIndex) 
	self.m_stageWidth = System.getLayoutWidth();
	self.m_quadBatchOffsetY = 14;

	self.m_screen = screen;
	self.m_container = new(Node);
	self.m_container:setPickable(false);
    self.m_container:setLevel(100);
	self.m_screen:addChild(self.m_container);

	--��ע������ʾ��
	self.m_userChipV = {};
	self.m_betZoneSpriteV = {};
	self.m_betZoneQuadBatchV = {};
    for i=1,9 do
		self.m_betZoneSpriteV[i] = new(BetInZone, "w");--��λ��id���
		self.m_betZoneSpriteV[i]:setVisible(false);
		self.m_betZoneSpriteV[i]:setPos(SeatManager.m_chipPositionV[i].x, SeatManager.m_chipPositionV[i].y);
		self.m_container:addChild(self.m_betZoneSpriteV[i]);

		self.m_betZoneQuadBatchV[i] = new(Node);--����λid���
		self.m_betZoneQuadBatchV[i]:setPos(SeatManager.m_chipPositionV[i].x + 36, SeatManager.m_chipPositionV[i].y - self.m_quadBatchOffsetY);
		self.m_container:addChild(self.m_betZoneQuadBatchV[i]);

		self.m_userChipV[i] = new(UserChip, self.m_betZoneQuadBatchV[i], SeatManager.m_userSeatV[i]);
	end

	--���س�����ʾ��
	self.m_potChipV = {};
	self.m_potZoneSpriteV = {};
	self.m_potZoneQuadBatchV = {};
    for i=1,9 do
		self.m_potZoneSpriteV[i] = new(BetInZone, "y");--��λ��id���
		self.m_potZoneSpriteV[i]:setVisible(false);
		self.m_potZoneSpriteV[i]:setPos(SeatManager.m_potPositionV[i].x, SeatManager.m_potPositionV[i].y);
		self.m_container:addChild(self.m_potZoneSpriteV[i]);
	end
    for i=9,1,-1 do
		self.m_potZoneQuadBatchV[i] = new(Node);--��λ��id���
		self.m_potZoneQuadBatchV[i]:setPos(SeatManager.m_potPositionV[i].x + 36, SeatManager.m_potPositionV[i].y - self.m_quadBatchOffsetY);
		self.m_container:addChild(self.m_potZoneQuadBatchV[i]);

		self.m_potChipV[i] = new(PotChip, self.m_potZoneQuadBatchV[i]);
	end

	--��ʼ���������أ��ı�ע���
	self.m_chip1 = "chip/room_chip_odd_1.png";
	self.m_chip2 = "chip/room_chip_even_1.png";
	self.m_chip3 = "chip/room_chip_odd_2.png";
	self.m_chip4 = "chip/room_chip_even_2.png";
	self.m_chip5 = "chip/room_chip_odd_5.png";
	self.m_chip6 = "chip/room_chip_even_5.png";


	--������Ϣ�����
	self.m_chipInfoPool = nil;

	--�ֽ��ض�ʱ��
	self.m_splitTimer = new(Timer, ChipManager.SPLIT_POTS_DURATION * 1000);

	self.m_biggestCardTypeTip = new(BiggestCardTypeTip);
    self.m_biggestCardTypeTip:setPos(self.m_stageWidth / 2, SeatManager.m_seatPositionV[4].y - 60);
    self.m_biggestCardTypeTip:setVisible(false);
    self.m_container:addChild(self.m_biggestCardTypeTip);
end

ChipManager.takeOutChipInfos = function(self, value)
	local chipInfoV = {};
	local chipStr = tostring(value);
	local chipLen = string.len(chipStr);
    for i=1,chipLen do
		local number = tonumber(string.sub(chipStr, i, i));
		local oddOrEven = (chipLen - i) % 2 == 1 and "even" or "odd";
		if (number >= 5) then
			chipInfoV[#chipInfoV+1] = self:retriveChipInfo(5, oddOrEven);
			number = number - 5;
		end
		while (number >= 2) do
			chipInfoV[#chipInfoV+1] = self:retriveChipInfo(2, oddOrEven);
			number = number - 2;
		end
		if (number == 1) then
			chipInfoV[#chipInfoV+1] = self:retriveChipInfo(1, oddOrEven);
		end
	end
	return chipInfoV;
end

ChipManager.retriveChipInfo = function(self, number, oddOrEven) 
	local chip = new(ChipInfo);
	if(number == 1) then
		if (oddOrEven == "odd") then
			chip.number = 1;
		else
			chip.number = 2;
		end
	elseif(number == 2) then
		if (oddOrEven == "odd") then
			chip.number = 3;
		else
			chip.number = 4;
		end
	elseif(number == 5) then
		if (oddOrEven == "odd") then
			chip.number = 5;
		else
			chip.number = 6;
		end
	end
	return chip;
end

ChipManager.getChip = function(self, number) 
    local filename = self["m_chip" .. number];
    local image = new(Image, filename);
	return image;
end

ChipManager.recycleChipInfoV = function(self, chipInfoV) 
	if (chipInfoV) then
		local infoLength = #chipInfoV;
        for i=1,infoLength do
			chipInfoV[i].x = 0;
			chipInfoV[i].y = 0;
			chipInfoV[i].alpha = 1;
		end
		chipInfoV = nil;
	end
end

--[Comment]
-- ������ע���ע���룬���ݾ������ֵ��������Ӧ���벢ʵ�ַ��붯��
-- @param	operationNeedChips	������Ҫ�ĳ���
-- @param	totalBetInChips		�ܼ�ע����
-- @param	userSeat			��λ����
ChipManager.popChip = function(self, operationNeedChips, totalBetInChips, userSeat) 
	self.m_userChipV[userSeat.m_seatId]:moveToBet(operationNeedChips, totalBetInChips);
end

ChipManager.setMovingBetChipInfo = function(self) 
    for i=1,9 do
		self.m_userChipV[i]:setMovingBetChipInfo();
	end
end

ChipManager.gatherPrizePool = function(self, data) 
    for i=1,9 do
		self.m_userChipV[i]:moveToPot();
		self.m_betZoneSpriteV[i]:setVisible(false);
	end
	self.m_timeout1 = setTimeout(self.replacePot, self, ChipManager.MOVE_POT_DURATION * 1000, data);
end

--�滻���س���
ChipManager.replacePot = function(self, data) 
	local chipInfoArr = data;
    for i=1,#chipInfoArr do
		self.m_potChipV[i]:refreshPot(chipInfoArr[i]);
		self:modifyPot(i, chipInfoArr[i]);
	end
end

ChipManager.splitPrizePool = function(self, data) 
	--��������
	self.m_potsInfo = data.chipsPotsInfo;
	local arrLength = #self.m_potsInfo;
	self.m_dealPoolId = 1;
	if (arrLength ~= 0) then
		self:startSplit();
	end
	if (arrLength > 1) then
		self.m_splitTimer:reset();
		self.m_splitTimer:setRepeatCount(arrLength - 1);
		self.m_splitTimer:setEvent(self, self.startSplit);
		self.m_splitTimer:start();
	end
end

ChipManager.onTimeoutShowBiggestCardType = function(self)
    self.m_biggestCardTypeTip:setVisible(false);
end

ChipManager.showBiggestCardType = function(self, currentSeatId) 
    self.m_biggestCardTypeTip:setVisible(true);

	if (self.m_dealPoolId <= #self.m_potsInfo) then
		local winnerArr = self.m_potsInfo[self.m_dealPoolId].winner;
        local i=1;
        while(i <= #winnerArr) do
			if (winnerArr[i].m_seatId == currentSeatId) then
				break;
			end
            i = i + 1;
		end
		clearTimeout(self.m_timeout4);
		if (i <= #winnerArr) then
			self.m_timeout4 = setTimeout(self.onTimeoutShowBiggestCardType, self, 3900);
		else
            self.m_timeout4 = setTimeout(self.onTimeoutShowBiggestCardType, self, 1900);
		end
	else
		clearTimeout(self.m_timeout4);
        setTimeout(self.onTimeoutShowBiggestCardType, self, 1900);
	end
end

ChipManager.onTimeoutStartSplit = function(userSeat)
    userSeat:stopWinAnimation();
end

ChipManager.startSplit = function(self) 
	if (not self.m_screen:handledGameOver()) then
		self.m_splitTimer:stop();
        self.m_splitTimer:setEvent(self, nil);
		return;
	end
	if (self.m_dealPoolId == #self.m_potsInfo+1 and self.m_splitTimer ~= nil) then
		self.m_splitTimer:stop();
		self.m_splitTimer:setEvent(self, nil);
	end

	PublicCardManager:fadeAllPublicCard();
	SeatManager:fadeAllHandCard();

    for i=1,9 do
		self.m_userChipV[i]:refresh();
	end

	local winnerArr = self.m_potsInfo[self.m_dealPoolId].winner;
	local userSeat = nil;
    for i=1,#winnerArr do
		userSeat = SeatManager:getUserSeat(winnerArr[i].seatId);
		if (userSeat.m_compulsoryShowHandCard) then
            for n=1,5 do
				PublicCardManager:hightLightPublicCard(winnerArr[i]["card" + n]);
				userSeat.m_handCard:hightLightHandCard(winnerArr[i]["card" + n]);
			end
		end

		--���û�û��վ�𣬲���Ӯ�ƶ���
		if not userSeat:isStanded() then
			userSeat:playWinAnimation();
			self.m_timeout3 = setTimeout(ChipManager.onTimeoutStartSplit, userSeat, ChipManager.SPLIT_POTS_DURATION * 1000 - 200);
			--�Լ�Ӯ�ƣ����Ŵ�Ӯ�ƶ���
			if userSeat:isSelf() then
				SeatManager:hideCardType();
				if self.m_screen:selfTrueWin() and SeatManager.selfInGame then
					self.m_screen:invalidSelfTrueWin();
					TableAnimationManager:youWin();
					if (winnerArr[i].cardType >= 6 and winnerArr[i].cardType <= 9) then
						SoundManager.playSound(Music.effect.YouWin);
					end

                    local cardType = userSeat:getCardType();

					if(cardType == 2) then
						--VoiceManager.play(Music.effect.MAN.WIN_HIGH_CARD);
					elseif(cardType == 3) then
						--VoiceManager.play(Music.effect.MAN.WIN_ONE_PAIR);
					elseif(cardType == 4) then
						--VoiceManager.play(Music.effect.MAN.WIN_TWO_PAIRS);
					elseif(cardType == 5) then
						--VoiceManager.play(Music.effect.MAN.WIN_THREE_OF_A_KIND);
					elseif(cardType == 6) then
						--VoiceManager.play(Music.effect.MAN.WIN_STRAIGHT);
					elseif(cardType == 7) then
						--VoiceManager.play(Music.effect.MAN.WIN_FLUSH);
					elseif(cardType == 8) then
						--VoiceManager.play(Music.effect.MAN.WIN_FULL_HOUSE);
					elseif(cardType == 9) then
						--VoiceManager.play(Music.effect.MAN.WIN_FOUR_OF_A_KIND);
					elseif(cardType == 10) then
						--VoiceManager.play(Music.effect.MAN.WIN_STRAIGHT_FLUSH);
					elseif(cardType == 11) then
						--VoiceManager.play(Music.effect.MAN.WIN_ROYAL_FLUSH);
                    end

					if (cardType >= 7 and CookieService.getString(CookieKeys.LOGIN_TYPE) == LoginTypes.LOGIN_TYPE_FACEBOOK and (Model.getData(ModelKeys.USER_IN_TUTOTIA) == nil or (Model.getData(ModelKeys.USER_IN_TUTOTIA) ~= nil and not Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart))) then
						--local cardType = STR_ROOM_CARD_TYPE[userSeat.m_cardType-1];
						--local typeKey = ChipManager.CARD_TYPE_KEY[userSeat.m_cardType - 2];
--						FrameworkGlobal.context.dispatchEventWith(CommandEventNames.ROOM_FACEBOOK_SHARE, false, {
--							"title":Localization.getText("SOCIAL.GOOD_HAND_SHARE_TITLE", cardType), 
--							"feedId":"cardType", 
--							"image":typeKey, 
--							"callBack":function (data:Object)
--							{
--								data.message = formatString(data.message, cardType);
--								data.picture = formatString(data.picture, typeKey);
--							}
--						});
					end
				end
			end
		end

		--�ֽ��ض���
		self:splitAnimation(self.m_potsInfo[self.m_dealPoolId].perMoney, userSeat);
		SoundManager.playSound(Music.effect.MovingChips);

		--�ϱ�Ӯ����󽱳�
		if(Model.getData(ModelKeys.USER_DATA) ~= nil) then
			if (userSeat:isSelf() and self.m_potsInfo[self.m_dealPoolId].perMoney > Model.getData(ModelKeys.USER_DATA).maxaward) then
--                FrameworkGlobal.context.dispatchEventWith(CommandEventNames.ROOM_SET_MAX_AWARD, false, self.m_potsInfo[self.m_dealPoolId].perMoney);
                EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_SET_MAX_AWARD, self.m_potsInfo[self.m_dealPoolId].perMoney);
			end
		end
	end

	self.m_dealPoolId = self.m_dealPoolId + 1;

	--��ʾӮ������
	if(userSeat.m_cardType > 0) then
		self:showBiggestCardType(userSeat.m_seatId);
		self.m_biggestCardTypeTip:setCardType(STR_ROOM_CARD_TYPE[userSeat.m_cardType]);
	end
end

--�ֽ��ض��� 
-- @param winChips
-- @param userSeat
ChipManager.splitAnimation = function(self, winChips, userSeat) 
	--�ɳ��붯��
	self.m_potChipV[self.m_dealPoolId]:refresh();
	self.m_userChipV[userSeat.m_seatId]:moveToSeat(winChips, self.m_dealPoolId);
	self.m_timeout2 = setTimeout(self.setUserSeatChips, self, ChipManager.MOVE_POT_DURATION * 1000, {winChips=winChips, userSeat=userSeat});

	--Ӱ�ؽ�����
	self:hidePot(self.m_dealPoolId);
end
		
ChipManager.setUserSeatChips = function(self, data) 
	local winChips = data.winChips;
	local userSeat = data.userSeat;
	if (not userSeat:isStanded()) then
		userSeat:setSeatChips(userSeat.m_seatData.seatChips + winChips);
	end
end

-- ת���ӽ�ʱ�������һ��ת��
ChipManager.moveBetZoneSprite = function(self, trackArr, movieTime, userSeat) 
	local arrLenth = #trackArr;
	local bezierArr = {};
	local positionId = 0;
	local trackX = 0;
	local trackY = 0;
    local x,y = self.m_betZoneQuadBatchV[userSeat.m_seatId]:getPos();
    bezierArr[1] = {x=x,y=y};
    for i=1,arrLenth do
		positionId = trackArr[i];
		trackX = SeatManager.m_chipPositionV[positionId].x + 36;
		trackY = SeatManager.m_chipPositionV[positionId].y - self.m_quadBatchOffsetY;
		bezierArr[i+1] = {x=trackX, y=trackY};
	end
--	TweenMax.to(self.m_betZoneQuadBatchV[userSeat.m_seatId], movieTime, {bezier:bezierArr});
    AnimKit.doBezier(self.m_betZoneQuadBatchV[userSeat.m_seatId], bezierArr, movieTime);
end

-- ת���ӽ�ʱ�������һ��ת��,����û��ת������
ChipManager.moveBetZoneSpriteNotAnimation = function(self, positionId, userSeat) 
	local x = SeatManager.m_chipPositionV[positionId].x + 36;
	local y = SeatManager.m_chipPositionV[positionId].y - self.m_quadBatchOffsetY;
    self.m_betZoneQuadBatchV[userSeat.m_seatId]:setPos(x, y);
end

ChipManager.hideBet = function(self, positionId) 
	self.m_betZoneSpriteV[positionId]:setVisible(false);
end
		
ChipManager.hideAllBet = function(self) 
    for i=1,9 do
		self.m_betZoneSpriteV[i]:setVisible(false);
	end
end

ChipManager.modifyBet = function(self, positionId, chips) 
	self.m_betZoneSpriteV[positionId]:setVisible(true);
	self.m_betZoneSpriteV[positionId]:setChipLabel(chips);
end

ChipManager.refreshBet = function(self, positionId, chips) 
	self.m_userChipV[positionId]:refreshBet(chips);
end

ChipManager.hidePot = function(self, positionId) 
	self.m_potZoneSpriteV[positionId]:setVisible(false);
end

ChipManager.hideAllPot = function(self) 
    for i=1,8 do
		self.m_potZoneSpriteV[i]:setVisible(false);
	end
end

ChipManager.modifyPot = function(self, positionId, chips) 
	self.m_potZoneSpriteV[positionId]:setVisible(true);
	self.m_potZoneSpriteV[positionId]:setChipLabel(chips);
end

ChipManager.refreshPot = function(self, positionId, chips) 
	self.m_potChipV[positionId]:refreshPot(chips);
end

ChipManager.refresh = function(self) 
	clearTimeout(self.m_timeout1);
	clearTimeout(self.m_timeout2);
	clearTimeout(self.m_timeout3);

	self.m_splitTimer:stop();
	self.m_splitTimer:setEvent(nil, nil);

	self:hideAllBet();
	self:hideAllPot();

    for i=1,9 do
		self.m_userChipV[i]:refresh();
		self.m_potChipV[i]:refresh();
	end

    self.m_biggestCardTypeTip:setVisible(false);
end

ChipManager.cleanUp = function(self) 
	clearTimeout(self.m_timeout1);
	clearTimeout(self.m_timeout2);
	clearTimeout(self.m_timeout3);

	self.m_splitTimer:stop();
	self.m_splitTimer:setEvent(nil, nil);

    for i=1,9 do
		local x = SeatManager.m_chipPositionV[i].x + 36;
		local y = SeatManager.m_chipPositionV[i].y - self.m_quadBatchOffsetY;
        self.m_betZoneQuadBatchV[i]:setPos(x, y);
	end
end

ChipManager.get_potZoneQuadBatchV = function(self)
	return self.m_potZoneQuadBatchV;
end
