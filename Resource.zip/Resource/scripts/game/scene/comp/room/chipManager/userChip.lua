-----------------------------------------------------------------
require("ui/point");

UserChip = class();

UserChip.TAG = "UserChip";

UserChip.m_quadBatch = nil;--:QuadBatch;
UserChip.m_userSeat = nil;--:UserSeat;
UserChip.m_popChipInfoV = nil;--:Vector.<ChipInfo>;
UserChip.m_previousBetChipInfoV = nil;--:Vector.<ChipInfo>;
UserChip.m_movingBetChipInfoV = nil;--:Vector.<ChipInfo>;
UserChip.m_betChipInfoV = nil;--:Vector.<ChipInfo>;
UserChip.m_potChipInfoV = nil;--:Vector.<ChipInfo>;
UserChip.m_chipThick = 0;

UserChip.ctor = function(self, quadBatch, userSeat)
	self.m_quadBatch = quadBatch;
	self.m_userSeat = userSeat;
	self.m_chipThick = ChipManager.CHIP_THICK;
    self:setBetChipStack();
	self.m_timerUpdate = 0;
	self.m_flagUpdate = 0;--1=bet, 2=pot, 3=seat
end

UserChip.createTimer = function(self)
--	Log.d(UserChip.TAG, "createTimer:" .. self.m_timerUpdate);
	if(self.m_timerUpdate == 0) then
		self.m_timerUpdate = setInterval(self.updateToXXX, self, 0);
	end
end

UserChip.destroyTimer = function(self)
--	Log.d(UserChip.TAG, "destroyTimer:" .. self.m_timerUpdate);
	if(self.m_timerUpdate ~= 0) then
		clearInterval(self.m_timerUpdate);
		self.m_timerUpdate = 0;
	end
end

UserChip.updateToXXX = function(self)
--	if(self.m_flagUpdate ~= 0) then
--		Log.d(UserChip.TAG, "updateToXXX:" .. self.m_flagUpdate);
--	end
	if(self.m_flagUpdate == 1) then
		self:updateToBet();
	elseif(self.m_flagUpdate == 2) then
		self:updateToPot();
	elseif(self.m_flagUpdate == 3) then
		self:updateToSeat();
	end
end

UserChip.setBetChipStack = function(self)--private 
	if (self.m_betChipInfoV and not Model.getData(ModelKeys.APP_DEACTIVATE)) then
		local infoLength = #self.m_betChipInfoV;
        for i=1,infoLength do
			local chip = ChipManager:getChip(self.m_betChipInfoV[i].number);
            local w,h = chip:getSize();
			self.m_betChipInfoV[i].x = 0;
			self.m_betChipInfoV[i].y = -(i-1) * self.m_chipThick;
            self.m_betChipInfoV[i].alpha = 1;
            chip:setPos(self.m_betChipInfoV[i].x - w/2, self.m_betChipInfoV[i].y - h/2);
			chip:setTransparency(self.m_betChipInfoV[i].alpha);
			self.m_quadBatch:addChild(chip);
		end
	end
end

UserChip.refreshBet = function(self, betChips)--public 
	--���ճ�������
	ChipManager:recycleChipInfoV(self.m_betChipInfoV);
	self.m_betChipInfoV = ChipManager:takeOutChipInfos(betChips);
			
	--�滻�����
	self:setBetChipStack();
end

UserChip.moveToBet = function(self, operationNeedChips, totalBetInChips)--public 
--	self.m_quadBatch:removeAllChildren();

	--�������ڷ��еĳ�������
	ChipManager:recycleChipInfoV(self.m_popChipInfoV);
	self.m_previousBetChipInfoV = self.m_betChipInfoV;

	--��ȡ�µĳ�������
	self.m_popChipInfoV = ChipManager:takeOutChipInfos(operationNeedChips);
	self.m_betChipInfoV = ChipManager:takeOutChipInfos(totalBetInChips);

	local infoLength = #self.m_popChipInfoV;
    for i=1,infoLength do
		local x = SeatManager.m_seatPositionV[self.m_userSeat.m_positionId].x + UserSeat.SEAT_WIDTH * 0.5;
		local y = SeatManager.m_seatPositionV[self.m_userSeat.m_positionId].y + UserSeat.SEAT_HEIGHT * 0.5;
		x,y = self.m_quadBatch:convertSurfacePointToView(x, y);
		self.m_popChipInfoV[i].x = x;
		self.m_popChipInfoV[i].y = y;
		self.m_popChipInfoV[i].alpha = 0.5;

        local lpfnComplete = nil;
        if (i == infoLength) then
            lpfnComplete = self.moveToBetCompleteHandler;
        end
        AnimKit.tweenTo(self.m_popChipInfoV[i], ChipManager.POP_CHIP_DURATION*1000,
            {
                delay = (i-1) * ChipManager.MOVE_DELAY_DURATION * 1000,
                alpha = 1,
                x = 0,
                y = -(i-1) * self.m_chipThick,
                onComplete = lpfnComplete,
                obj = self,
            });
	end
    if(infoLength > 0) then
		self.m_flagUpdate = 1;
		self:createTimer();
    else
        self.m_flagUpdate = 0;
--		self:destroyTimer();
    end
end

UserChip.updateToBet = function(self)--public
	self.m_quadBatch:removeAllChildren();

	local length1 = 0;
	local chip = nil;
	local i = 0;
	if (self.m_previousBetChipInfoV) then
		length1 = #self.m_previousBetChipInfoV;
        for i=1,length1 do
			chip = ChipManager:getChip(self.m_previousBetChipInfoV[i].number);
            local w,h = chip:getSize();
			self.m_previousBetChipInfoV[i].x = 0;
			self.m_previousBetChipInfoV[i].y = -(i-1) * self.m_chipThick;
            self.m_previousBetChipInfoV[i].alpha = 1;
            chip:setPos(self.m_previousBetChipInfoV[i].x - w/2, self.m_previousBetChipInfoV[i].y - h/2);
			chip:setTransparency(self.m_previousBetChipInfoV[i].alpha);
			self.m_quadBatch:addChild(chip);
		end
	end
	local length2 = self.m_popChipInfoV and #self.m_popChipInfoV or 0;
    for i=1,length2 do
		chip = ChipManager:getChip(self.m_popChipInfoV[i].number);
        local w,h = chip:getSize();
        chip:setPos(self.m_popChipInfoV[i].x - w/2, self.m_popChipInfoV[i].y - length1 * self.m_chipThick - h/2);
        local alpha = self.m_popChipInfoV[i].alpha;
		chip:setTransparency(alpha);
		if (alpha > 0.5) then
			self.m_quadBatch:addChild(chip);
        end
	end
end

--tween�������滻����� 
-- @param quadBatch
-- 
UserChip.moveToBetCompleteHandler = function(self)--private 
--	self:destroyTimer();
	self.m_flagUpdate = 0;
	self.m_quadBatch:removeAllChildren();

	--�������ڷ��еĳ�������
	ChipManager:recycleChipInfoV(self.m_popChipInfoV);
	self.m_popChipInfoV = nil;
	ChipManager:recycleChipInfoV(self.m_previousBetChipInfoV);
	self.m_previousBetChipInfoV = nil;

	--�滻�����
	self:setBetChipStack();
end

UserChip.setMovingBetChipInfo = function(self)--public 
	self.m_movingBetChipInfoV = self.m_betChipInfoV;
end

UserChip.moveToPot = function(self)--public 
	self.m_quadBatch:removeAllChildren();

	--�������ڷ��еĳ�������
	ChipManager:recycleChipInfoV(self.m_popChipInfoV);
	self.m_popChipInfoV = nil;
	ChipManager:recycleChipInfoV(self.m_previousBetChipInfoV);
	self.m_previousBetChipInfoV = nil;

	if (self.m_movingBetChipInfoV) then
		local infoLength = #self.m_movingBetChipInfoV;
        for i=infoLength,1,-1 do
			local x,y = ChipManager.m_potZoneQuadBatchV[1]:getPos();
			x,y = self.m_quadBatch:convertSurfacePointToView(x, y);
            local lpfnComplete = nil;
            if(i == 1) then
                lpfnComplete = self.moveToPotCompleteHandler;
            end
            AnimKit.tweenTo(self.m_movingBetChipInfoV[i], ChipManager.MOVE_POT_DURATION * 1000,
                {
                    delay = (infoLength - i)  * ChipManager.MOVE_DELAY_DURATION * 1000,
                    alpha = 0.5,
                    x = x,
                    y = y,
                    onComplete = lpfnComplete,
                    obj = self,
                });
		end
        if(infoLength > 0) then
			self.m_flagUpdate = 2;
			self:createTimer();
        end
	end
end

UserChip.updateToPot = function(self)--private 
	self.m_quadBatch:removeAllChildren();

	if (self.m_movingBetChipInfoV) then
		local infoLength = #self.m_movingBetChipInfoV;
        for i=1,infoLength do
			local chip = ChipManager:getChip(self.m_movingBetChipInfoV[i].number);
            local w,h = chip:getSize();
			chip:setPos(self.m_movingBetChipInfoV[i].x - w/2, self.m_movingBetChipInfoV[i].y - h/2);
			chip:setTransparency(self.m_movingBetChipInfoV[i].alpha);
			if (self.m_movingBetChipInfoV[i].alpha > 0.5) then
				self.m_quadBatch:addChild(chip);
			end
		end
	end
end

UserChip.moveToPotCompleteHandler = function(self)--private 
    self.m_flagUpdate = 0;
--	self:destroyTimer();
	self.m_quadBatch:removeAllChildren();
	ChipManager:recycleChipInfoV(self.m_movingBetChipInfoV);
	if (self.m_betChipInfoV == self.m_movingBetChipInfoV) then
		self.m_betChipInfoV = nil;
	end
	self.m_movingBetChipInfoV = nil;
end

UserChip.moveToSeat = function(self, winChips, potId)--public 
	self.m_quadBatch:removeAllChildren();

	--�������ڷ��еĳ�������
	ChipManager:recycleChipInfoV(self.m_potChipInfoV);

	--��ȡ�µĳ�������
	self.m_potChipInfoV = ChipManager:takeOutChipInfos(winChips);
	local infoLength = #self.m_potChipInfoV;
    for i=1,infoLength do
		local x = ChipManager.m_potZoneQuadBatchV[potId].m_x;
		local y = ChipManager.m_potZoneQuadBatchV[potId].m_y - 1 * self.m_chipThick;
		x,y = self.m_quadBatch:convertSurfacePointToView(x, y);
		self.m_potChipInfoV[i].x = x;
		self.m_potChipInfoV[i].y = y;
	end

    for i=infoLength,1,-1 do
		local x = SeatManager.m_seatPositionV[self.m_userSeat.m_positionId].x + UserSeat.SEAT_WIDTH * 0.5;
		local y = SeatManager.m_seatPositionV[self.m_userSeat.m_positionId].y + UserSeat.SEAT_HEIGHT * 0.5;
        x,y = self.m_quadBatch:convertSurfacePointToView(x, y);

        local lpfnComplete = nil;
        if(i == 1) then
            lpfnComplete = self.moveToSeatCompleteHandler;
        end
        AnimKit.tweenTo(self.m_potChipInfoV[i], ChipManager.MOVE_POT_DURATION * 1000,
            {
                delay = (infoLength - i) * ChipManager.MOVE_DELAY_DURATION * 1000,
                alpha = 0.5,
                x = x,
                y = y,
                onComplete = lpfnComplete,
                obj= self,
            });
	end
	self.m_flagUpdate = 3;
	self:createTimer();
end

UserChip.updateToSeat = function(self)--private 
	self.m_quadBatch:removeAllChildren();
	local infoLength = self.m_potChipInfoV and #self.m_potChipInfoV or 0;
    for i=1,infoLength do
		local chip = ChipManager:getChip(self.m_potChipInfoV[i].number);
        local w,h = chip:getSize();
		chip:setPos(self.m_potChipInfoV[i].x - w/2, self.m_potChipInfoV[i].y - h/2);
		chip:setTransparency(self.m_potChipInfoV[i].alpha);
		if (self.m_potChipInfoV[i].alpha > 0.5) then
			self.m_quadBatch:addChild(chip);
		end
	end
end

UserChip.moveToSeatCompleteHandler = function(self)--private 
    self.m_flagUpdate = 0;
--	self:destroyTimer();
	ChipManager:recycleChipInfoV(self.m_potChipInfoV);
	self.m_potChipInfoV = nil;
	self.m_quadBatch:removeAllChildren();
end

UserChip.refresh = function(self)--public 
	ChipManager:recycleChipInfoV(self.m_potChipInfoV);
	self.m_potChipInfoV = nil;
	ChipManager:recycleChipInfoV(self.m_betChipInfoV);
	self.m_betChipInfoV = nil;
	ChipManager:recycleChipInfoV(self.m_previousBetChipInfoV);
	self.m_previousBetChipInfoV = nil;
	ChipManager:recycleChipInfoV(self.m_movingBetChipInfoV);
	self.m_movingBetChipInfoV = nil;
	ChipManager:recycleChipInfoV(self.m_popChipInfoV);
	self.m_popChipInfoV = nil;

	self.m_quadBatch:removeAllChildren();
	self.m_flagUpdate = 0;
	self:destroyTimer();
end
