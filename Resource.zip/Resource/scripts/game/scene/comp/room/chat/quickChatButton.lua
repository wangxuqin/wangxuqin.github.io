--------------------------------------------------------
QuickChatButton = class(Button, false);

QuickChatButton.ctor = function(self, label, w, h, objOnClick, funcOnClick)
	super(self, "chat/chat-quick-chat-up.png", "chat/chat-quick-chat-down.png", nil, nil, 10, 10, 10, 10);
	self:setSize(w, h);
	self.m_label = new(Text, label);
	self.m_label:setAlign(kAlignCenter);
	self:addChild(self.m_label);
	self.m_objOnClick = objOnClick;
	self.m_funcOnClick = funcOnClick;
	self:setOnClick(self, self.__onClick);
end

QuickChatButton.__onClick = function(self)
	if(self.m_funcOnClick) then
		self.m_funcOnClick(self.m_objOnClick, self.m_label:getText());
	end
end
