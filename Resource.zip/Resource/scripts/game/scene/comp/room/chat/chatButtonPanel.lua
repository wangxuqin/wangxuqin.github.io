--------------------------------------------------------
ChatButtonPanel = class(Node, false);

ChatButtonPanel.TAG = "ChatButtonPanel";

ChatButtonPanel.ctor = function(self, screen)--public
	super(self);

    self.m_screen = nil;--:GameRoomScreen;
    self.m_emtBtn = nil;--:DynamicHitAreaButton;
    self.m_chatBtn = nil;--:Scale3Image;
    self.m_chatLog = nil;--:Label;
    self.m_chatPop = nil;--:ChatPop;
    self.m_logBg = nil;--:Scale3Image;

    self.m_screen = screen;
--	this.addEventListener(Event.ADDED_TO_STAGE, addedToStageHandler);
    Model.watchData(ModelKeys.ROOM_CHAT_DATA, self, self.setChatLog, false);
	Model.watchData(ModelKeys.ROOM_SMALL_LABA_DATA, self, self.setChatLog, false);
    self:initialize();
end

ChatButtonPanel.dtor = function(self)
	Model.unwatchData(ModelKeys.ROOM_CHAT_DATA, self, self.setChatLog);
	Model.clearWatcher(ModelKeys.ROOM_SMALL_LABA_DATA, self, self.setChatLog);
end

--ChatButtonPanel.removedFromStageHandler = function(self)--private
--{
--	this.removeEventListener(Event.REMOVED_FROM_STAGE, removedFromStageHandler);
--	this.addEventListener(Event.ADDED_TO_STAGE, addedToStageHandler);
--	FrameworkGlobal.context.removeEventListener(CommandEventNames.ROOM_CHAT_SEND_EXPRESSION, removeChildFromStage);
--	FrameworkGlobal.context.removeEventListener(UIEventNames.REMOVE_CHAT_POPUP, removeChildFromStage);
--	FrameworkGlobal.context.removeEventListener(UIEventNames.ROOM_PASSIVE_LEAVE_ROOM, removeChildFromStage);
--	
--	Model.clearWatcher(ModelKeys.ROOM_CHAT_DATA, setChatLog);
--	Model.clearWatcher(ModelKeys.ROOM_SMALL_LABA_DATA, setChatLog);
--	
--	self.m_chatLog.text = "";
--}
--
--ChatButtonPanel.addedToStageHandler = function(self)--private
--{
--	this.removeEventListener(Event.ADDED_TO_STAGE, addedToStageHandler);
--	this.addEventListener(Event.REMOVED_FROM_STAGE, removedFromStageHandler);
--	FrameworkGlobal.context.addEventListener(CommandEventNames.ROOM_CHAT_SEND_EXPRESSION, removeChildFromStage);
--	FrameworkGlobal.context.addEventListener(UIEventNames.REMOVE_CHAT_POPUP, removeChildFromStage);
--	FrameworkGlobal.context.addEventListener(UIEventNames.ROOM_PASSIVE_LEAVE_ROOM, removeChildFromStage);
--	
--	Model.watchData(ModelKeys.ROOM_CHAT_DATA, setChatLog, false);
--	Model.watchData(ModelKeys.ROOM_SMALL_LABA_DATA, setChatLog, false);
--}

--ChatButtonPanel.draw = function(self)--override protected
--	self.m_logBg.y = (self.m_chatBtn.height - self.m_logBg.height) * 0.5;
--	
--	self.m_chatLog.validate();
--	self.m_chatLog.x = self.m_logBg.x + 4;
--	self.m_chatLog.y = layoutCenter(self.m_logBg.y, self.m_logBg.height, self.m_chatLog.height);
--	
--	self.m_emtBtn.validate();
--	self.m_emtBtn.x = 2;
--	self.m_emtBtn.y = 3;
--end

ChatButtonPanel.initialize = function(self)--override protected
	local stageWidth = System.getLayoutWidth();
	local stageHeight = System.getLayoutHeight();
    self:setSize(288 * (stageWidth / 960));

	--聊天按钮
	self.m_chatBtn = self.m_screen:getNodeByName("bg.btn_chat");
	self.m_chatBtn:setOnClick(self, self.chatBtnTriggeredHandler);

	--表情按钮
	self.m_emtBtn = self.m_screen:getNodeByName("bg.btn_chat.btn_emt");
	self.m_emtBtn:setOnClick(self, self.emtBtnTriggeredHandler);


	--记录
	self.m_chatLog = self.m_screen:getNodeByName("bg.btn_chat.img_input_bg.chat_log");

    self.m_chatLog:setPickable(false);

end


ChatButtonPanel.chatBtnTriggeredHandler = function(self)--private
    Log.d(ChatButtonPanel.TAG, "chatBtnTriggeredHandler");
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_CHAT_POP);
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_QUICK_CHAT);
end

ChatButtonPanel.emtBtnTriggeredHandler = function(self)--private
    Log.d(ChatButtonPanel.TAG, "emtBtnTriggeredHandler");
--??	PopUpManager.addPopUp(self.m_chatPop, true, false);
--??	FrameworkGlobal.context.dispatchEventWith(CommandEventNames.ROOM_QUICK_EXPRESSION,false);
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_CHAT_POP);
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_QUICK_EXPRESSION);
end

ChatButtonPanel.removeChildFromStage = function(self)
	if self.m_chatPop ~= nil then
		self.m_chatPop:removeFromParent(true);
    end
end

ChatButtonPanel.setChatLog = function(self, data)--private
	--小喇叭消息变下颜色
	if (data["type"] and data["type"] == 2) then
        self.m_chatLog:setFontSize(20);
        local r,g,b = RGBKit.getRGB(0x76a9bf);
        self.m_chatLog:setColor(r, g, b);
	else
        self.m_chatLog:setFontSize(20);
        local r,g,b = RGBKit.getRGB(0x60676e);
        self.m_chatLog:setColor(r, g, b);
	end
    local msg = data.senderName .. " : " .. data.message;
--	Formatter.spliceMultiLineLongString(data.senderName + " : " + data.message, self.m_chatLog.width, 2, self.m_chatLog, TextFieldAutoSize.LEFT);
    self.m_chatLog:setText(msg);
end
