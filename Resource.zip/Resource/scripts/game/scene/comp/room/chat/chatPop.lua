-------------------------------------------------------------
require("view/room/layout_chat_pop");
require("game/scene/comp/room/chat/expressionButton");
require("game/scene/comp/room/chat/quickChatButton");

ChatPop = class(PopupDialog, false);

ChatPop.TAG = "ChatPop";

ChatPop.LEFT_MARGIN = 9;
ChatPop.PAGE_EXPRESSION = "expression";
ChatPop.PAGE_QUICKCHAT = "quickChat";

ChatPop.ctor = function(self)
    super(self, layout_chat_pop, true);

    self.m_currentMode = 1;--1=普通聊天，2=小喇叭，3=大喇叭
    self.m_normalTexture = "chat/chat-quick-chat-icon.png";
	self.m_dalabaTexture = "chat/chat-dalaba-icon.png";
	self.m_xiaolabaTexture = "chat/chat-xiaolaba-icon.png";

    self.m_root:setLevel(10);
    local tabBG = self.m_root:getNodeByName("operation_area.bg2.page_expression.tab_bg");
    self.m_widthTabBG = tabBG:getSize();
    self.m_chatTypeIcon = self.m_root:getNodeByName("operation_area.bg1.chat_input.btn_select.chat_type_icon");
    self.m_defaultText = STR_ROOM_CLICK_INPUT_CHAT_MESSAGE;
    --文字本地化
    local allLocalization =
    {
        { "operation_area.bg1.btn_send.tx_send", STR_SETTING_SEND },--发送按钮文字
        { "check_panel.bg.btn_chat_normal.text_normal_chat", STR_ROOM_NORMAL_CHAT },--普通聊天
        { "check_panel.bg.btn_small_horn.text_small_horn", STR_ROOM_SMALL_LABA },--小喇叭
        { "check_panel.bg.btn_big_horn.text_big_horn", STR_ROOM_BIG_LABA },--大喇叭
        { "check_panel.bg.btn_buy_horn.text_buy_horn", STR_ROOM_BUY_LABA },--购买喇叭
    };
    for _,v in pairs(allLocalization) do
        local tx = self.m_root:getNodeByName(v[1]);
        tx:setText(v[2]);
    end
    --输入框hint
    self.m_textInput = self.m_root:getNodeByName("operation_area.bg1.chat_input.input");
    self.m_textInput:setHintText(STR_ROOM_CLICK_INPUT_CHAT_MESSAGE);
    --聊天记录
    local wStage = System.getScreenScaleWidth();
    local hStage = System.getScreenScaleHeight();
    local bg1 = self.m_root:getNodeByName("operation_area.bg1");
    local w1,h1 = bg1:getSize();
    local bg2 = self.m_root:getNodeByName("operation_area.bg2");
    local w2,h2 = bg2:getSize();
    local scroll = new(ScrollView2, 0, 0, wStage, hStage-h1-h2, true);
    self.m_scrollChatLog = scroll;
    self:addChild(scroll);
    --聊天记录填充内容(test)
--    for i=1,32 do
--        local tx = new(Text, string.format("GerryGuo:message %d", i), nil, nil, nil, nil, 32, 255, 255, 255);
--        scroll:addChild(tx);
--    end
    --表情聊天区域
    self.m_pageExpression = self.m_root:getNodeByName("operation_area.bg2.page_expression");
    self.m_viewExpression = self.m_root:getNodeByName("operation_area.bg2.page_expression.expression");
    --tab
    self.m_tabsExpression = {};
    --普通表情scrollview
    local scroll = new(ScrollView2, 0, 0, wStage, 238, true);
    scroll:setDirection(kHorizontal);
    self.m_viewExpression:addChild(scroll);
    local data = {};
    for i=1,30 do
        data[i] = { id=i, texture="expressions/expression-" .. i .. "-0001.png" };
    end
    self:addExpressions(data, scroll);
    self.m_tabsExpression[#self.m_tabsExpression+1] = scroll;
    --VIP表情scrollview
    local scroll = new(ScrollView2, 0, 0, wStage, 238, true);
    scroll:setDirection(kHorizontal);
    self.m_viewExpression:addChild(scroll);
    local data = {};
    for i=61,90 do
        data[i] = { id=i, texture="expressions/expression-" .. i .. "-0001.png" };
    end
    self:addExpressions(data, scroll);
    self.m_tabsExpression[#self.m_tabsExpression+1] = scroll;
    --VIP Bear表情scrollview
    local scroll = new(ScrollView2, 0, 0, wStage, 238, true);
    scroll:setDirection(kHorizontal);
    self.m_viewExpression:addChild(scroll);
    local data = {};
    for i=10101,10112 do
        data[i] = { id=i, texture="expressions/racoon-expression-" .. i .. "-0001.png" };
    end
    self:addExpressions(data, scroll);
    self.m_tabsExpression[#self.m_tabsExpression+1] = scroll;

    --快捷聊天页面
    local scroll = new(ScrollView2, 0, 0, w2, h2, true);
    self.m_pageQuickChat = scroll;
    bg2:addChild(scroll);
    local item = nil;
    for i=1,#STR_ROOM_PHRASE_ARRAY do
        local label = STR_ROOM_PHRASE_ARRAY[i];
        if((i-1) % 2 == 0) then
            item = new(DrawingEmpty);
            item:setSize(w2, 84);
            scroll:addChild(item);
        end
        local btn = new(QuickChatButton, label, 610, 64, self, self.__onQuickChatBtnClick);
        btn:setAlign(kAlignCenter);
        if((i-1)%2 == 0) then
            btn:setPos(-315);
        else
            btn:setPos(315);
        end
        item:addChild(btn);
    end
    self.m_pageQuickChat:setVisible(false);
    --操作面板
    self.m_checkPanel = self.m_root:getNodeByName("check_panel");
    self:hideCheckPanel();
    self.m_smallLabaNumber = 1;--test
    self.m_bigLabaNumber = 1;--test
    self.m_xiaolabaLabel = self.m_root:getNodeByName("check_panel.bg.btn_small_horn.num_bg.text_num");
    self.m_dalabaLabel = self.m_root:getNodeByName("check_panel.bg.btn_big_horn.num_bg.text_num");
    self.m_xiaolabaNumber = self.m_root:getNodeByName("check_panel.bg.btn_small_horn.num_bg");
    self.m_dalabaNumber = self.m_root:getNodeByName("check_panel.bg.btn_big_horn.num_bg");
    --事件注册
    local allEvents =
    {
        { UIEvent, UIEvent.s_cmd.REMOVE_CHAT_POPUP, "__onRemoveChatPop" },
        { CommandEvent, CommandEvent.s_cmd.ROOM_QUICK_CHAT, "__onSwitchToQuickChat" },
        { CommandEvent, CommandEvent.s_cmd.ROOM_QUICK_EXPRESSION, "__onSwitchToExpression" },
    };
    self.m_allEventParams = {};
    for _,v in pairs(allEvents) do
        local param = new(EventParam, v[1], v[2], self, v[3]);
        self.m_allEventParams[#self.m_allEventParams+1] = param;
        EventDispatcher.getInstance():registerByParam(param);
    end

    self:__setExpressionTab(1);
    self.m_curPage = ChatPop.PAGE_EXPRESSION;
end

ChatPop.dtor = function(self)
    for _,v in pairs(self.m_allEventParams) do
        EventDispatcher.getInstance():unregisterByParam(v);
    end
    self.m_allEventParams = {};
    Model.unwatchData(ModelKeys.ROOM_CHAT_HISTORY, self, self.setChatLog);
end

ChatPop.update = function(self, data)
    --拉取喇叭数量
	Model.watchData(ModelKeys.ROOM_USER_PROP_DATA, self, self.__getUserPropData, false);
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_GET_USER_PROPS);
end

ChatPop.onPopupEnd = function(self)
    local operation_area = self.m_root:getNodeByName("operation_area");
    operation_area:removeProp(0);
    if(self.m_scrollChatLog) then
        self.m_scrollChatLog:removeProp(0);
    end
    --事件响应
    local eventlist =
    {
        { "operation_area.bg1", "setEventTouch", self.__onTouchBG1 },
        { "btn_close", "setOnClick", self.onClickClose },
        { "operation_area.bg2.page_expression", "setEventTouch", self.__onTouchTab },
        { "operation_area.bg1.btn_expression", "setOnClick", self.__onClickBtnExpression },
        { "operation_area.bg1.chat_input.btn_select", "setOnClick", self.__onClickBtnQuickChat },
        { "check_panel.bg.btn_chat_normal", "setOnClick", self.__onClickBtnNormalChat },
        { "check_panel.bg.btn_small_horn", "setOnClick", self.__onClickBtnSmallHorn },
        { "check_panel.bg.btn_big_horn", "setOnClick", self.__onClickBtnBigHorn },
        { "check_panel.bg.btn_buy_horn", "setOnClick", self.__onClickBtnBuyHorn },
        { "check_panel", "setEventTouch", self.__onTouchCheckPanel },
        { "operation_area.bg1.btn_send", "setOnClick", self.__onClickBtnSend },
    };
    for _,v in pairs(eventlist) do
        local view = self.m_root:getNodeByName(v[1]);
        if(view) then
            view[v[2]](view, self, v[3]);
        end
    end
end

ChatPop.setChatLog = function(self, data)
    --test
    if(data == nil) then
        data =
        {
            { message="大家好", senderName="gym", type=1 },
            { message="all in", senderName="gerry", type=1 },
            { message="网络不好", senderName="gym", type=1 },
            { message="快来", senderName="gym", type=1 },
        };
    end
	if (data) then
--??		_dataProvider.data = data;  --得到聊天记录
--??		_dataProvider.dispatchEventWith(CollectionEventType.RESET);
--??		_dataProvider.dispatchEventWith(Event.CHANGE);
--??		this.invalidate();
        self.m_scrollChatLog:removeAllChildren();
        for _,v in pairs(data) do
            local tx = new(Text, v.senderName .. ":" .. v.message, nil, nil, nil, nil, 32, 255, 255, 255);
            self.m_scrollChatLog:addChild(tx);
        end
	end
end

ChatPop.show = function(self)
    local function onShow(self)
        local operation_area = self.m_root:getNodeByName("operation_area");
        local animX,animY = operation_area:addAtomPropTranslateEase(0, kAnimNormal, EaseType.ExpOut, 500, 0, nil, nil, 420, 0);
        if(self.m_scrollChatLog) then
            local w,h = self.m_scrollChatLog:getSize();
            self.m_scrollChatLog:gotoBottom();
            self.m_scrollChatLog:addAtomPropTranslateEase(0, kAnimNormal,EaseType.ExpOut, 500, 0, nil,nil, -h, 0);
        end
        Model.watchData(ModelKeys.ROOM_CHAT_HISTORY, self, self.setChatLog);
	    Model.setData(ModelKeys.HAS_POP_UP, true);
        return animY;
    end
    PopupDialog.show(self, PopupDialog.kPopupStyleCustom, onShow);
end

ChatPop.onClickClose = function(self)
    self:close();
end

ChatPop.addExpressions = function(self, allExpress, container)
    local wScroll,hScroll = container:getSize();
    local item = nil;
    local i = 0;
    for _,express in pairs(allExpress) do
        if(i % 2 == 0) then
            item = new(DrawingEmpty);
            item:setSize(100, hScroll);
            container:addChild(item);
        end

        local btn = new(ExpressionButton, express.id, express.texture, "chat/expression-btn-down.png");
        btn:setPos(50, (i % 2) * 100 + 56);
        item:addChild(btn);
        i = i + 1;
    end
end

ChatPop.__onTouchBG1 = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
end

ChatPop.__onTouchTab = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
    Log.d(ChatPop.TAG, "touch tab");
    if(finger_action == kFingerDown) then
        self.m_iTabDown = math.floor((x - ChatPop.LEFT_MARGIN) / self.m_widthTabBG) + 1;
    elseif(finger_action == kFingerMove) then
    elseif(finger_action == kFingerUp) then
        local iTab = math.floor((x - ChatPop.LEFT_MARGIN) / self.m_widthTabBG) + 1;
        if(iTab == self.m_iTabDown) then
            self:__setExpressionTab(iTab);
        end
    end
end

ChatPop.__setExpressionTab = function(self, iTab)
    if(self.m_tabsExpression[iTab]) then
        local tabBG = self.m_root:getNodeByName("operation_area.bg2.page_expression.tab_bg");
        tabBG:setPos(ChatPop.LEFT_MARGIN+self.m_widthTabBG*(iTab-1));
        for i=1,#self.m_tabsExpression do
            if(i == iTab) then
                self.m_tabsExpression[i]:setVisible(true);
            else
                self.m_tabsExpression[i]:setVisible(false);
            end
        end
    end
end

ChatPop.__onQuickChatBtnClick = function(self, data)
    SoundManager.playButtonClickSound();
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_CHAT_SEND_MESSAGE, data);
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.REMOVE_CHAT_POPUP);
end

ChatPop.__onRemoveChatPop = function(self, data)
    self:close();
end

ChatPop.__onClickBtnExpression = function(self)
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_QUICK_EXPRESSION);
end

ChatPop.__onClickBtnQuickChat = function(self)
    if(self.m_curPage == ChatPop.PAGE_QUICKCHAT) then
        self.m_checkPanel:setVisible(true);
    end
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_QUICK_CHAT);
end

ChatPop.__onSwitchToExpression = function(self)
    self:__switchToPageExpression(true);
end

ChatPop.__onSwitchToQuickChat = function(self)
    self:__switchToPageQuickChat(true);
end

ChatPop.__switchToPageExpression = function(self, arrow_ani)
    self.m_pageExpression:setVisible(true);
    self.m_pageQuickChat:setVisible(false);
    if(self.m_curPage ~= ChatPop.PAGE_EXPRESSION) then
        local arrow = self.m_root:getNodeByName("operation_area.bg2.arrow_indicator");
        if(arrow_ani) then
            KTween.remove(arrow);
            KTween.to(arrow, 200, {startX=85, x=0});
        else
            KTween.remove(arrow);
            KTween.to(arrow, 0, {startX=85, x=0});
        end
        self.m_curPage = ChatPop.PAGE_EXPRESSION;
    end
end

ChatPop.__switchToPageQuickChat = function(self, arrow_ani)
    self.m_pageExpression:setVisible(false);
    self.m_pageQuickChat:setVisible(true);
    if(self.m_curPage ~= ChatPop.PAGE_QUICKCHAT) then
        local arrow = self.m_root:getNodeByName("operation_area.bg2.arrow_indicator");
        if(arrow_ani) then
            KTween.remove(arrow);
            KTween.to(arrow, 200, {startX=0, x=85});
        else
            KTween.remove(arrow);
            KTween.to(arrow, 0, {startX=0, x=85});
        end
        self.m_curPage = ChatPop.PAGE_QUICKCHAT;
    end
end

ChatPop.__onClickBtnNormalChat = function(self)
    self.m_chatTypeIcon:setFile(self.m_normalTexture);
    self.m_currentMode = 1;
    self:hideCheckPanel();
--    self.m_textInput:setFocus(true);--EditText没有setFocus方法
end

ChatPop.__onClickBtnSmallHorn = function(self)
    if(self.m_smallLabaNumber > 0) then
        self.m_chatTypeIcon:setFile(self.m_xiaolabaTexture);
		self.m_currentMode = 2;
--??		_chatTypeIcon.readjustSize();
--??		_chatTypeIcon.x = (58 - _chatTypeIcon.width) * 0.5;
--??		_chatTypeIcon.y = (_selectorBtn.height - _chatTypeIcon.height) * 0.5;
--??				
--??		_textInput.setFocus();
	else
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,{
            message = STR_ROOM_ROOM_CHAT_XIAO_LA_BA_PROMPT,
			confirm = STR_GIFT_BUY,
            cancel = STR_COMMON_CANCEL,
			obj = self,
            callback=self.confirmReturn,
		});
	end
	self:hideCheckPanel();
end

ChatPop.confirmReturn = function(self, stype)
	if(stype == DialogCallback.CONFIRM) then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_PROPS_PAGE);
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.REMOVE_CHAT_POPUP);
	end
end

ChatPop.hideCheckPanel = function(self)
    self.m_checkPanel:setVisible(false);
end

ChatPop.__onClickBtnBigHorn = function(self)
    if(self.m_bigLabaNumber > 0) then
		self.m_chatTypeIcon:setFile(self.m_dalabaTexture);
		self.m_currentMode = 3;
--??		_chatTypeIcon.readjustSize();
--??		_chatTypeIcon.x = (58 - _chatTypeIcon.width) * 0.5;
--??		_chatTypeIcon.y = (_selectorBtn.height - _chatTypeIcon.height) * 0.5;
--??				
--??		_textInput.setFocus();
	else
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,{
            message = STR_ROOM_ROOM_CHAT_DA_LA_BA_PROMPT,
			confirm = STR_GIFT_BUY,
            cancel = STR_COMMON_CANCEL,
			obj = self,
            callback=self.confirmReturn,
		});
	end
	self:hideCheckPanel();
end

ChatPop.__onClickBtnBuyHorn = function(self)
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_PROPS_PAGE);
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.REMOVE_CHAT_POPUP);
end

ChatPop.__onTouchCheckPanel = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
    if(finger_action == kFingerDown) then
        self:hideCheckPanel();
    end
end

ChatPop.__getUserPropData = function(self, data)
    --互动道具分类
    for i=1,#data do
        local iType = tonumber(data[i].a);
        local num = tonumber(data[i].b);
		if(iType == 30) then
			if (num > 0) then
				self.m_xiaolabaNumber:setFile("chat/chat-laba-enabled-bg.png");
			else
                self.m_xiaolabaNumber:setFile("chat/chat-laba-disabled-bg.png");
			end
			self.m_smallLabaNumber = num;
			self.m_xiaolabaLabel:setText(tostring(num));--小喇叭
		elseif(iType == 32) then
			if (num > 0) then
				self.m_dalabaNumber:setFile("chat/chat-laba-enabled-bg.png");
			else
				self.m_dalabaNumber:setFile("chat/chat-laba-disabled-bg.png");
            end
			self.m_bigLabaNumber = num;
			self.m_dalabaLabel:setText(tostring(num));--大喇叭
	    end
    end
end

ChatPop.__onClickBtnSend = function(self)
	local txt = self.m_textInput:getText();
	if(txt and txt ~= self.m_defaultText and string.len(txt) > 0) then
		SoundManager.playButtonClickSound();
		if(self.m_currentMode == 1) then--普通聊天信息
            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_CHAT_SEND_MESSAGE, txt);
		elseif(self.m_currentMode == 2) then--小喇叭信息
			if (self.m_smallLabaNumber > 0) then
                EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_CHAT_SMALL_LABA, txt);
			else
                EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_NO_SMALL_LABA);
			end
		elseif(self.m_currentMode == 3) then--大喇叭信息
			if (self.m_bigLabaNumber > 0) then
                EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_CHAT_BIG_LABA, txt);
			else
                EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_NO_BIG_LABA);
			end
        end
--		_textInput.text = _defaultText;
--		_textInput.textEditorProperties.color = _defaultColor;
        self.m_textInput:setText("");
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.REMOVE_CHAT_POPUP);
	end
end
