require("view/room/layout_room_chat_bubble");
require("ui/layoutText")
ChatBubble = class(Node, false);

ChatBubble.LEFT         = 1;
ChatBubble.RIGHT        = 2;
ChatBubble.ctor = function(self, lr, fixedWidth)
    super(self);
    self.m_root         = SceneLoader.load(layout_room_chat_bubble);
    self.m_container    = self.m_root:getNodeByName("container");
    self.m_imgLeft      = self.m_root:getNodeByName("container.img_left");
    self.m_imgRight     = self.m_root:getNodeByName("container.img_right");

    self:setLR(lr);
    
    self.m_fixedWidth       = fixedWidth or 136;
    self:countLayout(self);
    self:addChild(self.m_container);
end


ChatBubble.setLR = function(self, lr)
    lr = lr or ChatBubble.LEFT;
    if self.m_lr ~= lr then
        self.m_lr = lr;
        self.m_imgLeft:setVisible((self.m_lr == ChatBubble.LEFT));
        self.m_imgRight:setVisible((self.m_lr == ChatBubble.RIGHT));
    end
end

ChatBubble.countLayout = function(self)
    self.m_txtContent  = self.m_root:getNodeByName("container.txt_content");
    
    local x,        y           = self.m_txtContent:getPos();
    local width,    height      = self.m_txtContent:getSize();
    local imgWidth, imgHeight   = self.m_imgLeft:getSize();
    
    self.m_txtContent:getParent():removeChild(self.m_txtContent, true);
    if self.m_fixedWidth < width then
        self.m_fixedWidth = width;
    end
    self.m_txtContent = new(LayoutText, width, height, self.m_fixedWidth);
    self.m_txtContent:setColor(0x1a1a1a);
    self.m_origImgWidth     = imgWidth;
    self.m_origImgHeight    = imgHeight;
    self.m_deltaWidth       = imgWidth - width;
    self.m_deltaHeight      = imgHeight - height;
    
    self.m_curWidth         = imgWidth;
    self.m_curHeight        = imgHeight;
    self:setSize(self.m_curWidth, self.m_curHeight);
    
    self.m_txtContent:setPos(x, y);
    self.m_txtContent:setAlign(kAlignTopLeft);
    self.m_container:addChild(self.m_txtContent); 
end

ChatBubble.setText = function(self, str)
    str = str or "";
    if self.m_str ~= str then
        self.m_str = str;
        self.m_txtContent:setText(self.m_str);
        self:__layout();
    end
end

ChatBubble.__layout = function(self)
    if self.m_txtContent ~= nil then
        local width, height     = self.m_txtContent:getSize();
        self.m_curWidth         = width + self.m_deltaWidth;
        self.m_curHeight        = height + self.m_deltaHeight;
        self.m_imgLeft:setSize(self.m_curWidth, self.m_curHeight);
        self.m_imgRight:setSize(self.m_curWidth, self.m_curHeight);
        self:setSize(self.m_curWidth, self.m_curHeight);
    end
end
