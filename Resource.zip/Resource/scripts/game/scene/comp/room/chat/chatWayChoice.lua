---------------------------------------------
ChatWayChoice = class(Button, false);

ChatWayChoice.ctor = function(self, currUp, currDown, labelText, unselectedLabelTf, selectedLabelTf)
	super(self, currUp, currDown);

--	this.defaultLabelProperties.textFormat=unselectedLabelTf;
--	this.iconPosition = ICON_POSITION_MANUAL;
--	this.defaultIcon=currUp;
--	this.downSkin=new Scale3Image(new Scale3Textures(atlas.getTexture("setting_panel_back_to_hall_bg"), 12, 1));
--	this.downIcon=currDown;
--	this.label=labelText;
--	this.horizontalAlign = Button.HORIZONTAL_ALIGN_LEFT;
--	this.labelOffsetX=68;
--	this.iconOffsetX=18;
--	this.iconOffsetY=28;
--	this.width=300;
--	this.height=80;
end
