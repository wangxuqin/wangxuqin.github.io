ExpressionButton = class(Node, false);

ExpressionButton.ctor = function(self, id, imgTexture, bgTexture)--public
    super(self);

    self.m_expressionId = 0;
    self.m_img = nil;--:Image;
    self.m_selectedBackground = nil;--:Image;

	self.m_expressionId = id;

	self.m_selectedBackground = new(Image, bgTexture);
	self.m_selectedBackground:setAlign(kAlignCenter);
    self.m_selectedBackground:setVisible(false);
	self:addChild(self.m_selectedBackground);

	self.m_img = new(Image, imgTexture);
    local w,h = self.m_img:getSize();
    self.m_img:setSize(w * 0.8, h * 0.8);
    self.m_img:setAlign(kAlignCenter);
	self:addChild(self.m_img);

    self.m_img:setEventTouch(self, self.onTouch);
end

ExpressionButton.onTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)--private
    if(finger_action == kFingerDown) then
        self.m_selectedBackground:setVisible(true);
        self.m_xDown = x;
        self.m_yDown = y;
        self.m_moveFar = false;
    elseif(finger_action == kFingerMove) then
        if(math.abs(x - self.m_xDown) > 4 or math.abs(y - self.m_yDown) > 4) then
            self.m_moveFar = true;
        end
    elseif(finger_action == kFingerUp) then
        self.m_selectedBackground:setVisible(false);
        if(not self.m_moveFar) then
            Log.d("express", "send expression");
            if (SeatManager.selfInSeat) then
			    SoundManager.playButtonClickSound();
			    if (self.m_expressionId <= 30 or (self.m_expressionId >= 61 and Model.getData(ModelKeys.USER_DATA).vip ~= 0)) then
--??				AnalysisUtil.onEvent(AnalysisEventIds.ROOM_EXPRESSION);
                    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_CHAT_SEND_EXPRESSION, self.m_expressionId);
			    elseif (self.m_expressionId >= 61 and Model.getData(ModelKeys.USER_DATA).vip == 0) then
                    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {
                        message = STR_ROOM_GOLD_CARD_PLAY_EMOTION,
                        confirm = STR_LOGIN_BECOME_VIP,
                        cancel = STR_COMMON_CANCEL,
                        callback = function(obj, stype)
                                       if(stype == DialogCallback.CONFIRM) then
                                           EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_VIP_PAGE);
                                       end
                                   end,
                    });
			    end
		    else
                EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_SIT_DOWN_PLAY_EMOTION);
            end
        end
    end
end
