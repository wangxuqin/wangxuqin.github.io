ShowHandCardAnimationData = class();

ShowHandCardAnimationData.m_rotation = nil;--:Number
ShowHandCardAnimationData.m_destX  = nil;--:int
ShowHandCardAnimationData.m_destY  = nil;--:int
		
ShowHandCardAnimationData.ctor = function (self,a, b, c)--:Number --:int --:int
	self.m_rotation = a;
	self.mdestX = b;
	self.mdestY = c;
end