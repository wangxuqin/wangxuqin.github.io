require("view/room/layout_public_card");
require("game/scene/comp/room/pokerCard");

PublicCardManager = {}

PublicCardManager.m_scene = nil;

PublicCardManager.initialize = function (self, scene)
    self.m_scene = scene;
    self.m_container = SceneLoader.load(layout_public_card);
    self.m_scene:addChild(self.m_container);
    self.m_publicCard = {};
    local card      = nil;
    local tmpCard   = nil;
    for i = 1,5 do
        tmpCard = self.m_container:getNodeByName("container.card"..i);
        local x,y = tmpCard:getPos();
        tmpCard:getParent():removeChild(tmpCard, true);
        card = new(PokerCard);
        card:setPos(x, y);
        card:setAlign(kAlignTopLeft);
        card.m_pickable = false;  
        card:setVisible(false);
        self.m_container:addChild(card);
        self.m_publicCard[i] = card;
    end

    self.m_cardWidth,self.m_cardHeight = self.m_publicCard[1]:getSize();
end

PublicCardManager.flipPublicCard = function (self,index, value)
	if value and index then    
        if (value > 0  and index < 6) then
		    self.m_publicCard[index]:setVisible(true); 
            if self.m_publicCard[index].m_isValue == false then    
		        self.m_publicCard[index]:createCard(value);             
            elseif self.m_publicCard[index].m_isValue == true then
                self.m_publicCard[index]:update(value);
            end
            self.m_publicCard[index]:showBack();
            self.m_publicCard[index].m_isFront = false;   
		    self.m_publicCard[index]:flipCardStage1();	
        end
    end
end

PublicCardManager.showPublicCard = function (self,index, value)--:int :uint
	if value and index then
        if (value > 0 and index < 6) then   
		    self.m_publicCard[index]:createCard(value);
		    self.m_publicCard[index]:setVisible(true);         
        end
	end
end

PublicCardManager.fadeAllPublicCard = function (self)
	for i = 1, 5 do
		self.m_publicCard[i]:showFadeCard();
	end
end

PublicCardManager.hightLightPublicCard = function (self,value)
    local cardType = nil;
    local cardValue = nil;
    if (value and value > 0 and self.m_handCard) then
        cardType, cardValue = self.m_handCard[1]:getCardTypeAndValueByValue(value);
    end
    if cardType and cardValue then
	    for i = 1, 5 do
		    if self.m_publicCard[i].m_cardValue == cardValue and self.m_publicCard[i].m_cardType == cardType then
			    self.m_publicCard[i]:showHighLight();
			    break;
		    end
	    end  
    end
    Log.d("highLight","is pressed")
end


PublicCardManager.refresh = function (self)
	for i = 1, 5 do
		self.m_publicCard[i]:setVisible(false);
		self.m_publicCard[i]:removeCardOverlay();
		self.m_publicCard[i]:refresh();
	end
end
		
PublicCardManager.cleanUp = function (self)
	for i = 1, 5 do
		self.m_publicCard[i]:setVisible(false);
		self.m_publicCard[i]:cleanUp();
	end
end

PublicCardManager.getPublicCard = function (self)
	return self.m_publicCard;
end