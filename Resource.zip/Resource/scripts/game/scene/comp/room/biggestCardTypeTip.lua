------------------------------------------

BiggestCardTypeTip = class(Node);

BiggestCardTypeTip.m_backGround = nil;--:Image;
BiggestCardTypeTip.m_typeLabel = nil;--:Label;

BiggestCardTypeTip.ctor = function(self)
--	addEventListener(Event.ADDED_TO_STAGE,addToStageHandler);
    self:initialize();
end

BiggestCardTypeTip.addToStageHandler = function(self)--private
	--播放动画
--??	this.clipRect.height = 0;
--??	this.clipRect.y = 0;
--??	this.clipRect.x = _backGround.x;
--??	this.visible = true;
--??	TweenLite.to(this.clipRect, 0.2, {
--??		height:_backGround.height,
--??		y:clipRect.y - _backGround.height / 2
--??	});
end

BiggestCardTypeTip.initialize = function(self)--override protected
	self.m_backGround = new(Image, "room/knockout-tip-background.png");
    local wBackground,hBackground = self.m_backGround:getSize();
	self.m_backGround:setPos(-wBackground * 0.5);
	self:addChild(self.m_backGround);

	self.m_typeLabel = new(Text, "顺子", nil, nil, nil, nil, 28, 0x57, 0x0a, 0x0a);
    self.m_typeLabel:setAlign(kAlignCenter);
	self.m_backGround:addChild(self.m_typeLabel);

    self:setPickable(false);
    self:setSize(wBackground, hBackground);

	self.m_backGround:setPos(-wBackground * 0.5, -hBackground * 0.5);

--??	this.clipRect = new Rectangle(0,0,_backGround.width,0);
--??	this.clipRect.width = _backGround.width;
--??	this.clipRect.height = 0;
end

BiggestCardTypeTip.setCardType = function(self, stype)--public
	self.m_typeLabel:setText(stype);
--	this.invalidate();
end

BiggestCardTypeTip.draw = function(self)--override protected
--??	super.draw();
--??	_typeLabel.validate();
--??	_typeLabel.x = - _typeLabel.width * 0.5;
--??	_typeLabel.y = -_typeLabel.height * 0.5 - 2;
--??			
--??	_backGround.x = -_backGround.width * 0.5;
--??	_backGround.y = -_backGround.height * 0.5;
end
