--[Comment]
require("ui/image");
require("ui/button");
require("libs/bit");

PokerCard = class(Image,false);

PokerCard.CARD_TYPES  = {"diamond","club","heart","spade"};
PokerCard.CARD_WIDTH  = 80;
PokerCard.CARD_HEIGHT = 108;

PokerCard.ctor = function (self, value)
    super(self,"card/poker-background.png",nil,kFilterLinear);

    self.m_isFront      = true;
    self.m_isflipPlay1  = false;
    self.m_isflipPlay2  = false;
    self.m_isShakePlay  = false;
    self.m_shakeSeq     = anim_alloc_id();
    self.m_flipSeq1     = anim_alloc_id();
    self.m_flipSeq2     = anim_alloc_id();
    if value and value > 0 then 
        self.m_cardType,self.m_cardValue = self:getCardTypeAndValueByValue(value);
        self:createCard();
    end
    
    self.m_cardChecked  = false;
    self.m_isValue      = false
    self.m_cardBack     = new(Image,"card/poker-back.png");
    
    self:setAlign(kAlignCenter);
    self:addChild(self.m_cardBack);
    self.m_cardBack:setLevel(10);
    self.m_cardBack:setVisible(false);
end

PokerCard.dtor = function(self)
    self.m_isValue = false;
end

PokerCard.getCardTypeAndValueByValue = function (self, value)
    if value and value > 0 then 
	    local cardValue = bit.band(value,0xff) ;
	    local cardType  = bit.brshift(value,8);
	    return cardType , cardValue;
    end
end

PokerCard.getCardValue2 = function(self, value)
	return bit.band(value, 0xff);
end

PokerCard.getCardVariety2 = function(self, value)
	return bit.brshift(value, 8);
end

PokerCard.createCard = function (self,value)
    self.m_isValue = true;
    if value and value > 0 then
        if self.m_cardType == nil or self.m_cardValue == nil then 
            self.m_cardType,self.m_cardValue = self:getCardTypeAndValueByValue(value);
        end
    end
    -- numbers
    if self.m_cardType == 2 or self.m_cardType == 4 then 
        self.m_numImg = new(Image,"card/poker-black-"..tostring(self.m_cardValue)..".png");                                  
    else
        self.m_numImg = new(Image,"card/poker-red-"..tostring(self.m_cardValue)..".png");                      
    end
    self.m_numImg:setPos(5,5)   
    self:addChild(self.m_numImg);


    --small icons
    self.m_smallIcon = new(Image,"card/poker-small-"..self.CARD_TYPES[self.m_cardType]..".png");
    self.m_smallIcon:setPos(8,35);                
    self:addChild(self.m_smallIcon);

    --big icons
    if 11 <= self.m_cardValue and self.m_cardValue <= 13 then
        self.m_bigIcon = new(Image,"card/poker-character-"..tostring(self.m_cardValue)..".png");  
        self.m_bigIcon:setPos(18,27);  
    else 
        self.m_bigIcon = new(Image,"card/poker-big-"..self.CARD_TYPES[self.m_cardType]..".png");
        self.m_bigIcon:setPos(23,37);       
    end
        
        self:addChild(self.m_bigIcon);


    --card highLight
    self.m_cardHLight = new(Image,"card/poker-hight-light.png");
    self.m_cardHLight:setLevel(11);
    self.m_cardHLight:setPos(4,0)
    self:addChild(self.m_cardHLight);
    self.m_cardHLight:setVisible(false);  

    --card darkLight
    self.m_cardDLight = new(Image,"card/poker-dark-light.png")
    self.m_cardDLight:setLevel(11);
    self.m_cardDLight:setPos(4,0);
    self:addChild(self.m_cardDLight);
    self.m_cardDLight:setTransparency(0.5);
    self.m_cardDLight:setVisible(false);
end

PokerCard.update = function (self,value)
    self:hideFadeCard();
    if value and value > 0 then
        self.m_cardType,self.m_cardValue = self:getCardTypeAndValueByValue(value);
    end
    if self.m_cardType == 2 or self.m_cardType == 4 then 
        self.m_numImg:setFile("card/poker-black-"..tostring(self.m_cardValue)..".png");                                  
    else
         self.m_numImg:setFile("card/poker-red-"..tostring(self.m_cardValue)..".png");                  
    end

    self.m_smallIcon:setFile("card/poker-small-"..self.CARD_TYPES[self.m_cardType]..".png");
    
    if 11 <= self.m_cardValue and self.m_cardValue <= 13 then
        self.m_bigIcon:setFile("card/poker-character-"..tostring(self.m_cardValue)..".png");  
    else 
        self.m_bigIcon:setFile("card/poker-big-"..self.CARD_TYPES[self.m_cardType]..".png");      
    end
end

PokerCard.setCard = function (self,value)
    if self.m_isValue == false then
        self:createCard(value);
    elseif self.m_isValue == true then
        self:update(value)
    end        
end

PokerCard.flipCardStage1 = function (self)
    if self.m_visible == true then
        self.m_isflipPlay1 = true;
        local anim = self:addPropScale(self.m_flipSeq1, 0, 200, 0, 1, 0.01,nil,nil,1);
        anim:setEvent(self,self.flipCardStage2)
    end
end

PokerCard.flipCardStage2 = function (self)
    if self.m_isFront == true then
                self.m_cardBack:setVisible(true);
                self.m_isFront = false;
    elseif self.m_isFront == false then
                self.m_cardBack:setVisible(false);
                self.m_isFront = true;
    end

    self.m_isflipPlay1 = false;

    if self.m_flipSeq1 then
        self:removeProp(self.m_flipSeq1);
        self.m_isflipPlay2 = true;
        local anim = self:addPropScale(self.m_flipSeq2, 0, 200, 0, 0.01, 1,nil,nil,1);
        anim:setEvent(self,function ()
            self:removeProp(self.m_flipSeq2);
            self.m_isflipPlay2 = false;
        end)
    end
end


PokerCard.onTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
    if finger_action == kFingerUp then    
        if self.m_cardChecked == false then
            self:addPropTranslate(0, kAnimNormal, 100, 100, 0, 0, 0, -40);
            self.m_cardChecked = true;
        else       
            self:removeProp(0);   
            self.m_cardChecked = false; 
        end
      
        if self.m_cardChecked == true then
            table.insert(pickedCardsTable,self);
        else
            for i = #pickedCardsTable,1,-1 do
                if pickedCardsTable[i].m_cardChecked == false then
                    table.remove(pickedCardsTable,i);
                end
            end
        end
        
        if cardAnalyzer.LegalIdentify(pickedCardsTable,outCardsTable) then
            buttonOut:setEnable(true);
        else
            buttonOut:setEnable(false);
        end 
    end

end

PokerCard.stopFlipCard = function (self)
    if self.m_isflipPlay1 == true then
       self:removeProp(self.m_flipSeq1);
    end

    if self.m_isflipPlay2 == true then
       self:removeProp(self.m_flipSeq2);
    end 
end

PokerCard.shakeCard = function (self)
    self.m_isShakePlay = true;
    self:addPropTranslate(self.m_shakeSeq, 2, 50, 0, 0, 2, -2, 0);
end

PokerCard.stopShakeCard = function (self)
    if self.m_isShakePlay == true then
        self:removeProp(self.m_shakeSeq);
        self.m_isShakePlay = false;
    end
end

PokerCard.showBack = function (self)
    self.m_cardBack:setVisible(true);
    self.m_isFront = false;
end

PokerCard.hideBack = function (self)
    if self.m_cardBack ~= nil then
        self.m_isFront = true;
        self.m_cardBack:setVisible(false);
    end
end

PokerCard.showHighLight = function (self)
    self.m_cardHLight:setVisible(true);
end

PokerCard.hideHighLight = function (self)
    if self.m_cardHLight ~= nil then
        self.m_cardHLight:setVisible(false);
    end
end

PokerCard.showFadeCard = function (self)
    if self.m_cardDLight ~= nil then
        self.m_cardDLight:setVisible(true);
    end
end

PokerCard.hideFadeCard = function (self)
    if self.m_cardDLight ~= nil then
        self.m_cardDLight:setVisible(false);
    end
end

PokerCard.getCardType = function (self)
    return self.m_cardType
end
 
PokerCard.getCardValue = function (self)
    return self.m_cardValue;
end

PokerCard.setChecked = function (self, checked)
    self.m_checked = checked;
end

PokerCard.isChecked = function (self)
    return self.m_checked;
end

PokerCard.isFront = function (self)
    return self.m_isFront;
end

PokerCard.refresh  = function (self)
	self:stopFlipCard();
	self:stopShakeCard();
    self:removeCardOverlay();
end

PokerCard.cleanUp  = function (self)
	self:stopFlipCard();
	self:stopShakeCard();
    self:removeCardOverlay();
end

PokerCard.removeCardOverlay = function (self)
    self:hideBack();
    self:hideFadeCard();
    self:hideHighLight();
end

PokerCard.showCard = function (self)
    if self.m_isFront == false then
        self:hideBack();
    end
    self:setVisible(true);
    self.m_isflipPlay1 = false;
    self.m_isflipPlay2 = false;
end