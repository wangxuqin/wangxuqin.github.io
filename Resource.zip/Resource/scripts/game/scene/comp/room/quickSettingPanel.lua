--------------------------------------------------------------
require("view/room/layout_quicksetting_panel");

QuickSettingPanel = class(PopupDialog, false);

QuickSettingPanel.ctor = function(self)
    super(self, layout_quicksetting_panel, true);
    local slider = self.m_root:getNodeByName("bg.sound_slider");
    slider:setImages("setting/slider_max.png", "setting/slider_min.png", "setting/toggle_thumb_up.png");
end

QuickSettingPanel.onPopupEnd = function(self)
    local mainContainer = self:getDialog();
    mainContainer:removeProp(0);
    --�¼���Ӧ
    local btn = self.m_root:getNodeByName("bg.btn_back_to_hall");
    btn:setOnClick(self, self.__onBtnClickBackToHall);
    local btn = self.m_root:getNodeByName("bg.btn_game_review");
    btn:setOnClick(self, self.__onBtnClickGameReview);
    local slider = self.m_root:getNodeByName("bg.sound_slider");
    slider:setOnChange(self, self.__onChangeSliderSound);
    local switch = self.m_root:getNodeByName("bg.vibrate");
    switch:setOnChange(self, self.__onChangeVibrate);
end

QuickSettingPanel.show = function(self)
    local function onPreShow(self)
        local mainContainer = self:getDialog();
        local anim = mainContainer:addPropTranslate(0, kAnimNormal, 200, 100, 0, 0, -360, 0);
        return anim;
    end
    PopupDialog.show(self, PopupDialog.kPopupStyleCustom, onPreShow);
end

QuickSettingPanel.__onBtnClickBackToHall = function(self)
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.BACK_TO_HALL_TIP);
    self:close();
end

QuickSettingPanel.__onBtnClickGameReview = function(self)
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_GAME_REVIEW_POP_UP);
    self:close();
end

QuickSettingPanel.__onChangeSliderSound = function(self, progress)
    Log.d("test", "progress=" .. tostring(progress));
end

QuickSettingPanel.__onChangeVibrate = function(self, state)
    Log.d("test", "vibrate:" .. tostring(state));
end
