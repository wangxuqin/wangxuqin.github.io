----------------------------------------------------
Handle = class();

Handle.HELPER_POINT = new(Point);

Handle.ctor = function(self, node, objOnTrigger, funcOnTrigger)
	self.m_knob = nil;
	self.m_handgrip = nil;
	self.m_base = nil;
	self.m_startY = 0;
	self.m_currentY = 0;
	self.m_lightWaterarray = nil;
	self.m_interval = 0;
	self.m_autoHandleFlag = false;
	self.m_increaseY = 1;

	self.m_container = node;
	self.m_container:setEventTouch(self, self.touchHandler);

	--手柄（24-32）
	self.m_handgrip = self.m_container:getChildByName("handgrip");
	self.m_handgrip:setPickable(false);
	self.m_handgripY = As3Kit.getNodeY(self.m_handgrip);

	--球（0-24）
	self.m_knob = self.m_container:getChildByName("knob");
	self.m_knob:setPickable(false);
	self.m_knobY = As3Kit.getNodeY(self.m_knob);

	self.m_lightWaterarray = {};
	for i=1,4 do
		local lightWater = self.m_container:getChildByName("lightwater" .. i);--流水灯
		table.insert(self.m_lightWaterarray, lightWater);
	end

	self.m_objOnTrigger = objOnTrigger;
	self.m_funcOnTrigger = funcOnTrigger;

--	self:addedToStageHandler();
	self.m_oldDtor = self.m_container.dtor;
	self.m_container.dtor = function(this)
		self:removedToStageHandler();
		self.m_oldDtor(this);
	end
end

Handle.setPickable = function(self, value)
	self.m_container:setPickable(value);
end

Handle.onAdded = function(self)
	if(not self.m_autoHandleFlag) then
		for i=1,#self.m_lightWaterarray do
			if(SeatManager.selfInSeat) then
				self.m_lightWaterarray[i]:setVisible(true);
			else
				self.m_lightWaterarray[i]:setVisible(false);
			end
		end
	else
		self:removeCirculateLight();
		self.m_autoHandleFlag = false;
	end
end

Handle.removedToStageHandler = function(self)
	clearInterval(self.m_interval);
	self:removeCirculateLight();
end

Handle.addedToStageHandler = function(self)
	self:onAdded();
	self.m_interval = setInterval(self.sparkShine, self, 200);
end

Handle.removeCirculateLight = function(self)
	for i=1,#self.m_lightWaterarray do
		self.m_lightWaterarray[i]:setVisible(false);
	end
	clearInterval(self.m_interval);
end

Handle.sparkShine = function(self)
	self.m_increaseY = self.m_increaseY + self.m_increaseY;
	while(self.m_increaseY >= 120) do
		self.m_increaseY = self.m_increaseY - 120;
	end
	self:updateStatus();
end

Handle.updateStatus = function(self)
	local currentPos = -1;
	local imageBetween =20;	--相邻两点之间的距离

	--找离当前角度最近的那个亮点下标
	for i=1,#self.m_lightWaterarray do
		if(i == 1) then
			if(self.m_increaseY <= (imageBetween/2) or 120 - self.m_increaseY <= imageBetween/2) then
				currentPos = i;
				break;
			end
		else
			if(math.abs(self.m_increaseY - (i-1) * (imageBetween)) <= imageBetween/2) then
				currentPos = i;
				break;
			end
		end
	end

	--更新当前亮点 及残影 所在亮点的alpha值
	for i=1,#self.m_lightWaterarray do
		--计算alpha值
		local alpha1 = (#self.m_lightWaterarray  - (i-1) / 0.8);
		if(alpha1 <= 0) then
			alpha1 = 0;
		end
		alpha1 = alpha1 / #self.m_lightWaterarray;

		--更新alpha值
		if(currentPos - i < 0) then
			self.m_lightWaterarray[currentPos - i + 1 + #self.m_lightWaterarray]:setTransparency(alpha1);
		else
			self.m_lightWaterarray[currentPos - i + 1]:setTransparency(alpha1);
		end
	end

	--将指针指向正对当前亮点的那个点，那个点也会是亮点
	currentPos = currentPos + #self.m_lightWaterarray;
	if(currentPos > #self.m_lightWaterarray) then
		currentPos = currentPos - #self.m_lightWaterarray;
	end

	--更新将指针指向正对当前亮点的那个点 及残影 所在亮点的alpha值
	for i=1,#self.m_lightWaterarray do
		--计算alpha值
		local alpha2 = (#self.m_lightWaterarray- (i-1) / 0.8);
		if(alpha2 <= 0) then
			alpha1 = 0;
		end
		alpha2 = alpha2 / #self.m_lightWaterarray;

		--更新alpha值
		if(currentPos - i < 0) then
			self.m_lightWaterarray[currentPos - i + 1 + #self.m_lightWaterarray]:setTransparency(alpha2);
		else
			self.m_lightWaterarray[currentPos -i + 1]:setTransparency(alpha2);
		end
	end
end

Handle.touchHandler = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
	TouchHelper.catch(self, finger_action, x, y);
	if(TouchHelper.isClick(self)) then
		self:autoHandle();
		self:removeCirculateLight();
		return;
	end
	self.m_currentY = y;
	if(finger_action == kFingerDown) then
		self.m_startY = self.m_currentY;
		self:removeCirculateLight();
	elseif(finger_action == kFingerMove) then
		self:turnHandle();
	elseif(finger_action == kFingerUp) then
		if (As3Kit.getNodeY(self.m_knob) >= 64) then
			--确定把手有效，开始老虎机
			if(type(self.m_funcOnTrigger) == "function") then
				self.m_funcOnTrigger(self.m_objOnTrigger);
			end
		end
		self:handleBack();
	end
end

Handle.turnHandle = function(self)
	local distance = self.m_currentY - self.m_startY;
	local _,knobY = self.m_knob:getPos();
	local scaleY = 1;
	local handgripY = 0;
	local bMove = false;
	if (knobY >= 0 and knobY <= 64) then
		knobY = knobY + distance;
		scaleY = 1 - knobY * 0.625 / 40 * 0.4;
		handgripY = 24 + knobY * 0.625;
		bMove = true;
	elseif (knobY > 64 and knobY <= 144) then
		knobY = knobY + distance;
		scaleY = -(knobY - 64) * 0.3 / 24 * 0.6 - 0.4;
		handgripY = -scaleY * 64 + 76 + (knobY - 64) * 0.3;
		bMove = true;
	end

	if (knobY > 144) then
		knobY = 144;
		scaleY = -1;
		handgripY = 164;
		bMove = true;
	elseif (knobY < 0) then
		knobY = 0;
		scaleY = 1;
		handgripY = 24;
		bMove = true;
	end
	if(bMove) then
		self.m_knob:setPos(nil, knobY);
		self.m_handgrip:setScale(1, scaleY, kCenterXY, 0, 0);
		self.m_handgrip:setPos(nil, handgripY);
	end
	self.m_startY = self.m_currentY;
end

Handle.handleBack = function(self)
	local action = new(ActionMoveTo, 0.2, nil, 0);
	action:apply(self.m_knob);
	local action = new(ActionMoveTo, 0.2, nil, 24);
	action:apply(self.m_handgrip);
	local action = new(ActionScaleTo, 0.2, 1, 1, kCenterXY, 0, 0);
	action:apply(self.m_handgrip);
end

Handle.autoHandle = function(self)
	local action = new(ActionMoveTo, 0.4, nil, 144);
	action:apply(self.m_knob);
	local action1 = new(ActionMoveTo, 0.4, nil, 164);
	local action2 = new(ActionScaleTo, 0.4, 1, -1, kCenterXY, 0, 0);
	local spawn = new(ActionSpawn, action1, action2);
	local call = new(ActionCallFuncN, self, self.autoHandlerCompleteHandler);
	local action = new(ActionSequence, spawn, call);
	action:apply(self.m_handgrip);
end

Handle.autoHandlerCompleteHandler = function(self)
	self.m_autoHandleFlag = true;
	self:removeCirculateLight();
	if(type(self.m_funcOnTrigger) == "function") then
		self.m_funcOnTrigger(self.m_objOnTrigger);
	end
	self:handleBack();
end
