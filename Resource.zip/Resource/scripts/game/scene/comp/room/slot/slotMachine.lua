
require("view/room/layout_slotmachine");
require("game/scene/comp/room/slot/betChip");
require("game/scene/comp/room/slot/flashBar");
require("game/scene/comp/room/slot/slotPokers");
require("game/scene/comp/room/slot/handle");

--老虎机
SlotMachine = class(Node, false);

SlotMachine.TAG = "SlotMachine";

SlotMachine.ctor = function(self, screen)
	super(self);

	self.m_screen = nil;
	self.m_operationPanel = nil;
	self.m_pokers = nil;
	self.m_handle = nil;
	self.m_sideBtn = nil;
	self.m_sideBtnIcon = nil;
	self.m_sideBtnIconUpTexture = nil;
	self.m_sideBtnIconDownTexture = nil;
	self.m_sideBtnIconGlowTexture = nil;
	self.m_helpButton = nil;
	self.m_flashBar = nil;
	self.m_betBtns = nil;
	self.m_autoBtn = nil;
	self.m_stageWidth = 0;
	self.m_smallBlind = 0;--小盲注
	self.m_betMoney = 10;--下注金额
	self.m_retryTimes = 3;-- 重试次数
	self.m_luckyPoker = nil;--幸运牌型
	self.m_luckyTimes = nil;--幸运牌型中奖倍数
	self.m_srcX = 0;
	self.m_startX = 0;
	self.m_endX = 0;
	self.m_isInvalid = false;
	self.m_showing = false;
	self.m_slotActive = false;
	self.m_interval = 0;
	self.m_touchBeginX = 0;
	self.m_touchMoveX = 0;
	self.m_touchEndX = 0;
	self.m_minusChipLabel = nil;
	self.m_minusChipSprite = nil;

	self.m_screen = screen;
	self.m_stageWidth = System.getScreenScaleWidth();
	self.m_stageHeight = System.getScreenScaleHeight();

	self:setSize(self.m_stageWidth, self.m_stageHeight);
	self.m_screen:addChild(self);
	self.m_root = SceneLoader.load(layout_slotmachine);
	self:addChild(self.m_root);

	self:initialize();
	self:addEventList();
end

SlotMachine.dtor = function(self)
	self:stopSlot();
	self:removeEventList();
end

SlotMachine.addEventList = function(self)
    if self.m_eventList == nil then
        self.m_eventList = {
            {UIEvent, UIEvent.s_cmd.TOUCH_ROOM_SCENE_BG, "__touchEvtHandler"};
        };
    end
    EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
end

SlotMachine.removeEventList = function(self)
    if self.m_eventList ~= nil then
        EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
    end
    self.m_eventList = nil;
end

SlotMachine.initialize = function(self)
	self.m_operationPanel = self.m_root:getNodeByName("slotmachine.operation_panel");
	--帮助按钮
	self.m_helpButton = self.m_root:getNodeByName("slotmachine.operation_panel.btn_help");
	self.m_helpButton:setOnClick(self, self.helpBtnTriggeredHandler);
	--闪光bar
	self.m_flashBar = new(FlashBar, self.m_root:getNodeByName("slotmachine.operation_panel.flashbar"));
	--扑克牌
	self.m_pokers = new(SlotPokers, self.m_root:getNodeByName("slotmachine.operation_panel.slot_pokers.pokers"), self, self.pokerTurnCompleteHandler);
	--自动操作按钮
	self.m_autoBtn = self.m_root:getNodeByName("slotmachine.operation_panel.btn_auto.select");
	self.m_autoBtn:setVisible(false);
	local label = self.m_root:getNodeByName("slotmachine.operation_panel.btn_auto.label");
	label:setText(STR_ROOM_SLOT_AUTO_PLAY);
	local btn = self.m_root:getNodeByName("slotmachine.operation_panel.btn_auto");
	btn:setOnClick(self, self.autoChangeHandler);
	--把手
	self.m_handle = new(Handle, self.m_root:getNodeByName("slotmachine.operation_panel.handle"), self, self.handleCompleteHandler);
	--3个加注操作按钮
	self.m_betBtns = {};
	for i=1,3 do
		self.m_betBtns[i] = new(BetChip, self.m_root:getNodeByName("slotmachine.operation_panel.bet_chip" .. i), i, self, self.betBtnTriggeredHandler);
	end
	--边栏按钮
	self.m_sideBtn = self.m_root:getNodeByName("slotmachine.btn_side");
	self.m_sideBtnIconUpTexture = "room/slot/slot-side-btn-icon-up.png";
	self.m_sideBtnIconDownTexture = "room/slot/slot-side-btn-icon-down.png";
	self.m_sideBtnIconGlowTexture = "room/slot/slot-side-btn-icon-glow.png";
	self.m_sideBtnIcon = self.m_root:getNodeByName("slotmachine.btn_side.icon");
	local hitTransparent = self.m_root:getNodeByName("slotmachine.btn_side.hit");
	self.m_hitDrawingId = hitTransparent.m_drawingID;
	hitTransparent:setEventTouch(self, self.touchHandler);
--	NewerTipManager.instance.registerNewerTip(ScreenNames.GAME_ROOM, "slot", NewerTipDirection.RIGHT, self.m_sideBtn);

	self.__watchList =
	{
		{ ModelKeys.ROOM_SLOT_SUCC_DATA, self, self.slotSucc, false, },
		{ ModelKeys.ROOM_SLOT_FAIL_DATA, self, self.slotFail, false, },
		{ ModelKeys.USER_LOGINED_ROOM, self, self.onLoginedRoom, false, },
	};
	for _,v in pairs(self.__watchList) do
		Model.watchData(v[1], v[2], v[3], v[4]);
	end

	self.m_operationPanel:setVisible(false);
	self:setPos(384);
	self:getLucky();
end

SlotMachine.onLoginedRoom = function(self, bb)
	if (not bb and self.m_autoBtn:getVisible()) then
		self.m_autoBtn:setVisible(false);
		clearInterval(self.m_interval);
		self.m_interval = 0;
	end
	if (bb and self.m_luckyPoker ~= nil) then
		self.m_flashBar:setLucky(self.m_luckyPoker);
	end
end

SlotMachine.getLucky = function(self)
	if (self.m_retryTimes >= 0) then
		HttpService.post({["mod"]="tiger", ["act"]="getLucky"}, self, self.getLuckyCallback, TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
		self.m_retryTimes = self.m_retryTimes - 1;
	end
end

SlotMachine.getLuckyCallback = function(self, data)
	local function getlucyCB(self, data)
		local retObj = json.decode(data);
		if (retObj.ret ~= nil and retObj.ret == 0 and retObj.lucky ~= nil) then
			self.m_luckyTimes = tonumber(retObj.times);
			local lucky = tostring(retObj.lucky);
			self.m_luckyPoker = {};
			for i=1,string.len(lucky) do
				self.m_luckyPoker[i] = string.sub(lucky, i, i);
			end
			self.m_flashBar:setLucky(self.m_luckyPoker);
		else
			self:getLucky();
		end
	end
	local res = pcall(getlucyCB, self, data);
	if(not res) then
		self:getLucky();
	end
end

SlotMachine.helpBtnTriggeredHandler = function(self)
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_SLOTBONUS_POPUP, {luckyPoker = self.m_luckyPoker, luckyTimes = self.m_luckyTimes});
end

SlotMachine.autoChangeHandler = function(self)
	local visible = self.m_autoBtn:getVisible();
	visible = not visible;
	self.m_autoBtn:setVisible(visible);
	if (visible) then
		SoundManager.playSound("SlotAutoBet");
		--自动操作的情况，设置为三秒的频率
		if (not self.m_slotActive) then
			self.m_handle:setPickable(false);
			self.m_handle:autoHandle();
			self.m_interval = setInterval(self.m_handle.autoHandle, self.m_handle, 6000);
		end
	else
		if (not self.m_slotActive) then
			self.m_handle:setPickable(true);
		end
		clearInterval(self.m_interval);
		self.m_interval = 0;
	end
end

SlotMachine.betBtnTriggeredHandler = function(self, data)
	for i=1,#self.m_betBtns do
		self.m_betBtns[i]:glow(false);
	end
	if(self.m_betBtns[data]) then
		self.m_betBtns[data]:glow(true);
		self.m_flashBar:setJackpot(self.m_betBtns[data]:getBetValue() * 10000);
		self.m_betMoney = self.m_betBtns[data]:getBetValue();
	end
end

SlotMachine.__touchEvtHandler = function(self, data)
	self:touchHandler(data.finger_action, data.x, data.y, data.drawing_id_first, data.drawing_id_current);
end

SlotMachine.touchHandler = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
	if(finger_action == kFingerDown) then
		self.m_startX = x;
		self.m_srcX = self:getPos();
		self.m_isInvalid = false;
		if (self.m_startX < self.m_stageWidth * 0.5) then
			self.m_isInvalid = true;
		else
			ActionBase.stopAllActions(self);
			if(not self.m_operationPanel:getVisible()) then
				self.m_handle:addedToStageHandler();
			end
			self.m_operationPanel:setVisible(true);
		end
	elseif(finger_action == kFingerMove) then
		self.m_endX = x;
		if (not self.m_isInvalid) then
			local newX = self.m_srcX + (self.m_endX - self.m_startX);
			if (newX > 384) then
				newX = 384;
			elseif (newX < 0) then
				newX = 0;
			end
			self:setPos(newX);
		end
	elseif(finger_action == kFingerUp) then
		self.m_endX  = x;
		if (not self.m_isInvalid) then
			if (self.m_showing) then
				if ((self.m_endX - self.m_startX) > 17
					or (drawing_id_current == self.m_hitDrawingId and math.abs(self.m_endX - self.m_startX) < 7)) then
					self.m_showing = true;
				else
					self.m_showing = false;
				end
			else
				if ((self.m_startX - self.m_endX) > 17
					or (drawing_id_current == self.m_hitDrawingId and math.abs(self.m_endX - self.m_startX) < 7)) then
					self.m_showing = false;
				else
					self.m_showing = true;
				end
			end
			self:tweenSelf();
		end
	end
end

SlotMachine.tweenSelf = function(self)
	if (self.m_showing) then
		local move = new(ActionMoveTo, 0.5, 384, nil);
		local call = new(ActionCallFuncN, self, function(self, node)
													if(self.m_operationPanel:getVisible()) then
														self.m_handle:removedToStageHandler();
													end
													self.m_operationPanel:setVisible(false);
												end);
		local action = new(ActionSequence, move, call);
		action:apply(self);
		self.m_showing = false;
	else
		if(not self.m_operationPanel:getVisible()) then
			self.m_handle:addedToStageHandler();
		end
		self.m_operationPanel:setVisible(true);
		ActionBase.stopAllActions(self);
		local action = new(ActionMoveTo, 0.5, 0, nil);
		action:apply(self);
		self.m_showing = true;
--		NewerTipManager.instance.finishNewerTip(ScreenNames.GAME_ROOM, "slot");
	end
end

--老虎机失败，提示用户场外资产不足 
-- @param modifyMoney
SlotMachine.slotFail = function(self, modifyMoney)
	-- maintain user's money out of the table
	local userData = Model.getData(ModelKeys.USER_DATA);
	userData.money = modifyMoney;
	if (SeatManager.selfInSeat) then
		SeatManager:getSelfSeat():getSeatData().totalChips = userData.money;
	end

	--顶部通知栏
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_NOT_ENOUGH_MONEY_PLAY_SLOT);
end

--老虎机成功 
-- @param data (winMoney, modifyMoney, cards)
SlotMachine.slotSucc = function(self, data)
	-- maintain user's money out of the table
	local userData = Model.getData(ModelKeys.USER_DATA);
	userData.money = data.modifyMoney;
	if (SeatManager.selfInSeat) then
		SeatManager:getSelfSeat():getSeatData().totalChips = userData.money;
	end
	self.m_pokers:setWinMoney(data.winMoney);
	self.m_pokers:setCards(data.cards);
	self.m_pokers:setPacketLoss(false);

	-- 中奖牌型大于三条，发OG
	if (CalculateCardType:calculateType(0, 0, data.cards) >= CalculateCardType.THREE_KIND and not CookieService.getBoolean(CookieKeys.SENDED_SLOT_OG .. userData.uid)) then
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.SOCIAL_OG, {["type"]="slot"});
		CookieService.setBoolean(CookieKeys.SENDED_SLOT_OG .. userData.uid, true);
	end

	if (not self.m_operationPanel:getVisible()) then
		--扣钱动画
		if (self.m_minusChipLabel == nil) then
			self.m_minusChipSprite = new(Node);
			self.m_minusMoneyIcon = new(Image, "room/play-expression-minus-money-icon.png");
			self.m_minusChipSprite:addChild(self.m_minusMoneyIcon);
			self.m_minusChipLabel = new(Text, "0", nil, nil, kTextAlignCenter, nil, 24, 0xEC, 0xCE, 0x0B);
			self.m_minusChipLabel:setPos(24);
			self.m_minusChipSprite:addChild(self.m_minusChipLabel);
			self.m_sideBtn:addChild(self.m_minusChipSprite);
		end
		self.m_minusChipSprite:setTransparency(1);
		self.m_minusChipLabel:setText(STR_COMMON_NUMBER_CURRENCY_LABEL .. Formatter.formatBigNumber(self.m_betMoney, false));

		self.m_minusChipLabel:setPos(nil, (6 - As3Kit.getNodeHeight(self.m_minusChipLabel)) * 0.5);

		local wOpr,hOpr = self.m_operationPanel:getSize();
		local wBtnSide, hBtnSide = self.m_sideBtn:getSize();
		self.m_minusChipSprite:setPos(wBtnSide, (hBtnSide - As3Kit.getNodeHeight(self.m_minusChipLabel)) * 0.5 + 4);
		self.m_minusChipSprite:setVisible(true);

		local targetX = - (As3Kit.getNodeWidth(self.m_minusMoneyIcon) + As3Kit.getNodeWidth(self.m_minusChipLabel)) - 8;
		local move = new(ActionMoveTo, 1, targetX, nil);
		local delay = new(ActionDelayTime, 1);
		local alpha = new(ActionFadeTo, 1, 0.1);
		local call = new(ActionCallFuncN, self, function(self) self.m_minusChipSprite:setVisible(false); end);
		local action = ActionSequence.createWithArray({move, delay, alpha, call});
		action:apply(self.m_minusChipSprite);
	end
end

SlotMachine.pokerTurnCompleteHandler = function(self)
	self.m_slotActive = false;

	if (self.m_pokers:getCloneWinMoney() > 0) then
		if (self.m_operationPanel:getVisible()) then
			SoundManager.playSound("ChipDropping");
			self.m_flashBar:startFlash(self.m_pokers:getCloneWinMoney());
			setTimeout(self.m_flashBar.stopFlash, self.m_flashBar, 2000);--两秒后停止赢动画
			setTimeout(self.timeoutHandler, self, 2000);
		else
			if (CookieService.getBoolean(CookieKeys.ROOM_SLOT_NEED_TIPS, true)) then
				--顶部通知栏
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP,
						{
							message = StringKit.substitute(STR_ROOM_SLOT_WIN_TOP_TIP, Formatter.formatBigNumber(self.m_pokers:getCloneWinMoney())),
							image = new(Image, "room/slot/slot-win-top-tip-icon.png"),
						});
			end
			self:setSideBtnIconTexture(self.m_sideBtnIconGlowTexture);
			setTimeout(self.setSideBtnIconTexture, self, 1000, self.m_sideBtnIconUpTexture);
		end
	end

	--自动操作的情况，设置为三秒的频率
	if (self.m_autoBtn:getVisible()) then
		if (self.m_interval == 0) then
			self.m_handle:autoHandle();
			self.m_interval = setInterval(self.m_handle.autoHandle, self.m_handle, 6000);
		end
	else
		self.m_handle:setPickable(true);
	end
end

SlotMachine.timeoutHandler = function(self)
	if (self.m_slotActive) then
		self.m_flashBar:setJackpot(self.m_betMoney * 10000);
	end
end

SlotMachine.handleCompleteHandler = function(self)
	if (self.m_operationPanel:getVisible()) then
		SoundManager.playSound(SlotPull);
	end

	self:setSideBtnIconTexture(self.m_sideBtnIconDownTexture);
	setTimeout(self.setSideBtnIconTexture, self, 200, self.m_sideBtnIconUpTexture);
	EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.USER_PLAY_SLOT, self.m_betMoney);
			
	if (not self.m_flashBar:getRunning()) then
		self.m_flashBar:setJackpot(self.m_betMoney * 10000);
	end

	--开始老虎机动画
	self.m_pokers:setWinMoney(0);
	self.m_pokers:setPacketLoss(true);
	self.m_pokers:startTurnPokers();
	self.m_handle:setPickable(false);
	self.m_slotActive = true;
end

SlotMachine.setSideBtnIconTexture = function(self, texture)
	self.m_sideBtnIcon:setFile(texture);
	As3Kit.reAdjustSize (self.m_sideBtnIcon);
	local w, h = self.m_sideBtnIcon:getSize();
	self.m_sideBtnIcon:setPos((37 - w) * 0.5, (80 - h) * 0.5);
end

SlotMachine.stopSlot = function(self)
	self.m_pokers:stopAnimation();
	self.m_handle:setPickable(true);
	self.m_autoBtn:setVisible(false);
	self.m_slotActive = false;
	clearInterval(self.m_interval);
	self.m_interval = 0;
end

SlotMachine.setSmallBlind = function(self, value)
	self.m_smallBlind = value;
	local userData = Model.getData(ModelKeys.USER_DATA);
	local maxBet = userData.TIGER_MAX;
	local multiBet = userData.TIGER_MULTIPLE and userData.TIGER_MULTIPLE or 1;

	for i=1,#self.m_betBtns do
		self.m_betBtns[i]:glow(false);
	end

	if(Model.getData(ModelKeys.USER_DATA)["SLOT_ROOT"] ~= nil) then
--?		ServiceLocator.remoteCacheService.cacheXML(Model.getData(ModelKeys.USER_DATA)["SLOT_ROOT"],function(self, xml:XML)
--?		{
--?					
--?			for each(local tmp:XML in xml.a)
--?			{
--?				if((tmp.sb<self.m_smallBlind)and(self.m_smallBlind<=tmp.mb))
--?				{
--?					self.m_betBtns[0].betValue = tmp.e;
--?					self.m_betBtns[0].glow(true);
--?					self.m_betMoney = self.m_betBtns[0].betValue;
--?							
--?					self.m_betBtns[1].betValue = tmp.f;
--?					self.m_betBtns[2].betValue = tmp.g;
--?				}
--?			}
--?					
--?		},defaultHandler);
	else
		if (value * 4 * multiBet > maxBet) then
			self.m_betBtns[1]:setBetValue(maxBet / 4);
			self.m_betBtns[1]:glow(true);
			self.m_betMoney = self.m_betBtns[1]:getBetValue();

			self.m_betBtns[2]:setBetValue(maxBet / 2);
			self.m_betBtns[3]:setBetValue(maxBet);
		else
			self.m_betBtns[1]:setBetValue(value * multiBet);
			self.m_betBtns[1]:glow(true);
			self.m_betMoney = self.m_betBtns[1]:getBetValue();

			self.m_betBtns[2]:setBetValue(value * 2 * multiBet);
			self.m_betBtns[3]:setBetValue(value * 4 * multiBet);
		end
	end
end

SlotMachine.defaultHandler = function(self)
end
