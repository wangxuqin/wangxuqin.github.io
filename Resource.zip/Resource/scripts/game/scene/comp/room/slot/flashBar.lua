-------------------------------------------------
FlashBar = class();

FlashBar.ctor = function(self, node)
	self.m_star = nil;
	self.m_lightTexture = nil;
	self.m_darkTexture = nil;
	self.m_interval = 0;
	self.m_jackpotLabel = nil;
	self.m_jackpot = 0;
	self.m_running = false;
	self.m_luckyPoker = "";

	self.m_lightTexture = "room/slot/slot-flash-light.png";
	self.m_darkTexture = "room/slot/slot-flash-dark.png";
	self.m_star = node;
	self.m_bLight = false;

	self.m_jackpotLabel = node:getChildByName("jackpot_label");

	node:setPickable(false);
end

FlashBar.startFlash = function(self, value)
	self.m_interval = setInterval(self.flash, self, 100);
	self.m_jackpotLabel:setText(StringKit.substitute(STR_ROOM_SLOT_WIN_TIP, STR_COMMON_CURRENCY_LABEL .. Formatter.formatBigNumber(value, true)));
	self.m_running = true;
end

FlashBar.setJackpot = function(self, value)
	self.m_jackpot = value;
	self.m_jackpotLabel:setText(StringKit.substitute(STR_ROOM_JACKPOT, STR_COMMON_CURRENCY_LABEL .. Formatter.formatBigNumber(value, true)));
end

FlashBar.setLucky = function(self, value)
	if (value ~= nil) then
		self.m_luckyPoker = "";
		local char = "";
		for i=1,#value do
			local ch = value[i];
			if(ch == "a") then
				char = "10";
			elseif(ch == "b") then
				char = "J";
			elseif(ch == "c") then
				char = "Q";
			elseif(ch == "d") then
				char = "K";
			elseif(ch == "e") then
				char = "A";
			else
				char = ch;
			end
			if (i < #value) then
				self.m_luckyPoker = self.m_luckyPoker .. char .. ", ";
			else
				self.m_luckyPoker = self.m_luckyPoker .. char;
			end
		end
	end
	if (self.m_luckyPoker) then
		self.m_jackpotLabel:setText(StringKit.substitute(STR_ROOM_SLOT_LUCKY_POKER, self.m_luckyPoker));
	end
end

FlashBar.flash = function(self)
	self.m_bLight = not self.m_bLight;
	if(self.m_bLight) then
		self.m_star:setFile(self.m_lightTexture);
	else
		self.m_star:setFile(self.m_darkTexture);
	end
end

FlashBar.stopFlash = function(self)
	clearInterval(self.m_interval);
	self.m_bLight = false;
	self.m_star:setFile(self.m_darkTexture);
	self.m_interval = 0;
	self.m_running = false;
end

FlashBar.getRunning = function(self)
	return self.m_running;
end
