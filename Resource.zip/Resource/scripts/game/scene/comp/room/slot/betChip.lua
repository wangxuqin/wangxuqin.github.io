------------------------------------------------
BetChip = class();

BetChip.ctor = function(self, node, id, objTrigger, funcTrigger)
	self.m_id = 0;
	self.m_betValue = 0;
	self.m_chipLabel = nil;
	self.m_glow = nil;
	self.m_overlay = nil;

	self.m_id = id;

	self.m_glow = node:getChildByName("glow");
	self.m_glow:setVisible(false);

	local chip = node:getChildByName("chip");

	self.m_chipLabel = node:getChildByName("label");

	self.m_overlay = node:getChildByName("overlay");
	self.m_overlay:setVisible(true);

	self.m_objTrigger = objTrigger;
	self.m_funcTrigger = funcTrigger;
	chip:setEventTouch(self, self.touchHandler);
end

BetChip.glow = function(self, bool)
	if (bool) then
		self.m_glow:setVisible(true);
		self.m_overlay:setVisible(false);
	else
		self.m_glow:setVisible(false);
		self.m_overlay:setVisible(true);
	end
end

BetChip.touchHandler = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
	TouchHelper.catch(self, finger_action, x, y);
	if(TouchHelper.isClick(self)) then
		if(self.m_funcTrigger) then
			self.m_funcTrigger(self.m_objTrigger, self.m_id);
		end
		SoundManager.playSound("SlotBet");
	end
end

BetChip.getBetValue = function(self)
	return self.m_betValue;
end

BetChip.setBetValue = function(self, value)
	self.m_betValue = value;
	self.m_chipLabel:setText(tostring(Formatter.formatBigNumber(value)));
end
