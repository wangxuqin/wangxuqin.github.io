-------------------------------------------------------------------
require("game/scene/comp/room/slot/turningPoker");

SlotPokers = class();

SlotPokers.ctor = function(self, node, objOnComplete, funcOnComplete)
	self.m_pokerV = nil;
	self.m_turningPokerV = nil;
	self.m_currentIndex = 1;
	self.m_timeout = 0;
	self.m_winMoney = 0;
	self.m_cloneWinMoney = 0;
	self.m_cards = nil;
	self.m_cloneCards = nil;
	self.m_packetLoss = true;
	self.m_container = node;
	self.m_objOnComplete = objOnComplete;
	self.m_funcOnComplete = funcOnComplete;
	self:initialize();
end

SlotPokers.initialize = function(self)
	self.m_cards = {0x040A, 0x040B, 0x040C, 0x040D, 0x040E};
	self.m_cloneCards = {0, 0, 0, 0, 0};
			
	local gap = 62;
	self.m_pokerV = {};
	self.m_turningPokerV = {};
	for i=1,5 do
		self.m_pokerV[i] = new(PokerCard);
		self.m_pokerV[i]:setAlign(kAlignTopLeft);
		self.m_pokerV[i]:setLevel(10);
		self.m_pokerV[i]:setPos(gap * (i-1) - 2, 0);
		self.m_pokerV[i]:setScale(0.75, 0.75, kCenterXY, 0, 0);
		self.m_pokerV[i]:setCard(self.m_cards[i]);
		self.m_pokerV[i]:setFile("room/slot/poker-background2.png");
		self.m_container:addChild(self.m_pokerV[i]);

		self.m_turningPokerV[i] = new(TurningPoker, "room/slot/slot-poker-shadow-skin.png", 61, 81);
		self.m_turningPokerV[i]:setPos(gap * (i-1) + 1, 0);
		self.m_container:addChild(self.m_turningPokerV[i]);
	end

	self.m_container:setClip(true, 0, 0, 308, 81);
end

SlotPokers.startTurnPokers = function(self)
	if (self.m_currentIndex <= 5) then
		local duration = 0.2;
		local action = new(ActionMoveTo, duration, nil, 81);
		action:apply(self.m_pokerV[self.m_currentIndex]);
		self.m_turningPokerV[self.m_currentIndex]:setPos(nil, 0);
		local action = new(ActionMoveBy, duration, nil, 81);
		local call = new(ActionCallFuncN, {self=self, turningPoker=self.m_turningPokerV[self.m_currentIndex]}, self.startTurnCompleteHandler);
		local action = new(ActionSequence, action, call);
		action:apply(self.m_turningPokerV[self.m_currentIndex]);
	else
		self.m_currentIndex = 1;
		--延迟0.5秒停止
		self.m_timeout = setTimeout(self.stopTurnTimeout, self, 500);
	end
end

SlotPokers.startTurnCompleteHandler = function(data)
	local self = data.self;
	local turningPoker = data.turningPoker;
	turningPoker:startTurn();
	self.m_currentIndex = self.m_currentIndex + 1;
	self:startTurnPokers();
end

SlotPokers.stopTurnTimeout = function(self)
	--丢包的情况下，获取随机牌型
	if (self.m_packetLoss) then
		self.m_cards = self:getCardsRandom();
	end
	self:stopTurnPokers();
end

SlotPokers.stopTurnPokers = function(self)
	if (self.m_currentIndex <= 5) then
		if (self.m_currentIndex == 1) then
			for i=1,5 do
				self.m_cloneCards[i] = self.m_cards[i];
			end
			self.m_cloneWinMoney = self.m_winMoney;
		end
		self.m_pokerV[self.m_currentIndex]:setCard(self.m_cloneCards[self.m_currentIndex]);
		self.m_pokerV[self.m_currentIndex]:setPos(nil, -81);

		local duration = 0.5;
		local action = new(ActionMoveTo, duration, nil, 0);
		action:apply(self.m_pokerV[self.m_currentIndex]);

		self.m_turningPokerV[self.m_currentIndex]:stopTurn();
		local move = new(ActionMoveBy, duration, nil, 81);
		local call = new(ActionCallFuncN, {self=self,turningPoker=self.m_turningPokerV[self.m_currentIndex]}, self.stopTurnCompleteHandler);
		local action = new(ActionSequence, move, call);
		action:apply(self.m_turningPokerV[self.m_currentIndex]);
	else
		self.m_currentIndex = 1;
		if(type(self.m_funcOnComplete) == "function") then
			self.m_funcOnComplete(self.m_objOnComplete);
		end
	end
end

SlotPokers.stopTurnCompleteHandler = function(data)
	local self = data.self;
	local turningPoker = data.turningPoker;
	self.m_currentIndex = self.m_currentIndex + 1;
	self:stopTurnPokers();
	turningPoker:setPos(nil, -As3Kit.getNodeHeight(turningPoker));
end

SlotPokers.stopAnimation = function(self)
	if (self.m_pokerV and self.m_turningPokerV) then
		clearTimeout(self.m_timeout);
		for i=1,5 do
			ActionBase.stopAllActions(self.m_pokerV[i]);
			self.m_pokerV[i]:setCard(self.m_cards[i]);
			self.m_pokerV[i]:setPos(nil, 0);

			ActionBase.stopAllActions(self.m_turningPokerV[i]);
			self.m_turningPokerV[i]:setPos(nil, -As3Kit.getNodeHeight(self.m_turningPokerV[i]));
			self.m_turningPokerV[i]:stopTurn();
		end
		self.m_currentIndex = 1;
	end
end

-- 丢包情况下，获取随机牌（必定非中奖牌型）
SlotPokers.getCardsRandom = function(self)
	local cards = {};
	local color = math.floor(math.random() * 4) + 1;
	local value = math.floor(math.random() * 13) + 2;
	--第一张牌
	cards[1] =  color * 256 + value;

	color = color + 1;
	if (color > 4) then
		color = 1
	end
	value = value + 1;
	if (value > 14) then
		value = 2;
	end
	--第二张牌
	cards[2] =  color * 256 + value;

	color = color + 1;
	if (color > 4) then
		color = 1
	end
	value = value + 2;
	if (value > 14) then
		value = 2;
	end
	--第三张牌
	cards[3] =  color * 256 + value;

	color = color + 1;
	if (color>4) then
		color = 1
	end
	value = value + 3;
	if (value>14) then
		value = 2;
	end
	--第四张牌
	cards[4] =  color * 256 + value;

	color = color + 1;
	if (color > 4) then
		color = 1
	end
	value = value + 4;
	if (value > 14) then
		value = 2;
	end
	--第五张牌
	cards[5] =  color * 256 + value;

	return cards;
end

SlotPokers.getPokerV = function(self)
	return self.m_pokerV;
end

SlotPokers.setCards = function(self, value)
	self.m_cards = value;
end

SlotPokers.setPacketLoss = function(self, value)
	self.m_packetLoss = value;
end

SlotPokers.getPacketLoss = function(self)
	return self.m_packetLoss;
end

SlotPokers.setWinMoney = function(self, value)
	self.m_winMoney = value;
end

SlotPokers.getCloneWinMoney = function(self)
	return self.m_cloneWinMoney;
end
