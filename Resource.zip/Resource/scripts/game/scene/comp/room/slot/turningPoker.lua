-------------------------------------------
TurningPoker = class(Node, false)

TurningPoker.HELPER_POINT = new(Point);
TurningPoker.POINT_ARRAY = { new(Point, 0, 0.75), new(Point, 1, 0.75), new(Point, 0, 1), new(Point, 1, 1) };

TurningPoker.ctor = function(self, texture, w, h)
	super(self);
	self.m_img1 = new(Image, texture);
	self.m_img2 = new(Image, texture);
	local _,h = self.m_img1:getSize();
	self.m_cyImage = h;
	self.m_img1:setSize(61);
	self.m_img2:setSize(61);
	self.m_img1:setPos(0, -h);
	self.m_img2:setPos(0, 0);
	self:addChild(self.m_img1);
	self:addChild(self.m_img2);

	self:setSize(w, h);
end

TurningPoker.dtor = function(self)
	Scheduler.getInstance():unscheduleUpdate(self, self.start);
end

TurningPoker.startTurn = function(self)
	Scheduler.getInstance():scheduleUpdate(self, self.start);
	self.m_img1:setPos(0, -self.m_cyImage);
	self.m_img2:setPos(0, 0);
	self.m_yMove = 0;
	local _,h = self:getSize();
	self.m_offsetY = -h;
end

TurningPoker.start = function(self)
	self.m_yMove = self.m_yMove + 10.4;
	if(self.m_yMove > self.m_cyImage) then
		self.m_yMove = self.m_yMove - self.m_cyImage;
	end
	self.m_img1:setPos(nil, self.m_yMove - self.m_cyImage + self.m_offsetY);
	self.m_img2:setPos(nil, self.m_yMove + self.m_offsetY);
end

TurningPoker.stopTurn = function(self)
	Scheduler.getInstance():unscheduleUpdate(self, self.start);
end
