---------------------------------------------------------
require("view/room/layout_slotmachine_help");

SlotBonusPopUp = class(PopupDialog, false);

SlotBonusPopUp.ctor = function(self)
	super(self, layout_slotmachine_help, true);
	self.m_title = nil;
	self.m_cardTypeLabelV = nil;
	self.m_oddsLabelV = nil;
	self.m_slotHelp = nil;
	self.m_systemTip1 = nil;
	self.m_systemTip2 = nil;
	self.m_check = nil;
	self.m_luckyPoker = nil;
	self.m_luckyTimes = 0;
	self.m_labelSprite = nil;
	self.m_luckyPokerCards = {};
	self:initialize();
end

SlotBonusPopUp.onPopupEnd = function(self)
	--添加事件响应
	local btn = self.m_root:getNodeByName("bg.btn_close");
	btn:setOnClick(self, self.onClickBtnClose);
	local group = self.m_root:getNodeByName("bg.check_view.checkgroup");
	group:setOnChange(self, self.checkChangeHandler);
end

SlotBonusPopUp.onClickBtnClose = function(self)
	self:close();
end

SlotBonusPopUp.update = function(self, data)
	local luckyPoker = data.luckyPoker;
	local luckyTimes = data.luckyTimes;
	self:setLuckyPoker(luckyPoker);
	self:setLuckyTimes(luckyTimes);
end

SlotBonusPopUp.initialize = function(self)
	--赔率表文字
	self.m_cardTypeLabelV = {};
	self.m_oddsLabelV = {};
	for i=1,9 do
		self.m_cardTypeLabelV[i] = self.m_root:getNodeByName("bg.mask.odds.cardtype" .. i);
		self.m_cardTypeLabelV[i]:setText(STR_ROOM_CARD_TYPE[12-i]);

		self.m_oddsLabelV[i] = self.m_root:getNodeByName("bg.mask.odds.odds" .. i);
	end
	self.m_oddsLabelV[1]:setText(StringKit.substitute(STR_COMMON_TIMES, "10000"));
	self.m_oddsLabelV[2]:setText(StringKit.substitute(STR_COMMON_TIMES, "1000"));
	self.m_oddsLabelV[3]:setText(StringKit.substitute(STR_COMMON_TIMES, "200"));
	self.m_oddsLabelV[4]:setText(StringKit.substitute(STR_COMMON_TIMES, "80"));
	self.m_oddsLabelV[5]:setText(StringKit.substitute(STR_COMMON_TIMES, "20"));
	self.m_oddsLabelV[6]:setText(StringKit.substitute(STR_COMMON_TIMES, "10"));
	self.m_oddsLabelV[7]:setText(StringKit.substitute(STR_COMMON_TIMES, "5"));
	self.m_oddsLabelV[8]:setText(StringKit.substitute(STR_COMMON_TIMES, "3"));
	self.m_oddsLabelV[9]:setText(StringKit.substitute(STR_COMMON_TIMES, "1"));

	self.m_check = self.m_root:getNodeByName("bg.check_view.checkgroup.check");
	local label = self.m_root:getNodeByName("bg.check_view.label");
	label:setText(STR_ROOM_SLOT_LUCKY_TIP_CHECK);

	if(CookieService.getBoolean(CookieKeys.ROOM_SLOT_NEED_TIPS, true)) then
		self.m_check:setChecked(false);
	else
		self.m_check:setChecked(true);
	end

	--标题
	self.m_title = self.m_root:getNodeByName("bg.mask.title");
	self.m_title:setText(STR_ROOM_REWARD_ODDS);
	self.m_title:setPickable(false);

	--奖金提示文字
	self.m_slotHelp = self.m_root:getNodeByName("bg.mask.slot_help");
	self.m_slotHelp:setText(STR_ROOM_SLOT_HELP);
	self.m_slotHelp:setPickable(false);

	--系统提示标签
	self.m_systemTip1 = self.m_root:getNodeByName("bg.sys_tip1");
	local str = StringKit.substitute(STR_ROOM_SLOT_LUCKY_POKER_TIP1, self.m_luckyTimes);
	self.m_systemTip1:setText(str);
	self.m_systemTip1:setPickable(false);

	self.m_systemTip2 = self.m_root:getNodeByName("bg.sys_tip2");
	self.m_systemTip2:setText(STR_ROOM_SLOT_LUCKY_POKER_TIP2);
	self.m_systemTip2:setPickable(false);
end

SlotBonusPopUp.checkChangeHandler = function(self)
	local bCheck = self.m_check:isChecked();
	CookieService.setBoolean(CookieKeys.ROOM_SLOT_NEED_TIPS, not bCheck);
end

SlotBonusPopUp.setLuckyPokers = function(self)
	if (self.m_luckyPoker) then
		for _,v in pairs(self.m_luckyPokerCards) do
			self:getDialog():removeChild(v);
		end
		self.m_luckyPokerCards = {};

		local startX = As3Kit.layoutCenter(436, 300, PokerCard.CARD_WIDTH + PokerCard.CARD_WIDTH * 0.5 * (#self.m_luckyPoker - 1));
		for i=1,#self.m_luckyPoker do
			poker = new(PokerCard);
			poker:setAlign(kAlignTopLeft);
			local val = tonumber(self.m_luckyPoker[i], 16);
			if (i >= 5) then
				poker:setCard(0x100 + 0x100 * 0 + val);
			else
				poker:setCard(0x100 + 0x100 * i + val);
			end
			poker:setPos(startX + (i-1) * PokerCard.CARD_WIDTH * 0.5, 92 + As3Kit.getNodeHeight(self.m_systemTip1) + 32);
			self:getDialog():addChild(poker);
			table.insert(self.m_luckyPokerCards, poker);
		end
	end
end

SlotBonusPopUp.setLuckyPoker = function(self, value)
	self.m_luckyPoker = value;
	self:setLuckyPokers();
end

SlotBonusPopUp.setLuckyTimes = function(self, value)
	self.m_luckyTimes = value;
	self.m_systemTip1:setText(StringKit.substitute(STR_ROOM_SLOT_LUCKY_POKER_TIP1, self.m_luckyTimes));
end
