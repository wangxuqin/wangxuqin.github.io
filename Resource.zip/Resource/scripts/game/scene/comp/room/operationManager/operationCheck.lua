--[Comment]
--������CheckBox��ť
OperationCheck = class();
OperationCheck.m_btn           = nil;--CheckBox��ť
OperationCheck.m_label         = nil;--��ǩ
OperationCheck.m_isVisible     = true;
OperationCheck.m_isEnable      = true;
		
OperationCheck.ctor = function (self, btn, label)
	if btn == nil then
        error("OperationCheck.ctor 's args btn must not be nil!!!");
    end
    self.m_btn          = btn;
    self.m_label        = label;
end

OperationCheck.dtor = function(self)
end

--[Comment]
--�����Ƿ����
OperationCheck.setEnable = function(self, value)
    if value ~= nil and type(value) == "boolean" then
        self.m_isEnable = value;
        if self.m_btn ~= nil then
            self.m_btn:setEnable(value);
        end
    end
end

OperationCheck.isEnable = function(self)
    return self.m_isEnable;
end

--[Comment]
--���õ���ص�
OperationCheck.setOnChange = function(self, obj, func)
    if self.m_btn ~= nil then
        self.m_btn:setOnChange(obj, func);
    end
end

--[Comment]
--���ñ�ǩ
OperationCheck.setLabel = function(self, value)
    if self.m_label ~= nil then        self.m_label:setText(value);
    end
end

OperationCheck.setVisible = function(self, value)
    if self.m_btn ~= nil then
        self.m_isVisible = value;
        self.m_btn:setVisible(value);
        if value == true then
            local parent = self.m_btn:getParent();
            if parent ~= nil then
                parent:setVisible(true);
            end
        end
    end
end

OperationCheck.isVisible = function(self, value)
    return self.m_isVisible;
end

OperationCheck.setChecked = function(self, value)
    if self.m_btn ~= nil then
        self.m_btn:setChecked(value);
    end
end

OperationCheck.isChecked = function(self)
    local ret = false;
    if self.m_btn ~= nil then
        ret = self.m_btn:isChecked();
    end
    return ret;
end

OperationCheck.getBtn = function(self)
    return self.m_btn;
end