--
-- UI2 Library, Version: 1.0 Alpha (0.99.2.1675-SNAPSHOT)
-- 
-- This file is a part of UI2 Library.
--
-- Author:
-- Xiaofeng Yang     2015
-- Vicent.Gong       2013
--
--

require("core/constants");
require("core/object");
require("ui/node");
require("ui/image");

SliderV = class(Node);

SliderV.s_defaultBgImage = "room/raise/room-raise-track-bg-overlay.png";
SliderV.s_defaultFgImage = "room/raise/room-raise-blue-track-bg.png";
SliderV.s_defaultButtonImage = "common/common-Slider-thumb-vertical.png";

SliderV.setDefaultImages = function(bgImage, fgImage, buttonImage)
    SliderV.s_bgImage = bgImage or SliderV.s_defaultBgImage;
    SliderV.s_fgImage = fgImage or SliderV.s_defaultFgImage;
    SliderV.s_buttonImage = buttonImage or SliderV.s_defaultButtonImage;
end

SliderV.ctor = function(self, width, height, bgImage, fgImage, buttonImage, leftWidth, rightWidth, topWidth, bottomWidth)
    self.m_bgImage = bgImage or SliderV.s_bgImage or SliderV.s_defaultBgImage;
    self.m_fgImage = fgImage or SliderV.s_fgImage or SliderV.s_defaultFgImage;
    self.m_buttonImage = buttonImage or SliderV.s_buttonImage or SliderV.s_defaultButtonImage;

    self.m_bg = new(Image,self.m_bgImage,nil,nil,leftWidth,rightWidth,topWidth,bottomWidth);
    width = (width and width >= 1) and width or self.m_bg:getSize();
    height = (height and height >= 1) and height or select(2,self.m_bg:getSize());
    
    SliderV.setSize(self,width,height);
    
    SliderV.addChild(self,self.m_bg);
    self.m_bg:setFillParent(true,true);
    self.m_bg:setEventTouch(self,self.onBackgroundEventTouch);

    self.m_fg = new(Image,self.m_fgImage,nil,nil,leftWidth,rightWidth,topWidth,bottomWidth);
    --self.m_fg:setAlign(kAlignBottom);

    SliderV.addChild(self,self.m_fg);
    self.m_fg:setFillParent(true,true);    
    
    self.m_button = new(Image,self.m_buttonImage);
    SliderV.addChild(self,self.m_button);
    self.m_button:setAlign(kAlignBottom);
    self.m_button:setPos(0,0);
    self.m_button:setEventTouch(self,self.onEventTouch);
    
    self.m_width = width;
    SliderV.setProgress(self,1.0);

    self.m_changeCallback = {};
end

SliderV.setImages = function(self, bgImage, fgImage, buttonImage)
    self.m_bgImage = bgImage or SliderV.s_bgImage or SliderV.s_defaultBgImage;
    self.m_fgImage = fgImage or SliderV.s_fgImage or SliderV.s_defaultFgImage;
    self.m_buttonImage = buttonImage or SliderV.s_buttonImage or SliderV.s_defaultButtonImage;

    self.m_bg:setFile(self.m_bgImage);
    self.m_fg:setFile(self.m_fgImage);
    self.m_button:setFile(self.m_buttonImage);
end

SliderV.setProgress = function(self, progress)
    progress = progress > 1 and 1 or progress;
    progress = progress < 0 and 0 or progress;
    self.m_progress = progress;
    
    local buttonW,buttonH = self.m_button:getSize();
    local buttonY = self.m_progress*self.m_height - buttonH/2;
    self.m_button:setPos(0,buttonY);
    self.m_fg:setClip(true,0,self.m_height*(1-self.m_progress),buttonW,self.m_height);
    print_string(self.m_progress);
   
end

SliderV.getProgress = function(self)
    return self.m_progress;
end

SliderV.setEnable = function(self, enable)
    self.m_button:setPickable(enable);
end

SliderV.setButtonVisible = function(self, visible)
    self.m_button:setVisible(visible);
end

SliderV.setOnChange = function(self, obj, func)
    self.m_changeCallback.obj = obj;
    self.m_changeCallback.func = func;
end

SliderV.dtor = function(self)
    
end

---------------------------------private functions-----------------------------------------

SliderV.onEventTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
    if finger_action == kFingerDown then
        self.m_dragingY = y;
        self.m_button:setColor(128,128,128);
    else 
        local bgX, bgY = self:getAbsolutePos();

        local notifyChange = function ()
            if self.m_changeCallback.func then
                self.m_changeCallback.func(self.m_changeCallback.obj,self.m_progress);
            end 
        end

        if (bgY <= y) and (self.m_height + bgY >= y) then 
            local diffY = y - self.m_dragingY;
            local progress = self.m_progress - diffY/self.m_height;
            SliderV.setProgress(self,progress);
            self.m_dragingY = y;
        
            notifyChange();
        elseif (y < bgY) and (self.m_progress < 1) then 
            -- 移动太快，刚跳出边界时，校正下。
            SliderV.setProgress(self,1);
            self.m_dragingY = bgY;
        
            notifyChange();
        elseif (y > self.m_height + bgY) and (self.m_progress > 0) then 
            -- 移动太快，刚跳出边界时，校正下。
            SliderV.setProgress(self,0);
            self.m_dragingY = self.m_height + bgY;
        
            notifyChange();
        end 

        if finger_action ~= kFingerMove then
            self.m_button:setColor(255,255,255);
        end
    end
end

SliderV.onBackgroundEventTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
    if finger_action == kFingerDown then
        local bgX, bgY = self:getAbsolutePos();
        local deltaY = y-bgY ;
        local progress = 1-deltaY/self.m_height;

        SliderV.setProgress(self,progress);
    end 

    self:onEventTouch(finger_action, x, y, drawing_id_first, drawing_id_current);
end
