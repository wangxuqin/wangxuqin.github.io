RaiseButton = class();--extends Button
	
RaiseButton.m_raiseButtonUpScale9Textures = nil;--:Scale9Textures
RaiseButton.m_raiseButtonDownScale9Textures = nil;--Scale9Textures
RaiseButton.m_raiseDefaultTextTf = nil;--:BitmapFontTextFormat;
RaiseButton.m_raiseDisabledTextTf = nil;--:BitmapFontTextFormat;
		
RaiseButton.init = function (self)
	local atlas = AssetManager.instance.getTextureAtlas("main-texture");--TextureAtlas
			
	raiseButtonUpScale9Textures = new (Scale9Textures,atlas.getTexture("room-raise-btn-up"), new (Rectangle,8, 8, 24, 24));
	raiseButtonDownScale9Textures = new (Scale9Textures,atlas.getTexture("room-raise-btn-down"), new (Rectangle,8, 8, 24, 24));
	raiseDefaultTextTf = new (BitmapFontTextFormat,"SUB_MENU_TITLE_FMT", 20, 0xabb1bb,  TextFormatAlign.CENTER);
	raiseDisabledTextTf = new (BitmapFontTextFormat,"SUB_MENU_TITLE_FMT", 20, 0x464747,  TextFormatAlign.CENTER);
end
		
RaiseButton.ctor = function (self,btnLabel, width)--:String :Number
	super();
			
	self.defaultSkin = new (Scale9Image,raiseButtonUpScale9Textures);
	self.downSkin = new (Scale9ImageraiseButtonDownScale9Textures);
	self.disabledSkin = self.downSkin;
	TextFormatManager.instance.tryUseBitmapFont(self, raiseDefaultTextTf, raiseDisabledTextTf, raiseDisabledTextTf);
	self.label = btnLabel;
	self.defaultLabelProperties.width = width;
    self.width = width;
	self.height = 88;
end
