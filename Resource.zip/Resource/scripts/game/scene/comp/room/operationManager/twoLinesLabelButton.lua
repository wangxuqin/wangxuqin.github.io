--[Comment]
--�����б�ǩ�İ�ť
TwoLinesLabelButton = class();

TwoLinesLabelButton.m_btn = nil;
TwoLinesLabelButton.m_topLabel = nil;
TwoLinesLabelButton.m_buyInChipsLabel = nil;
		
TwoLinesLabelButton.ctor = function (self, btn, topLabel, buyInChipsLabel)
	self.m_btn = btn;
    self.m_topLabel = topLabel;
    self.m_buyInChipsLabel = buyInChipsLabel;
    self.m_buyInChipsLabel:setText(StringKit.substitute(STR_ROOM_BUY_IN_CHIPS, STR_COMMON_CURRENCY_LABEL)..Formatter.formatNumberWithSplit(0));
end
		
TwoLinesLabelButton.setOnClick = function(self, obj, func)
    if self.m_btn ~= nil then
        self.m_btn:setOnClick(obj, func);
    end
end

--[Comment]
--�������б�ǩ
TwoLinesLabelButton.setTopLabel = function(self, text)
    if self.m_topLabel ~= nil then
        self.m_topLabel:setText(text);
    end
end	

--[Comment]
--�������б�ǩ
TwoLinesLabelButton.setBuyInChips = function(self, chips)
    if self.m_buyInChipsLabel ~= nil then
        local label = StringKit.substitute(STR_ROOM_BUY_IN_CHIPS, STR_COMMON_CURRENCY_LABEL..Formatter.formatBigNumber(chips, true));
	    self.m_buyInChipsLabel:setText(label);
    end
end

TwoLinesLabelButton.setEnable = function(self, value)
    if self.m_btn ~= nil then
        self.m_btn:setEnable(value);
    end
end

TwoLinesLabelButton.setVisible = function(self, value)
    if self.m_btn ~= nil then
        self.m_btn:setVisible(value);
    end
end

--[Comment]
--���ÿ����ԺͿɼ���
TwoLinesLabelButton.setEnableVisible = function(self, value)
    self:setEnable(value);
    self:setVisible(value);
end

TwoLinesLabelButton.getVisible = function(self, value)
    local ret = false;
    if self.m_btn ~= nil then
        ret = self.m_btn:getVisible();
    end
    return ret;
end