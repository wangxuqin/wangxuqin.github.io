require("view/room/layout_raise_slider");
require("ui/node");
require("game/scene/comp/room/operationManager/operationSlider")
RaiseSlider = class(Node,false)
RaiseSlider.CHIP_SCALE ={
    1,              2,              5,              10,             25,             50, 
    100,            200,            500,            1000,           2000,           5000, 
    10000,          20000,          50000,          100000,         200000,         500000, 
    1000000,        2000000,        5000000,        10000000,       20000000,       50000000, 
    100000000,      200000000,      500000000,      1000000000,     2000000000,     5000000000, 
    10000000000,    20000000000,    50000000000,    100000000000,   200000000000,   500000000000, 
    1000000000000};
				
RaiseSlider.m_enabledChips = 0;
RaiseSlider.m_smallBlind = 0;
		
RaiseSlider.m_forepartU = 0;
RaiseSlider.m_endpartU = 0;
RaiseSlider.m_forepartURate = 0;
RaiseSlider.m_endpartURate = 0;
		
RaiseSlider.m_raiseChips = 0;
RaiseSlider.m_forepartValue = 0;
RaiseSlider.m_endpartScale = 0;
		
RaiseSlider.ctor = function(self,scene)
	super(self);			
	self.m_scene = scene;
    self:setSize(280,560);
    self:__initialize();
    self.m_maxRaiseChips = 850;
    self.m_minRaiseChips = 0;      
    self:__setProgress(0);
    self:setAlign(kAlignBottomRight);
    self:setPos(12,85);
end

RaiseSlider.__setProgress = function(self,progress)
    self.m_slider:setProgress(progress);
    self:__changeChipNumber();
end
	
RaiseSlider.__initialize  = function(self)  
    self.m_root = SceneLoader.load(layout_raise_slider);
    self:addChild(self.m_root);	
    self.m_imgChipBg            = self.m_root:getNodeByName("bg.img_chip_bg");
    self.m_txtChip              = self.m_root:getNodeByName("bg.img_chip_bg.txt_chip");
    self.m_btnAllIn             = self.m_root:getNodeByName("bg.btn_all_in");
    self.m_btnAllPot            = self.m_root:getNodeByName("bg.btn_all_pot");
    self.m_btnHalfPot           = self.m_root:getNodeByName("bg.btn_half_pot");
    self.m_btnTriple            = self.m_root:getNodeByName("bg.btn_triple");
    self.m_btnThreeQuarterPot   = self.m_root:getNodeByName("bg.btn_three_quarter_pot");
    self.m_slider               = new(OperationSlider, self.m_root, 0, 100);
    self.m_slider:setOnChange(self, self.__changeHandler);
end

RaiseSlider.__changeChipNumber  = function(self)
    local chip = math.ceil((self.m_maxRaiseChips- self.m_minRaiseChips) * (self.m_slider:getProgress() / 100));
    self.m_txtChip:setText("$".. chip);	
end

	
RaiseSlider.raiseButtonTriggeredHandler  = function(self)
	if self.m_raiseChips > 0 then
		OperationManager:raiseOperation(self.m_raiseChips);
	end
end
		
RaiseSlider.__beginInteractionHandler  = function(self)
	self.m_beginInteraction = true;
end
		
RaiseSlider.__endInteractionHandler  = function(self)
	self.m_beginInteraction = false;
end
		
RaiseSlider.__changeHandler  = function(self)
			
	--根据滑动值和U值计算加注筹码额
	local currentRaiseChips;
	if self.m_slider:getProgress() == self.m_slider:getMaxProgress() then
		currentRaiseChips = self.m_maxRaiseChips;
		--判断是否all in了，播放all in动画
        local userSeat = SeatManager:getSelfSeat();
		if userSeat ~= nil and currentRaiseChips == userSeat:getSeatData().seatChips then
			self.m_imgChipBg:setVisible(false);
			self.m_btnAllIn:setVisible(true);
			self.m_slider:setBlueVisible(false);
		end
	else
		self.m_imgChipBg:setVisible(true);
		self.m_btnAllIn:setVisible(false);
		self.m_slider:setBlueVisible(true);		
				
		if (self.m_slider:getProgress() <= 38.2) then
			currentRaiseChips = self.m_forepartU * 
                math.ceil(self.m_slider:getProgress() / self.m_forepartURate) + self.m_minRaiseChips;
		else
			currentRaiseChips = self.m_forepartValue + self.m_minRaiseChips + 
                self.m_endpartU * math.ceil((self.m_slider:getProgress() - 38.2) / self.m_endpartScale / self.m_endpartURate);
		end
	end
			
	--判断是否播放齿轮声音
	if (self.m_raiseChips ~= currentRaiseChips and self.m_beginInteraction) then
		SoundManager.playSound("WheelTick");
	end
	self.m_raiseChips = currentRaiseChips;
    self.m_txtChip:setText("$"..self.m_raiseChips);
end
		
RaiseSlider.setMaxAndMinRaiseChips  = function(self,minRaiseChips, maxRaiseChips)
	self.m_minRaiseChips = minRaiseChips;
	self.m_maxRaiseChips = maxRaiseChips;
end
		
--[Comment]
--计算滑动条最小刻度值
RaiseSlider.__calculateUAndURate =  function(self)
	local forepartU;
	local endpardU;

	if self.m_enabledChips <= 50 * self.m_smallBlind then
		forepartU = self.m_enabledChips * 0.01;
        endpardU = self.m_enabledChips * 0.01;
	
    elseif self.m_enabledChips <= 100 * self.m_smallBlind then
		forepartU = self.m_smallBlind * 0.5;
		endpardU = self.m_enabledChips * 0.01;
	
    elseif self.m_enabledChips <= 200 * self.m_smallBlind then
		forepartU = self.m_smallBlind;
		endpardU = self.m_enabledChips * 0.01;
	
    elseif self.m_enabledChips <= 400 * self.m_smallBlind then
		forepartU = 2 * self.m_smallBlind;
		endpardU = self.m_enabledChips * 0.01;
	
    else
		forepartU = 4 * self.m_smallBlind;
		endpardU = self.m_enabledChips * 0.01;
	
    end
			
	self.m_forepartU = self:__roundU(forepartU);
	self.m_forepartURate = self.m_forepartU / forepartU;
			
	self.m_endpartU = self:__roundU(endpardU);
	self.m_endpartURate = self.m_endpartU / endpardU;
			
end
		
--[Comment]
--格式化最接近整数刻度值的U值
RaiseSlider.__roundU =  function(self,u)
	local i= 1; 
	local ru = 0;
	while u > self.CHIP_SCALE[i] do
		i = i + 1;
	end
			
	if i > 1 then
		local numberRange   = self.CHIP_SCALE[i] - self.CHIP_SCALE[i - 1];
		local rangeRate     = (u - self.CHIP_SCALE[i - 1]) / numberRange;
		if (rangeRate > 0.5) then
			ru = self.CHIP_SCALE[i];
		else
			ru = self.CHIP_SCALE[i-1];
		end
	else
		ru = self.CHIP_SCALE[1];
	end
	return ru;
end

RaiseSlider.setVisible =  function(self,value)	
	Node.setVisible(self, value);
    if value then
		self.m_slider:setProgress(0);
		self.m_enabledChips = self.m_maxRaiseChips - self.m_minRaiseChips;
		if  self.m_enabledChips > 0 then
			self.m_slider:setEnable(true);
			self:__calculateUAndURate();
			self.m_forepartValue = self.m_forepartU * math.ceil(38.2 / self.m_forepartURate);
			self.m_endpartScale = 0.618 / (1 - self.m_forepartValue / self.m_enabledChips);
			self:__changeHandler();
		else
            self.m_slider:setEnable(false);
			self.m_raiseChips = self.m_maxRaiseChips;
            self.m_txtChip:setText("$".. self.m_raiseChips);		
		end
				
		self.m_imgChipBg:setVisible(true);
        self.m_btnAllIn:setVisible(false);	
        	
		--最大加注是否是all in
        local userSeat = SeatManager:getSelfSeat();
		if userSeat ~= nil and self.m_maxRaiseChips == userSeat:getSeatData().seatChips then
             self.m_btnAllIn:setOnClick(self,self.__allInButtonTriggeredHandler);
		end
		
        --判断三倍反加按钮
		if (OperationManager.currentMaxRaiseChips * 3 >= self.m_minRaiseChips 
                and OperationManager.currentMaxRaiseChips * 3 <= self.m_maxRaiseChips) then
			self.m_btnTriple:setEnable(true);            
            self.m_btnTriple:setOnClick(self,self.__tripleButtonTriggeredHandler); 
		
        else
			self.m_btnTriple:setEnable(false);
		end
		
        --判断1/2奖池按钮
		if (self.m_scene:getTotalChipsInTable() * 0.5 >= self.m_minRaiseChips 
                and self.m_scene:getTotalChipsInTable() * 0.5 <= self.m_maxRaiseChips) then
			self.m_btnHalfPot:setEnable(true);            
            self.m_btnHalfPot:setOnClick(self,self.__halfPotButtonTriggeredHandler);
		
        else
			self.m_btnHalfPot:setEnable(false);
		end
		
        --判断3/4奖池按钮
		if (self.m_scene:getTotalChipsInTable() * 0.75 >= self.m_minRaiseChips 
                and self.m_scene:getTotalChipsInTable() * 0.75 <= self.m_maxRaiseChips) then			
            self.m_btnThreeQuarterPot:setOnClick(self,self.__threeQuarterPotButtonTriggeredHandler);
            self.m_btnThreeQuarterPot:setEnable(true);
		
        else
            self.m_btnAllPot:setOnClick(self,self.__allPotButtonTriggeredHandler);
			self.m_btnThreeQuarterPot:setEnable(false);
		end
		
        --判断全部奖池按钮
		if (self.m_scene:getTotalChipsInTable() >= self.m_minRaiseChips 
                and self.m_scene:getTotalChipsInTable() <= self.m_maxRaiseChips) then
			self.m_btnAllPot:setEnable(true);
		
        else
			self.m_btnAllPot:setEnable(false);
		end
	end
end

--[Comment]
--三倍奖池按钮响应
RaiseSlider.__tripleButtonTriggeredHandler =  function(self)
	local raiseChips = math.ceil(OperationManager.currentMaxRaiseChips * 3);
	local userSeat = SeatManager:getSelfSeat();
    if userSeat ~= nil and raiseChips > userSeat:getSeatData().seatChips then
		raiseChips = SeatManager:getSelfSeat():getSeatData().seatChips;
	end
	if raiseChips > 0 then
		self.m_raiseChips = raiseChips;
		self:raiseButtonTriggeredHandler();
	end
end

--[Comment]
--一半奖池	 		
RaiseSlider.__halfPotButtonTriggeredHandler =  function(self)
	self.m_raiseChips = math.ceil(self.m_scene:getTotalChipsInTable() * 0.5);
	self:raiseButtonTriggeredHandler();
end

--[Comment]
--3/4奖池		
RaiseSlider.__threeQuarterPotButtonTriggeredHandler =  function(self)
	self.m_raiseChips = math.ceil(self.m_scene:getTotalChipsInTable() * 0.75);
	self:raiseButtonTriggeredHandler();
end

--[Comment]
--全部奖池		
RaiseSlider.__allPotButtonTriggeredHandler =  function(self)
	self.m_raiseChips = math.ceil(self.m_scene:getTotalChipsInTable());
	self:raiseButtonTriggeredHandler();
end
		
RaiseSlider.__allInButtonTriggeredHandler =  function(self)
	self:raiseButtonTriggeredHandler();
end
		
RaiseSlider.setSmallBlind =  function(self,value)
	self.m_smallBlind = value;
end

RaiseSlider.getMinRaiseChips =  function(self)
	return self.m_minRaiseChips;
end

RaiseSlider.getMaxRaiseChips =  function(self)
	return self.m_maxRaiseChips;
end

RaiseSlider.getRaiseChips =  function(self)
	return self.m_raiseChips;
end

RaiseSlider.setRaiseButtonIsEnabled =  function(self,value)
	self.m_btnAllIn:setEnable(value);
    self.m_btnAllPot:setEnable(value);
    self.m_btnHalfPot:setEnable(value);
    self.m_btnThreeQuarterPot:setEnable(value);
    self.m_btnTriple:setEnable(value);
end