--[Comment]
--滑动条
OperationSlider = class();

OperationSlider.ctor = function(self, scene, minProgress, maxProgress)
    self.m_scene                = scene;
    self.m_imgTraceBg           = self.m_scene:getNodeByName("bg.img_trace_bg");
    self.m_imgTrackBgOverlay    = self.m_scene:getNodeByName("bg.img_trace_bg.img_trace_bg_overlay");
    self.m_imgYellowTrace       = self.m_scene:getNodeByName("bg.img_trace_bg.img_yellow_trace");
    self.m_imgBlueTrace         = self.m_scene:getNodeByName("bg.img_trace_bg.img_blue_trace");
    self.m_btnSlider            = self.m_scene:getNodeByName("bg.img_trace_bg.btn_slider");
    self:setBlueVisible(true);
    self.m_callback             = {};
    self.m_minProgress          = minProgress or 0;
    self.m_curProgress          = 0;
    self.m_maxProgress          = maxProgress or 100;
    self:__count();
    self.m_btnSlider:setEventTouch(self,self.__onTouchSlider); 
    
end

OperationSlider.dtor = function(self)
    self.m_callback = nil;
end

OperationSlider.__count = function(self)
    _,self.m_sliderHeight   = self.m_btnSlider:getSize();
    _,self.m_trackByHeight  = self.m_imgTraceBg:getSize();
    self.m_minHeightValue   = -5;
    self.m_maxHeightValue   = self.m_trackByHeight - self.m_sliderHeight + 5;
end

OperationSlider.__countProgress = function(self, value)
    if value < self.m_minHeightValue then
        value = self.m_minHeightValue;
    end

    if value > self.m_maxHeightValue then
        value = self.m_maxHeightValue;
    end

    local rate = (value - self.m_minHeightValue) / (self.m_maxHeightValue - self.m_minHeightValue);
    self:setProgress((1 - rate) * self.m_maxProgress);
end

OperationSlider.setProgress = function(self, value)
    if self.m_minProgress <= value and value <= self.m_maxProgress then
        self.m_curProgress = value;
        self:__updateView(value / self.m_maxProgress);
        self:__onChange(self.m_curProgress);
    end
end

OperationSlider.getProgress = function(self)
    return self.m_curProgress;
end

OperationSlider.getMaxProgress = function(self)
    return self.m_maxProgress;
end

OperationSlider.__updateView = function(self, rate)
    if 0 <= rate and rate <= 1.0 then
        local newY = (1 - rate) * (self.m_maxHeightValue - self.m_minHeightValue) + self.m_minHeightValue;
        self.m_btnSlider:setPos(nil,newY);
        local height = self.m_trackByHeight - newY - self.m_sliderHeight / 2;
        if height < 0 then
            height = 0;
        end
        local maxHeight = self.m_trackByHeight - self.m_minHeightValue - self.m_sliderHeight / 2;
        self.m_imgBlueTrace:setSize(12, height);
        self.m_imgBlueTrace:setPos(nil, self.m_trackByHeight - height - 3);
   end
end


OperationSlider.__onTouchSlider = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
    if finger_action == kFingerDown then
        self.m_startY = y;
        _, self.m_startSliderY = self.m_btnSlider:getPos();

    elseif finger_action == kFingerMove then
        local newY  = self.m_startSliderY + (y - self.m_startY);
        if newY < self.m_minHeightValue then newY = self.m_minHeightValue end;
        if newY > self.m_maxHeightValue then newY = self.m_maxHeightValue end;
        self:__countProgress(newY);

    elseif finger_action == kFingerUp then  
    end
end

OperationSlider.__onChange = function(self, progress)
    if self.m_callback ~= nil then
        if self.m_callback.func ~= nil then
            Log.d("OperationSlider", " progress = ", progress);
            if self.m_callback.obj == nil then
                self.m_callback.func(progress);
            else
                self.m_callback.func(self.m_callback.obj, progress);
            end
        end
    end
end

OperationSlider.setOnChange = function(self, obj, func)
    self.m_callback.obj = obj;
    self.m_callback.func = func;
end


OperationSlider.setEnable = function(self, value)
    self.m_btnSlider:setEnable(value);
end

OperationSlider.setBlueVisible = function(self, value)
    if self.m_imgBlueTrace ~= nil then
        self.m_imgBlueTrace:setVisible(value);
    end
    if self.m_imgYellowTrace ~= nil then
        self.m_imgYellowTrace:setVisible(not value);
    end
end