--[Comment]
--��������ť
OperationButton = class();
OperationButton.m_btn           = nil;--��ť
OperationButton.m_label         = nil;--��ǩ
OperationButton.m_img_unable    = nil;--��ť���ñ���
OperationButton.m_isVisible     = true;
OperationButton.m_isEnable      = true;
		
OperationButton.ctor = function (self, btn, label, imgUnable)
	if btn == nil then
        error("operationButton.ctor 's args btn must not be nil!!!");
    end
    self.m_btn          = btn;
    self.m_label        = label;
    self.m_img_unable   = imgUnable;
end

OperationButton.dtor = function(self)
end

--[Comment]
--�����Ƿ����
OperationButton.setEnable = function(self, value)
    if value ~= nil and type(value) == "boolean" then
        self.m_isEnable = value;
        if self.m_btn ~= nil then
            self.m_btn:setEnable(value);
        end

        if self.m_img_unable ~= nil then
            self.m_img_unable:setVisible(not value);
        end
    end
end

OperationButton.isEnable = function(self)
    return self.m_isEnable;
end

--[Comment]
--���õ���ص�
OperationButton.setOnClick = function(self, obj, func)
    if self.m_btn ~= nil then
        self.m_btn:setOnClick(obj, func);
    end
end

--[Comment]
--���ñ�ǩ
OperationButton.setLabel = function(self, value)
    if self.m_label ~= nil then
        self.m_label:setText(value);
    end
end

OperationButton.setVisible = function(self, value)
    if self.m_btn ~= nil then
        self.m_isVisible = value;
        self.m_btn:setVisible(value);
    end
end

OperationButton.isVisible = function(self, value)
    return self.m_isVisible;
end