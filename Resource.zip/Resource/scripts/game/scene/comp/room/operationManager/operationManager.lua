--http://ipk-demo-3.boyaa.com/docs/
require("game/scene/comp/room/operationManager/roomTip");
require("game/scene/comp/room/operationManager/twoLinesLabelButton");
require("game/scene/comp/room/operationManager/operationButton");
require("game/scene/comp/room/operationManager/operationCheck");
require("game/scene/comp/room/operationManager/raiseSlider");
require("game/scene/comp/room/operationManager/operationLabel");
require("game/model/data/room/requestBuyInData");
OperationManager = class();

OperationManager.AUTO_NOTHING                       = -1; 
OperationManager.AUTO_CHECK_SELECTED                = 0;
OperationManager.AUTO_CHECK_OR_FOLD_SELECTED        = 1;
OperationManager.AUTO_CALL_ANY_SELECTED             = 2; 
OperationManager.AUTO_CALL_SELECTED                 = 3;
OperationManager.m_scene                            = nil;
OperationManager.m_buttonContainer                  = nil; --操作面板
OperationManager.m_btnCheck                         = nil;
OperationManager.m_btnFold                          = nil;
OperationManager.m_btnRaise                         = nil;
OperationManager.m_btnCall                          = nil;
OperationManager.m_btnConfirm                       = nil;
OperationManager.m_btnShowHandCard                  = nil;--亮出手牌按钮
OperationManager.m_btnQuickSitdown                  = nil;--快速开始按钮
OperationManager.m_btnBuyInAgain                    = nil;--重新买入按钮
OperationManager.m_txtRoomInfo                      = nil;
OperationManager.m_roomTip                          = nil;
		
OperationManager.m_checkBoxGroup                    = nil;
OperationManager.m_btnAutoCheck                     = nil;
OperationManager.m_btnAutoCheckOrFold               = nil;
OperationManager.m_btnAutoCallAny                   = nil;
OperationManager.m_btnAutoCall                      = nil;
OperationManager.m_raiseSlider                      = nil;
		
OperationManager.m_callNeedChips                    = nil;--跟注需要的钱数
OperationManager.m_myCallNeedChips                  = nil;--跟注需要的钱数（非server返回，由客户端计算出来的值）
OperationManager.m_currentMaxBetInChips             = 0;--当前轮次某个玩家已下注的最大筹码数
OperationManager.m_currentCase                      = nil;
OperationManager.m_operationTimeout                 = nil;
OperationManager.m_currentCheckFlag                 = nil;
OperationManager.m_operationRequestData             = nil;
		
OperationManager.selfAFK                            = nil;
OperationManager.myBetInChips                       = 0;--玩家自己已加注的筹码
OperationManager.hasRaise                           = false;--其他人的操作对于用户自己来说是否算加注
OperationManager.currentMaxRaiseChips               = 0;--当前轮次操作加注的最大筹码
OperationManager.caseFlag                           = 0;
OperationManager.m_operation_button_array           = {};

OperationManager.m_doubleClickCooldown              = false;--双击冷却标识

OperationManager.initialize = function (self, scene)--:GameRoomScreen  :int
	self.m_scene = scene;
	local ctrls = self.m_scene.m_ctrl;
    self.m_buttonContainer = self.m_scene:getNodeByName(ctrls.buttonContainer);  --获取按钮容器
	self.m_operationRequestData = new(OperationRequestData);
			
    --按钮
	self.m_btnCheck = new(OperationButton,                      --看牌
        self.m_scene:getNodeByName(ctrls.btnCheck),
        self.m_scene:getNodeByName(ctrls.txtCheck),
        self.m_scene:getNodeByName(ctrls.imgCheckUnable));
    self.m_btnCheck:setEnable(false);
    self.m_btnCheck:setLabel(STR_ROOM_CHECK);
			
	self.m_btnFold = new(OperationButton,                       --弃牌
        self.m_scene:getNodeByName(ctrls.btnFold),    
        self.m_scene:getNodeByName(ctrls.txtFold), 
        self.m_scene:getNodeByName(ctrls.imgFoldUnable));
    self.m_btnFold:setEnable(false);
    self.m_btnFold:setLabel(STR_ROOM_FOLD);
			
	self.m_btnRaise = new(OperationButton,                      --加注
        self.m_scene:getNodeByName(ctrls.btnRaise),    
        self.m_scene:getNodeByName(ctrls.txtRaise), 
        self.m_scene:getNodeByName(ctrls.imgRaiseUnable));
    self.m_btnRaise:setEnable(false);
    self.m_btnRaise:setLabel(STR_ROOM_RAISE);
			
	self.m_btnCall = new(OperationButton,                       --跟注
        self.m_scene:getNodeByName(ctrls.btnCall),
        self.m_scene:getNodeByName(ctrls.txtCall), 
        self.m_scene:getNodeByName(ctrls.imgCallUnable));
    self.m_btnCall:setEnable(false);
    self.m_btnCall:setLabel(StringKit.substitute(STR_ROOM_CALL, ""));
			
	self.m_btnConfirm = new(OperationButton,                    --确认
        self.m_scene:getNodeByName(ctrls.btnConfirm),
        self.m_scene:getNodeByName(ctrls.txtConfirm), 
        self.m_scene:getNodeByName(ctrls.imgConfirmUnable));
    self.m_btnConfirm:setEnable(false);
	self.m_btnConfirm:setLabel(STR_ROOM_CONFIRM);

    self.m_operation_button_array = {
        self.m_btnCheck,
        self.m_btnFold,
        self.m_btnRaise,
        self.m_btnCall,
        self.m_btnConfirm
    };
			
	--亮出手牌按钮
	self.m_btnShowHandCard = self.m_scene:getNodeByName(ctrls.btnShowHandCard);
    self.m_txtShowHandCard = self.m_scene:getNodeByName(ctrls.txtShowHandCard);
	self.m_btnShowHandCard:setEnable(false);
	self.m_txtShowHandCard:setText(STR_ROOM_SHOW_HAND_CARD);
			
	--快速开始按钮
	self.m_btnQuickSitdown = new(TwoLinesLabelButton,
        self.m_scene:getNodeByName(ctrls.btnQuickSitdown),
        self.m_scene:getNodeByName(ctrls.txtQuickSitdown),
        self.m_scene:getNodeByName(ctrls.txtQuickSitdownChips)
     );
    self.m_btnQuickSitdown:setTopLabel(STR_ROOM_PLAY_NOW);
    self.m_btnQuickSitdown:setEnable(false);

	--重新坐下按钮
	self.m_btnBuyInAgain = new(TwoLinesLabelButton,
        self.m_scene:getNodeByName(ctrls.btnBuyInAgain),
        self.m_scene:getNodeByName(ctrls.txtBuyInAgain),
        self.m_scene:getNodeByName(ctrls.txtBuyInAgainChips)
    );
    self.m_btnBuyInAgain:setTopLabel(STR_ROOM_BUY_IN_AGAIN);
    self.m_btnBuyInAgain:setEnable(false);
	
    --房间信息label
	self.m_txtRoomInfo = new(OperationLabel, 
        self.m_scene:getNodeByName(ctrls.txtRoomInfo1),
        self.m_scene:getNodeByName(ctrls.txtRoomInfo2)
    );
	
    self.m_checkBoxGroup = self.m_scene:getNodeByName(ctrls.checkBoxGroup);
	--单选
    self.m_btnAutoCheck = new(OperationCheck,
        self.m_scene:getNodeByName(ctrls.btnAutoCheck),
        self.m_scene:getNodeByName(ctrls.txtAutoCheck));
    self.m_btnAutoCheck:setLabel(STR_ROOM_AUTO_CHECK);
			
	self.m_btnAutoCheckOrFold =  new(OperationCheck,
        self.m_scene:getNodeByName(ctrls.btnAutoCheckOrFold),
        self.m_scene:getNodeByName(ctrls.txtAutoCheckOrFold));
    self.m_btnAutoCheckOrFold:setLabel(STR_ROOM_CHECK_OR_FOLD);
	
    self.m_btnAutoCallAny = new(OperationCheck,
        self.m_scene:getNodeByName(ctrls.btnAutoCallAny),
        self.m_scene:getNodeByName(ctrls.txtAutoCallAny));
    self.m_btnAutoCallAny:setLabel(STR_ROOM_CALL_ANY);

    self.m_btnAutoCall = new(OperationCheck,
        self.m_scene:getNodeByName(ctrls.btnAutoCall),
        self.m_scene:getNodeByName(ctrls.txtAutoCall));
    self.m_btnAutoCall:setLabel(StringKit.substitute(STR_ROOM_AUTO_CALL, ""));
    
    self.m_roomTip = new(RoomTip, 400);

    self.m_raiseSlider = new(RaiseSlider,self.m_scene);
    self.m_scene:addChild(self.m_raiseSlider);
    self.m_raiseSlider:setVisible(false);
	self:showDisabledCase();
    self:addEvents();
end

--[Comment]
--反初始化
OperationManager.deinitialize = function(self)
    self:removeEvents();
    self.__eventList = nil;
end

--[Comment]
--双击处理
OperationManager.doubleClickHandler = function (self,data)
	if self.m_btnCheck:isVisible() == true and self.m_btnCheck:isEnable() == true and self.m_doubleClickCooldown == false then					
		self:checkButtonHandler();
        self.m_doubleClickCooldown = true;
        setTimeout(self.doubleClickCooldownFinished, self, 500);
	end
end

--[Comment]
--双击冷却结束
OperationManager.doubleClickCooldownFinished = function(self)
    self.m_doubleClickCooldown = false;
end
		
OperationManager.addEvents = function(self)
    if self.__eventList == nil then
        self.__eventList = {
            {self.m_btnCheck,           "setOnClick",   self.checkButtonHandler     };
            {self.m_btnFold,            "setOnClick",   self.foldButtonHandler      };
            {self.m_btnRaise,           "setOnClick",   self.raiseButtonHandler     };
            {self.m_btnCall,            "setOnClick",   self.callButtonHandler      };
            {self.m_btnConfirm,         "setOnClick",   self.confirmButtonHandler   };

            {self.m_checkBoxGroup,      "setOnChange",  self.autoButtonHandler      };

            {self.m_btnQuickSitdown,    "setOnClick",   self.playNowSitDown         };
            {self.m_btnShowHandCard,    "setOnClick",   self.showSelfHandCard       };
            {self.m_btnBuyInAgain,      "setOnClick",   self.buyInAgain             };

        };
    end
    EventListKit.addEventList(self, self.__eventList);

    -- 添加桌面双击响应事件
    self.m_scene:setEventDoubleClick(self, self.doubleClickHandler);
end
		
OperationManager.removeEvents = function(self)   
    EventListKit.removeEventList(self, self.__eventList);

    -- 移除桌面双击响应事件
    self.m_scene:setEventDoubleClick(nil, nil);
end
		
OperationManager.m_oldSeatId = -1;

OperationManager.buyInAgain = function(self)
    self.m_oldSeatId = SeatManager.selfSeatId;
    EventDispatcher.getInstance():dispatch(
        CommandEvent.s_event, CommandEvent.s_cmd.USER_STAND_UP);
    Model.watchData(ModelKeys.ROOM_USER_STAND_UP_DATA, self, userStandUp, false);
end
		
OperationManager.m_requestBuyIn = new(RequestBuyInData);
OperationManager.m_buyInAgainTimeout = 0;

OperationManager.userStandUp = function(self, data)
    if self.m_oldSeatId == data.seatId then
        self:showDisabledCase();
        self.m_buyInAgainTimeout = setTimeout(self.buyInAgainTimeout, self, 600);
    end
    Model.clearWatcher(ModelKeys.ROOM_USER_STAND_UP_DATA, userStandUp);
end

OperationManager.buyInAgainTimeout = function(self)           
    self.m_requestBuyIn.seatId = self.m_oldSeatId;
    self.m_requestBuyIn.buyinChips = SeatManager.selfBuyInChips;
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.USER_BUY_IN, self.m_requestBuyIn);
end
		
--[Comment]
--亮出自己的手牌动画 		  	
OperationManager.showSelfHandCard = function (self)
	self:showDisabledCase();
	local selfHandCard = SeatManager:getSelfSeat().handCard;
    --亮出手牌动画
	SoundManager.playSound("ShowHandCard");
	EventDispatcher.getInstance():dispatch(
        CommandEvent.s_event, CommandEvent.s_cmd.ROOM_SHOW_HAND_CARD);
end
		
OperationManager.autoButtonHandler = function (self, index, isChecked)
	self.m_checkBoxGroup:clear();
    self.m_checkBoxGroup:setChecked(index, isChecked);
    Log.d(self.TAG, "index = ", index);
    if isChecked then
        local btn = self.m_checkBoxGroup:getCheckBox(index);
        if  btn == self.m_btnAutoCheck:getBtn() then            -- 看牌
            self.m_currentCheckFlag = self.AUTO_CHECK_SELECTED;
        elseif  btn == self.m_btnAutoCheckOrFold:getBtn() then  -- 看牌或者弃牌
            self.m_currentCheckFlag = self.AUTO_CHECK_OR_FOLD_SELECTED;
        elseif btn == self.m_btnAutoCall:getBtn() then          -- 跟注
            self.m_currentCheckFlag = self.AUTO_CALL_SELECTED;
        elseif btn == self.m_btnAutoCallAny:getBtn() then       -- 跟任何注
            self.m_currentCheckFlag = self.AUTO_CALL_ANY_SELECTED;
        end
    else
        self.m_currentCheckFlag = self.AUTO_NOTHING;
    end
end
		
OperationManager.raiseOperation = function(self, raiseChips)
    SoundManager.cancelAlertSound();
    self.m_operationRequestData.operationType = OperationRequestData.OP_TYPE_CALL;
    self.m_operationRequestData.betMoney = raiseChips;
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.PLAY_CARD_OPERATION, self.m_operationRequestData);
    SeatManager:stopSeatTimer();
    self:showEnabledCase4();
end
		
OperationManager.callButtonHandler = function (self) 
	SoundManager.cancelAlertSound();
	self.m_operationRequestData.operationType = OperationRequestData.OP_TYPE_CALL;
	if self.m_callNeedChips < self:getSelfSeat():getSeatData().seatChips then
		self.m_operationRequestData.betMoney = self.m_callNeedChips;
	else
		self.m_operationRequestData.betMoney = self:getSelfSeat():getSeatData().seatChips;
	end
	EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.PLAY_CARD_OPERATION, self.m_operationRequestData);	
	SeatManager:stopSeatTimer();
	self:showEnabledCase4();
end
		
OperationManager.confirmButtonHandler = function(self)
    if self.m_raiseSlider.m_raiseChips then
        self:raiseOperation(self.m_raiseSlider.m_raiseChips);
    end
end
		
OperationManager.raiseButtonHandler = function (self)
	--加注额已经限定死的情况
	if self.m_raiseSlider.m_minRaiseChips == self.m_raiseSlider.m_maxRaiseChips then
		self:raiseOperation(self.m_raiseSlider.m_minRaiseChips);
	else
		self.m_raiseSlider:setVisible(true);
		self.m_btnConfirm:setVisible(true);
		self.m_btnRaise:setVisible(false);
	end
end
		
OperationManager.m_isSelfFold = false;

OperationManager.foldButtonHandler = function(self)
    SoundManager.playSound("Fold");
    SoundManager.cancelAlertSound();
    self.m_operationRequestData.operationType = OperationRequestData.OP_TYPE_FOLD;
    self.m_operationRequestData.betMoney = 0;
    EventDispatcher.getInstance():dispatch(
        CommandEvent.s_event, CommandEvent.s_cmd.PLAY_CARD_OPERATION, self.m_operationRequestData);
    self.m_isSelfFold = true;
    SeatManager:stopSeatTimer();
    self:getSelfSeat():getHandCard():fadeHandCard();
    self:getSelfSeat():fadeSeat();
    self:getSelfSeat():showStatu(STR_ROOM_OPERATION_TYPE[OperationResultData.SEAT_FOLD]);
    self:showDisabledCase();
end
		
OperationManager.checkButtonHandler = function(self)
    SoundManager.playSound("Check");
    SoundManager.cancelAlertSound();

    self.m_operationRequestData.operationType = OperationRequestData.OP_TYPE_CHECK;
    self.m_operationRequestData.betMoney = 0;
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.PLAY_CARD_OPERATION, self.m_operationRequestData);

    SeatManager:stopSeatTimer();
    local userSeat = self:getSelfSeat();
    if userSeat ~= nil then
        userSeat:showStatu(STR_ROOM_OPERATION_TYPE[OperationResultData.SEAT_CHECK]);
    end
    self:showEnabledCase4();
end
		
OperationManager.hideAndRefreshAllControl = function (self)
    local children = self.m_buttonContainer:getChildren();
    if children then
        for _, child in pairs(children) do
            child:setVisible(false);
        end
    end

    if self.m_raiseSlider ~= nil then
        self.m_raiseSlider:setVisible(false);
    end

    for i = 1, #self.m_operation_button_array do
        self.m_operation_button_array[i]:setEnable(true);
    end

	if self.m_operationTimeout then
		clearTimeout(self.m_operationTimeout);
		self.m_operationTimeout = 0;
	end
	if self.m_showHandCardTimeout then
		clearTimeout(self.m_showHandCardTimeout);
		self.m_showHandCardTimeout = 0;
	end
end
		
--[[
轮到自己操作且没有加注（看牌、弃牌、加注）
--]]
OperationManager.showEnabledCase1 = function (self)
	self:hideAndRefreshAllControl();
	self.m_btnCheck:setVisible(true);
	self.m_btnFold:setVisible(true);
	self.m_btnRaise:setVisible(true);
			
	self.m_currentCase = 1;
	self.caseFlag = 1;		
	--提前0.5秒切换按钮，防止用户误操作
	if Model.getData(ModelKeys.USER_DATA) ~= nil and not TutotiaKit.isTutotia() then
		self.m_operationTimeout = setTimeout(self.showDisabledCase, self, SeatManager.countdown * 1000 - 500);
	end
end

--[Comment]
--轮到自己操作且有加注，自己余额不足以加注，加注按钮显示但灰态（跟注、弃牌、加注）
OperationManager.showEnabledCase2 = function(self)--:void
	self:hideAndRefreshAllControl();
	self.m_btnCall:setVisible(true);
	self.m_btnFold:setVisible(true);
	self.m_btnRaise:setVisible(true);
	
    --灰态加注按钮
	self.m_btnRaise:setEnable(false);
	self.m_btnRaise:setLabel(STR_ROOM_RAISE);		
	self.m_currentCase = 2;
	self.caseFlag = 2;		
	--提前0.5秒切换按钮，防止用户误操作
	if Model.getData(ModelKeys.USER_DATA) ~= nil and not TutotiaKit.isTutotia() then
		self.m_operationTimeout = setTimeout(self.showDisabledCase, SeatManager.countdown * 1000 - 500);
	end
end
		
--[Comment]
--轮到自己操作且有加注，自己余额足以加注（跟注、弃牌、加注）
OperationManager.showEnabledCase3 = function (self)--:void
	self:hideAndRefreshAllControl();
	self.m_btnCall:setVisible(true);
	self.m_btnFold:setVisible(true);
	self.m_btnRaise:setVisible(true);
	--这种情况下，别人all in了，自己只能跟注了，需要灰态加注按钮
	if  self.m_raiseSlider.m_minRaiseChips == self.m_myCallNeedChips and
        self.m_raiseSlider.m_minRaiseChips == self.m_raiseSlider.m_maxRaiseChips then
		self.m_btnRaise:setEnable(false);
		self.m_btnRaise:setLabel(STR_ROOM_RAISE);
	end
			
	self.m_currentCase = 3;
	self.caseFlag = 3;		
	--提前0.5秒切换按钮，防止用户误操作
	if Model.getData(ModelKeys.USER_DATA) ~= nil and not TutotiaKit.isTutotia() then
		self.m_operationTimeout = setTimeout(self.showDisabledCase, self, SeatManager.countdown * 1000 - 500);
	end
end
		
--[Comment]
--没轮到自己操作，且没有加注（自动看牌、看或弃、跟任何注）
OperationManager.showEnabledCase4 = function (self)
	if not TutotiaKit.isTutotia() then
	    self:hideAndRefreshAllControl();
	    self.m_btnAutoCheck:setVisible(true);
	    self.m_btnAutoCheck:setChecked(false);
	    self.m_btnAutoCheckOrFold:setVisible(true);
	    self.m_btnAutoCheckOrFold:setChecked(false);
	    self.m_btnAutoCallAny:setVisible(true);
	    self.m_btnAutoCallAny:setChecked(false);

	    self.m_currentCheckFlag = AUTO_NOTHING;
	    self.m_currentCase = 4;
        self.caseFlag = 4;
    end
end
		
--[Comment]
--没轮到自己操作，但是有加注（跟xx注、看或弃、跟任何注）
OperationManager.showEnabledCase5 = function (self)
	if not TutotiaKit.isTutotia() then
	    self:hideAndRefreshAllControl();
	    self.m_btnAutoCall:setVisible(true);
	    self.m_btnAutoCall:setChecked(false);
	    self.m_btnAutoCheckOrFold:setVisible(true);
	    self.m_btnAutoCheckOrFold:setChecked(false);
	    self.m_btnAutoCallAny:setVisible(true);
	    if self.m_btnAutoCallAny:isChecked() then
		    self.m_currentCheckFlag = self.AUTO_CALL_ANY_SELECTED;
	    else
		    self.m_currentCheckFlag = self.AUTO_NOTHING;
	    end
			
	    self.m_currentCase = 5;
        self.caseFlag = 5;
    end
end
		
OperationManager.showDisabledCase = function (self)
	self:hideAndRefreshAllControl();
	self.m_btnCheck:setVisible(true);
	self.m_btnCheck:setEnable(false);
	self.m_btnFold:setVisible(true);
	self.m_btnFold:setEnable(false);
	self.m_btnRaise:setVisible(true);
	self.m_btnRaise:setEnable(false);
	self.m_btnRaise:setLabel(STR_ROOM_RAISE);
	clearTimeout(self.m_operationTimeout);
	self.m_operationTimeout = 0;
	self.m_currentCase = 0;
    self.caseFlag = 0;
end
		
OperationManager.userAFK = function (self,data)
	if SeatManager.getUserSeat(data.seatId):isSelf() then
		if not self.selfAFK then
			--self.m_scene.addChild(new (OperationTimeoutTip));
		end
		self.selfAFK = true;
	end
end
		
OperationManager.showQuickSitdownBtn = function (self,minBuyinChips,maxBuyinChips)  --示快速开始按钮
	self:hideAndRefreshAllControl();
	self.m_btnQuickSitdown:setEnableVisible(true);
    self.m_txtRoomInfo:setVisible(true);
	local userChips = Model.getData(ModelKeys.USER_DATA).money;
	local buyInChips = 0;
	if userChips >= minBuyinChips and minBuyinChips == maxBuyinChips then
		buyInChips = minBuyinChips;
	elseif userChips < minBuyinChips then --用户资产小于最小买入，买入失败
		buyInChips = 0;
	elseif (userChips < maxBuyinChips * 0.5) then --用户资产小于最大买入的1/2
		buyInChips = userChips;
	else
		buyInChips = maxBuyinChips * 0.5;
	end
			
	if buyInChips == 0 then
		self:showDisabledCase();
	else
		self.m_btnQuickSitdown:setBuyInChips(buyInChips);
	end
end
		
OperationManager.m_showHandCardTimeout = 0;

OperationManager.showShowHandCardBtn = function (self)
	self:hideAndRefreshAllControl();
	self.m_btnShowHandCard:setVisible(true);
    self.m_txtRoomInfo:setVisible(true);
	self.m_showHandCardTimeout = setTimeout(self.showDisabledCase, self, 3500);
end
		
OperationManager.showBuyInAgainBtn = function (self)
	self:hideAndRefreshAllControl();
	self.m_btnBuyInAgain:setVisible(true);
    self.m_txtRoomInfo:setVisible(true);
	self.m_btnBuyInAgain.setBuyInChips(self:__getBuyInChips(SeatManager.selfBuyInChips));
end

OperationManager.__getBuyInChips = function(self, chips)
    return StringKit.substitute(STR_ROOM_BUY_IN_CHIPS, STR_COMMON_CURRENCY_LABEL..Formatter.formatBigNumber(chips, true));
end

OperationManager.showRoomTip = function(self)
    self:hideAndRefreshAllControl();
    self.m_roomTip:setVisible(true);
end
		
OperationManager.applyCaseFlag = function (self)
    if self.caseFlag == 0 then
        self:showDisabledCase();
    elseif self.caseFlag == 1 then
		self:showEnabledCase1();
    elseif self.caseFlag == 2 then
        self:showEnabledCase2();
    elseif self.caseFlag == 3 then
        self:showEnabledCase3();
    elseif self.caseFlag == 4 then
        self:showEnabledCase4();
    elseif self.caseFlag == 5 then
        self:showEnabledCase5();
    end
end
		
OperationManager.applyAutoOperation = function (self)
	if self.m_currentCheckFlag ~= -1 then
		self.m_operationRequestData.operationType = 0;
		self.m_operationRequestData.betMoney = 0;
		if self.m_currentCheckFlag == self.AUTO_CHECK_SELECTED then
            if self.m_currentMaxBetInChips <= self.myBetInChips then
				SoundManager.playSound("Check");
				SoundManager.cancelAlertSound();
				self.m_operationRequestData.operationType = OperationRequestData.OP_TYPE_CHECK;
				self.m_operationRequestData.betMoney = 0;
				EventDispatcher.getInstance():dispatch(
                    CommandEvent.s_event, CommandEvent.s_cmd.PLAY_CARD_OPERATION,  self.m_operationRequestData);
				SeatManager:stopSeatTimer();
				self:showEnabledCase4();
				self:getSelfSeat():showStatu(STR_ROOM_OPERATION_TYPE[OperationResultData.SEAT_CHECK]);
			end
        elseif self.m_currentCheckFlag == self.AUTO_CHECK_OR_FOLD_SELECTED then
            if self.m_currentMaxBetInChips > self.myBetInChips then
				SoundManager.playSound("Fold");
				SoundManager.cancelAlertSound();	
				self.m_operationRequestData.operationType = OperationRequestData.OP_TYPE_FOLD;
				self.m_operationRequestData.betMoney = 0;
				EventDispatcher.getInstance():dispatch(
                    CommandEvent.s_event, CommandEvent.s_cmd.PLAY_CARD_OPERATION, self.m_operationRequestData);
                self.m_isSelfFold = true;			
                SeatManager:stopSeatTimer();
				self:showDisabledCase();
				self:getSelfSeat():getHandCard():fadeHandCard();
				self:getSelfSeat():fadeSeat();
				self:getSelfSeat():showStatu(STR_ROOM_OPERATION_TYPE[OperationResultData.SEAT_FOLD]);
			else
				SoundManager.playSound("Check");
				SoundManager.cancelAlertSound();	
				self.m_operationRequestData.operationType = OperationRequestData.OP_TYPE_CHECK;
				self.m_operationRequestData.betMoney = 0;
				EventDispatcher.getInstance():dispatch(
                    CommandEvent.s_event, CommandEvent.s_cmd.PLAY_CARD_OPERATION, self.m_operationRequestData);		
				SeatManager:stopSeatTimer();
				self:showEnabledCase4();
				self:getSelfSeat():showStatu(STR_ROOM_OPERATION_TYPE[OperationResultData.SEAT_CHECK]);
			end
        elseif self.m_currentCheckFlag == self.AUTO_CALL_ANY_SELECTED then
            self.m_operationRequestData.operationType = OperationRequestData.OP_TYPE_CALL;
			if self.m_callNeedChips < self:getSelfSeat():getSeatData().seatChips then
				self.m_operationRequestData.betMoney = self.m_callNeedChips;
			else
				self.m_operationRequestData.betMoney = self:getSelfSeat():getSeatData().seatChips;
			end
			if self.m_operationRequestData.betMoney then
				SoundManager.cancelAlertSound();
				EventDispatcher.getInstance():dispatch(
                    CommandEvent.s_event, CommandEvent.s_cmd.PLAY_CARD_OPERATION, self.m_operationRequestData);		
				SeatManager:stopSeatTimer();
				self:showEnabledCase4();
			end
        elseif self.m_currentCheckFlag == self.AUTO_CALL_SELECTED then
            if self.m_myCallNeedChips then
				SoundManager.cancelAlertSound();
				self.m_operationRequestData.operationType = OperationRequestData.OP_TYPE_CALL;
				self.m_operationRequestData.betMoney = self.m_myCallNeedChips;
				EventDispatcher.getInstance():dispatch(
                    CommandEvent.s_event, CommandEvent.s_cmd.PLAY_CARD_OPERATION, self.m_operationRequestData);		
				SeatManager:stopSeatTimer();
				self:showEnabledCase4();
			end        
        end	
		self.m_currentCheckFlag = self.AUTO_NOTHING;
	end
end
		
OperationManager.handleLoginSucc = function (self,data) --LoginSuccData
	self.m_raiseSlider.m_smallBlind = data.smallBlind;	
	self.m_callNeedChips = data.callNeedChips;
	self.m_raiseSlider:setMaxAndMinRaiseChips(data.minRaiseChips, data.maxRaiseChips);
end


OperationManager.setOperationTurnToData = function(self, callNeedChips, minRaiseChips, maxRaiseChips)
	self.m_callNeedChips = callNeedChips;
	self.m_raiseSlider:setMaxAndMinRaiseChips(minRaiseChips, maxRaiseChips);
	--加注额已经限定死的情况
	if self.m_raiseSlider.m_minRaiseChips == self.m_raiseSlider.m_maxRaiseChips then
		local label = "";
        if LocalService.currentLocaleId() == "th_TH" or LocalService.currentLocaleId() == "id_ID" then
            label = STR_ROOM_RAISE.." "..STR_COMMON_CURRENCY_LABEL..Formatter.formatBigNumber(self.m_raiseSlider.m_minRaiseChips);
		else
			label = STR_ROOM_RAISE .."\n"..STR_COMMON_CURRENCY_LABEL..Formatter.formatBigNumber(self.m_raiseSlider.minRaiseChips);
		end
        self.m_btnRaise:setLabel(label);
	else
		self.m_btnRaise:setLabel(STR_ROOM_RAISE);
	end
end
		
OperationManager.setCurrentMaxBetInChips = function(self, value)
    if value > self.m_currentMaxBetInChips then
        if self.m_currentCheckFlag == self.AUTO_CALL_SELECTED then
            self.m_btnAutoCall:setChecked(false);
            self.m_currentCheckFlag = self.AUTO_NOTHING;
        end
        self.m_currentMaxBetInChips = value;
        self.m_myCallNeedChips = self.m_currentMaxBetInChips - self.myBetInChips;
        if self.m_myCallNeedChips then
            if self.m_myCallNeedChips > self:getSelfSeat():getSeatData().seatChips then
                self.m_myCallNeedChips = self:getSelfSeat():getSeatData().seatChips;
            end
            self.m_btnCall:setLabel(
                StringKit.substitute(STR_ROOM_CALL, STR_COMMON_CURRENCY_LABEL..Formatter.formatBigNumber(self.m_myCallNeedChips)));
            self.m_btnAutoCall:setLabel(
                StringKit.substitute(STR_ROOM_AUTO_CALL, STR_COMMON_CURRENCY_LABEL..Formatter.formatBigNumber(self.m_myCallNeedChips)));
        end
    end
end
		
OperationManager.setCurrentMaxRaiseChips = function(self,value)
    if value > self.currentMaxRaiseChips then
        self.currentMaxRaiseChips = value;
    end
end
		
OperationManager.setRoomInfoLabel = function(self, tid, smallBlind) 
    self.m_txtRoomInfo:setText(
        StringKit.substitute(STR_ROOM_MULTILINE_ROOM_INFO, tid, 
        Formatter.formatBigNumber(smallBlind, true), 
        Formatter.formatBigNumber(smallBlind * 2, true)));
--    TaskExecutor.instance.callLater( function(self)-- :void
--        self.m_txtRoomInfo.y =(self.m_btnQuickSitdown.height - self.m_txtRoomInfo.height) * 0.5;
--    end , 2);
end
		
OperationManager.refresh = function(self)
    self.hasRaise = false;
    self.myBetInChips = 0;
    self.m_myCallNeedChips = 0;
    self.m_currentMaxBetInChips = 0;
    self.currentMaxRaiseChips = 0;
    self.m_isSelfFold = false;
end

OperationManager.cleanUp = function(self)
    self:showDisabledCase();
    clearTimeout(self.m_buyInAgainTimeout);
    Model.unwatchData(ModelKeys.ROOM_USER_STAND_UP_DATA, self.userStandUp);
    self.selfAFK = false;
end

OperationManager.getSelfSeat = function(self)
	return SeatManager:getSelfSeat();
end
		
OperationManager.getCurrentMaxBetInChips = function (self)
	return self.m_currentMaxBetInChips;
end
		
OperationManager.getCurrentCase = function(self)
	return self.m_currentCase;
end

OperationManager.getButtonContainer = function(self)
	return self.m_buttonContainer;
end

OperationManager.getCurrentCheckFlag = function(self)
	return self.m_currentCheckFlag;
end

OperationManager.isSelfFold =  function(self)
	return self.m_isSelfFold;
end


OperationManager.hasRaiseHandle = function(self, isSelf)
    if isSelf then
        self.hasRaise = false;
    else
        self.hasRaise = true;
    end
end

--[Comment]
--显示操作区按钮
OperationManager.showButtonContainer = function(self, value)
    self.m_buttonContainer:setVisible(value);
end

--[Comment]
--立即坐下
OperationManager.playNowSitDown = function(self)
    SeatManager:playNowSitDown();
end