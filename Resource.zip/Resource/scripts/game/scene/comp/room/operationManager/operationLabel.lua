--[Comment]
--操作区标签
OperationLabel = class();

OperationLabel.ctor = function(self, txt1, txt2)
    self.m_txt1 = txt1;
    self.m_txt2 = txt2;
end

OperationLabel.dtor = function(self)
end

OperationLabel.setVisible = function(self, value)
    if self.m_txt1 ~= nil then
        self.m_txt1:setVisible(value);
    end

    if self.m_txt2 ~= nil then
        self.m_txt2:setVisible(value);
    end
end

OperationLabel.getVisible = function(self, value)
    local ret = false;
    if self.m_txt1 ~= nil then
        ret = self.m_txt1:getVisible();
    end

    if self.m_txt2 ~= nil then
        ret = self.m_txt2:getVisible();
    end

    return ret;
end

OperationLabel.setText = function(self, txt)
    if txt ~= nil then
        local arr = StringKit.split(txt, "\r");
        self:setTextHandle(arr[1] or "", arr[2] or "");
    else
        self:setTextHandle("", "");
    end
end

OperationLabel.setTextHandle = function(self, txt1, txt2)
    if self.m_txt1 ~= nil then
        self.m_txt1:setText(txt1);
    end

    if self.m_txt2 ~= nil then
        self.m_txt2:setText(txt2);
    end
end