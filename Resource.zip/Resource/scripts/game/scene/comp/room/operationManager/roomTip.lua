--[Comment]
--房间提示语
RoomTip = class(Node);
	
RoomTip.m_roomTipLabel  = nil;
RoomTip.m_startIndex    = 1;
RoomTip.m_tipsArray     = {};
RoomTip.m_interval      = 0;
		
RoomTip.ctor = function(self,spriteWidth)
	local arr = STR_COMMON_TIPS_TEXT_ARR;
	self.m_tipsArray = {};
	self.m_startIndex = math.random(#arr);
	for i = 1,#arr do
		self.m_tipsArray[i] = arr[i];
	end
			
	local background = new (Image,"room/room_operation_tip_bg.png", nil, nil, 8, 8, 36, 8);
	background:setSize(spriteWidth, 64);
    self:addChild(background);
	
	local textParam = new(TextParam);
    textParam.rgb = 0x336699;
    textParam.fontSize = 24;
    textParam.fontName = TextFormatKit.fontNames;
	textParam.width = spriteWidth;
    textParam.height = 64;

	self.m_roomTipLabel = UIFactory.createTextByParam(textParam);
	--self:addChild(self.m_roomTipLabel);
end
		
RoomTip.setVisible = function (self,value)--:Boolean
	Node.setVisible(self, value);
    if value then
		self.m_roomTipLabel.text = self.m_tipsArray[self.m_startIndex];
		self.m_interval = setInterval(self.intervalCallBack,self, 15 * 1000);
	else
		clearInterval(self.m_interval);
	end
end
		
RoomTip.intervalCallBack = function(self)
    local tmp = self.m_startIndex + 1;
	if tmp > #self.m_tipsArray then
		self.m_startIndex = 1;
	end
	self.m_roomTipLabel.text = self.m_tipsArray[self.m_startIndex];
end