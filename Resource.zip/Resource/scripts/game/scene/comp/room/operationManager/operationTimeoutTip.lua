OperationTimeoutTip = class() --extends FeathersControl

OperationTimeoutTip.m_tipBackground = nil;--:Scale9Image
OperationTimeoutTip.m_statusLabel = nil;--:Label
OperationTimeoutTip.m_interval = nil;--:uint
OperationTimeoutTip.m_second = 300;--:int --踢离座位秒数

OperationTimeoutTip.ctor = function (self)
    super();
end
		
OperationTimeoutTip.onTouch = function (self,evt)--:TouchEvent
	local touch= evt.touches[0];--:Touch 
	if touch and touch.phase == TouchPhase.BEGAN then
		evt.target.removeEventListener(TouchEvent.TOUCH, onTouch);
		FrameworkGlobal.context.dispatchEventWith(CommandEventNames.ROOM_REQUEST_BACK_SEAT);
		clearInterval(_interval);
		this.removeFromParent(true);
		OperationManager.selfAFK = false;
	end
end
		
OperationTimeout.drawTip = function (self)
	self.m_statusLabel.validate();
	self.m_statusLabel.x = (RuntimeInfo.instance.stageWidth - self.m_statusLabel.width) * 0.5;
	self.m_statusLabel.y = (RuntimeInfo.instance.stageHeight - self.m_statusLabel.height) * 0.5;
			
	self.m_tipBackground.width = self.m_statusLabel.width + 32;
	self.m_tipBackground.height = self.m_statusLabel.height + 16;
	self.m_tipBackground.x = (RuntimeInfo.instance.stageWidth - _tipBackground.width) * 0.5;
	self.m_tipBackground.y = (RuntimeInfo.instance.stageHeight - _tipBackground.height) * 0.5;
end
		
OperationTimeout.initialize = function (self)
	local quad = new (Quad,RuntimeInfo.instance.stageWidth, RuntimeInfo.instance.stageHeight, 0x1a1a1a);--:Quad
	quad.alpha = 0.85;
	quad.addEventListener(TouchEvent.TOUCH, onTouch);
			
	this.addChild(quad);
			
	self.m_tipBackground = new (Scale9Image,new (Scale9Textures,AssetManager.instance.getTextureAtlas("main-texture").getTexture("room-label-loading-background"), new (Rectangle,8, 8, 24, 20)));
	this.addChild(_tipBackground);
			
	self.m_statusLabel = new Label();
	self.m_statusLabel.textRendererProperties.textFormat = TextFormatManager.instance.smallLightTextFormat;
	self.m_statusLabel.text = Localization.getText("ROOM.OPERATION_TIMEOUT_TEXT", Formatter.secondTo0M0S(_second));
	this.addChild(_statusLabel);
			
	self.m_interval = setInterval(intervalHandler, 1000);
end
		
OperationTimeout.intervalHandler = function (self)
	if self.m_second > 0 then
		--self.m_statusLabel.text = Localization.getText("ROOM.OPERATION_TIMEOUT_TEXT", Formatter.secondTo0M0S(--_second));--[lucy]
		self.invalidate();
	end
end

