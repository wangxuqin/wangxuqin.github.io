require("ui/node");
LargeWinAnimation =class(Node,false)

LargeWinAnimation.ctor = function(self)
    super(self);
    self.m_imgWinLabel = new(Image,"room/win/large-win-label.png");
    local w,h =self.m_imgWinLabel:getSize();
    self.m_imgWinLabel:setVisible(false);
    self:addChild(self.m_imgWinLabel);
    self:setSize(w,h);
    self:playAnim();
end

LargeWinAnimation.dtor = function(self)

end

LargeWinAnimation.playAnim = function(self)
    self.anim = new(AnimInt,kAnimNormal,0,0,500,-1);
    self.anim:setEvent(self,function(self,animType,animID,repeat_num)
        local down = new(AnimInt,kAnimRepeat,0,0,350,0);
        down:setEvent(self,function(self,animType1,animID1,num)
            if(num % 2 == 0) then                
                self.m_imgWinLabel:addAtomPropTranslateEase(1,kAnimNormal,ResDoubleArrayQuintInOut, 200, 100,0,0,0,108,0,10); 
                self.m_imgWinLabel:setVisible(true);  
            end
            if(num == 2) then
                delete(up);
                delete(self.m_imgWinLabel);
            end
        end);
    end);
    self.anim:setDebugName(self.anim);
end