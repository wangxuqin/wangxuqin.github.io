require("ui/node");
SmallWinAnimation =class(Node,false)

SmallWinAnimation.ctor = function(self)
    super(self);
    self:setSize(131,188);

    self.m_imgWinSeatFrame = new(Image,"room/win/small-win-seat-frame.png");
    self.m_imgWinSeatFrame:setVisible(false);
    self:addChild(self.m_imgWinSeatFrame);

    self.m_imgWinLabel = new(Image,"room/win/small-win-label.png");
    local w,h =self.m_imgWinLabel:getSize();
    self.m_imgWinLabel:setAlign(kAlignTop);
    self.m_imgWinLabel:setPos(0,-h);
    self.m_imgWinLabel:setVisible(false);
    self:addChild(self.m_imgWinLabel);

    self:playAnim();

end

SmallWinAnimation.playAnim = function(self)
    self.anim = new(AnimInt,kAnimNormal,0,0,500,-1);
    self.anim:setEvent(self,function(self,animType,animID,repeat_num)
         self.m_imgWinSeatFrame:setVisible(true);
        local up = new(AnimInt,kAnimRepeat,0,0,500,0);
        up:setEvent(self,function(self,animType1,animID1,num)
            if(num % 2 == 0) then                
                self.m_imgWinLabel:addAtomPropTranslateEase(1,kAnimNormal,ResDoubleArrayQuintInOut, 200, 200,0,0,50,0,0,10); 
                self.m_imgWinLabel:setVisible(true);  
            end
            if(num == 2) then
                delete(up);
                delete(self.m_imgWinLabel);
                local delAnim = new(AnimInt,kAnimNormal,0,0,500,-1);
                delAnim:setEvent(self,function()
                    delete(self.m_imgWinSeatFrame);
                end);
                
            end
        end);
    end);
    self.anim:setDebugName(self.anim);
end

SmallWinAnimation.dtor = function(self)

end
