-----------------------------------------------------------------

CardTypeTip = class(Node);

CardTypeTip.ctor = function(self)
	self.m_backGround = nil;--:Scale3Image;
    self.m_typeLabel = nil;--:Label;
    self:initialize();
end

CardTypeTip.initialize = function(self)
	self.m_backGround = new(Image, "room/room-table-card-type-background.png", nil, nil, 8, 8, 8, 9);
    local cx = 108;
	self.m_backGround:setSize(cx);
	self.m_backGround:setPos(-cx * 0.5);
    local w,h = self.m_backGround:getSize();
    self:setSize(w, h);
    self:setAlign(kAlignTopLeft);

	self:addChild(self.m_backGround);

	self.m_typeLabel = new(Text, "0", nil, nil, nil, nil, 20, 0xf5, 0xf5, 0xf5);
    self.m_typeLabel:setPos(0, 0);
    self.m_typeLabel:setAlign(kAlignCenter);
	self.m_backGround:addChild(self.m_typeLabel);

    self:setPickable(false);
end

CardTypeTip.setCardType = function(self, stype)
	self.m_typeLabel:setText(stype);
end
