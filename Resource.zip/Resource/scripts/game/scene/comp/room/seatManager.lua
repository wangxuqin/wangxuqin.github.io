------------------------------------------------------------
require("ui/point");
require("atomAnim/drawingEx");
require("game/scene/comp/room/userInfo/sendChipSprite");
require("game/scene/comp/room/win/smallWinAnimation");
require("game/scene/comp/room/win/largeWinAnimation");
require("game/scene/comp/room/seatTimer");
require("game/scene/comp/room/showHandCard/showHandCardAnimationData");
require("game/scene/comp/room/cardTypeTip");

SeatManager = class();

SeatManager.TAG = "SeatManager";

SeatManager.TURN_SEAT_DURATION = 0.75;
SeatManager.HDDJ_SOUND = { 
    PourWater,      Hammer,         Tomato,         Toast, 
    Bomb,           Kiss,           Flower,         Dog, 
    FireCracker,    WineBottle,     FunnyBrush,     Pai,    SprayWater };

SeatManager.m_stageWidth = 0;
SeatManager.m_stageHeight = 0;

SeatManager.m_scene = nil;
SeatManager.m_container = nil;
SeatManager.m_buyInPopUp = nil;
SeatManager.m_userSeatV = nil;
SeatManager.m_currentUserSeatV = nil;
SeatManager.m_sitDownSeatV = nil;
SeatManager.m_tableDealer = nil;
SeatManager.m_cardTypeTip = nil;
SeatManager.m_selfSeatArrow = nil;

SeatManager.m_seatPositionV = nil;--9个座位位置的坐标
SeatManager.m_chipPositionV = nil;--9个加注筹码位置和奖池筹码的坐标
SeatManager.m_potPositionV = nil;--8奖池筹码的坐标
SeatManager.m_dealCardPositionV = nil;--:Vector.<Point>;--发牌位置
SeatManager.m_showHandCardAnimationDataV = nil;--:Vector.<ShowHandCardAnimationData>;

SeatManager.selfInRound = false;--是否在本轮游戏
SeatManager.selfInGame = false;--是否正在游戏（区别UserSeat的inGame属性，这个变量的有效期是游戏开始至游戏刷新，弃牌置为false）
SeatManager.selfInSeat = false;--是否坐在座位上（筹码不够时自动买入，会发出坐下包）
SeatManager.selfSeatId = -1;
SeatManager.selfBuyInChips = 0;--自己买入筹码数量
SeatManager.countdown = 20;--倒计时时间
SeatManager.roomType = LoginSuccData.ROOM_TYPE_NORMAL;--房间类型

SeatManager.m_requestLoginData = nil;
SeatManager.m_loginSuccData = nil;

SeatManager.m_dealerSeatId = 0;
SeatManager.m_currentOperationSeatId = -1;
SeatManager.m_maxSeatCount = 0;--房间最大座位数

SeatManager.m_timeout1 = 0;
SeatManager.m_timeout2 = 0;
SeatManager.m_timeout3 = 0;

SeatManager.m_requestBuyIn = nil;
SeatManager.m_atlas = nil;
SeatManager.m_arrowVelocity = 1;
SeatManager.m_arrowMoveTimes = 0;

SeatManager.m_touchBeginX = 0;
SeatManager.m_isShowAnimation = true;--是否有转动动画
SeatManager.m_inviteFriendSeatID = -1;
SeatManager.m_isHasEmptySeat = false;
SeatManager.m_timeoutNum = 0;
SeatManager.m_userSendChipArray = nil;
SeatManager.m_PHRASE_DATA = nil;

SeatManager.deg2rad = function(deg)
    return deg * math.pi / 180.0;
end

SeatManager.initialize = function(self, scene, childrenIndex)
	self.m_stageWidth = System.getScreenScaleWidth();
	self.m_stageHeight = System.getScreenScaleHeight();
	self.m_atlas =
    {
        getTexture = function(name)
                        return name .. ".png";
                     end
    };

	self.m_scene = scene;
	self.m_container = self.m_scene:getNodeByName("bg.seat_container");
    self.m_container:setVisible(true);

    self.m_centerPoint          = self.m_scene:getNodeByName("bg.seat_container.center_point");
    self.m_seatPositionV        = self:__getPos("seat", 9);
    self.m_chipPositionV        = self:__getPos("chip", 9);
    self.m_potPositionV         = self:__getPos("pot", 9);
	self.m_dealCardPositionV    = self:__getPos("d", 10);
	self.m_sendPositionV        = self:__getPos("send", 10);

	self.m_showHandCardAnimationDataV = {};
	self.m_showHandCardAnimationDataV[1] = new(ShowHandCardAnimationData, SeatManager.deg2rad(180, UserSeat.SEAT_WIDTH * 0.5, 204));
	self.m_showHandCardAnimationDataV[2] = new(ShowHandCardAnimationData, SeatManager.deg2rad(-125, -64, 164));
	self.m_showHandCardAnimationDataV[3] = new(ShowHandCardAnimationData, SeatManager.deg2rad(-60, -64, 24));
	self.m_showHandCardAnimationDataV[4] = new(ShowHandCardAnimationData, SeatManager.deg2rad(0, 32, -36));
	self.m_showHandCardAnimationDataV[5] = new(ShowHandCardAnimationData, SeatManager.deg2rad(0, UserSeat.SEAT_WIDTH / 2, -36));
	self.m_showHandCardAnimationDataV[6] = new(ShowHandCardAnimationData, SeatManager.deg2rad(0, 76, -36));
	self.m_showHandCardAnimationDataV[7] = new(ShowHandCardAnimationData, SeatManager.deg2rad(60, 172, 24));
	self.m_showHandCardAnimationDataV[8] = new(ShowHandCardAnimationData, SeatManager.deg2rad(125, 172, 164));
	self.m_showHandCardAnimationDataV[9] = new(ShowHandCardAnimationData, SeatManager.deg2rad(180, UserSeat.SEAT_WIDTH / 2, 204));

	self.m_userSeatV = {};
    for i=1,9 do
		self.m_userSeatV[i] = new(UserSeat, i);
		self.m_userSeatV[i]:setPos(self.m_seatPositionV[i].x, self.m_seatPositionV[i].y);
		self.m_userSeatV[i]:setVisible(false);
		self.m_userSeatV[i]:setSitdownCallback(self, self.__userSeatTouchHandler);
		self.m_container:addChild(self.m_userSeatV[i]);
	end

	--dealer
	self.m_tableDealer = new(Image, self.m_atlas.getTexture("room/room-table-dealer"));
	self.m_container:addChild(self.m_tableDealer);
	self.m_tableDealer:setVisible(false);

	--买入框
	self.m_buyInPopUp = {};
	self.m_requestBuyIn = new(RequestBuyInData);

	self.m_userSendChipArray = {};
    for i=1,9 do
		self.m_userSendChipArray[i] = 0;
	end

end

SeatManager.__getPos = function(self, item, count)
    local container = self.m_container:getNodeByName(item.."_pos_container");
    local ret = {};
    local node = nil;
    local centerX, centerY = self.m_centerPoint:getPos();
    local sCenterX, sCenterY = System.getScreenScaleWidth() / 2, System.getScreenScaleHeight() / 2;
    local offsetX, offsetY = (centerX - sCenterX), (sCenterY - centerY);
    for i = 1, count do
        node = container:getNodeByName(item.."_pos_"..i);
        local x, y = node:getPos();
        x = x + offsetX;
        y = y + offsetY;
        table.insert(ret, new(Point, x, y));
    end
    container:getParent():removeChild(container, true);
    return ret;
end

SeatManager.newerTipHandler = function(self, data)
	if data ~= nil and data.screenName == ScreenNames.GAME_ROOM and data.id == "userInfo" then
		local seatId = getNotEmptySeatId();
		if seatId >= 0 then
			local bounds = new(Rect, 
                self.m_seatPositionV[self.m_userSeatV[seatId].positionId].x, 
                self.m_seatPositionV[self.m_userSeatV[seatId].positionId].y, 
                UserSeat.SEAT_WIDTH, 
                UserSeat.SEAT_HEIGHT);
			--NewerTipManager.instance.registerNewerTip(ScreenNames.GAME_ROOM, "userInfo", NewerTipDirection.VERTICAL, null, bounds);
		end
	end
end
		
SeatManager.selfUseGift = function(self, evt, data)--private static
--m	local giftId:int = int(data);
--m	if (SeatManager.selfInSeat)
--m	{
--m		getSelfSeat().addGift(giftId);
--m	}
end

--[Comment]
--用户坐下处理
SeatManager.__userSeatTouchHandler = function(self, userSeat)
    local userData = Model.getData(ModelKeys.USER_DATA);
    if userSeat:isShowInviteFriends() then  --如果当前为显示好友按钮
		local friendList = Model.getData(ModelKeys.FRIEND_LIST_NEW);
		--显示邀请好友对话框
		if friendList ~= nil and #friendList > 0 then
			--派发显示邀请好友窗口时间
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_INVITE_FRIENDS_DIALOG, friendList);
		else
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, {["message"]= STR_FRIEND_NO_FRIEND});
		end
	else
	    if userSeat:getSeatData().uid == nil or userSeat:getSeatData().uid == -1 then --座位为空
            if TableLimit.checkPreSitdown(self.m_loginSuccData.tableLevel) then
				if userData.money >= self.m_loginSuccData.minBuyIn then
					EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_ROOM_BUYIN_DIALOG, {
                        ["minBuyIn"] = self.m_loginSuccData.minBuyIn,
                        ["maxBuyIn"] = self.m_loginSuccData.maxBuyIn,
                        ["money"]    = userData.money,
                        ["seatId"]   = userSeat:getSeatId()
                    });
				elseif userData.money < userData.smallBlid * 20 and userData.bank_money > 0 then--用户筹码不足
					EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {
						["message"] = STR_ROOM_USEER_GAME_IN_CURRENT_CHIP_SHORTSTAGE, 
						["confirm"] = STR_ROOM_CHIP_SHORTSTAGE_GO_BANK, 
						["cancel"]  = STR_HALL_GO_TO_STORE,
                        ["obj"]     = self, 
                        ["callback"]= self.__sitdownGoBankTip,
					});
				elseif userData.money < userData.smallBlid * 20 and userData.bank_money == 0 then
					EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {
						["message"] = STR_ROOM_NOT_ENOUGH_CHIPS, 
						["confirm"] = STR_ROOM_BUY_CHIPS, 
						["obj"]     = self,
                        ["callback"]= self._sitdownGoStoreTip,
					});
				elseif userData.money > userData["smallBlid"] * 20 then
					--弹框提示用户资产不足，购买筹码或者换桌
					EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {
						["message"] = STR_ROOM_NOT_ENOUGH_MONEY, 
						["confirm"] = STR_ROOM_BUY_CHIPS, 
						["cancel"]  = STR_ROOM_SWITCH_TABLE, 
						["obj"]     = self,
                        ["callback"]= self.confirmHandler,
						["cancelSP"]= true
					});
				end
			end		
		else
			if userData ~=  nil and userSeat:getSeatData().uid == userData.uid then
				--AnalysisUtil.onEvent(AnalysisEventIds.ROOM_MY_HEAD);
			else
				--AnalysisUtil.onEvent(AnalysisEventIds.ROOM_OTHER_HEAD);
			end
			
            --NewerTipManager.instance.finishNewerTip(ScreenNames.GAME_ROOM, "userInfo");
			--新手引导不能显示信息
            if not TutotiaKit.isTutotia() then
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_ROOM_USERINFO, userSeat:getSeatData());
			end
       end
    end
end

--[Comment]
--坐下身上钱不够，但是银行有存款，提示可以去银行取钱
SeatManager.__sitdownGoBankTip = function(self, types)
	if types == DialogCallback.CONFIRM then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_BANK_POPUP);
	elseif types==DialogCallback.CANCEL then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_CHIPS_PAGE);
	end
end

--[Comment]
--坐下身上钱不够，并且银行也没有存款，提示可以去商城购买Chips
SeatManager.__sitdownGoStoreTip = function(self, types)
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_CHIPS_PAGE);
end

--[Comment]
--设置设置庄家位置 （1~9）
SeatManager.setDealerPosition = function(self, dealerSeatId, duration)
    duration = duration or (SeatManager.TURN_SEAT_DURATION * 1000);

	self.m_dealerSeatId = dealerSeatId;
	local positionId = self:getUserSeat(self.m_dealerSeatId).m_positionId;
	local destX = 0;
	local destY = 0;
	if (positionId == 3 or positionId == 4 or positionId == 5 or positionId == 6 or positionId == 7) then
		destX = self.m_dealCardPositionV[positionId].x;
		destY = self.m_dealCardPositionV[positionId].y + 36;
	elseif (positionId == 2) then
		destX = self.m_seatPositionV[positionId].x;
		destY = self.m_seatPositionV[positionId].y + UserSeat.SEAT_HEIGHT + 8;
	elseif (positionId == 8) then
		destX = self.m_seatPositionV[positionId].x + UserSeat.SEAT_WIDTH - As3Kit.getNodeWidth(self.m_tableDealer);
		destY = self.m_seatPositionV[positionId].y + UserSeat.SEAT_HEIGHT + 8;
	elseif (positionId == 1) then
		destX = self.m_seatPositionV[positionId].x + UserSeat.SEAT_WIDTH + 8;
		destY = self.m_seatPositionV[positionId].y + UserSeat.SEAT_HEIGHT - As3Kit.getNodeHeight(self.m_tableDealer);
	else
		destX = self.m_seatPositionV[positionId].x - As3Kit.getNodeWidth(self.m_tableDealer) - 8;
		destY = self.m_seatPositionV[positionId].y + UserSeat.SEAT_HEIGHT - As3Kit.getNodeHeight(self.m_tableDealer);
	end

	if (duration ~= 0) then
        local x,y = self.m_tableDealer:getPos();
        local anim = self.m_tableDealer:addPropTranslate(0, kAnimNormal, duration, 0, 0,destX-x, 0,destY-y);
        local function onMoveDealerEnd(self)
            self.m_tableDealer:removeProp(0);
            self.m_tableDealer:setPos(destX, destY);
        end
        anim:setEvent(self, onMoveDealerEnd);
	else
		self.m_tableDealer:setPos(destX, destY);
    end
end

SeatManager.handleLoginSucc = function(self, data)
    local userData = Model.getData(ModelKeys.USER_DATA);
    Log.d(SeatManager.TAG, "uid=" .. userData.uid);
	self.m_loginSuccData = data;
	SeatManager.roomType = self.m_loginSuccData.roomType;
	SeatManager.countdown = self.m_loginSuccData.betInExpire;
	SeatTimer.setCountdown(SeatTimer, self.m_loginSuccData.betInExpire);
	self.m_maxSeatCount = self.m_loginSuccData.maxSeatCount;
	if(Model.getData(ModelKeys.USER_IN_TUTOTIA) == nil) then
		self.m_tableDealer:setVisible(true);
	elseif(not Model.getData(ModelKeys.USER_IN_TUTOTIA).isShowDealer) then
		self.m_tableDealer:setVisible(false);
	else
		self.m_tableDealer:setVisible(true);
    end

	self.m_sitDownSeatV = {};
	Model.setData(ModelKeys.ROOM_SIT_DOWN_USERS, self.m_sitDownSeatV);
	Model.setData(ModelKeys.USER_SELF_SEAT_ID, -1);
	--设置dealer位置
	self:setDealerPosition(self.m_loginSuccData.dealerSeatId, 0);

	--根据相应场次展示座位
	self:showUserSeat();
			
	--玩家列表不为空
	if self.m_loginSuccData.playerList ~= nil then
		local playerNum = #self.m_loginSuccData.playerList;--在座人数
		local tableUserData = nil;--:TableUserData;
		local userSeat = nil;--:UserSeat;
        for i=1,playerNum do
			tableUserData = self.m_loginSuccData.playerList[i];
			userSeat = self.m_userSeatV[tableUserData.seatId];
			userSeat:setSeatData(tableUserData);
			userSeat:fadeSeat();
			userSeat:sitDownAnimation(0);
			userSeat:setStanded(false);
					
			--需要考虑只有一个玩家在座但游戏尚未结束的情况
			if (self.m_loginSuccData.playerCount == 1) then
				userSeat.m_seatData.operationStatus = TableUserData.SEAT_WAIT;
            end
			if (tableUserData.operationStatus > 1) then
				userSeat:showStatu(STR_ROOM_OPERATION_TYPE[tableUserData.operationStatus + 1]);
			end

			--判断是否在玩
			if (self.m_loginSuccData.playerCount > 1 and tableUserData.operationStatus ~= TableUserData.SEAT_WAIT and tableUserData.operationStatus ~= TableUserData.SEAT_FLOD) then
				userSeat.m_inGame = true;
				userSeat:cancelFadeSeat();
				if (userSeat:isSelf()) then
					SeatManager.selfInRound = true;
					SeatManager.selfInGame = true;
                end
			end

			if (userSeat:isSelf()) then
				SeatManager.selfSeatId = tableUserData.seatId;
				SeatManager.selfInSeat = true;
				self:turnToFrontView();
				Model.setData(ModelKeys.USER_SELF_SEAT_ID, SeatManager.selfSeatId);
				--非比赛场显示站起按钮
				if (self.m_loginSuccData.roomType == LoginSuccData.ROOM_TYPE_KNOCKOUT or 
					self.m_loginSuccData.roomType == LoginSuccData.ROOM_TYPE_TOURNAMENT) then
					self.m_scene:setStandUpButton(false);
				else
					self.m_scene:setStandUpButton(true);
                end
			end
					
            self.m_sitDownSeatV[#self.m_sitDownSeatV + 1] = userSeat;
		end
	end
	--显示当前操作玩家的计时器和姓名
	if (self.m_loginSuccData.betInSeatId ~= -1) then
		self:startSeatTimer(self.m_loginSuccData.betInSeatId);
        TableAnimationManager:showTableLight(self.m_loginSuccData.betInSeatId, 0);
		self.m_userSeatV[self.m_loginSuccData.betInSeatId]:showName();
	end
	--如果自己在座位，影藏坐下按钮
	if (SeatManager.selfInSeat) then
		self:hideAllSitDownButton();
    end
			
	self.m_buyInPopUp.minBuyInChips = self.m_loginSuccData.minBuyIn;
	self.m_buyInPopUp.maxBuyInChips = self.m_loginSuccData.maxBuyIn;
end

SeatManager.turnToFrontView = function(self)--private static
--			if(RoomSocketDataProvider.inReconnecting)
--			{
--				self.m_isShowAnimation = false;
--			}
--			else
--			{
--				self.m_isShowAnimation = true;
--			}
	local userSeat = self:getSelfSeat();
	--设置自己的手牌位置
	userSeat.m_handCard:setPos(148, 96);
	userSeat.m_handCard:setHandCardShowingPosition(0, 0);--??

	local tweenRange = 5 - userSeat.m_positionId;--移动范围
	local selfPositionId = userSeat.m_positionId;--原始位置ID
	local tempSelfSeatId = SeatManager.selfSeatId;
	local tempPositionId = 0;

	--计算轨迹位置id
	local trackArr = {{}, {}, {}, {}, {}, {}, {}, {}, {}};--存放9个座位的轨迹坐标位置
	local i = 0;
	local j = 0;
	if (selfPositionId >= 6 and selfPositionId <= 9) then
        for j=1,9 do
			tempPositionId = selfPositionId + j - 1;
			if (tempPositionId >= 10) then
                tempPositionId = tempPositionId - 9;
            end

            for i=1,selfPositionId-5 do
                tempPositionId = tempPositionId - 1;
				if (tempPositionId < 1) then
                    tempPositionId = 9;
                end
				trackArr[tempSelfSeatId][i] = tempPositionId;
			end
            tempSelfSeatId = tempSelfSeatId + 1;
			if (tempSelfSeatId >= 10) then
                tempSelfSeatId = 1;
            end
		end
	elseif (selfPositionId >= 1 and selfPositionId <= 4) then
        for j=1,9 do
			tempPositionId = selfPositionId - j + 1;
			if (tempPositionId < 1) then
                tempPositionId = tempPositionId + 9;
            end

            for i=9,selfPositionId+5,-1 do
                tempPositionId = tempPositionId + 1;
				if (tempPositionId >= 10) then
                    tempPositionId = 1;
                end
				trackArr[tempSelfSeatId][9-i+1] = tempPositionId;
			end

            tempSelfSeatId = tempSelfSeatId - 1;
			if (tempSelfSeatId < 1) then
                tempSelfSeatId = 9;
            end
		end
	end
	if (selfPositionId ~= 5) then--大范围移动，先影藏筹码加注区
		ChipManager:hideAllBet();
	end
    for i=1,9 do
        local positionId = self.m_userSeatV[i].m_positionId + tweenRange;
		if (positionId < 1) then
			positionId = positionId + 9;
		elseif (positionId > 9) then
			positionId = positionId - 9;
        end
        self.m_userSeatV[i]:setPositionId(positionId);
		--大范围移动，影藏发牌精灵，影藏已亮出手牌的手牌
		if (selfPositionId ~= 5) then
			DealCardManager:hideDealCard(self.m_userSeatV[i].m_positionId);
			if (self.m_userSeatV[i].m_showedHandCard) then
				self.m_userSeatV[i].m_handCard:setVisible(false);
			end
		end
		--转动效果
		self:turnSeatAnimation(self.m_userSeatV[i], trackArr[i]);
	end
	if(self.m_isShowAnimation) then
		self:setDealerPosition(self.m_dealerSeatId);
	else
		self:setDealerPosition(self.m_dealerSeatId,0);
	end
	if (self.m_currentOperationSeatId ~= -1) then
		TableAnimationManager:showTableLight(self.m_currentOperationSeatId, SeatManager.TURN_SEAT_DURATION);
	end
end

SeatManager.turnSeatAnimation = function(self, userSeat, track)--private static
	local arrLenght = #track;
	local bezierArr = {};
	local positionId = 0;
    local x,y = userSeat:getPos();
    bezierArr[1] = {x=x,y=y};
    for i=1,arrLenght do
		positionId = track[i];
		bezierArr[i+1] = {x=self.m_seatPositionV[positionId].x, y=self.m_seatPositionV[positionId].y};--轨迹坐标数组
	end
	if (arrLenght == 0 and userSeat.m_positionId == 5) then
		self:turnCompleteHandler(userSeat);
	else
		if self.m_isShowAnimation == true then
            local function onEnd(data)
                data.my:turnCompleteHandler(data.seat);
            end
            AnimKit.doBezier(userSeat, bezierArr, SeatManager.TURN_SEAT_DURATION*1000, {seat=userSeat,my=self}, onEnd, 50);
			--转动筹码
			ChipManager:moveBetZoneSprite(track, SeatManager.TURN_SEAT_DURATION, userSeat);
		else
			--转动座位
			userSeat:setPos(self.m_seatPositionV[userSeat.m_positionId].x, self.m_seatPositionV[userSeat.m_positionId].y);
			self:turnCompleteHandler(userSeat);
			--转动筹码
			ChipManager:moveBetZoneSpriteNotAnimation(userSeat.m_positionId, userSeat);
		end
	end
end

SeatManager.turnCompleteHandler = function(self, userSeat)--private static
	if (userSeat.m_inGame and not userSeat:isSelf()) then
		DealCardManager:showDealCard(userSeat.m_positionId);
    end
	if (userSeat.m_seatData.betInChips > 0) then
		ChipManager:modifyBet(userSeat.m_positionId, userSeat.m_seatData.betInChips);
	end
	--坐下动画
	if (self.m_isShowAnimation and userSeat:isSelf() and (Model.getData(ModelKeys.USER_IN_TUTOTIA) == nil or not Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart)) then
		if (not self.m_selfSeatArrow) then
			self.m_selfSeatArrow = new(Image, "room/room-self-seat-arrow.png");
            self.m_selfSeatArrow:setPos(self.m_seatPositionV[5].x + (UserSeat.SEAT_WIDTH - As3Kit.getNodeWidth(self.m_selfSeatArrow)) * 0.5);
		end
		self.m_selfSeatArrow:setPos(nil, self.m_seatPositionV[5].y - As3Kit.getNodeHeight(self.m_selfSeatArrow));
        TableAnimationManager:addChild(self.m_selfSeatArrow);
        self.m_selfSeatArrow:setVisible(true);
		self.m_arrowMoveTimes = 0;
        self.m_timerArrow = setInterval(self.arrowAnimation, self, 18);
	end
end



--
--坐下动画
--
SeatManager.arrowAnimation = function(self)--private static
    local _,y = self.m_selfSeatArrow:getPos();
    local _,h = self.m_selfSeatArrow:getSize();
	if (y > self.m_seatPositionV[5].y - h) then
		self.m_arrowVelocity = -1;
		self.m_arrowMoveTimes = self.m_arrowMoveTimes + 1;
	elseif (y < self.m_seatPositionV[5].y - h - 20) then
		self.m_arrowVelocity = 1;
	end
	self.m_selfSeatArrow:setPos(nil, y + self.m_arrowVelocity);

	if self.m_arrowMoveTimes == 4 then
        self.m_selfSeatArrow:setVisible(false);
        clearInterval(self.m_timerArrow);
	end
end

--[Comment]
--清除黄色箭头动画
SeatManager.clearArrowAnim = function(self)
    if self.m_timerArrow ~= nil and self.m_timerArrow > 0 then
        clearInterval(self.m_timerArrow);
        self.m_selfSeatArrow:setVisible(false);
    end
end

--
--去商城或换桌 
-- @param type
--
SeatManager.confirmHandler = function(self, stype)--private static
--m	if (!Model.getData(ModelKeys.USER_IN_ROOM))
--m	{
--m		return;
--m	}
--m	if (stype == DialogCallback.CONFIRM)
--m	{
--m		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_CHIPS_PAGE);
--m	}
--m	elseif (stype == DialogCallback.CANCEL)
--m	{
--m		self.m_scene.switchRoom(enterRoom);
--m	}
end

SeatManager.enterRoom = function(self)--private static
--m	EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.PREPARE_LOGIN_ROOM, {"playNow":true, "enterFrom":requestLoginData.enterFrom});
end

SeatManager.playNowSitDown = function(self)
    local userData = Model.getData(ModelKeys.USER_DATA);
	if (not SeatManager.selfInSeat) then
		local id = self:getEmptySeatId();
		if (id ~= -1) then
			if((self.m_loginSuccData.tableLevel==LoginSuccData.ROOM_LEVEL_NEWER) and (userData["CANCEL_LEVEL_LIMIT"] and (userData["CANCEL_LEVEL_LIMIT"]>0))) then
                EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,
                    {
                        message=STR_ROOM_PREVENT_STEAT_STORE_LEVEL_LIMIT,
                        confirm=STR_COMMON_CONFIRM,
                    });
			else
				if (userData.money >= self.m_loginSuccData.minBuyIn) then--请求买入
					self.m_requestBuyIn.seatId = id;
					self.m_requestBuyIn.buyinChips = self:getDefaultBuyInChips(self.m_loginSuccData);
					EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.USER_BUY_IN, self.m_requestBuyIn);
				elseif ((userData["money"]<userData["smallBlid"] * 20)and(userData["bank_money"]>0)) then
                    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,
                    {
                        message = STR_ROOM_USEER_GAME_IN_CURRENT_CHIP_SHORTSTAGE,
                        confirm = STR_ROOM_CHIP_SHORTSTAGE_GO_BANK,
                        cancel = STR_HALL_GO_TO_STORE,
                        callback = function(stype)
                            if (stype == DialogCallback.CONFIRM) then
								EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_BANK_POPUP,false);
							elseif(stype==DialogCallback.CANCEL) then
                                EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_CHIPS_PAGE);
							end
                        end,
                    });
				elseif(userData.money<userData["smallBlid"] * 20 and userData["bank_money"] == 0) then
                    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,
                    {
                        message = STR_ROOM_NOT_ENOUGH_CHIPS,
                        confirm = STR_ROOM_BUY_CHIPS,
                        callback = function(stype)
                            if (stype == DialogCallback.CONFIRM) then
                                EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_CHIPS_PAGE);
                            end
                        end,
                    });
				elseif (userData.money > userData["smallBlid"] * 20) then
					--买入筹码不够，弹框提示用户资产不足，购买筹码或者换桌
                    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,
                    {
                        message = STR_ROOM_NOT_ENOUGH_MONEY,
						confirm = STR_ROOM_BUY_CHIPS,
						cancel = STR_ROOM_SWITCH_TABLE,
						callback = self.confirmHandler,
                    });
				end
			end
		end
	end
end

--
-- 获取一个空座位的座位id
-- */
SeatManager.getEmptySeatId = function(self)
	if (self.m_maxSeatCount == 9) then--九人场
        for i=1,9 do
			if (self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]].m_seatData.uid == -1) then
				return self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]].m_seatId;
            end
		end
	elseif (self.m_maxSeatCount == 5) then--五人场
        for i=1,5 do
			if (self.m_userSeatV[BasicRoomData.FIVE_SEAT_LIST[i]].m_seatData.uid == -1) then
				return self.m_userSeatV[BasicRoomData.FIVE_SEAT_LIST[i]].m_seatId;
			end
        end
	elseif (self.m_maxSeatCount == 2) then--两人场
        for i=1,2 do
			if (self.m_userSeatV[BasicRoomData.TWO_SEAT_LIST[i]].m_seatData.uid == -1) then
				return self.m_userSeatV[BasicRoomData.TWO_SEAT_LIST[i]].m_seatId;
			end
		end
	end
	return -1; 
end

--
-- 获取一个非空座位的座位id
-- */
SeatManager.getNotEmptySeatId = function(self, excludeSelf)--private static
    excludeSelf = excludeSelf or true;
    local userData = Model.getData(ModelKeys.USER_DATA);
	if (self.m_maxSeatCount == 9) then--九人场
        for i=1,9 do
			if (self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]].m_seatData.uid ~= -1 and
				(not excludeSelf or self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]].m_seatData.uid ~= userData.uid)) then
				return self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]].m_seatId;
			end
		end
	elseif (self.m_maxSeatCount == 5) then--五人场
        for i=1,5 do
			if (self.m_userSeatV[BasicRoomData.FIVE_SEAT_LIST[i]].m_seatData.uid ~= -1 and
				(not excludeSelf or self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]].m_seatData.uid ~= userData.uid)) then
				return self.m_userSeatV[BasicRoomData.FIVE_SEAT_LIST[i]].m_seatId;
			end
		end
	elseif (self.m_maxSeatCount == 2) then--两人场
		for i=1,2 do
			if (self.m_userSeatV[BasicRoomData.TWO_SEAT_LIST[i]].m_seatData.uid ~= -1 and
				(not excludeSelf or self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]].m_seatData.uid ~= userData.uid)) then
				return self.m_userSeatV[BasicRoomData.TWO_SEAT_LIST[i]].m_seatId;
			end
		end
	end
	return -1; 
end

SeatManager.showUserSeat = function(self)--private static
	self.m_currentUserSeatV = {};
	if(Model.getData(ModelKeys.USER_IN_TUTOTIA) ~= nil and Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart and not Model.getData(ModelKeys.USER_IN_TUTOTIA).isShowUserSeat) then
		return;
	end
	if (self.m_maxSeatCount == 9) then--九人场
        for i=1,9 do
			if (self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]].m_seatData.uid == -1) then
				self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]]:setVisible(true);
				self.m_currentUserSeatV[#self.m_currentUserSeatV+1] = self.m_userSeatV[BasicRoomData.NINE_SEAT_LIST[i]];
            end
		end
	elseif (self.m_maxSeatCount == 5) then--五人场
        for i=1,5 do
			if (self.m_userSeatV[BasicRoomData.FIVE_SEAT_LIST[i]].m_seatData.uid == -1) then
				self.m_userSeatV[BasicRoomData.FIVE_SEAT_LIST[i]]:setVisible(true);
				self.m_currentUserSeatV[#self.m_currentUserSeatV+1] = self.m_userSeatV[BasicRoomData.FIVE_SEAT_LIST[i]];
			end
		end
	elseif (self.m_maxSeatCount == 2) then--两人场
        for i=1,2 do
			if (self.m_userSeatV[BasicRoomData.TWO_SEAT_LIST[i]].m_seatData.uid == -1) then
				self.m_userSeatV[BasicRoomData.TWO_SEAT_LIST[i]]:setVisible(true);
				self.m_currentUserSeatV[#self.m_currentUserSeatV+1] = self.m_userSeatV[BasicRoomData.TWO_SEAT_LIST[i]];
			end
		end
	end
end

SeatManager.startSeatTimer = function(self, seatId)
    local userData = Model.getData(ModelKeys.USER_DATA);
	self:stopSeatTimer();
	self.m_userSeatV[seatId]:startTimer();
	self.m_currentOperationSeatId = seatId;
	if (self.m_userSeatV[seatId]:isSelf() and userData and (Model.getData(ModelKeys.USER_IN_TUTOTIA) == nil or not Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart)) then
		self.m_timeout2 = setTimeout(self.shakeCardTimeout, self, SeatManager.countdown * 750);
	end
end

SeatManager.shakeCardTimeout = function(self)--private static
--m	getSelfSeat().m_handCard.handCardV[0].shakeCard();
--m	getSelfSeat().m_handCard.handCardV[1].shakeCard();
end
		
SeatManager.stopSeatTimer = function(self)
    local userData = Model.getData(ModelKeys.USER_DATA);
	if self.m_currentOperationSeatId ~= -1 then
		self.m_userSeatV[self.m_currentOperationSeatId]:stopTimer();
		if (self.m_userSeatV[self.m_currentOperationSeatId]:isSelf() and userData and (Model.getData(ModelKeys.USER_IN_TUTOTIA) == nil or not Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart)) then
			local handCard  = self:getSelfSeat().m_handCard;
            local handCardV = handCard:getHandCardV();
            if handCardV ~= nil then
                handCardV[1]:stopShakeCard();
			    handCardV[2]:stopShakeCard();
            end
		end
		clearTimeout(self.m_timeout2);
		self.m_currentOperationSeatId = -1;
	end
end

SeatManager.getUserSeat = function(self, seatId)
	if (self.m_userSeatV[seatId]) then
		return self.m_userSeatV[seatId];
	else
		return nil;
	end
end

SeatManager.hideAllSitDownButton = function(self)
	for i=1,#self.m_currentUserSeatV do
		if self.m_currentUserSeatV[i].m_seatData.uid == -1 and 
            not self.m_currentUserSeatV[i]:isShowInviteFriends() then
			self.m_currentUserSeatV[i]:setVisible(false);
		end
	end
end

SeatManager.showAllSitDownButton = function(self)
	for i=1,#self.m_currentUserSeatV do
		if (self.m_currentUserSeatV[i].m_seatData.uid == -1) then
			self.m_currentUserSeatV[i]:setVisible(true);
			self.m_currentUserSeatV[i]:changeSitdownIconTexture();
		end
	end
end

SeatManager.getSelfSeat = function(self)
	if SeatManager.selfSeatId ~= -1 then
		return self.m_userSeatV[SeatManager.selfSeatId];
	else
		return nil;
	end
end

SeatManager.fadeAllHandCard = function(self)
	for i=1,9 do
		if (self.m_userSeatV[i].m_compulsoryShowHandCard) then
			self.m_userSeatV[i].m_handCard:fadeHandCard();
        end
	end
end

SeatManager.setUserSitDown = function(self, data)
	local userSeat = self.m_userSeatV[data.seatId];
	if (userSeat.m_seatData.uid ~= -1) then     --自动买入坐下
		userSeat:playBuyinAnimation(data.seatChips);
		return;
	end

	userSeat.m_seatData.seatId = data.seatId;
	userSeat.m_seatData.uid = data.uid;
	userSeat.m_seatData.name = data.name;
	userSeat.m_seatData.gender = data.gender;
	userSeat.m_seatData.totalChips = data.totalChips;
	userSeat.m_seatData.exp = data.exp;
	userSeat.m_seatData.vip = data.vip;
	userSeat.m_seatData.photoUrl = data.photoUrl;
	userSeat.m_seatData.winRound = data.winRound;
	userSeat.m_seatData.loseRound = data.loseRound;
	userSeat.m_seatData.currentPlace = data.currentPlace;
	userSeat.m_seatData.homeTown = data.homeTown;
	userSeat.m_seatData.giftId = data.giftId;
	userSeat.m_seatData.seatChips = data.seatChips;
			
	userSeat:setSeatData(userSeat.m_seatData);
	userSeat:setVisible(true);
	userSeat:fadeSeat();

	--自己坐下
	if (userSeat:isSelf()) then
		self:hideAllSitDownButton();
		OperationManager:showDisabledCase();
		SeatManager.selfSeatId = data.seatId;
		Model.setData(ModelKeys.USER_SELF_SEAT_ID, SeatManager.selfSeatId);
		SeatManager.selfInSeat = true;
		SeatManager.selfBuyInChips = data.seatChips;

		if (userSeat.m_positionId == 5) then
			userSeat:sitDownAnimation();
		else
			userSeat:sitDownAnimation(0);
        end
		self:turnToFrontView();
				
		--1秒后，提示等待下一轮
		self.m_timeout1 = setTimeout(function(self)
			    if (not SeatManager.selfInGame) then
                    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_WAIT_NEXT_ROUND);
			    end
		    end, self, 1000);
				
		--用户坐下后，找到一个空座位显示邀请好友图标
		self:findEmptySeat();
	else
		--当显示邀请图标的座位上坐了玩家后，重新在别的座位显示
		if(self.m_inviteFriendSeatID ~= -1 and userSeat.m_seatId == self.m_inviteFriendSeatID and SeatManager.selfInSeat) then
			--先干掉定时器
			clearTimeout(self.m_timeoutNum);
			self:findEmptySeat();
		elseif(self.m_inviteFriendSeatID == -1 and self:getEmptySeatId() ~= -1) then
			self:findEmptySeat();
		end
		userSeat:sitDownAnimation();
	end
    local bFind = false;
    for _,v in pairs(self.m_sitDownSeatV) do
        if(v == userSeat) then
            bFind = true;
            break;
        end
    end
    if(not bFind) then
        self.m_sitDownSeatV[#self.m_sitDownSeatV + 1] = userSeat;
    end
end

SeatManager.findEmptySeat = function(self)
	--好友邀请暂时关闭，若要打开，去掉return，并且打开接受好友邀请功能
--			return;
	if(Model.getData(ModelKeys.USER_IN_TUTOTIA) and Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart) then
		return;
	end
	if(not SeatManager.selfInSeat) then
		return;
	end
	if(self.m_scene:isMatch()) then
		return;
	end
	local friendList = Model.getData(ModelKeys.FRIEND_LIST_NEW);
	if(friendList and #friendList == 0) then
		return;
	end
	local emptySeatId = self:getEmptySeatId(); 
	if(emptySeatId ~= -1) then
		self.m_userSeatV[emptySeatId]:setVisible(true);
		self.m_userSeatV[emptySeatId]:showInviteFriends();
		self.m_inviteFriendSeatID = emptySeatId;
		self.m_isHasEmptySeat = true;
	else
		self.m_isHasEmptySeat = false;
	end
end

SeatManager.hideInviteSeat = function(self)
    for i=1,#self.m_userSeatV do
		if(self.m_userSeatV[i]:isShowInviteFriends()) then
			self.m_currentUserSeatV[i]:setVisible(false);
		end
	end
end

SeatManager.setUserStandUp = function(self, seatId)
	local userSeat = self.m_userSeatV[seatId];
	if (userSeat:isSelf()) then
		userSeat.m_handCard:setPos(UserSeat.SEAT_WIDTH * 0.5, UserSeat.SEAT_HEIGHT * 0.5);
		userSeat.m_handCard:resetHandCardPosition();
		OperationManager:showDisabledCase();
		SeatManager.selfSeatId = -1;
		Model.setData(ModelKeys.USER_SELF_SEAT_ID, SeatManager.selfSeatId);
		SeatManager.selfInRound = false;
		SeatManager.selfInGame = false;
		SeatManager.selfInSeat = false;
		userSeat.m_seatData.uid = -1;
		if(not LoginSuccData.isMatch(SeatManager.roomType)) then
			self:showAllSitDownButton();--显示坐下按钮
		end

		clearTimeout(self.m_timeout3);
		clearTimeout(self.m_timeout2);
		self:hideCardType();--影藏牌型提示
        --EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_CLEAR_CALCULATOR);--清理算牌器
		if (self.m_selfSeatArrow) then
            self.m_selfSeatArrow:setVisible(false);
		end
		self.m_inviteFriendSeatID = -1;
	else
		DealCardManager:hideDealCard(userSeat.m_positionId);
		--别人站起显示邀请好友图标 ,淘汰赛只在比赛开始前显示，比赛中不显示
		if(SeatManager.selfInSeat and self.m_isHasEmptySeat == false) then
			if(SeatManager.roomType == LoginSuccData.ROOM_TYPE_NORMAL and not self.m_scene.isMatch) then
				self.m_timeoutNum = setTimeout(SeatManager.findEmptySeat,1000);
			end
		end
	end
	userSeat:cleanUp();

	local index = ArrayKit.indexOf(self.m_sitDownSeatV, userSeat);
	if (index ~= -1) then
        As3Kit.deleteAt(self.m_sitDownSeatV, index);
	end
end

SeatManager.playExpression = function(self, data)
	if ((data.expressionId >= 1 and data.expressionId <= 30 or data.expressionId >= 61 and data.expressionId <= 90 or data.expressionId >= 10101 and data.expressionId <= 10112)
		and self.m_userSeatV[data.seatId].m_seatData.uid ~= -1) then
		local userSeat = self.m_userSeatV[data.seatId];
		--每播放一次表情扣除相应的钱
		if(data.expressionId <=30 and data.minusMoney > 0 and userSeat.m_seatData.seatChips >= data.minusMoney) then
			if(userSeat and not LoginSuccData.isMatch(self.m_loginSuccData.roomType)) then
				userSeat:setSeatChips(userSeat.seatData.seatChips - data.minusMoney);
				if(userSeat:isSelf()) then
					userSeat:playExpressionMinusMoneyAnimation(data.minusMoney);
				end
			end
		end
		if (self:get_appDeactivate()) then
			return;
        end
				
		local expression;
		if ((data.expressionId >= 1 and data.expressionId <= 30 or data.expressionId >= 61 and data.expressionId <= 90)) then
			expression = new MovieClip(AssetManager.instance.getTextureAtlas("room-hd").getTextures("expression-" + data.expressionId + "-"), 3);
			self:showException(expression, data);
		elseif (data.expressionId >= 10101 and data.expressionId <= 10112) then
			self:loadVipBear(data);
		end
	end
end

SeatManager.showException = function(self, expression, data)--private static
--m	expression.x = self.m_seatPositionV[self.m_userSeatV[data.seatId].m_positionId].x + (UserSeat.SEAT_WIDTH - expression.width) * 0.5;
--m	expression.y = self.m_seatPositionV[self.m_userSeatV[data.seatId].m_positionId].y - 12);
--m	expression.touchable = false;
--m	if (data.expressionId >= 61 and data.expressionId<= 90)
--m	{
--m		expression.fps = 2;
--m	}
--m	if (data.expressionId >= 10101 and data.expressionId <= 10112) {
--m		expression.fps = 3;
--m	}
--m	switch (data.expressionId)
--m	{
--m		case 61:
--m		case 64:
--m		case 65:
--m		case 78:
--m		case 79:
--m			expression.loop = false;
--m			break;
--m		case 62:
--m			expression.fps = 1.5;
--m			break;
--m		case 74:
--m		case 77:
--m			expression.fps = 6;
--m			break;
--m		case 76:
--m		case 81:
--m		case 86:
--m		case 88:
--m		case 89:
--m			expression.fps = 3;
--m			break;
--m		case 10102:
--m			expression.fps = 2;
--m			break;
--m		case 10103:
--m			expression.x += -2);
--m			expression.y += -20);
--m			break;
--m		case 10104:
--m			expression.fps = 5;
--m			expression.x += 10);
--m			break;
--m		case 10105:
--m			expression.fps = 4;
--m			break;
--m		case 10106:
--m			expression.fps = 5;
--m			break;
--m		case 10107:
--m			expression.fps = 4;
--m			expression.x += 20);
--m			expression.y += -24);
--m			break;
--m		case 10108:
--m			expression.fps = 5;
--m			expression.x += 14);
--m			expression.y += -24);
--m			break;
--m		case 10109:
--m			expression.fps = 4;
--m			break;
--m		case 10110:
--m			expression.fps = 5;
--m			break;
--m		case 10111:
--m			expression.fps = 4;
--m			expression.x += 8);
--m			expression.y += -24);
--m			break;
--m		default:
--m			break;
--m	}
--m	Starling.juggler.add(expression);
--m	TableAnimationManager.addChildAt(expression, 0);
--m	Starling.juggler.delayCall(expression.removeFromParent, 3, true);
end

SeatManager.loadVipBear = function(self, data)--private static
--m	if (AssetManager.instance.getTexture("racoon-expression-10101-0001") == null) {
--m		AssetManager.instance.enqueue(File.applicationDirectory.resolvePath("act/expression"));
--m		AssetManager.instance.loadQueue(function (progressNum:Number):void {
--m			if(progressNum==1)
--m			{
--m				AssetManager.instance.getTextureAtlas("expression");
--m				local mc:MovieClip = new MovieClip(AssetManager.instance.getTextureAtlas("expression").getTextures("racoon-expression-" + data.expressionId + "-"), 3);
--m				showException(mc, data);
--m			}
--m		});
--m	} else {
--m		AssetManager.instance.getTextureAtlas("expression");
--m		local mc:MovieClip = new MovieClip(AssetManager.instance.getTextureAtlas("expression").getTextures("racoon-expression-" + data.expressionId + "-"), 3);
--m		showException(mc, data);
--m	}
end

SeatManager.expressionOver = function(self)--private static
--m	(arguments[0] as MovieClip).removeFromParent(true);
end

SeatManager.sendGift = function(self, data)
	local arrLenth = #data.userArr;
	local userSeat = nil;
	if (self.m_userSeatV[data.sendSeatId]:isSelf() and (Model.getData(ModelKeys.USER_IN_TUTOTIA) == nil or not Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart)) then
		TaskReporter.getInstance():reportSendTableGifts();
	end
    local userData = Model.getData(ModelKeys.USER_DATA);
    for i=1,arrLenth do
		--座位未更换玩家的情况下
		userSeat = self.m_userSeatV[data.userArr[i].seatId];
		if (userSeat.m_seatData.uid == data.userArr[i].seatUid) then
			userSeat:addGift(data.giftId, data.sendSeatId);--设置座位礼物
		end
		if(data.userArr[i].seatUid == userData.uid) then
			--当前用户收到礼物，播放语音
			VoiceManager.play(VoiceKeys.RECEIVE_GIFT_FROM_USER);
		end
	end
end

--[Comment]
-- 发送互动道具、并播放动画
SeatManager.startHddj = function(self, data)
	local userData = Model.getData(ModelKeys.USER_DATA);
    if data.hddjId <= 13 and  data.receiveSeatId <= 10 then
	    local sendSeatId   = data.sendSeatId;		--发送者座位id
	    if userData ~= nil and sendSeatId == self.selfSeatId and not TutotiaKit.isTutotia() then
		    TaskReporter.getInstance():reportUseProp();
	    end
			
	    local fPoint = new(Point, 0, 0);--起始点
	    local tPoint = new(Point, 0, 0);--目标点
	    local mPoint = new(Point, 0, 0);--中间点
	    local pPoint = new(Point, 0, 0);--播放点
			
	    local sendedSeatId = data.receiveSeatId;	--目标座位id,n目标作为id为9表示荷官
	    local xParse       = 0;
			
	    if sendSeatId > 0 and sendedSeatId > 0 then
	        fPoint.x, fPoint.y = self:getSendPos(sendSeatId)
            pPoint.x, pPoint.y = self:getSendPos(sendedSeatId);
	        
            local hddjIcon          = nil;
	        local hddjIconName      = "HDDJ_ICON"..sendSeatId.."_"..sendedSeatId;
	        local hddjMcName        = "HDDJ_MC"..sendSeatId.."_"..sendedSeatId;
	        
            --删除正在播放的动画
	        self:removeOldHddj(hddjIconName, hddjMcName)
			
	        local hddjImage      = PropKit.getImage(data.hddjId);
            
            hddjImage:setAlign(kAlignTopLeft);
            hddjImage:setScale(0.6);
            local w, h = hddjImage:getSize();
            hddjImage:setPos( - w / 2, - h / 2);
            
            local hddjIcon  = new(Node);
	        hddjIcon:addChild(hddjImage);
            hddjIcon:setPos(fPoint.x, fPoint.y);
	        hddjIcon:setName(hddjIconName);
	        TableAnimationManager:addChild(hddjIcon);
            self:moveHddj(data, hddjIcon, hddjMcName, sendedSeatId, tPoint, mPoint, fPoint, pPoint);
        end
    end
end


--[Comment]
--移除旧的互动道具
SeatManager.removeOldHddj = function(self, hddjIconName, hddjMcName)
    local oldHddj = TableAnimationManager:getChildByName(hddjIconName);
	if oldHddj ~= nil then
        local objHddjParent = oldHddj:getParent();
        if oldHddj ~= nil and objHddjParent ~= nil then
		    objHddjParent:removeChild(oldHddj, true);
		    oldHddj = nil;
	    end
    end
	
    oldHddj = TableAnimationManager:getChildByName(hddjMcName);
    if oldHddj ~= nil then
        local objHddjParent = oldHddj:getParent();
        if oldHddj ~= nil and objHddjParent ~= nil then
		    objHddjParent:removeChild(oldHddj, true);
		    oldHddj = nil;
	    end
    end
end


--[Comment]
--移动互动道具
SeatManager.moveHddj = function(self, data, hddjIcon, hddjMcName, sendedSeatId, tPoint, mPoint, fPoint, pPoint)
    local id = data.hddjId;
    local dealerPosition = new(Point, 0, 0);
    dealerPosition.x, dealerPosition.y = self:getSendPos(10);
    local dealerSeatId = 10;
    if id == 1 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 70;
			pPoint.y = dealerPosition.y - 110;
		else
            pPoint.x = pPoint.x - 75;
			pPoint.y = pPoint.y - 85;
        end
        tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, -70, -110, - 75, - 85);
        self:hddjTweenTo(id, hddjIcon, hddjMcName, tPoint, pPoint);

    elseif id == 2 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 140;
			pPoint.y = dealerPosition.y - 140;
		else
            pPoint.x = pPoint.x - 145;
			pPoint.y = pPoint.y - 120;
        end
        tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 40, -70, 40, -60);
        self:hddjTweenTo(id, hddjIcon, hddjMcName, tPoint, pPoint);

    elseif id == 3 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 50;
			pPoint.y = dealerPosition.y - 30;
		else
            pPoint.x = pPoint.x - 50;
			pPoint.y = pPoint.y - 30;
        end
        tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 0, 0, 0, 0);
		self:hddjTweenBezier(id, hddjIcon, hddjMcName, tPoint, mPoint, fPoint, pPoint, true);

    elseif id == 4 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 100;
			pPoint.y = dealerPosition.y - 80;
		else
            pPoint.x = pPoint.x - 100;
			pPoint.y = pPoint.y - 60;
        end
        tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 0, 0, 0, 0);
		self:hddjTweenBezier(id, hddjIcon, hddjMcName, tPoint, mPoint, fPoint, pPoint, false);

    elseif id == 5 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 85;
			pPoint.y = dealerPosition.y - 115;
		else
            pPoint.x = pPoint.x - 90;
			pPoint.y = pPoint.y - 95;
        end

        tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 0, 0, 0, 0);
		self:hddjTweenBezier(id, hddjIcon, hddjMcName, tPoint, mPoint, fPoint, pPoint, true);

    elseif id == 6 then
	    if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 40;
			pPoint.y = dealerPosition.y - 60;
		else
            pPoint.x = pPoint.x - 40;
			pPoint.y = pPoint.y - 60;
        end
        tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 0, 0, 0, 0);
		self:hddjTweenTo(id, hddjIcon, hddjMcName, tPoint, pPoint);

    elseif id == 7 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 40;
			pPoint.y = dealerPosition.y - 60;
		else
            pPoint.x = pPoint.x - 40;
			pPoint.y = pPoint.y - 60;
        end
	    tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 0, 0, 0, 0);
	    self:hddjTweenTo(id, hddjIcon, hddjMcName, tPoint, pPoint);

    elseif id == 8 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 50;
			pPoint.y = dealerPosition.y - 80;
		else
            pPoint.x = pPoint.x - 50;
			pPoint.y = pPoint.y - 80;
        end
		tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 0, 0, 0, 0);
		self:hddjTweenTo(id, hddjIcon, hddjMcName, tPoint, pPoint);
    
    elseif id == 9 then
		if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 50;
			pPoint.y = dealerPosition.y - 60;
        else
            pPoint.x = pPoint.x - 50;
			pPoint.y = pPoint.y - 60;
        end
		tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 0, 0, 0, 0);
		self:hddjTweenTo(id, hddjIcon, hddjMcName, tPoint, pPoint);
        hddjIcon:setRotate(self:getRotation(fPoint, tPoint) - 45);

    elseif id == 10 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 60;
			pPoint.y = dealerPosition.y - 80;
        else
            pPoint.x = pPoint.x - 60;
			pPoint.y = pPoint.y - 80;
        end
		tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 0, 0, 0, 0);
		self:hddjTweenBezier(id, hddjIcon, hddjMcName, tPoint, mPoint, fPoint, pPoint, true);
    
    elseif id == 11 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 30;
			pPoint.y = dealerPosition.y - 80;
        else
            pPoint.x = pPoint.x - 30;
			pPoint.y = pPoint.y - 80;
        end
        tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 0, 0, 0, 0);
		self:hddjTweenTo(id, hddjIcon, hddjMcName, tPoint, pPoint);

    elseif id == 12 then
		if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 110;
			pPoint.y = dealerPosition.y - 80;
        else
            pPoint.x = pPoint.x - 110;
			pPoint.y = pPoint.y - 60;
        end
        tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, -30, -30, -30, -20);
		self:hddjTweenTo(id, hddjIcon, hddjMcName, tPoint, pPoint);

    elseif id == 13 then
        if sendedSeatId == dealerSeatId then
			pPoint.x = dealerPosition.x - 40;
			pPoint.y = dealerPosition.y - 128;
        else
            pPoint.x = pPoint.x - 40;
			pPoint.y = pPoint.y - 100;
        end
        tPoint.x, tPoint.y = self:getHddjTargetPoint(sendedSeatId, 80, -20, 80, -20);
		self:hddjTweenTo(id, hddjIcon, hddjMcName, tPoint, pPoint);
    end
end


SeatManager.getHddjTargetPoint = function(self, sendedSeatId, dOffsetX, dOffsetY, offsetX, offsetY)
    local tPoint = new(Point, 0, 0);
    if sendedSeatId == 10 then
        tPoint.x, tPoint.y = self:getSendPos(sendedSeatId);
        tPoint.x = tPoint.x + dOffsetX;
        tPoint.y = tPoint.y + dOffsetY;
	else
		tPoint.x, tPoint.y = self:getSendPos(sendedSeatId);
        tPoint.x = tPoint.x + offsetX;
        tPoint.y = tPoint.y + offsetY;
	end
    return tPoint.x, tPoint.y;
end

SeatManager.hddjTweenTo = function(self, hddjId, hddjIcon, hddjMcName, tPoint, pPoint)
    local x, y = hddjIcon:getPos();
    local tranX = tPoint.x - x;
    local tranY = tPoint.y - y;
    KTween.to(hddjIcon, 1000, {
            easeType    = EaseType.CircInOut, 
            x           = tranX, 
            y           = tranY, 
            delay       = 50,
            onComplete  = self.playHddj, 
            obj         = self,
            onCompleteParams={hddjId = hddjId, hddjMcName = hddjMcName, hddjIcon = hddjIcon, pPoint = pPoint}});
end

SeatManager.hddjTweenBezier = function(self, hddjId, hddjIcon, hddjMcName, tPoint, mPoint, fPoint, pPoint, isRotate)
    mPoint.x = (fPoint.x + tPoint.x) / 2;
    local xParse   = math.abs(mPoint.x - tPoint.x);
    mPoint.y = (fPoint.y + tPoint.y) / 2 - xParse /2;
    
    local param = {
        bezier     = {mPoint, tPoint}, 
        easeType   = EaseType.CircIn, 
        onComplete = self.playHddj, 
        center     = kCenterDrawing,
        obj        = self,
        onCompleteParams = {hddjId = hddjId, hddjMcName = hddjMcName, hddjIcon = hddjIcon, pPoint = pPoint};
    };

    if isRotate == true then
        local rotation = 0;
        if fPoint.x > tPoint.x then
	        rotation = -3 * 360;
        else
	        rotation = 3 * 360;
        end
        param.angle = rotation;
    end

    KTween.to(hddjIcon, 1000, param);
end


--[Comment]
-- 播放互动道具动画
SeatManager.playHddj = function(self, data)
    local hddjId    = data.hddjId;
    local mcName    = data.hddjMcName;
    local hddjIcon  = data.hddjIcon;
    local pPoint    = data.pPoint;

    if hddjIcon ~= nil then
        local parent = hddjIcon:getParent();
        if parent ~= nil then
            parent:removeChild(hddjIcon, true);
        end
    end


    local container = TableAnimationManager:getContainer();

    self.m_hddjAnim = AtomAnimManager.getInstance():playAnim(PropKit.getAnimPath(hddjId), container, pPoint.x, pPoint.y, true, true, kAlignTopLeft);
    self.m_hddjAnim:setScale(1.15);
    self.m_hddjAnim:setName(mcName);
	self.m_hddjAnim:setPickable(false);
	SoundManager.playSound(self.HDDJ_SOUND[hddjId]);
end

--[Comment]
-- 计算两点连线相对于水平线的角度
SeatManager.getRotation = function(self, fPoint, tPoint)
	local c = Point.distance(fPoint, tPoint);
	local a = math.abs(fPoint.y - tPoint.y);
	local sinValue = a / c;
	local rotation = math.asin(sinValue) / math.pi * 180;
			
	--根据位置校正角度
	if (fPoint.x < tPoint.x) then
		if (fPoint.y > tPoint.y) then
			rotation = 90 - rotation;
		elseif (fPoint.y < tPoint.y) then
			rotation = 90 + rotation;
		else
			rotation = 90;
		end
	else
		if (fPoint.y > tPoint.y) then
			rotation = -(90 - rotation);
		elseif (fPoint.y < tPoint.y) then
			rotation = -(90 + rotation);
		else
			rotation = -90;
        end
	end
	return rotation;
end

SeatManager.startAddFriend = function(self, data)
	local sendSeatId = data.sendSeatId;
	local receiveSeatId = data.receiveSeatId;
	if (receiveSeatId ~= -1 and sendSeatId ~= -1 and self.m_userSeatV[receiveSeatId]:isSelf()) then
		local sendUid = self.m_userSeatV[sendSeatId].m_seatData.uid;
		local friendList = Model.getData(ModelKeys.FRIEND_UID_LIST);
		local myFriend = false;
		if (friendList) then
            for n=1,#friendList do
				if (friendList[n] == sendUid) then
					myFriend = true;
					break;
				end
			end
		end
		if (not myFriend) then
			local button = new(Button, "common/dialog/common_green_btn_up.png", nil, nil, nil, 9, 10, 9, 10);
            local label = new(Text, STR_COMMON_CONFIRM);
            label:setAlign(kAlignCenter);
            button:addChild(label);
            button:setSize(128, 60);
            button:setOnClick(self, function(self)
				--座位未换人
				if (sendUid == self.m_userSeatV[sendSeatId].m_seatData.uid) then
					local addFriendData = {sendSeatId = SeatManager.selfSeatId, receiveSeatId = data.sendSeatId};
					--如果在座，则通过server进行广播，不在座，只发出本人看得到的加牌友动画
					if (SeatManager.selfSeatId ~= -1) then
					else
						addFriendData.notInSeat = true;
						Model.setData(ModelKeys.ROOM_ADD_FRIEND_DATA, addFriendData);
					end
				end
			end);
					
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,
                                           {
                                           title = "提示",
                                           message = STR_ROOM_ROOM_ADD_FRIEND_TIP,
                                           confirm = STR_COMMON_CONFIRM,
                                           cancel = STR_COMMON_CANCEL,
                                           });
		end
	end

	if (self.get_appDeactivate()) then
		return;
	end
	local sendMail = new(Image, self.m_atlas.getTexture("room-add-friend"));
    sendMail:setPickable(false);
	if (data.notInSeat) then
		sendMail:setPos(0, 0);
	else
		local x = self.m_seatPositionV[self.m_userSeatV[sendSeatId].m_positionId].x + UserSeat.SEAT_WIDTH * 0.5;
		local y = self.m_seatPositionV[self.m_userSeatV[sendSeatId].m_positionId].y + UserSeat.SEAT_HEIGHT * 0.5;
        sendMail:setPos(x, y);
	end
end

--赠送筹码
SeatManager.startSendChip = function(self, data)
	local userData = Model.getData(ModelKeys.USER_DATA);
    local sendSeat = self.m_userSeatV[data.senderSeatId];
	
    --如果是送给玩家，修改发送者座位筹码数；如果是送给荷官修改用户资产
	if data.recieverSeatId <= 9 and not TutotiaKit.isTutotia() then
		sendSeat:setSeatChips(sendSeat:getSeatData().seatChips - data.sendChips);
		if self.m_userSeatV[data.recieverSeatId]:getSeatData().uid == userData.uid then
			--用户收到筹码，播放声音
			--VoiceManager.play(VoiceKeys.RECEIVE_CHIPS_FROM_USER);
		end
	elseif not TutotiaKit.isTutotia() then
		if sendSeat:isSelf() then
			userData.money = userData.money - data.sendChips;
            Model.setData(ModelKeys.USER_DATA, userData);
		end
		sendSeat:getSeatData().totalChips = sendSeat:getSeatData().totalChips - data.sendChips;
	end
			
	--动画
	local sendChipSprite = new(SendChipSprite, data.sendChips);
    sendChipSprite:setAlign(kAlignCenter);
    TableAnimationManager:addChild(sendChipSprite);
	local x = self.m_seatPositionV[sendSeat.m_positionId].x + UserSeat.SEAT_WIDTH * 0.5;
	local y = self.m_seatPositionV[sendSeat.m_positionId].y + UserSeat.SEAT_HEIGHT * 0.5;
	local cx, cy = self.m_container:getPos();
    local rx, ry = 0, 0;
    if data.recieverSeatId < 10 then
        rx = self.m_seatPositionV[self.m_userSeatV[data.recieverSeatId].m_positionId].x + UserSeat.SEAT_WIDTH / 2;
        ry = self.m_seatPositionV[self.m_userSeatV[data.recieverSeatId].m_positionId].y + UserSeat.SEAT_HEIGHT / 2;
    else
        rx = System.getLayoutWidth() / 2;
        ry = self.m_seatPositionV[9].y + UserSeat.SEAT_HEIGHT;
    end

    sendChipSprite:setPos(x, y);
	--判断接受者是否是荷官 ,接受者id为10表示送给荷官
    KTween.to(sendChipSprite, 1500, {
        x = (rx - x), 
        y = (ry - y), 
        easeType = EaseType.CubicInOut, 
        onComplete = self.sendChipCompleteHandler, 
        onCompleteParams = data,
        obj = self, 
        delay = 500});

	--4秒后移除动画
	local param = {sendChipSprite = sendChipSprite,recieverSeatId = data.recieverSeatId, sendChips = data.sendChips};
    self.m_sendChipsTimeout = setTimeout(self.sendChipsTimeout, self, 3000, param);
end

SeatManager.getSendPos = function(self, index)
    local rx, ry = 0, 0;
    if index > 0 and index <= #self.m_sendPositionV then
        if index == 10 then
            rx, ry = self.m_sendPositionV[index].x, self.m_sendPositionV[index].y;
        else
            rx, ry = self.m_sendPositionV[self.m_userSeatV[index].m_positionId].x, self.m_sendPositionV[self.m_userSeatV[index].m_positionId].y;
        end
    end
    return rx, ry;
end

SeatManager.sendChipCompleteHandler = function(self, data)
	if data.recieverSeatId == 10 then
		local sendSeat = self.m_userSeatV[data.senderSeatId];
		self.m_userSendChipArray[data.senderSeatId] = self.m_userSendChipArray[data.senderSeatId] + 1;
		if self.m_userSendChipArray[data.senderSeatId] == 1 
            or self.m_userSendChipArray[data.senderSeatId] % 5 == 0 then
			local seatData = self.m_userSeatV[data.senderSeatId]:getSeatData();
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_DEALER_ACTION, {["seatId"] = seatData.seatId , ["userName"]= seatData.name, ["seatUid"] = seatData.uid});
		end
	end
end

SeatManager.sendChipsTimeout = function(self, data)
    data.sendChipSprite:getParent():removeChild(data.sendChipSprite,true);
	--修改接受者座位筹码数，如果送给荷官则不用修改
	if data.recieverSeatId < 10 then
		local receiveSeat = self.m_userSeatV[data.recieverSeatId];
        local chipNum = receiveSeat:getSeatData().seatChips + data.sendChips;
		receiveSeat:setSeatChips(chipNum);
    end
end

SeatManager.setCurrentCardType = function(self, stype)
	if (self:get_appDeactivate()) then
		self:delaySetCardType(stype);
	else
		if (self.m_timeout3 ~= 0) then
			clearTimeout(self.m_timeout3);
			self.m_timeout3 = 0;
		end
		self.m_timeout3 = setTimeout(self.delaySetCardType, self, 1000, stype);
	end
end

SeatManager.delaySetCardType = function(self, stype)
	self.m_timeout3 = 0;
	if (not self.m_cardTypeTip) then
		self.m_cardTypeTip = new(CardTypeTip);
		self.m_cardTypeTip:setPos(self.m_stageWidth * 0.5, self.m_seatPositionV[5].y - 36);
		self.m_container:addChild(self.m_cardTypeTip);
	end
	if(Model.getData(ModelKeys.USER_IN_TUTOTIA) == nil or not Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart) then
		self.m_cardTypeTip:setVisible(true);
		self.m_cardTypeTip:setCardType(stype);
	elseif(not Model.getData(ModelKeys.USER_IN_TUTOTIA).isShowCardType) then
		self.m_cardTypeTip:setVisible(false);
	else
		self.m_cardTypeTip:setVisible(true);
		self.m_cardTypeTip:setCardType(stype);
	end

    for i=1,5 do
		PublicCardManager:getPublicCard()[i]:removeCardOverlay();
	end
	self:getSelfSeat().m_handCard:getHandCardV()[1]:removeCardOverlay();
	self:getSelfSeat().m_handCard:getHandCardV()[2]:removeCardOverlay();

	--高亮关键牌型
    for i=1,5 do
        local keycardArr = CalculateCardType:getKeyCardArray();
		if (keycardArr[i]) then
			PublicCardManager:hightLightPublicCard(keycardArr[i]);
			self:getSelfSeat().m_handCard:hightLightHandCard(keycardArr[i]);
		end
	end
end

SeatManager.hideCardType = function(self)
	if (self.m_cardTypeTip) then
		self.m_cardTypeTip:setVisible(false);
		clearTimeout(self.m_timeout3);
	end
end

SeatManager.chatBubble = function(self, data)

end

SeatManager.refresh = function(self)
	SeatManager.selfInRound = false;
	SeatManager.selfInGame = false;

    for i=1,9 do
		self.m_userSeatV[i]:refresh();
		self.m_userSeatV[i].m_seatData.betInChips = 0;
		self.m_userSeatV[i].m_compulsoryShowHandCard = false;
	end
	if (SeatManager.selfInSeat) then
		self:hideCardType();--影藏牌型提示
		local selfHandCard = self:getSelfSeat().m_handCard;
		selfHandCard:setPos(148, 96);
		local handCardV = selfHandCard:getHandCardV();
        if handCardV ~= nil then
            handCardV[1]:setPos(0);
		    handCardV[2]:setPos(HandCard.card1X);
        end
	end

	clearTimeout(self.m_timeout1);
	clearTimeout(self.m_timeout2);
	clearTimeout(self.m_timeout3);
end

SeatManager.cleanUp = function(self)
    for i=1,9 do
		self.m_userSeatV[i]:setPositionId(i);
		self.m_userSeatV[i]:setPos(self.m_seatPositionV[i].x, self.m_seatPositionV[i].y);
		self.m_userSeatV[i]:cleanUp();
		self.m_userSeatV[i]:setVisible(false);
		self.m_userSeatV[i].m_seatData.uid = -1;
	end

	self.m_tableDealer:setVisible(false);
	SeatManager.selfSeatId = -1;
	SeatManager.selfInSeat = false;
	SeatManager.selfBuyInChips = 0;
	clearTimeout(self.m_timeout1);
	clearTimeout(self.m_timeout2);
	clearTimeout(self.m_timeout3);
	self:stopSeatTimer();
	self:hideCardType();
	if self.m_selfSeatArrow ~= nil then
        self.m_selfSeatArrow:removeFromParent(true);
    end
	--清空赠送荷官消费用户信息
    for i=1,#self.m_userSendChipArray do
		self.m_userSendChipArray[i] = 0;
	end

    --清除黄色箭头
    self:clearArrowAnim();
end

SeatManager.get_seatPositionV = function(self)
	return self.m_seatPositionV;
end

SeatManager.get_chipPositionV = function(self)
	return self.m_chipPositionV;
end

SeatManager.get_potPositionV = function(self)
	return self.m_potPositionV;
end

SeatManager.get_dealCardPositionV = function(self)
	return self.m_dealCardPositionV;
end

SeatManager.get_showHandCardAnimationDataV = function(self)
	return self.m_showHandCardAnimationDataV;
end

SeatManager.get_userSeatV = function(self)
	return self.m_userSeatV;
end

SeatManager.get_sitDownSeatV = function(self)
	return self.m_sitDownSeatV;
end

SeatManager.get_requestLoginData = function(self)
	return Model.getData(ModelKeys.ROOM_REQUEST_LOGIN_DATA);
end

SeatManager.get_appDeactivate = function(self)
	return Model.getData(ModelKeys.APP_DEACTIVATE);
end

--[Comment]
--获得默认买入筹码数目
SeatManager.getDefaultBuyInChips = function(self, loginSuccData)
	local buyInChips = 0;
    local userChips = Model.getData(ModelKeys.USER_DATA).money;
    if loginSuccData ~= nil then
        local minBuyIn = loginSuccData.minBuyIn;
        local maxBuyIn = loginSuccData.maxBuyIn;
	    if  userChips < minBuyIn then--用户资产小于最小买入，买入失败
		    buyInChips = 0;
	    elseif userChips < maxBuyIn * 0.5 then --用户资产小于最大买入的1/2
		    buyInChips = userChips;
	    else
		    buyInChips = maxBuyIn * 0.5;
	    end
    end
	return buyInChips;
end


SeatManager.expChangeAnimation = function(self, exp)
    local userSeat = self:getSelfSeat();
    if userSeat ~= nil then
        userSeat:playExpAnim(exp);
    end
    local userData = Model.getData(ModelKeys.USER_DATA);
	if userData ~= nil then
		userData.experience = userData.experience + exp;
	end
    Model.setData(ModelKeys.USER_DATA, userData);
end

SeatManager.getDealerHandlePos = function(self)
    local rx , ry = 0, 0;
    rx = System.getLayoutWidth() / 2;
    ry = self.m_seatPositionV[9].y + UserSeat.SEAT_HEIGHT;
    return rx, ry;
end