require("game/scene/comp/room/pokerCard");

HandCard = new(Node);

HandCard.CARD_0_ROTATION = -4;
HandCard.CARD_1_ROTATION = 10;
HandCard.LEFT_CARD_OFFSET = -15;
HandCard.RIGHT_CARD_OFFSET = 15;

HandCard.ctor = function (self)
    self.card0Y = 8;
    self.card1X = 40;
    self.srcCard1X = 28;
    self.m_handCard = {};
    self.m_handCard[1] = new(PokerCard);
    self.m_handCard[2] = new(PokerCard);

    self.m_handCard[1].m_pickable = false;
    self.m_handCard[2].m_pickable = false;

    self:addChild(self.m_handCard[1]);
    self:addChild(self.m_handCard[2]);  
end


HandCard.setHandCard = function (self,value1,value2)
    if value1 and value2 and value1 > 0 and value2 > 0 then        
        if self.m_handCard[1] ~= nil then
            if self.m_handCard[1].m_isValue == false then
                self.m_handCard[1]:createCard(value1);
            else
                self.m_handCard[1]:update(value1);
            end
        end

        if self.m_handCard[2] ~= nil then
            if self.m_handCard[2].m_isValue == false then
                self.m_handCard[2]:createCard(value2);
            else
                self.m_handCard[2]:update(value2);
            end
        end
    end
end

HandCard.setHandCardShowingPosition = function (self, x, y)
    local posX = x or 0;   
    local posY = y or 0;
    self.m_handCard[1]:setPos(posX + HandCard.LEFT_CARD_OFFSET,posY);
    self.m_handCard[2]:setPos(posX + HandCard.RIGHT_CARD_OFFSET,y);
    self.m_handCard[1]:addPropRotateSolid(0,HandCard.CARD_0_ROTATION,1);
    self.m_handCard[2]:addPropRotateSolid(0,HandCard.CARD_1_ROTATION,1);
end

HandCard.resetHandCardPosition = function (self)
    if self.m_handCard[1] then 
        self.m_handCard[1]:setPos(0,0);
        self.m_handCard[1]:removeProp(0,HandCard.CARD_0_ROTATION,1);
    end
    if self.m_handCard[2] then 
    self.m_handCard[2]:setPos(self.srcCard1X,0);
    self.m_handCard[2]:removeProp(0,HandCard.CARD_1_ROTATION,1);
    end
end

HandCard.flipHandCard = function (self,playSound)
    if self.m_handCard[1] then
        self.m_handCard[1]:flipCardStage1();
    end
    if self.m_handCard[2] then
	    self.m_handCard[2]:flipCardStage1();
    end
	--if playSound then
	--	self.m_timeout = setTimeout(playSoundDelay, 500);
	--end
    if self.m_handCardShowed then
        self.m_handCardShowed = true;
    end
end

HandCard.fadeHandCard = function (self)
    if self.m_handCard[1] then
        self.m_handCard[1]:showFadeCard();
    end
    if self.m_handCard[2] then
	    self.m_handCard[2]:showFadeCard();
    end
end

HandCard.showHandCard = function (self)
    if self.m_handCard[1] then
        self.m_handCard[1]:setVisible(true);
    end
    if self.m_handCard[2] then
	    self.m_handCard[2]:setVisible(true);
    end
end

HandCard.hideHandCard = function (self)
    if self.m_handCard[1] then
        self.m_handCard[1]:setVisible(false);
    end
    if self.m_handCard[2] then
	    self.m_handCard[2]:setVisible(false);
    end
end

HandCard.hightLightHandCard = function (self,value)
    if value and value > 0 then
        local cardType, cardValue = self.m_handCard[1]:getCardTypeAndValueByValue(value);
        if cardType and cardValue then
	        for i=1,2 do
		        if self.m_handCard[i].m_cardValue == cardValue and self.m_handCard[i].m_cardType == cardType then
			        self.m_handCard[i]:showHighLight();
			        break;
		        end
	        end  
        end
    end
end

HandCard.refresh = function (self)
    
    self.m_handCard[1]:setVisible(false);
    self.m_handCard[2]:setVisible(false);
    self.m_handCard[1]:refresh();
    self.m_handCard[2]:refresh();
end


--[Comment]
--ǿ��ˢ������
HandCard.forceReresh = function(self)
    self.m_handCard[1]:refresh();
    self.m_handCard[2]:refresh();
end

HandCard.getHandCard = function (self)
	return self.m_handCard;
end

HandCard.visibleHandCard = function (self)
    self:setVisible(true);
	self.m_handCard[1]:showCard();
	self.m_handCard[2]:showCard();
end

HandCard.playSoundDelay = function (self)
    --
end

HandCard.getHandCardV = function(self)
    return self.m_handCard;
end