require("game/scene/comp/room/tableLight")

--[Comment]
--���涯������[����]
TableAnimationManager = {};
		
TableAnimationManager.m_scene        = nil;
TableAnimationManager.m_container    = nil;
TableAnimationManager.m_youwin       = nil;
TableAnimationManager.m_tableLight   = nil;
		
TableAnimationManager.initialize = function(self, scene)
	self.m_scene = scene;
	self.m_container = new(Node)
	self.m_scene:addChild(self.m_container);
	self.m_tableLight = new(TableLight, "room/room-table-light.png");
    self.m_tableLight:setVisible(false);
    self.m_container:addChild(self.m_tableLight);
    --self.m_scene:setEventTouch(self,self.onEventTouch);
end

TableAnimationManager.onEventTouch = function (self, finger_action, x, y, drawing_id_first, drawing_id_current, event_time)
    --self:youWin();
end
	
TableAnimationManager.youWin = function(self)
	if self.m_youwin ~= nil then
        self.m_youwin:dtor();
        self.m_youwin = nil;
    end
    self.m_youwin = AtomAnimManager:playAnim("atomAnimTable/room/anim_large_win", self.m_scene);
	if not TutotiaKit.isTutotia() then
		setTimeout(self.removeYouWinFromParent, self, 3000);
	end
end

TableAnimationManager.removeYouWinFromParent = function(self)
end
		
TableAnimationManager.showTableLight = function(self, seatId)
	self.m_tableLight:setVisible(true);
	local userSeat = SeatManager:getUserSeat(seatId);
	local x = SeatManager.m_seatPositionV[userSeat.m_positionId].x + UserSeat.SEAT_WIDTH * 0.5;
	local y = SeatManager.m_seatPositionV[userSeat.m_positionId].y + UserSeat.SEAT_HEIGHT * 0.5;
    self.m_tableLight:rotation({x=x,y=y});
end

TableAnimationManager.hideTableLight = function(self)
    self.m_tableLight:setVisible(false);
end
			

TableAnimationManager.showContainer = function(self)
	self.m_container:setVisible(true);
end
		
TableAnimationManager.cleanUp = function(self)
	self.m_container:setVisible(false);
end

TableAnimationManager.addChild = function(self, displayObject)
    if displayObject ~= nil and not self.m_container:contains(displayObject) then
	    self.m_container:addChild(displayObject);
    end
end

TableAnimationManager.getChildByName = function(self, name)
    local child = nil;
    if self.m_container ~= nil then
        child = self.m_container:getChildByName(name);
    end
    return child;
end


TableAnimationManager.refresh = function(self)
end

--[Comment]
--��ȡ����
TableAnimationManager.getContainer = function(self)
    return self.m_container;
end