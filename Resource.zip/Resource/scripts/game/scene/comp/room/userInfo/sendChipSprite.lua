require("view/room/layout_room_userinfo_send_chip");
--[Comment]
--赠送筹码容器
SendChipSprite = class(Node, false)

SendChipSprite.ctor = function(self, sendChips)
    super(self);
    self.m_root     = SceneLoader.load(layout_room_userinfo_send_chip);   
    self.m_txtChip  = LayoutText.createByText(self.m_root:getNodeByName("container.bg_chip_label.txt_chip_label"), true);
    local str       = STR_COMMON_CURRENCY_LABEL..Formatter.formatBigNumber(sendChips);
    self.m_txtChip:setText(str);
	
    self.m_chipContainer = self.m_root:getNodeByName("container.chip_container");

	local chips = ChipManager:takeOutChipInfos(sendChips);
	
    --生成筹码堆
	if chips ~= nil then
		for i = 1,  #chips do
			local chip = ChipManager:getChip(chips[i].number);
			chip:setPos(0, -i * ChipManager.CHIP_THICK)
			chip:setAlpha(1.0)
			self.m_chipContainer:addChild(chip);
		end
	end
	self:setSize(self.m_root:getSize());
    self:addChild(self.m_root);
	self:setPickable(false);
end