----------------------------------------------------------
require("view/room/layout_room_self_userinfo");

MyselfUserInfoPopUp = class(PopupDialog, false);

MyselfUserInfoPopUp.ctor = function(self)
	super(self, layout_room_self_userinfo, true);

	self.m_seatData = nil;--:TableUserData;
	self.m_userData = nil;--:Object;
	self.m_photoLoader = nil;--:PhotoLoader;
	self.m_femalePhotoFrameTexture = nil;--:Scale9Textures;
	self.m_malePhotoFrameTexture = nil;--:Scale9Textures;
	self.m_photoFrame = nil;--:Scale9Image;
	self.m_chipSprite = nil;--:Sprite;
	self.m_chipLabel = nil;--:Label;
	self.m_levelSprite = nil;--:Sprite;
	self.m_levelLabel = nil;--:Label;
	self.m_score = nil;--:Label;
	self.m_winRate = nil;--:Label;
	self.m_myUid = nil;--:Label;
	self.m_ranking = nil;--:Label;
	self.m_userNick = nil;--:StageTextTextEditor;
	self.m_vipIcon = nil;--:Image;
	self.m_myFriendButton = nil;--:DynamicHitAreaButton;
	self.m_myPropButton = nil;--:DynamicHitAreaButton;
	self.m_myGiftButton = nil;--:DynamicHitAreaButton;
	self.m_closeButton = nil;--:DynamicHitAreaButton;

	self:initialize();
end

MyselfUserInfoPopUp.initialize = function(self)--override protected
	self.m_closeButton = self.m_root:getNodeByName("bg.btn_close");
	--头像
	self.m_photoLoader = self.m_root:getNodeByName("bg.head_face");
	--头像边框
	self.m_femalePhotoFrameTexture = "userinfo/user_info_photo_frame_female.png";
	self.m_malePhotoFrameTexture = "userinfo/user_info_photo_frame_male.png";
	self.m_photoFrame = self.m_root:getNodeByName("bg.head_face.head_frame");
	--VIP
	self.m_vipIcon = self.m_root:getNodeByName("bg.head_face.vip");
	self.m_vipIcon:setVisible(false);
	--名字
	self.m_userNick = self.m_root:getNodeByName("bg.username");
	-- 筹码
	self.m_chipLabel = self.m_root:getNodeByName("bg.chip_label");
	-- 等级
	self.m_levelLabel = self.m_root:getNodeByName("bg.level_label");
	--排名
	self.m_ranking = self.m_root:getNodeByName("bg.ranking");
	self.m_ranking:setText(STR_ROOM_USERINFO_RANKING .. ">10000");
	-- 积分
	self.m_score = self.m_root:getNodeByName("bg.score");
	self.m_score:setText(STR_COMMON_USER_SCORE .. "0");
	--胜率
	self.m_winRate = self.m_root:getNodeByName("bg.win_rate");

	self.m_myUid = self.m_root:getNodeByName("bg.uid");

	-- 我的好友
	self.m_myFriendButton = self.m_root:getNodeByName("bg.btn_myfriend");
	local label = self.m_root:getNodeByName("bg.btn_myfriend.btnlabel_myfriend");
	label:setText(STR_ROOM_MY_FRIEND);
	-- 我的道具
	self.m_myPropButton = self.m_root:getNodeByName("bg.btn_my_prop");
	local label = self.m_root:getNodeByName("bg.btn_my_prop.btnlabel_my_prop");
	label:setText(STR_ROOM_MY_PROP);
	-- 我的礼物
	self.m_myGiftButton = self.m_root:getNodeByName("bg.btn_my_gift");
	local label = self.m_root:getNodeByName("bg.btn_my_gift.btnlabel_my_gift");
	label:setText(STR_GIFT_MY_GIFT);

	Model.watchProperty(ModelKeys.USER_DATA, "vip", self, function(self, val)
		val = val or 0;
		self.m_vipIcon:setVisible(val > 0 and true or false);
		if(val > 0) then
			self.m_vipIcon:setFile("vip_icon_" .. val .. ".png");
			As3Kit.reAdjustSize (self.m_vipIcon);
		end
	end);
end

MyselfUserInfoPopUp.update = function(self, data)
	self:setSeatData(data);
end

MyselfUserInfoPopUp.onPopupEnd = function(self)--private
	-- 单机游戏
	self.m_userData = Model.getData(ModelKeys.USER_DATA);
	if(self.m_userData) then
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_GET_USER_RANKING, self.m_seatData.uid);
	end

	self.m_myFriendButton:setOnClick(self, self.buttonTriggeredMyFriend);
	self.m_myPropButton:setOnClick(self, self.buttonTriggeredMyProp);
	self.m_myGiftButton:setOnClick(self, self.buttonTriggeredMyGift);
	self.m_closeButton:setOnClick(self, self.closeButtonHandler);

	Model.watchData(ModelKeys.ROOM_USER_RANKING_DATA, self, self.getUserRankingData, false);
end

MyselfUserInfoPopUp.dtor = function(self)
	Model.unwatchData(ModelKeys.ROOM_USER_RANKING_DATA, self, self.getUserRankingData);
end

MyselfUserInfoPopUp.getUserRankingData = function(self, data)--private
	--排名
	if (data.rankMoney > 10000) then
		self.m_ranking:setText(STR_ROOM_USERINFO_RANKING .. ">10000");
	else
		self.m_ranking:setText(STR_ROOM_USERINFO_RANKING .. data.rankMoney);
	end

	self:draw();
end

MyselfUserInfoPopUp.draw = function(self)--override protected
	self:commitData();
end

MyselfUserInfoPopUp.commitData = function(self)--private
	self.m_userData = Model.getData(ModelKeys.USER_DATA);
	-- 昵称
	self.m_userNick:setText(self.m_seatData.name);
	-- 积分
	self.m_score:setText(STR_COMMON_USER_SCORE .. self.m_userData.score);
	--资产
	self.m_chipLabel:setText(STR_COMMON_CURRENCY_LABEL .. Formatter.formatBigNumber(self.m_seatData.totalChips));
	--胜率
	local winrate = 0;
	if (self.m_seatData.winRound + self.m_seatData.loseRound == 0) then
		winrate = 0;
	else
		winrate = math.modf(self.m_seatData.winRound / (self.m_seatData.winRound + self.m_seatData.loseRound) * 100);
	end
	self.m_winRate:setText(StringKit.substitute(STR_ROOM_USERINFO_WINRATE, winrate));
	--等级头衔
	self.m_levelLabel:setText(STR_ROOM_USERINFO_LEVEL .. ExpKit.getLevelByExp(self.m_seatData.exp));
	--uid
	self.m_myUid:setText("UID:" .. self.m_userData.uid);
	--用户头像
	if (self.m_seatData.gender == "m") then
		self.m_photoFrame:setFile(self.m_malePhotoFrameTexture);
	else
		self.m_photoFrame:setFile(self.m_femalePhotoFrameTexture);
	end
	if (string.len(self.m_seatData.photoUrl) <= 5) then
		local guestPhotoTexture = "userinfo/imgface_" .. self.m_seatData.photoUrl .. ".jpg";
		if (FileKit.isFileExist(guestPhotoTexture)) then
			self.m_photoLoader:setFile(guestPhotoTexture);--获取游客头像
		else
			if (self.m_seatData.gender == "m") then
				self.m_photoLoader:setFile("room/room-default-male-photo.png");
			else
				self.m_photoLoader:setFile("room/room-default-female-photo.png");
			end
		end
	elseif (self.m_seatData.gender == "m") then
		self.m_photoLoader:setFile("room/room-default-male-photo.png");
	else
		self.m_photoLoader:setFile("room/room-default-female-photo.png");
	end
end

MyselfUserInfoPopUp.closeButtonHandler = function(self)--private
	self:close();
end

MyselfUserInfoPopUp.buttonTriggeredMyFriend = function(self)--private
	FriendModule.openFriendPopUp();
	self:close();
end

MyselfUserInfoPopUp.buttonTriggeredMyProp = function(self)
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_OWNER_PROPS_PAGE);
	self:close();
end

MyselfUserInfoPopUp.buttonTriggeredMyGift = function(self)
--?	FrameworkGlobal.context.dispatchEventWith(CommandEventNames.OPEN_GIFT_POPUP, false, {isInRoom:false, tabId:2});
	self:close();
end

MyselfUserInfoPopUp.setSeatData = function(self, value)--public
	self.m_seatData = value;
--	this.invalidate(INVALIDATION_FLAG_DATA);
	self:draw();
end
