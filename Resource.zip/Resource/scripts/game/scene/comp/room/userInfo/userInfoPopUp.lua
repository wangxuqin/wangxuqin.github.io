---------------------------------------------------
require("view/room/layout_room_userinfo");
require("game/scene/comp/room/userInfo/hddjButton");

UserInfoPopUp = class(PopupDialog, false);

UserInfoPopUp.ctor = function(self)--public
	super(self, layout_room_userinfo, true);

	self.m_photoLoader = nil;--:PhotoLoader;
	self.m_femalePhotoFrameTexture = nil;--:Scale9Textures;
	self.m_malePhotoFrameTexture = nil;--:Scale9Textures;
	self.m_photoFrame = nil;--:Scale9Image;
	self.m_chipSprite = nil;--:Sprite;
	self.m_chipLabel = nil;--:Label;
	self.m_levelSprite = nil;--:Sprite;
	self.m_levelLabel = nil;--:Label;
	self.m_winRate = nil;--:Label;
	self.m_ranking = nil;--:Label;
	self.m_userNick = nil;--:StageTextTextEditor;
	self.m_vipIcon = nil;--:Image;
	self.m_userUid = nil;--:Label;
	self.m_othersPanel = nil;--:Sprite;
	self.m_addFriendIcon = nil;--:Image;
	self.m_sendGiftIcon = nil;--:Image;
	self.m_operationButton = nil;--:Button;
	self.m_kickButton = nil;--:DynamicHitAreaButton;
	self.m_container = nil;--:ScrollContainer;
	self.m_sendChipPanel = nil;--:SendChipPanel;
	self.m_rightWidth = 0;
	self.m_leftWidth = 0;
	self.m_seatData = nil;--:TableUserData;
	self.m_myFriend = false;
	self.m_sendChipData = nil;--:SendChipsData;
	self.m_sendChip = 500;

	self:initialize();
end

UserInfoPopUp.dtor = function(self)
	Model.unwatchData(ModelKeys.ROOM_USER_RANKING_DATA, self, self.getUserRankingData);
end

UserInfoPopUp.initialize = function(self)--override protected
	--ͷ��
	self.m_photoLoader = self.m_root:getNodeByName("bg.head_face");
	self.m_photoLoader:setFile("room/room-default-male-photo.png");
	--ͷ��߿�
	self.m_femalePhotoFrameTexture = "userinfo/user_info_photo_frame_female.png";
	self.m_malePhotoFrameTexture = "userinfo/user_info_photo_frame_male.png";
	self.m_photoFrame = self.m_root:getNodeByName("bg.head_face.head_frame");
	--VIP
	self.m_vipIcon = self.m_root:getNodeByName("bg.head_face.vip");
	self.m_vipIcon:setVisible(false);
	--���˰�ť
	self.m_kickButton = self.m_root:getNodeByName("bg.btn_kick");
	self.m_kickButton:setVisible(false);
	--uid
	self.m_userUid = self.m_root:getNodeByName("bg.uid");
	--����
	self.m_userNick = self.m_root:getNodeByName("bg.username");
	--������ť
	self.m_addFriendIcon = "room/user-info-add-friend-btn-icon.png";
	self.m_sendGiftIcon = "room/user-info-send-gift-btn-icon.png";

	self.m_operationButton = self.m_root:getNodeByName("bg.btn_operation");
	self.m_operationIcon = self.m_root:getNodeByName("bg.btn_operation.icon");
	self.m_operationLabel = self.m_root:getNodeByName("bg.btn_operation.label");
	self.m_operationIcon:setFile(self.m_addFriendIcon);
	self.m_operationLabel:setText(STR_ROOM_ADD_FRIEND);
	-- ����
	self.m_chipLabel = self.m_root:getNodeByName("bg.chip");
	-- �ȼ�
	self.m_levelLabel = self.m_root:getNodeByName("bg.level");
	--ʤ��
	self.m_winRate = self.m_root:getNodeByName("bg.win_rate");
	--����
	self.m_ranking = self.m_root:getNodeByName("bg.ranking");
	self.m_ranking:setText(STR_ROOM_USERINFO_RANKING .. ">10000");

	self.m_currencyMultiple = tonumber(STR_COMMON_CURRENCY_MULTIPLE);
	--������������
	local mask = self.m_root:getNodeByName("bg.mask");
	local wMask,hMask = mask:getSize();
	self.m_container = new(ScrollView2, 3, 3, wMask-6, hMask-6, true);
	mask:addChild(self.m_container);
	local numButtonPerLine = 4;
	local item = nil;
	for i=1,13 do
		if((i-1) % numButtonPerLine == 0) then
			item = new(DrawingEmpty);
			item:setSize(nil, 120);
			self.m_container:addChild(item);
		end
		local hddjButton = new(HddjButton, i);
		hddjButton:setPos(59 + 119 * ((i-1) % numButtonPerLine), 60);
		hddjButton:setClickCallback(self, self.hddjButtonTriggeredHandler);
		item:addChild(hddjButton);
	end
	--���ͳ���
	self.m_sendChipPanel = self.m_root:getNodeByName("bg.sendchip_panel");
	local slider = self.m_root:getNodeByName("bg.sendchip_panel.slider");
	local x,y = slider:getPos();
	local w,h = slider:getSize();
	local align = slider:getAlign();
	self.m_sendChipSlider = new(Slider, w, nil,
		"room/user-info-send-chip-slider-track-bg.png",
		"room/user-info-send-chip-slider-track-overlay.png",
		"room/user-info-send-chip-slider-thumb.png", 4, 4, 4, 4);
	self.m_sendChipSlider:setAlign(align);
	self.m_sendChipSlider:setPos(x, y);
	slider:getParent():addChild(self.m_sendChipSlider);
	local userData = self:getUserData();
	if ( userData["isSendChips"] and userData["isSendChips"] == 0) then
		self.m_sendChipPanel:setVisible(false);
		local w,h = self:getDialog():getSize();
		mask:setSize(nil, h - 16 - 16);
		self.m_container:setSize(nil, h - 16 - 16 - 6);
	end
	self.m_sendChipLabel = self.m_root:getNodeByName("bg.sendchip_panel.btn_send.label_chip");

	self.m_sendChipData = new(SendChipsData);
	Model.watchData(ModelKeys.ROOM_USER_RANKING_DATA, self, self.getUserRankingData, false);

	if(self:getUserData()) then
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.GET_USER_HDDJ_NUMBER);
	end

	self.m_sendChipSlider:setProgress(0.5);
	self:__onSliderChange(0.5);

	-- �ж��Ƿ��Ǻ���
	local friendList = Model.getData(ModelKeys.FRIEND_UID_LIST);
	if (friendList) then
		for n=1,#friendList do
			if (friendList[n] == self.m_seatData.uid) then
				self.m_myFriend = true;
				break;
			end
		end
	end

	--������Ϸ��������
	if(not self:getUserData()) then
		self.m_kickButton:setVisible(false);
		self.m_operationButton:setEnable(false);
	else
		-- ˽�˷���ʾ���˰�ť
		if(Model.getData(ModelKeys.PRIVATE_ROOM_OWNER) == self:getUserData().uid) then
			self.m_kickButton:setVisible(true);
		else
			self.m_kickButton:setVisible(false);
		end
		if (self.m_myFriend) then
			self.m_operationIcon:setFile(self.m_sendGiftIcon);
			self.m_operationLabel:setText(STR_ROOM_PRESENT_GIFT);
		else
			self.m_operationIcon:setFile(self.m_addFriendIcon);
			self.m_operationLabel:setText(STR_ROOM_ADD_FRIEND);
		end
	end
end

UserInfoPopUp.update = function(self, data)
	self:setSeatData(data);
end

UserInfoPopUp.onPopupEnd = function(self)
	--�¼���Ӧ
	self.m_kickButton:setOnClick(self, self.kickButtonTriggered);
	self.m_operationButton:setOnClick(self, self.addFriendTriggered);
	local btn = self.m_root:getNodeByName("bg.btn_close");
	btn:setOnClick(self, self.__onClickClose);
	local btn = self.m_root:getNodeByName("bg.sendchip_panel.btn_send");
	btn:setOnClick(self, self.sendTriggeredHandler);
	self.m_sendChipSlider:setOnChange(self, self.__onSliderChange);
end

UserInfoPopUp.__onClickClose = function(self)
	self:close();
end

UserInfoPopUp.__onSliderChange = function(self, data)
	self.m_sendChip = tonumber(data) * self.m_currencyMultiple * 1000;
	if(self.m_sendChip <= 0) then
		self.m_sendChip = 1;
	end
	SoundManager.playSound("WheelTick");
	self.m_sendChipLabel:setText(STR_COMMON_NUMBER_CURRENCY_LABEL .. Formatter.formatBigNumber(math.modf(self.m_sendChip)));
end

UserInfoPopUp.getUserRankingData = function(self, data)--private
	if(data == nil) then
		return;
	end
	if(data.rankMoney == nil) then
		return;
	end
	--����
	if (data.rankMoney > 10000) then
		self.m_ranking:setText(STR_ROOM_USERINFO_RANKING .. ">10000");
	else
		self.m_ranking:setText(STR_ROOM_USERINFO_RANKING .. data.rankMoney);
	end

	self:draw();
end

UserInfoPopUp.kickButtonTriggered = function(self)--private
--?	JuhuaAndHintManager.showJuhua(this);
	self:close();
	local kickdata = {["mod"]="mobilePrivateRoom", ["act"]="kick", ["puid"]=self.m_seatData.uid};
	HttpService.post(kickdata, self, self.resultCallback, self.errorCallback, self.errorCallback);
end

UserInfoPopUp.errorCallback = function(self)--private
	TopTipKit.badNetworkHandler();
end

UserInfoPopUp.resultCallback = function(self, data)--private
	if(data == nil) then
		return;
	end
	local checkkickdata = json.decode(data);
	if(checkkickdata.ret == 1) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_ONWER_KICK_SUCCESS);
	elseif(checkkickdata.ret == -3) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_ONWER_KICK_FAIL);
	else
		TopTipKit.badNetworkHandler();
	end
end

UserInfoPopUp.sendTriggeredHandler = function(self)--private
	local selfSeatId = SeatManager.selfSeatId;
	self.m_sendChipData.sendChips = self.m_sendChip;
	self.m_sendChipData.recieverSeatId = self.m_seatData.seatId;
	self.m_sendChipData.senderSeatId = selfSeatId;
	if (SeatManager.roomType == LoginSuccData.ROOM_TYPE_NORMAL) then
		if (selfSeatId ~= -1) then
			EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_BROADCAST_SEND_CHIP, self.m_sendChipData);
			self:close();
		else
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_SIT_DOWN_SEND_CHIPS);
		end
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_MATCH_TABLE_SEND_CHIPS);
	end
end

UserInfoPopUp.addFriendTriggered = function(self)--private
	local text = self.m_operationLabel:getText();
	if (text == STR_ROOM_ADD_FRIEND) then
		local addFriendData = {["sendSeatId"]=SeatManager.selfSeatId, ["receiveSeatId"]=self.m_seatData.seatId};
		--�����������ͨ��server���й㲥����������ֻ�������˿��õ��ļ����Ѷ���
		if (SeatManager.selfSeatId ~= -1) then
			EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_BROADCAST_ADD_FRIEND, addFriendData);--֪ͨserver���й㲥
		else
			addFriendData.notInSeat = true;
			Model.setData(ModelKeys.ROOM_ADD_FRIEND_DATA, addFriendData);
		end
		--����php��Ϊ����
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_REQUEST_ADD_FRIEND, self.m_seatData.uid);
		self.m_operationIcon:setFile(self.m_sendGiftIcon);
		self.m_operationLabel:setText(STR_ROOM_PRESENT_GIFT);
	elseif(text == STR_ROOM_PRESENT_GIFT) then
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.OPEN_GIFT_POPUP, {isInRoom=true, uid=self.m_seatData.uid, seatId=self.m_seatData.seatId, userNick=self.m_seatData.name, tabId=0});
	end
	self:close();
end

UserInfoPopUp.hddjButtonTriggeredHandler = function(self, hddjId)--private
	SoundManager.playButtonClickSound();
	local selfSeatId = SeatManager.selfSeatId;
	local loginSuccData = Model.getData(ModelKeys.ROOM_LOGIN_SUCC_DATA);
	if (LoginSuccData.ROOM_TYPE_TOURNAMENT == loginSuccData.roomType) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_MATCH_ROOM_NOT_PLAY_HDDJ);
	elseif (selfSeatId ~= -1) then
		local userData = self:getUserData();
		if(userData == nil) then
			self:close();
			--���Ŷ���
			local hddjData1 = new(HddjData);
			hddjData1.sendSeatId = selfSeatId;
			hddjData1.hddjId = hddjId;
			hddjData1.receiveSeatId = self.m_seatData.seatId;
			Model.setData(ModelKeys.ROOM_HDDJ_DATA, hddjData1);
		elseif (Model.getData(ModelKeys.USER_HDDJ_NUMBER) > 0) then
			EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_BROADCAST_SEND_HDDJ, {["sendSeatId"]=selfSeatId, ["hddjId"]=hddjId, ["sendedSeatId"]=self.m_seatData.seatId});
			self:close();
			--���Ŷ���
			local hddjData = new(HddjData);
			hddjData.sendSeatId = selfSeatId;
			hddjData.hddjId = hddjId;
			hddjData.receiveSeatId = self.m_seatData.seatId;
			hddjData.uid = userData.uid;
			Model.setData(ModelKeys.ROOM_HDDJ_DATA, hddjData);
		else
			--���ӵ��ߴΔ��������ʾ
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,{
				message = STR_ROOM_NOT_ENOUGH_HDDJ,
				confirm = STR_COMMON_BUY,
				obj = self,
				callback = self.confirmHandler,
			});
		end
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_SIT_DOWN_PLAY_HDDJ);
	end
end

UserInfoPopUp.confirmHandler = function(self, types)--private
	if (types == DialogCallback.CONFIRM) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_PROPS_PAGE);
		self:close();
	end
end

UserInfoPopUp.commitData = function(self)--private
	--uid
	self.m_userUid:setText(STR_ROOM_USER_INFO_PAGE_UID .. tostring(self.m_seatData.uid));
	--����
	self.m_userNick:setText(self.m_seatData.name);
	--VIP
	self.m_vipIcon:setVisible(self.m_seatData.vip > 0);
	if(self.m_seatData.vip > 0 and FileKit.isFileExist("store/vip_icon_" .. self.m_seatData.vip)) then
		self.m_vipIcon:setFile("store/vip_icon_" .. self.m_seatData.vip);
		As3Kit.reAdjustSize (self.m_vipIcon);
	end
	--�ʲ�
	self.m_chipLabel:setText(STR_COMMON_CURRENCY_LABEL .. Formatter.formatBigNumber(self.m_seatData.totalChips));
	--ʤ��
	local winrate = 0;
	if (self.m_seatData.winRound + self.m_seatData.loseRound == 0) then
		winrate = 0;
	else
		winrate = math.modf(self.m_seatData.winRound / (self.m_seatData.winRound + self.m_seatData.loseRound) * 100);
	end
	self.m_winRate:setText(StringKit.substitute(STR_ROOM_USERINFO_WINRATE, winrate));
	--����
	local userData = self:getUserData();
	if(userData) then
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_GET_USER_RANKING, self.m_seatData.uid);
	end
	--�ȼ�ͷ��
	self.m_levelLabel:setText(STR_ROOM_USERINFO_LEVEL .. ExpKit.getLevelByExp(self.m_seatData.exp));
	--�û�ͷ��
	if (self.m_seatData.gender == "m") then
		self.m_photoFrame:setFile(self.m_malePhotoFrameTexture);
	else
		self.m_photoFrame:setFile(self.m_femalePhotoFrameTexture);
	end
	if (string.len(self.m_seatData.photoUrl) <= 5) then
		local guestPhotoTexture = "userinfo/imgface_" .. self.m_seatData.photoUrl .. ".jpg";
		if (FileKit.isFileExist(guestPhotoTexture)) then
			self.m_photoLoader:setFile(guestPhotoTexture);--��ȡ�ο�ͷ��
		else
			if (self.m_seatData.gender == "m") then
				self.m_photoLoader:setFile("room/room-default-male-photo.png");
			else
				self.m_photoLoader:setFile("room/room-default-female-photo.png");
			end
		end
	elseif (self.m_seatData.gender == "m") then
		self.m_photoLoader:setFile("room/room-default-male-photo.png");
	else
		self.m_photoLoader:setFile("room/room-default-female-photo.png");
	end
end

UserInfoPopUp.draw = function(self)--override protected
	self:commitData();
end

UserInfoPopUp.setSeatData = function(self, value)--public
	self.m_seatData = value;
	self:draw();
end

UserInfoPopUp.getUserData = function(self)--public static
	return Model.getData(ModelKeys.USER_DATA);
end
