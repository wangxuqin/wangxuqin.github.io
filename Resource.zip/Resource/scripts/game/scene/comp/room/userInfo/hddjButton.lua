---------------------------------------------------
HddjButton = class(Node, false);

HddjButton.TAG = "HddjButton";

HddjButton.ctor = function(self, id)
	super(self);

	self.m_hddjId = id;
	self.m_upImage = new(Image, "room/user-info-hddj-btn-up.png", nil, nil, 10, 10, 10, 12);
	self.m_upImage:setAlign(kAlignCenter);
	self.m_upImage:setSize(96, 96);
	self:addChild(self.m_upImage);

	self.m_icon = new(Image, "room/hddj/hddj_" .. id .. ".png");
	self.m_icon:setAlign(kAlignCenter);
	self:addChild(self.m_icon);

	self.m_downImage = new(Image, "main/main_page_btn_down_skin.png", nil, nil, 7, 7, 7, 7);
	self.m_downImage:setAlign(kAlignCenter);
	self.m_downImage:setSize(92, 92);
	self.m_downImage:setVisible(false);
	self.m_downImage:setPos(nil, -2);
	self:addChild(self.m_downImage);

	self.m_upImage:setEventTouch(self, self.__onTouch);
	self.m_clickCallback = {};
end

HddjButton.setClickCallback = function(self, obj, func)
	self.m_clickCallback.func = func;
	self.m_clickCallback.obj = obj;
end

HddjButton.__onTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
	TouchHelper.catch(self, finger_action, x, y);
	if(finger_action == kFingerDown) then
		self.m_downImage:setVisible(true);
	elseif(finger_action == kFingerUp) then
		self.m_downImage:setVisible(false);
		if(TouchHelper.isClick(self)) then
			if(self.m_clickCallback.func) then
				self.m_clickCallback.func(self.m_clickCallback.obj, self.m_hddjId);
			end
		end
	end
end
