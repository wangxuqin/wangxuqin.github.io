require("view/room/layout_user_crash");
UserCrash =class(PopupDialog, false)
UserCrash.m_postCounts=4;
UserCrash.m_userCashData = nil;


UserCrash.ctor = function(self)
    super(self, layout_user_crash, true);
    Model.watchData(ModelKeys.ROOM_USER_CRASH_DATA,self,self.open, false);
end


UserCrash.dtor = function(self)
    Model.unwatchData(ModelKeys.ROOM_USER_CRASH_DATA,self,self.open, false);
end

UserCrash.onPopupEnd = function(self)
    self.m_btnClose     = self.m_root:getNodeByName("bg.btn_close");    
    self.m_btnBuyChip   = self.m_root:getNodeByName("bg.btn_buy_chips");
        
    self.m_txtTime      = self.m_root:getNodeByName("bg.img_center_bg.img_chip.img_time_bg.txt_time"); 
    self.m_txtReason    = self.m_root:getNodeByName("bg.img_center_bg.txt_reason");
    self.m_txtPercent   = self.m_root:getNodeByName("bg.img_center_bg.img_chip.img_time_bg.txt_percent");  

    self.m_txtTitle     = self.m_root:getNodeByName("bg.txt_title");
    self.m_txtBuyChips  = self.m_root:getNodeByName("bg.btn_buy_chips.txt_buy_chips");

    self.m_txtTitle:setText(STR_ROOM_USER_CRASH_TITLE);
    self.m_txtBuyChips :setText(STR_ROOM_BUY_CHIPS_TEXT);
    self.m_txtReason:setText(STR_ROOM_CRASH_DESC_TEXT4);
    self.m_btnClose:setOnClick(self,self.onBtnClickClose);
    self.m_btnBuyChip:setOnClick(self,self.onBtnClickBuyChip);
    

    --[lucy����]
    self:__userCrashCallbackTest();
end

UserCrash.onBtnClickBuyChip = function(self)
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG);
    self:close();
end

UserCrash.onBtnClickClose = function(self)
    self:close();
end

UserCrash.open = function(self,data)
    self.m_data = data;    
    self:draw();
    local postData = {["mod"] = "break", ["act"] = "getInfo"};
    if data.field ~= nil then
        postData["field"] = data["field"];
    end
    --HttpService.post(postData, self, self.__userCrashCallback, self.__badNetworkLeaveRoomHandler, self.__badNetworkLeaveRoomHandler);   
end


UserCrash.draw = function(self)
    if self.m_data.times == 1 then
        self.m_txtReason:setText(StringKit.substitute(STR_ROOM_CRASH_DESC_TEXT1, tostring(self.m_data.subsidizeChips) ) );
    elseif self.m_data.times == 2 then
        self.m_txtReason:setText(StringKit.substitute(STR_ROOM_CRASH_DESC_TEXT2, tostring(self.m_data.subsidizeChips) ) );
    elseif self.m_data.times == 3 then
        if(self.m_userCashData and self.m_userCashData.ret == 1) then
            self.m_txtReason:setText(STR_ROOM_CRASH_DESC_TEXT4);
        else
            self.m_txtReason:setText(STR_ROOM_CRASH_DESC_TEXT3);
        end       
    else
        self.m_txtReason:setText(STR_ROOM_CRASH_DESC_TEXT3);
    end

    self.m_txtPercent:setText(StringKit.substitute(STR_ROOM_PERCENT_TEXT, tostring(self.m_data..info.discount)));
end

UserCrash.__userCrashCallbackTest = function (self)
	local returnObj = {};	
	if(returnObj)then
		returnObj.ret = 1
		returnObj.info = {};
		returnObj.info.expire = 60;
		returnObj.info.discount = 0.6 ;
		self.m_userCashData = returnObj;		
		self.m_remainTime = returnObj.info.expire;				
		self.m_percentNum= returnObj.info.discount;

        self.m_txtPercent:setText(StringKit.substitute(STR_ROOM_PERCENT_TEXT, tostring(self.m_percentNum)));
		self.m_txtTime:setText(ToolKit.secondTo0H0M0S(self.m_remainTime));

        intervalNum = setInterval(function()
	        self.m_remainTime =self.m_remainTime - 1;
	        if(self.m_remainTime == 0) then
		        clearInterval(intervalNum);
	        end
		    self.m_txtTime:setText(ToolKit.secondTo0H0M0S(self.m_remainTime));
        end,self,1000);
				
		Model.setData(ModelKeys.USER_CASH_DISCOUNT_DATA,returnObj.info);
	end
end

UserCrash.__userCrashCallback = function(self,data)
    if(data) then
		local returnObj = json.decode(data);
		if(returnObj.ret == 0) then --������ȷ�����û�û�г�ֵ�Ż�
			self.m_userCashData = returnObj;			
			Model.setData(ModelKeys.USER_CASH_DISCOUNT_DATA,nil);
		elseif(returnObj.ret == 1 and Model.getProperty(returnObj,"info") and Model.getProperty(returnObj.info,"expire") and Model.getProperty(returnObj.info,"discount")) then --������ȷ�����û����Ż�
			self.m_userCashData = returnObj;
			--invalidate(INVALIDATION_TEXT);
			self.m_remainTime = returnObj.info.expire;
					
			self.m_percentNum= returnObj.info.discount;
			self.m_txtTime:setText(ToolKit.secondTo0H0M0S(self.m_remainTime));
            intervalNum = setInterval(function()
	            self.m_remainTime =self.m_remainTime - 1;
	            if(self.m_remainTime == 0) then
		            clearInterval(intervalNum);
	            end
		        self.m_txtTime:setText(ToolKit.secondTo0H0M0S(self.m_remainTime));
            end,self,1000);
					
			Model.setData(ModelKeys.USER_CASH_DISCOUNT_DATA,returnObj.info);
		else --�������
			if(self.m_postCounts <= 0)then
				self.m_userCashData = nil;
				return;
			end
			Model.setData(ModelKeys.USER_CASH_DISCOUNT_DATA,nil);
			local postData = {["mod"] = "break", ["act"] = "getInfo"};
            if data.field ~= nil then
                postData["field"] = data["field"];
            end
            HttpService.post(postData, self, self.__userCrashCallback, self.__badNetworkLeaveRoomHandler, self.__badNetworkLeaveRoomHandler);
			self.m_postCounts = self.m_postCounts-1;
		end
	end
end






