require("view/room/layout_room_invite_friends_page");
require("game/scene/comp/room/inviteFriends/roomInviteFriendsItem");

RoomInviteFriendsPage = class(PopupDialog, false);
RoomInviteFriendsPage.TAG = "RoomInviteFriendsPage";


RoomInviteFriendsPage.ctor = function(self)
    super(self, layout_room_invite_friends_page, true);
    EventDispatcher.getInstance():registerEventList(self, RoomInviteFriendsPage.s_eventList);
end

RoomInviteFriendsPage.dtor = function(self)
    PopupDialog.dtor(self);
end


--弹出后，进行初始化
RoomInviteFriendsPage.onPopupEnd = function(self)
    self:getCtrls();
    self:initialize();
    self.m_timer = setInterval(self.timerHandler, self, 60 * 1000);
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FRIEND_REQUEST_REFRESH);
    self:addEventList();
    Model.setData(ModelKeys.HAS_POP_UP, true);
    self:watchData();
end

--关闭弹窗
RoomInviteFriendsPage.close = function(self)
    self:unwatchData();
    Model.setData(ModelKeys.HAS_POP_UP, false);
    self:removeEventList();
    clearInterval(self.m_timer);
    PopupDialog.close(self);
end

-- 初始化
RoomInviteFriendsPage.initialize = function(self)
    self.m_btnClose:setOnClick(self, self.onCloseBtnClick);
    self.m_txtTitle:setText(STR_FRIEND_INVITE_FRIEMDS_PAGE_TITEL);
    self.m_topLight:setTransparency(0.6);
    local width, height = self.m_friendContainer:getSize();
    self.m_friendListView = new(ListView2, 0, 0, width, height);
    self.m_friendContainer:addChild(self.m_friendListView); 
    self.m_operateList = {};
end



RoomInviteFriendsPage.getCtrls = function(self)
    self.m_btnClose         = self.m_root:getNodeByName("bg.btn_close");
    self.m_txtTitle         = self.m_root:getNodeByName("bg.txt_title");
    self.m_topLight         = self.m_root:getNodeByName("bg.img_top_light");
    self.m_friendContainer  = self.m_root:getNodeByName("bg.friend_container");
    self.m_loadAnimContainer = self.m_root:getNodeByName("bg.load_anim_container");
    self.m_loadAnimContainer:setVisible(false);
end

RoomInviteFriendsPage.addEventList = function(self)
    if self.m_eventList == nil then
        self.m_eventList = {
            {UIEvent,      UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM,           "close"};
            {CommandEvent, CommandEvent.s_cmd.UPDATA_FRIENDS_OPERATE_LIST,  "setOperateList"};
        };
    end
    EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
end

RoomInviteFriendsPage.removeEventList = function(self)
    if self.m_eventList ~= nil then
        EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
    end
    self.m_eventList = nil;
end


RoomInviteFriendsPage.update = function (self, data)
    self.m_data = data;
end

RoomInviteFriendsPage.onCloseBtnClick = function(self)
    self:close();
end

RoomInviteFriendsPage.timerHandler = function(self)
    Log.d(self.TAG, "timerHandler");
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FRIEND_REQUEST_REFRESH);
end

RoomInviteFriendsPage.watchData = function(self)
    if self.m_watchDataList == nil then
        self.m_watchDataList = {
            {ModelKeys.FRIEND_LIST_IS_LOADING, self, self.watchFriendListIsLoading, true};
            {ModelKeys.FRIEND_LIST_NEW,        self, self.watchFriendListNew,       true};
        }
    end
    Model.watchDataList(self.m_watchDataList);
end

RoomInviteFriendsPage.unwatchData = function(self)
    if self.m_watchDataList ~= nil then
        Model.unwatchDataList(self.m_watchDataList);
    end
    self.m_watchDataList = nil;
end


RoomInviteFriendsPage.watchFriendListIsLoading = function(self, value)
	self.m_isLoading = value;
end

RoomInviteFriendsPage.watchFriendListNew = function(self, value)
    if value == nil then
        self.m_miniLoad = AtomAnimManager.getInstance():playAnim("atomAnimTable/common/anim_common_miniLoad", self.m_loadAnimContainer, 0, 0, false);
		self.m_loadAnimContainer:setVisible(true);
        self.m_friendListView:setVisible(false);
	else
		if self.m_miniLoad ~= nil then
            self.m_miniLoad:release();
            self.m_miniLoad = nil;
        end
        self.m_loadAnimContainer:setVisible(false);
		self.m_friendListView:setVisible(true);
		self.m_vector = value or {};
		self.m_vector = AlgorithmKit.quickSort(self.m_vector, self, self.sortFunction);			
		self.m_operateList = Model.getData(ModelKeys.ROOM_FRIENDS_INVITE_OR_CALLBACK_LIST) or {};
		self:setOperateData(self.m_operateList, self.m_vector);
		self.m_friendListView:setAdapter(new(CacheAdapter, RoomInviteFriendsItem, self.m_vector));
    end
end

--[Comment]
RoomInviteFriendsPage.setOperateData = function(self, operateList, vector)
	if operateList == nil or #operateList == 0 then
        for i = 1, #vector do 
            vector[i].isOperate = false;
        end
        return;
	end
    for n = 1, #vector do 
        local m = 0;
        for j = 1, #operateList do
            if(vector[n].uid == operateList[j]) then
				break;
            end
            m = m + 1;
        end
        if m ~= #operateList  then
			vector[n].isOperate = true;
        else
            vector[n].isOperate = false;
        end
    end
end

--[Comment]
RoomInviteFriendsPage.setOperateList = function(self, data)
    local uid = data;
    local j = 0;
    for i = 1, #self.m_operateList do
        if(self.m_operateList[i] == uid) then
			break;
        end
        j = j + 1;
    end
    if j == #self.m_operateList then
        table.insert(self.m_operateList, uid);
    end
	Model.setData(ModelKeys.ROOM_FRIENDS_INVITE_OR_CALLBACK_LIST,self.m_operateList);
	self:setOperateData(self.m_operateList, self.m_vector);
    setTimeout(function (id) self:updataOperateList(id); end, self, 300000, uid);
end

RoomInviteFriendsPage.updataOperateList = function (self, id)
    for i=1, #self.m_operateList do
        if self.m_operateList[i] == id then
            table.remove(self.m_operateList, i);
        end
    end
    Model.setData(ModelKeys.ROOM_FRIENDS_INVITE_OR_CALLBACK_LIST,self.m_operateList);
	self:setOperateData(self.m_operateList,self.m_vector);
end

--[Comment]
--特定排序
RoomInviteFriendsPage.sortFunction = function(self, data1, data2)
	local ret = 0;
    if data1.status == data2.status then
		if data1.status == FriendVO.STATUS_AT_PLAY then
			if data1:isSupportTable() and not data2:isSupportTable() then
				ret = -1;
			elseif not data1:isSupportTable() and data2:isSupportTable() then
				ret = 1;
			else
				ret = 0;
			end
		elseif data1.status == FriendVO.STATUS_OFF_LINE then
			if data1.offLineDays > data2.offLineDays then
				ret = 1;
			elseif data1.offLineDays < data2.offLineDays then
				ret = -1;
			else
				ret = 0;
			end
		else
			ret = 0;
		end
	else
		local statusArray = {FriendVO.STATUS_AT_PLAY, FriendVO.STATUS_ON_LINE, FriendVO.STATUS_OFF_LINE};
		local index1 = ArrayKit.indexOf(statusArray, data1.status);
		local index2 = ArrayKit.indexOf(statusArray, data2.status);
		if index1 < index2 then
			ret = -1;
		elseif index1 > index2 then
			ret = 1;
		else
			ret = 0;
		end
	end
    return ret;
end