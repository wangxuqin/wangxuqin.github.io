require("game/model/data/vo/friendVO");
require("view/room/layout_room_inviteFriendsItem");
require("ui/ex/urlImage");

RoomInviteFriendsItem = class(Node);
RoomInviteFriendsItem.TAG = "RoomInviteFriendsItem";
RoomInviteFriendsItem.DEFAULT_FILE = 
{
    MALE    = "userinfo/imgface_default_male.jpg";
    FEMALE  = "userinfo/imgface_default_female.jpg";
}

RoomInviteFriendsItem.ONLINE_FILE = 
{
    ONLINE    = "room/room-invitefriends-online-icon.png";
    OFFLINE  = "room/room-invitefriends-offline-icon.png";
}
RoomInviteFriendsItem.ctor = function(self,data) 
    if not data or type(data)~="table" then
        Log.e(self.TAG, "ctor", "data is nil or not table");
        return;
    end 
    self:setSize(700,80); 
    self.m_root = SceneLoader.load(layout_room_inviteFriendsItem);
    self:addChild(self.m_root);
    self.m_data = data;
    self:getCtrls();
    self:initialize();
end

RoomInviteFriendsItem.dtor = function(self)
   
end

RoomInviteFriendsItem.getCtrls = function(self)
    self.m_imgOnline = self.m_root:getNodeByName("img_online");
    self.m_txtName = self.m_root:getNodeByName("txt_name");
    self.m_txtChip = self.m_root:getNodeByName("txt_chip");
    self.m_btnInvite = self.m_root:getNodeByName("btn_invite");
    self.m_txtInvite = self.m_root:getNodeByName("btn_invite.txt_invite");
end

RoomInviteFriendsItem.initialize = function(self)
    if self.m_data.sex == "m" then
        self:addHeadImage(RoomInviteFriendsItem.DEFAULT_FILE.MALE, self.m_data.image);
    else
        self:addHeadImage(RoomInviteFriendsItem.DEFAULT_FILE.FEMALE, self.m_data.image);
    end
    if self.m_data.status == FriendVO.STATUS_OFF_LINE then
        self.m_imgOnline:setFile(RoomInviteFriendsItem.ONLINE_FILE.OFFLINE);
    else
        self.m_imgOnline:setFile(RoomInviteFriendsItem.ONLINE_FILE.ONLINE);
    end 
    self.m_txtName:setText(self.m_data.name);
    self.m_txtChip:setText(STR_COMMON_USER_CHIP..Formatter.formatBigNumber(self.m_data.chip));
    
    if not self.m_data.isOperate then
        self.m_txtInvite:setText(STR_FRIEND_TAB_INVITE);
		self.m_btnInvite:setEnable(true);
	else
        self.m_txtInvite:setText(STR_FRIEND_ALREAD_INVITED_TIP);
		self.m_btnInvite:setEnable(false);
    end
    self.m_btnInvite:setOnClick(self, self.onInviteBtnClick);
end

RoomInviteFriendsItem.onInviteBtnClick = function(self)
    Log.d(self.TAG, "onInviteBtnClick");
    self.m_txtInvite:setText(STR_FRIEND_ALREAD_INVITED_TIP);
    self.m_btnInvite:setEnable(false);
    local obj = {};
    if self.m_data.status == FriendVO.STATUS_OFF_LINE then
        --邀请不在线好友
        obj.fuid = self.m_data.uid;
		--邀请者房间id
		local requestLoginData = Model.getData(ModelKeys.ROOM_REQUEST_LOGIN_DATA);
		obj.tid = requestLoginData.tid;
        EventDispatcher.getInstance():dispatch(CommandEvent.s_event ,CommandEvent.s_cmd.SEND_INVITE_OFFLINE_FRIENDS_MESSAGE, obj);
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event ,CommandEvent.s_cmd.UPDATA_FRIENDS_OPERATE_LIST, self.m_data.uid);
    else
        --邀请在线好友
        obj.uid         = self.m_data.uid;
		obj.name        = self.m_data.name;
		obj.picUrl      = self.m_data.image;
		obj.tid         = self.m_data.tid;
		obj.tableName   = self.m_data.tableName;
		obj.smallBlind  = self.m_data.smallBlind;
		obj.ip          = self.m_data.ip;
		obj.port        = self.m_data.port;
		obj.tableType   = self.m_data.tableType;
		obj.tableLevel  = self.m_data.tableLevel;
		obj.flag        = self.m_data.roomFlag;
        EventDispatcher.getInstance():dispatch(CommandEvent.s_event ,CommandEvent.s_cmd.SEND_INVITE_FRIENDS_MESSAGE, obj);
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event ,CommandEvent.s_cmd.UPDATA_FRIENDS_OPERATE_LIST, self.m_data.uid);
		EventDispatcher.getInstance():dispatch(UIEvent.s_event ,UIEvent.s_cmd.SHOW_TOP_TIP, STR_FRIEND_FRIEND_POPUP_INVITE_SUCC);
    end
end

RoomInviteFriendsItem.addHeadImage = function(self, defaultFile, url)
    if string.len(url) <= 5 then
        if FileKit.isFileExist("userinfo/imgface_" .. url .. ".jpg") then
            self.m_headImage = new(Image, "userinfo/imgface_" .. url .. ".jpg");
        else
            self.m_headImage = new(Image, defaultFile);
        end
    else
        self.m_headImage = new(UrlImage, defaultFile, url, nil, 1);
    end
    
    self.m_headImage:setSize(50, 50);
    self.m_headImage:setPos(64, 15);
    self.m_root:addChild(self.m_headImage);
end
