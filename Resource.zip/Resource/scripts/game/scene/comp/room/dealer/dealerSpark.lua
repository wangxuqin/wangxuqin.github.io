--------------------------------------------------------------------
DealerSpark = class(Node);

DealerSpark.ctor = function(self)--public 
--	super(self);

	self.m_image2 = new(Image, "room/dealer-spark-2.png");
--	self.m_image2.pivotX = self.m_image2.width * 0.5;
--	self.m_image2.pivotY = self.m_image2.height * 0.5;
    self.m_image2:setAlign(kAlignCenter);
	self:addChild(self.m_image2);

	self.m_image1 = new(Image, "room/dealer-spark-1.png");
--	self.m_image1.pivotX = self.m_image1.width * 0.5;
--	self.m_image1.pivotY = self.m_image1.height * 0.5;
    self.m_image1:setAlign(kAlignCenter);
	self:addChild(self.m_image1);

--	this.addEventListener(Event.ADDED_TO_STAGE, addToStageHandler);
--	this.addEventListener(Event.REMOVED_FROM_STAGE, removeFromStageHandler);
--	this.touchable = false;
    self.m_image1:addPropRotate(0, kAnimRepeat, 10000, 0, 0, 360, kCenterDrawing, 0, 0);
    self.m_image2:addPropRotate(0, kAnimRepeat, 10000, 0, 360, 0, kCenterDrawing, 0, 0);
end

DealerSpark.dtor = function(self)
    self.m_image1:removeProp(0);
    self.m_image2:removeProp(0);
end

--private function removeFromStageHandler():void
--{
--	TaskExecutor.instance.removeEnterframeCallback(spark);
--}
--
--private function addToStageHandler():void
--{
--	TaskExecutor.instance.addEnterframeCallback(spark);
--}
--
--private function spark():void
--{
--	self.m_image1.rotation += DealerSpark.ROTATION_VELOCITY;
--	self.m_image2.rotation -= DealerSpark.ROTATION_VELOCITY;
--}
