---------------------------------------------------------
DealerHddjButton = class(Node, false);

DealerHddjButton.m_hddjId = 0;
DealerHddjButton.m_hddjImage = nil;--:Image;

DealerHddjButton.ctor = function(self, id)--public
    super(self);
	self.m_hddjId = id;
	self.m_hddjImage = new(Image, "room/hddj/hddj_" .. self.m_hddjId .. ".png");
	self:addChild(self.m_hddjImage);

    As3Kit.setImageScale(self.m_hddjImage, 0.75, 0.75);

    self:setSize(80, 80);
    local w,h = self:getSize();
    local wImage,hImage = self.m_hddjImage:getSize();
	self.m_hddjImage:setPos(As3Kit.layoutCenter(0, w, wImage), As3Kit.layoutCenter(0, h, hImage));
end

DealerHddjButton.setUiEvent = function(self)
    self:setEventTouch(self, self.__onTouch);
end

DealerHddjButton.__onTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)--private
	TouchHelper.catch(self, finger_action, x, y);
	if(TouchHelper.isClick(self)) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SEND_DEALER_HDDJ, self.m_hddjId);
    end
end
