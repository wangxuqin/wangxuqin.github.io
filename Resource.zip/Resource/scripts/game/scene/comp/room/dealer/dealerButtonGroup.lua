require("view/room/layout_dealer_buttonGroup");
require("game/scene/comp/room/dealer/dealerHddjButton");

--[Comment]
--荷官操作面板，换荷官，给小费
DealerButtonGroup = class(PopupDialog, false);

DealerButtonGroup.TAG = "DealerButtonGroup";

DealerButtonGroup.ctor = function(self)
    super(self, layout_dealer_buttonGroup, false);

    self.m_gap = 10;
    self.m_backgroudTexture = nil;
    self.m_backScale9Texture = nil;
    self.m_backScale9Image = nil;
    self.m_dealerTips = 0;
    self.m_quad = nil;
    self.m_dealerChangeButton = nil;  --换荷官
    self.m_userSendTipsButton = nil;  --给小费按钮
    self.m_split = nil;               --分割线
    self.m_changeDealerWindow = nil;
    self.m_dealerHddjBackground = nil;
    self.m_container = nil;
    self.m_backgroundImage = nil;
    self:initialize();
    self:addEventList();
end

DealerButtonGroup.dtor = function(self)
    self:removeEventList();
end

DealerButtonGroup.update = function(self, data)
    self:selfAddToStageHandler();
end


DealerButtonGroup.addEventList = function(self)
    if self.m_eventList == nil then
        self.m_eventList = {
            {UIEvent, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM, "dealerButtonGroupHide"};
            {UIEvent, UIEvent.s_cmd.SEND_DEALER_HDDJ,         "dealerHddjTriggeredHandler"};
        }
    end
    EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
end 

DealerButtonGroup.removeEventList = function(self)
    if self.m_eventList ~= nil then
        EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
    end
    self.m_eventList = nil;
end 


--初始化
DealerButtonGroup.initialize = function(self)
    local tx = self.m_root:getNodeByName("bg.btn_change_dealer.change_dealer");
    tx:setText(STR_ROOM_CHANGE_DEALER);

    --给小费按钮
    local tx = self.m_root:getNodeByName("bg.btn_give_tips.give_tips");
    tx:setText(STR_ROOM_SEND_TIPS_TO_DEALER);

    --添加荷官互动道具
    local scrollbg = self.m_root:getNodeByName("bg.bg_hddj");
    local w,h = scrollbg:getSize();
    self.m_container = new(ScrollView2, 0, 0, w, h, true);
    scrollbg:addChild(self.m_container);
    self.m_container:setDirection(kHorizontal);
	self.m_container:setScrollBarWidth(0);
    self.m_allHddj = {};
    local allHddj =
    {
        7,2,4,3,1, 5,6,8,9,10,11,12,13,
    };
    for i=1,#allHddj do
        local btn = new(DealerHddjButton, allHddj[i]);
        self.m_allHddj[#self.m_allHddj+1] = btn;
		local item = new(DrawingEmpty);
		item:setSize(w/3);
		item:addChild(btn);
        self.m_container:addChild(item);
    end
end


DealerButtonGroup.onPopupEnd = function(self)
    local mainContainer = self:getDialog();
    mainContainer:removeProp(0);
    mainContainer:removeProp(1);
    --添加事件响应

    --换荷官按钮
    local btn = self.m_root:getNodeByName("bg.btn_change_dealer");
    btn:setOnClick(self, self.dealerChangeButtonHandler);
    --给小费按钮
    local btn = self.m_root:getNodeByName("bg.btn_give_tips");
    btn:setOnClick(self, self.userSendTipsButtonHandler);
    --互动道具区域
    for _,v in pairs(self.m_allHddj) do
        v:setUiEvent();
    end
end

DealerButtonGroup.show = function(self)
    local function onPreShow(self)
        local mainContainer = self:getDialog();
        local w,h = mainContainer:getSize();
        local duration = 300;
        local anim = mainContainer:addPropScale(0, kAnimNormal, duration, 100, 0,1, 0,1, kCenterXY, w/2, 0);
        local anim2 = mainContainer:addPropTransparency(1, kAnimNormal, duration, 100, 0, 1);
        return anim;
    end
    PopupDialog.show(self, PopupDialog.kPopupStyleCustom, onPreShow);
end

DealerButtonGroup.dealerHddjTriggeredHandler = function(self, data)
    SoundManager.playSound("ButtonClick");
	local userData = Model.getData(ModelKeys.USER_DATA);
    local selfSeatId = SeatManager:getSelfSeat():getSeatId();
	local hddjId = data;
	
    --如果是单机游戏，直接播放互动道具
	if userData == nil then
		self:close();
	    self:updateRoomHddjData(selfSeatId, hddjId, 1003);--播放动画
	
    elseif TutotiaKit.isTutotia() then
		self:close();
		self:updateRoomHddjData(selfSeatId, hddjId, userData.uid)--播放动画
	
    elseif SeatManager.roomType == LoginSuccData.ROOM_TYPE_NORMAL then  --只有普通场才能使用荷官道具
		
        if selfSeatId ~= -1 then 
            local hdNumber = Model.getData(ModelKeys.USER_HDDJ_NUMBER);
			if hdNumber> 0 then --判断用户荷官道具次数是否为0
                EventDispatcher.getInstance():dispatch(
                    CommandEvent.s_event, 
                    CommandEvent.s_cmd.ROOM_BROADCAST_SEND_HDDJ, 
                    {sendSeatId = selfSeatId, hddjId=hddjId, sendedSeatId=9});
				self:close();
				self:updateRoomHddjData(selfSeatId, hddjId, userData.uid)--播放动画
			
            else
				
                EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {--互動道具次數不夠的提示
						message = STR_ROOM_NOT_ENOUGH_HDDJ,
						confirm = STR_COMMON_BUY,
						obj = self,
                        callback = self.confirmHandler,
					});
			end
		else
            EventDispatcher.getInstance():dispatch(  -- 只有坐下才能使用荷官道具
                UIEvent.s_event, 
                UIEvent.s_cmd.SHOW_TOP_TIP, 
                STR_ROOM_SIT_DOWN_PLAY_HDDJ);
			self:dealerButtonGroupHide();
		end
	else
        EventDispatcher.getInstance():dispatch(
            UIEvent.s_event, 
            UIEvent.s_cmd.SHOW_TOP_TIP, 
            STR_ROOM_MATCH_TABLE_SEND_CHIPS);
	end
end

--[Comment]
--更新互动道具数据
DealerButtonGroup.updateRoomHddjData = function(self, selfSeatId, hddjId, uid)
    local hddjData = new(HddjData);
	hddjData.sendSeatId = selfSeatId;
	hddjData.hddjId = hddjId;
	hddjData.receiveSeatId = 10;
	hddjData.uid = 1003;
	Model.setData(ModelKeys.ROOM_HDDJ_DATA, hddjData);
 end

DealerButtonGroup.confirmHandler = function(self, stype)
	if (stype == DialogCallback.CONFIRM) then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_STORE_DIALOG, StoreDialog.STORE_POP_UP_PROPS_PAGE);
		self:close();
	end
end

DealerButtonGroup.selfAddToStageHandler = function(self)--private
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.GET_USER_HDDJ_NUMBER);
end

--送小费
DealerButtonGroup.userSendTipsButtonHandler = function(self, touchEvent)--private
	--给服务器发送消息
	local selfSeatId = SeatManager.selfSeatId;
	if(Model.getData(ModelKeys.USER_IN_TUTOTIA) and Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart) then
		local _sendChipsData = new(SendChipsData);
		_sendChipsData.senderSeatId   = 4;
		_sendChipsData.sendChips      = 10;
		_sendChipsData.recieverSeatId = 9+1;
		SeatManager:startSendChip(_sendChipsData);
		self:dealerButtonGroupHide();
	elseif(SeatManager.roomType == LoginSuccData.ROOM_TYPE_NORMAL) then --只有普通场才能给荷官送筹码
		if(selfSeatId ~= -1) then     --只有坐下才能给荷官送筹码
            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_BROADCAST_SEND_DEALER_CHIP);
			self:dealerButtonGroupHide();
		else
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_SIT_DOWN_SEND_CHIPS);
			self:dealerButtonGroupHide();
		end
	else
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_MATCH_TABLE_SEND_CHIPS);
		self:dealerButtonGroupHide();
	end
	SoundManager.playButtonClickSound();
end

--[Comment]
--换荷官
DealerButtonGroup.dealerChangeButtonHandler = function(self, touchEvent)--private
	local selfSeatId = SeatManager.selfSeatId;
	if(SeatManager.roomType == LoginSuccData.ROOM_TYPE_NORMAL or (Model.getData(ModelKeys.USER_IN_TUTOTIA) and Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart)) then --只有普通场才能换荷官
		if (selfSeatId ~= -1) then     --只有坐下才能换荷官
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_DEALER_CHOICE);
		else
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_SIT_DOWN_CHANGE_DEALER);
		end
	else
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_MATCH_TABLE_SEND_CHIPS);
	end
	self:dealerButtonGroupHide();
	SoundManager.playButtonClickSound();
end

--隐藏荷官按钮组
DealerButtonGroup.dealerButtonGroupHide = function(self)--public
    self:close();
end

DealerButtonGroup.close = function(self)
    KTween.remove(self:getDialog());
    local w,h = self:getDialog():getSize();
    KTween.to(self:getDialog(), 200, {scale=0,  center=kCenterXY, centerX = w / 2, onComplete = self.onComplete, obj = self, delay = 50});
end

DealerButtonGroup.onComplete = function(self)
    KTween.remove(self:getDialog());
    PopupDialog.close(self);
end