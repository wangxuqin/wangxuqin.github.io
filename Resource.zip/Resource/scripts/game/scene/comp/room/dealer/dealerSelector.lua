require("game/scene/comp/room/dealer/dealerItem");

DealerSelector = class(Node, false);

DealerSelector.TAG = "DealerSelector";

DealerSelector.ctor = function(self, w, h)
    super(self);

    self.m_xOffset = 0;

    self:setSize(w, h);
    self:setClip(true,0, 0, w, h);
	self.m_gridWidth = math.modf(w / 3);
    self:setEventTouch(self, self.onTouch);

    self.m_bRecordDistance = false;
    self.m_bSpeedDown = false;
    self.m_lastTime = System.getTickTime();
    self.m_timerMove = setInterval(self.__funcMove, self, 16);
end

DealerSelector.dtor = function(self)
    clearInterval(self.m_timerMove);
end

DealerSelector.setPos = function(self, x, y)
    Node.setPos(self, x, y);
    local w,h = self:getSize();
    self:setClip(true,0, 0, w, h);
end

DealerSelector.setSelectedDealer = function(self, val)
    val = tostring(val);
    local index = -1;
    local arrChildren = self:getChildren();
    for k,v in pairs(arrChildren) do
        if(v:getId() == val) then
            index = k;
            break;
        end
    end
    if(index ~= -1) then
        self.m_xOffset = -(index-1-1) * self.m_gridWidth;
        self:__rePositionDealers();
    end
	local tmpSelectedDealer = self:getSelectedDealer();
    local arrChildren = self:getChildren();
    for k,v in pairs(arrChildren) do
        if(v:getId() == tmpSelectedDealer) then
            v:setLabelEnable(true);
            KTween.remove(v);
            KTween.to(v, 0, {
                                alpha = 1,
                                scale = 1,
                            });
        else
            v:setLabelEnable(false);
            KTween.remove(v);
            KTween.to(v, 0, {
                                alpha = 0.6,
                                scale = 0.86,
                            });
        end
	end
end

DealerSelector.getSelectedDealer = function(self)
	local minDistance = 10000;
	local index = -1;
    local xCenter = self:getSize()/2;
    local arrChildren = self:getChildren();
    for k,v in pairs(arrChildren) do
        if(v:getVisible()) then
            local x,y = v:getPos();
            local dist = math.abs(x - xCenter);
		    if(dist < minDistance) then
			    index = k;
			    minDistance = dist;
		    end
        end
	end
	if(index ~= -1) then
		return arrChildren[index]:getId(),index;
    end
	return -1,-1;
end

DealerSelector.__getNearestDealerIndex = function(self)
    local minDistance = 10000;
	local index = -1;
    local xCenter = self:getSize()/2;
    local arrChildren = self:getChildren();
    for k,v in pairs(arrChildren) do
        if(v:getVisible()) then
            local x,y = v:getPos();
            local dist = math.abs(x - xCenter);
		    if(dist < minDistance) then
			    index = k;
			    minDistance = dist;
		    end
        end
	end
    return index;
end

DealerSelector.onTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
    if(finger_action == kFingerDown) then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.DEALER_SPARK_SHRINK);
        local arrChildren = self:getChildren();
        local selectedDealer = self:getSelectedDealer();
        for k,v in pairs(arrChildren) do
			if(v:getId() == selectedDealer) then
                v:setLabelEnable(false);
                KTween.remove(v);
                KTween.to(v, 200, {
                            alpha = 0.6,
                            scale = 0.86,
                            center = kCenterXY,
                            centerX = 0,
                            centerY = 0,
                            });
				break;
			end
		end
        self.m_touchBeginX = x;
		self.m_touchCurX = x;
        self.m_touchLastX = x;
        self.m_timeDown = System.getTickTime();
        self.m_touchOffsetX = x - self.m_xOffset;
        self.m_bSpeedDown = false;
        self.m_bMoveToDealer = false;
        self.m_bMovingToNextOrPrev = false;
        --开启定时器记录位移
        self.m_distanceVector = {};
        self.m_bRecordDistance = true;
    elseif(finger_action == kFingerMove) then
        self.m_touchCurX = x;
        self.m_xOffset = x - self.m_touchOffsetX;
        self:__rePositionDealers();
    elseif(finger_action == kFingerUp) then
        self.m_bRecordDistance = false;
        --判断是否是点击上一个或者下一个荷官
        if(math.abs(x - self.m_touchBeginX) < 4) then
            Log.d(DealerSelector.TAG, "click next or prev");
            if(x < System.getScreenWidth() / 2 - self.m_gridWidth/4) then
                self:previousimage();
			elseif(x > System.getScreenWidth() / 2 + self.m_gridWidth/4) then
				self:nextimage();
            else
                self.m_speed = 0;
                self.m_speedDown = 0;
                self.m_bSpeedDown = true;
            end
        else -- 移动
            local numDistance = #self.m_distanceVector;
            Log.d(DealerSelector.TAG, "num=" .. numDistance);
            if(numDistance <= 0) then
                numDistance = 0;
            end
            if(numDistance > 0) then
                local timeTotal = numDistance * 5;
                local distanceTotal = 0;
                for _,v in pairs(self.m_distanceVector) do
                    distanceTotal = distanceTotal + v;
                end
--                distanceTotal = x - self.m_touchBeginX;
                timeTotal = (System.getTickTime() - self.m_timeDown) / 10;
                self.m_speed = distanceTotal / timeTotal;
                self.m_speedDown = -self.m_speed / 1.0;
                Log.d(DealerSelector.TAG, "speed=" .. self.m_speed);
                self.m_bSpeedDown = true;
            end
        end
    end
end

DealerSelector.__funcMove = function(self)
    local thisTime = System.getTickTime();
    local elapsedTime = thisTime - self.m_lastTime;
    self.m_lastTime = thisTime;
    local bRepositionDealers = false;
    --拖动时收集一定时间的鼠标位移
    if(self.m_bRecordDistance) then
        local distance = self.m_touchCurX - self.m_touchLastX;
        self.m_touchLastX = self.m_touchCurX;
        self.m_distanceVector[#self.m_distanceVector+1] = distance;
        while(#self.m_distanceVector > 16) do
            As3Kit.deleteAt(self.m_distanceVector, 1);
        end
    end
    --减速运动
    if(self.m_bSpeedDown) then
        local newSpeed = self.m_speed + self.m_speedDown * elapsedTime / 1000;
        if(self.m_speedDown > 0 and newSpeed > 0) then
            newSpeed = 0;
        elseif(self.m_speedDown < 0 and newSpeed < 0) then
            newSpeed = 0;
        end
        self.m_speed = newSpeed;
        self.m_xOffset = self.m_xOffset + self.m_speed;
--        self:__rePositionDealers();
        bRepositionDealers = true;
        if(math.abs(self.m_speed) < 3) then--减速运动完毕
            --求最接近中间的荷官
            local index = self:__getNearestDealerIndex();
            if(index ~= -1) then
                local arrChildren = self:getChildren();
                local dealer = arrChildren[index];
                Log.d(DealerSelector.TAG, "dealer:" .. tostring(dealer));
                local xPos = dealer:getPos();
                local distance = self.m_gridWidth * 3 / 2 - xPos;
                self.m_xOffsetTo = self.m_xOffset + distance;
                self.m_bMoveToDealer = true;

                KTween.remove(dealer);
                KTween.to(dealer, 200, {
                            startAlpha = 0.6,
                            alpha = 1,
                            startScale = 0.86,
                            scale = 1,
                            center = kCenterXY,
                            centerX = 0,
                            centerY = 0,
                            });
                dealer:setLabelEnable(true);
            end
            self.m_bSpeedDown = false;
        end
    end
    --减速运动完后移到最接近的荷官上
    if(self.m_bMoveToDealer) then
        local bEnd = false;
        local speed = 8;
        if(self.m_xOffset < self.m_xOffsetTo) then
            self.m_xOffset = self.m_xOffset + speed;
            if(self.m_xOffset >= self.m_xOffsetTo) then
                self.m_xOffset = self.m_xOffsetTo;
                bEnd = true;
            end
        elseif(self.m_xOffset > self.m_xOffsetTo) then
            self.m_xOffset = self.m_xOffset - speed;
            if(self.m_xOffset <= self.m_xOffsetTo) then
                self.m_xOffset = self.m_xOffsetTo;
                bEnd = true;
            end
        else
            bEnd = true;
        end
        if(bEnd) then--移动完毕
            self.m_bMoveToDealer = false;
            --光效放大
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.DEALER_SPARK_ENLARGE);
        end
        bRepositionDealers = true;
    end
    --移动到上一个或下一个荷官
    if(self.m_bMovingToNextOrPrev) then
        local bEnd = false;
        local speed = 32;
        if(self.m_xOffset < self.m_xOffsetTo) then
            self.m_xOffset = self.m_xOffset + speed;
            if(self.m_xOffset >= self.m_xOffsetTo) then
                self.m_xOffset = self.m_xOffsetTo;
                bEnd = true;
            end
        elseif(self.m_xOffset > self.m_xOffsetTo) then
            self.m_xOffset = self.m_xOffset - speed;
            if(self.m_xOffset <= self.m_xOffsetTo) then
                self.m_xOffset = self.m_xOffsetTo;
                bEnd = true;
            end
        else
            bEnd = true;
        end
        if(bEnd) then
            self.m_bMovingToNextOrPrev = false;
            --光效放大
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.DEALER_SPARK_ENLARGE);
            local index = self:__getNearestDealerIndex();
            if(index ~= -1) then
                local dealer = self:getChildren()[index];
                KTween.remove(dealer);
                KTween.to(dealer, 200, {
                            startAlpha = 0.6,
                            alpha = 1,
                            startScale = 0.86,
                            scale = 1,
                            center = kCenterXY,
                            centerX = 0,
                            centerY = 0,
                            });
                dealer:setLabelEnable(true);
            end
        end
        bRepositionDealers = true;
    end
    if(bRepositionDealers) then
        self:__rePositionDealers();
    end
end

-- 下一个荷官
-- @param self.m_distance
DealerSelector.nextimage = function(self) 
	if(self.m_bMovingToNextOrPrev) then
        return;
    end
    local index = self:__getNearestDealerIndex();
    if(index ~= -1) then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.DEALER_SPARK_SHRINK);
        local arrChildren = self:getChildren();
        local dealer = arrChildren[index];
        local xPos = dealer:getPos() + self.m_gridWidth;
        local distance = self.m_gridWidth * 3 / 2 - xPos;
        self.m_xOffsetTo = self.m_xOffset + distance;
        self.m_bMovingToNextOrPrev = true;
        dealer:setLabelEnable(false);
        KTween.remove(dealer);
        KTween.to(dealer, 200, {
                    alpha = 0.6,
                    scale = 0.86,
                    center = kCenterXY,
                    centerX = 0,
                    centerY = 0,
                    });
    end
end

-- 上一个荷官
-- @param self.m_distance
DealerSelector.previousimage = function(self)
	if(self.m_bMovingToNextOrPrev) then
        return;
    end
    local index = self:__getNearestDealerIndex();
    if(index ~= -1) then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.DEALER_SPARK_SHRINK);
        local arrChildren = self:getChildren();
        local dealer = arrChildren[index];
        local xPos = dealer:getPos() - self.m_gridWidth;
        local distance = self.m_gridWidth * 3 / 2 - xPos;
        self.m_xOffsetTo = self.m_xOffset + distance;
        self.m_bMovingToNextOrPrev = true;
        dealer:setLabelEnable(false);
        KTween.remove(dealer);
        KTween.to(dealer, 200, {
                    alpha = 0.6,
                    scale = 0.86,
                    center = kCenterXY,
                    centerX = 0,
                    centerY = 0,
                    });
    end
end

-- 添加荷官
-- @param self.m_distance
DealerSelector.addDealer = function(self, id, name, texture)
	if(texture == nil) then
		return;
	end

    local w,h = self:getSize();

	local dealer = new(DealerItem, id, name, texture);
    dealer:setSize(self.m_gridWidth);
    local numChildren = self:getChildrenNum();
    dealer:setPos(self.m_gridWidth * 0.5 + numChildren * self.m_gridWidth, h/2);
    self:addChild(dealer);
    KTween.remove(dealer);
    KTween.to(dealer, 0, {
                alpha = 0.6,
                scale = 0.86,
                });
end

DealerSelector.getDealerNum = function(self)
    local numChildren = self:getChildrenNum();
	return numChildren;
end

DealerSelector.__rePositionDealers = function(self)
    local numChildren = self:getChildrenNum();
    local iStart = 1;
    local xOffset = math.modf(self.m_xOffset);
    local xStart = 0;
    local wTotal = self:getSize();
    if(xOffset > 0) then
        iStart = -math.ceil(xOffset / self.m_gridWidth) + 1;
        while(iStart <= 0) do
            iStart = iStart + numChildren;
        end
        xStart = math.modf(xOffset % self.m_gridWidth);
        if(xStart > 0) then
            xStart = xStart - self.m_gridWidth;
        end
    elseif(xOffset < 0) then
        iStart = math.floor(-xOffset / self.m_gridWidth) + 1;
        while(iStart > numChildren) do
            iStart = iStart - numChildren;
        end
        xStart = -math.modf(-xOffset % self.m_gridWidth);
    end
    local arrChildren = self:getChildren();
    local xOff = self.m_gridWidth * 0.5;
--    Log.d(DealerSelector.TAG, "reposition children");
    for i=1,numChildren do
        local child = arrChildren[iStart];
--        Log.d(DealerSelector.TAG, "child:" .. tostring(child));
        if(xStart < wTotal) then
            child:setVisible(true);
            child:setPos(xOff + xStart);
        else
            child:setVisible(false);
        end
        iStart = iStart + 1;
        if(iStart > numChildren) then
            iStart = 1;
        end
        xStart = xStart + self.m_gridWidth;
    end
end
