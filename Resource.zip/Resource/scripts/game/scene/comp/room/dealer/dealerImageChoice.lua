---------------------------------------------------------
require("view/room/layout_dealer_choice");
require("game/scene/comp/room/dealer/dealerSpark");
require("game/scene/comp/room/dealer/dealerSelector");
require("game/scene/comp/room/dealer/dealerUtil");
require("game/scene/comp/common/pageIndicator");
require("game/scene/comp/social/shareButton");

DealerImageChoice = class(PopupDialog, false);

DealerImageChoice.TAG = "DealerImageChoice";
		
DealerImageChoice.ctor = function(self)--public 
	super(self, layout_dealer_choice, true);

    self.m_confirmbutton = nil;--:Button;
    self.m_previousbutton = nil;--:Button;
    self.m_nextbutton = nil;--:Button;
    self.m_dealerSpark = nil;--:DealerSpark;
    self.m_shareButton = nil;--:ShareButton;
    self.m_dealerSelector = nil;--:DealerSelector;
    self.m_pages = nil;--:PageIndicator;    --页面指示器
    self.m_describelabel = nil;--:Label		--荷官内容描述
    self.m_describeTipsLable = nil;--:Label; --台费描述
    self.m_dealerDataArray = nil;--:Array;
    self.m_titleLabel = nil;--:Label;

	--断线关闭窗口
    local param = new(EventParam, UIEvent, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM, self, "doHide");
    self.m_eventPassiveLeaveRoom = param;
    EventDispatcher.getInstance():registerByParam(param);
    self.m_dealerDataArray = Model.getData(ModelKeys.ROOM_DEALER_DATA);
    self:initialize();
end

DealerImageChoice.dtor = function(self)
    EventDispatcher.getInstance():unregisterByParam(self.m_eventPassiveLeaveRoom);
end

DealerImageChoice.onPopupEnd = function(self)
    local btn = self.m_root:getNodeByName("bg.btn_close");
    btn:setOnClick(self, self.onBtnClickClose);
    local btn = self.m_root:getNodeByName("bg.btn_share");
    local btn = self.m_root:getNodeByName("bg.btn_confirm");
    btn:setOnClick(self, self.onConfirm);
    local btn = self.m_root:getNodeByName("bg.btn_previous");
    btn:setOnClick(self, self.previousImage);
    local btn = self.m_root:getNodeByName("bg.btn_next");
    btn:setOnClick(self, self.nextImage);
end

DealerImageChoice.onBtnClickClose = function(self)
    self:close();
end

DealerImageChoice.show = function(self, popupStyle, customStyleFunc)--public 
--	self.m_dealerDataArray = Model.getData(ModelKeys.ROOM_DEALER_DATA);
	if(self.m_dealerDataArray) then
		PopupDialog.show(self, popupStyle, customStyleFunc);
	else
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_COMMON_BAD_NETWORK);
	end
end

DealerImageChoice.close = function(self)--override
    if(self.m_eventSparkShrink) then
        EventDispatcher.getInstance():unregisterByParam(self.m_eventSparkShrink);
        self.m_eventSparkShrink = nil;
    end
    if(self.m_eventSparkEnlarge) then
        EventDispatcher.getInstance():unregisterByParam(self.m_eventSparkEnlarge);
        self.m_eventSparkEnlarge = nil;
    end
    PopupDialog.close(self);
end

DealerImageChoice.doHide = function(self)--public 
	local userData = Model.getData(ModelKeys.USER_DATA);
	local dealerId = 0;
	if(userData.defaultHeguan ~= 0 and userData.defaultHeguan >= 1) then
		dealerId = userData.defaultHeguan;
	else
		dealerId = 1;
	end
	if(self.m_dealerSelector) then
		self.m_dealerSelector:setSelectedDealer(dealerId);
	end

    self:close();
end

DealerImageChoice.initialize = function(self)--override protected
    local tx = self.m_root:getNodeByName("bg.btn_confirm.confirm");
    tx:setText(STR_ROOM_CONFRIM_DEALER_BUTTON);

    --荷官背景发光图片
	self.m_dealerSpark = new(DealerSpark);
    KTween.to(self.m_dealerSpark, 0, {scale = 3});
    local w,h = self:getDialog():getSize();
    self.m_dealerSpark:setPos(w/2, 175);
	self:getDialog():addChild(self.m_dealerSpark);

	local dealerDataArray = Model.getData(ModelKeys.ROOM_DEALER_DATA);
	if(dealerDataArray) then
		self:dealerInformation(dealerDataArray);
	else
		Model.watchData(ModelKeys.ROOM_DEALER_DATA, self, self.dealerInformation, true);
	end

	self.m_titleLabel = self.m_root:getNodeByName("bg.title");
	self.m_titleLabel:setText(STR_ROOM_DEALER_CHANGE_PAGE_TITLE);

	self.m_describelabel = self.m_root:getNodeByName("bg.describe");
	self.m_describeTipsLable = self.m_root:getNodeByName("bg.describe_tip");

    --分享按钮
    local btn = self.m_root:getNodeByName("bg.btn_share");
    local x,y = btn:getPos();
    local w,h = btn:getSize();
    local parent = self:getDialog();--btn:getParent();
    btn:setVisible(false);
    local btnShare = new(ShareButton, "changeDealer", nil, w, h);
--    local btnShare = new(Button, "common/dialog/common_green_btn_up.png", "common/dialog/common-btn-disabled.png", nil, nil, 9, 10, 9, 10);
    btnShare:setPos(x, y);
    btnShare:setLevel(100);
    parent:addChild(btnShare);

	self:dealerChangeHandler();
end

DealerImageChoice.dealerChangeHandler = function(self)--private 
    if(self.m_dealerSelector == nil) then
        return;
    end
	local index = self:getDealerIndex(self.m_dealerSelector:getSelectedDealer());
    if(self.m_pages) then
	    self.m_pages:setSelectedIndex(index);
    end
    local data = self.m_dealerDataArray[index];
    if(data) then
	    self.m_describelabel:setText(data.heguan_name .. ": " .. data.heguan_desc);
    end
    local heguan_price = data and tonumber(data.heguan_price) or 0;
	if(heguan_price == 0) then
		self.m_describeTipsLable:setText(STR_ROOM_FREE_SERVICE);
	elseif(heguan_price > 0) then
		self.m_describeTipsLable:setText(StringKit.substitute(STR_ROOM_DEALER_CHARGE_DESCRIBE, heguan_price));
	end
end

DealerImageChoice.getDealerIndex = function(self, id)--private 
	local dealerDataArray = Model.getData(ModelKeys.ROOM_DEALER_DATA);
	if(dealerDataArray) then
        for i=1,#dealerDataArray do
			if(dealerDataArray[i].heguan_id == id) then
				return i;
			end
		end
	end
	return -1;
end

DealerImageChoice.dealerInformation = function(self, dealerDataArray)--public 
	if(not dealerDataArray) then
		return;
	end

    local width = self:getDialog():getSize();

    local w,h = width - 2 * 60, 220;
	self.m_dealerSelector = new(DealerSelector, w, h);
    self.m_dealerSelector:setPos((width-w)/2, 64);

    --test
--    local bg = new(Image, "common/black.png");
--    bg:setSize(w, h);
--    bg:setPos((width-w)/2, 64);
--    self:getDialog():addChild(bg);

    local i = 1;
    while(i <= #dealerDataArray) do
		local dealerData = dealerDataArray[i];
		local texture = "dealer/room-dealer-" .. DealerUtil.getImageId(dealerData.heguan_id) .. ".png";
        local img = new(Image, texture);
        local w,h = img:getSize();
        delete(img);
		if(w > 0 and h > 0) then
			self.m_dealerSelector:addDealer(dealerData.heguan_id, dealerData.heguan_name, texture);
		else
            As3Kit.deleteAt(dealerDataArray, i);
			i = i - 1;
		end
        i = i + 1;
	end
	--在语言文件中存入最新上线荷官，如果语言文件中取不到最新荷官id则展示默认荷官
	local newDealerId = nil;--STR_COMMON_NEW_DEALER_ID;
	local newDealerIndex = 1;
	if(newDealerId) then
        for i=1,#dealerDataArray do
			if(dealerDataArray[i].heguan_id == STR_COMMON_NEW_DEALER_ID) then
				newDealerIndex = i;
            end
		end
	else
		local userData = Model.getData(ModelKeys.USER_DATA);
        for i=1,#dealerDataArray do
			if(dealerDataArray[i].heguan_id == tostring(userData.defaultHeguan)) then
				newDealerIndex = i;
            end
		end
	end
--	self.m_dealerSelector:setSelectedDealer(newDealerIndex);
    self.m_dealerSelector:setSelectedDealer(dealerDataArray[newDealerIndex].heguan_id);
    if(self.m_eventSparkShrink == nil) then
        self.m_eventSparkShrink = new(EventParam, UIEvent, UIEvent.s_cmd.DEALER_SPARK_SHRINK, self, "shineImageSmall");
        EventDispatcher.getInstance():registerByParam(self.m_eventSparkShrink);
    end
    if(self.m_eventSparkEnlarge == nil) then
        self.m_eventSparkEnlarge = new(EventParam, UIEvent, UIEvent.s_cmd.DEALER_SPARK_ENLARGE, self, "shineImageLarge");
        EventDispatcher.getInstance():registerByParam(self.m_eventSparkEnlarge);
    end
	self:getDialog():addChild(self.m_dealerSelector);

	--添加页面指示器
    local w,h = self:getDialog():getSize();
	self.m_pages = new(PageIndicator, self.m_dealerSelector:getDealerNum(), 34, PageIndicator.DIRECTION_HORIZONTAL, "room/nocheck-point.png", "room/check-point.png");
    self.m_pages:setPos(w/2, 350);
	local _,selectIndex = self.m_dealerSelector:getSelectedDealer();
	self.m_pages:setSelectedIndex(tonumber(selectIndex));
	self:getDialog():addChild(self.m_pages);

    Model.unwatchData(ModelKeys.ROOM_DEALER_DATA, self, self.dealerInformation);
end

DealerImageChoice.shineImageLarge = function(self)--public 
	self:dealerChangeHandler();
    KTween.remove(self.m_dealerSpark);
    KTween.to(self.m_dealerSpark, 300, {scale = 3});
end

DealerImageChoice.shineImageSmall = function(self)--public 
	self:dealerChangeHandler();
    KTween.remove(self.m_dealerSpark);
    KTween.to(self.m_dealerSpark, 300, {scale = 0});
end

DealerImageChoice.nextImage = function(self)--public 
	self:dealerChangeHandler();
	if(self.m_dealerSelector) then
		self.m_dealerSelector:nextimage();
		SoundManager.playButtonClickSound();
	end
end

DealerImageChoice.previousImage = function(self)--public 
	self:dealerChangeHandler();
	if(self.m_dealerSelector) then
		self.m_dealerSelector:previousimage();
		SoundManager.playButtonClickSound();
	end
end

DealerImageChoice.onConfirm = function(self)--public 
	SoundManager.playButtonClickSound();
	if(self.m_dealerSelector == nil) then
		return;
	end

	local selectedDealer = self.m_dealerSelector:getSelectedDealer();
	local userData = Model.getData(ModelKeys.USER_DATA);
	if(selectedDealer == userData.defaultHeguan) then
		self:doHide();
		return;
    end

--??	JuhuaAndHintManager.showJuhua(this);
--??	FrameworkGlobal.context.addEventListener(UIEventNames.CONFIRM_DEALER_INFO,removeJuhua);
    self.m_eventConfirmDealerInfo = new(EventParam, UIEvent, UIEvent.s_cmd.CONFIRM_DEALER_INFO, self, "removeJuhua");
    EventDispatcher.getInstance():registerByParam(self.m_eventConfirmDealerInfo);
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_DEALER_CHANGE_CONFIRM, selectedDealer);
end

DealerImageChoice.removeJuhua = function(self)--private
    if(self.m_eventConfirmDealerInfo) then
        EventDispatcher.getInstance():unregisterByParam(self.m_eventConfirmDealerInfo);
        self.m_eventConfirmDealerInfo = nil;
    end
	self:doHide();
end
