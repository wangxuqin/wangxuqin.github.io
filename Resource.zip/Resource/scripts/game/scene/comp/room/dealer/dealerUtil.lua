require("game/scene/comp/room/dealer/dealerConfig");
--[Comment]
--�ɹٹ�����
DealerUtil = {}

DealerUtil.m_dealerIdMap = nil;
DealerUtil.m_isInitialized = false;

DealerUtil.initialize = function()
	local dealerMapsStr = STR_COMMON_DEALER_ID_MAP;
	if dealerMapsStr ~= nil and dealerMapsStr ~= "" then
        DealerUtil.m_dealerIdMap = {};
        dealerMapsStr = string.gsub(dealerMapsStr, ":", "=");
        dealerMapsStr = "dealer" .. string.gsub(dealerMapsStr, ",", ",dealer");
        dealerMapsStr = string.format("local t={%s};return t;", dealerMapsStr);
        local mm = loadstring(dealerMapsStr)();
        DealerUtil.m_dealerIdMap = mm;
	else
		DealerUtil.m_dealerIdMap = {};
	end
	DealerUtil.m_isInitialized = true;
end

DealerUtil.getImageId = function(actualId)
	if not DealerUtil.m_isInitialized then
		DealerUtil.initialize();
	end
	local mapKey = "dealer" .. actualId;
    if DealerUtil.m_dealerIdMap[mapKey]  then
        return DealerUtil.m_dealerIdMap[mapKey];
    else
        return actualId;
    end
end

DealerUtil.getDealerTexture = function(actualId, useDefault)--public static
    useDefault = useDefault or false;
	local dealerTexture = "dealer/room-dealer-" .. DealerUtil.getImageId(actualId);
	if (not dealerTexture) and useDefault then
		dealerTexture = "dealer/room-dealer-" .. DealerUtil.getImageId(DealerUtil.getDefaultId());
	end
	if not dealerTexture then
		dealerTexture = "dealer/room-dealer-" .. DealerUtil.getImageId(tonumber(STR_COMMON_DEALER_ID));
	end
    dealerTexture = dealerTexture..".png"
	return dealerTexture;
end

DealerUtil.getDeafaultId = function()
	local userData = Model.getData(ModelKeys.USER_DATA);
	if userData ~= nil then
        if userData.defaultHeguan ~= 0 and userData.defaultHeguan >= 1 then
            return userData.defaultHeguan;
        else
            return tonumber(STR_COMMON_DEALER_ID);
        end
	else
		return tonumber(STR_COMMON_DEALER_ID);
    end
end

DealerUtil.getRoomDealerDeltaY = function(actualId)
	local imageId = DealerUtil.getImageId(actualId);
	local deltaY = -20;
    if DealerConfig.deltaY[imageId] ~= nil then
        deltaY = DealerConfig.deltaY[imageId];
    end
	return deltaY;
end