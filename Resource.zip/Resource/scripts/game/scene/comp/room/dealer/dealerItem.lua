----------------------------------------------------------

DealerItem = class(Node, false);

DealerItem.m_id = 0;--:int;
DealerItem.m_bgLabel = nil;--:Button;
DealerItem.m_dealer = nil;--:Image;
DealerItem.m_name = "";--:String;
DealerItem.m_texture = nil;--:Texture;

DealerItem.ctor = function(self, id, name, texture)--public
	super(self);
	self.m_id = id;
	self.m_name = name;
	self.m_texture = texture;

    self.m_dealer = new(Image, texture);
    self:addChild(self.m_dealer);

    self.m_texLabel = {"room/checked.png", "room/nochecked.png"};
    self.m_texColor = {0xfcde67, 0xacc5df};
	self.m_bgLabel = new(Image, "room/checked.png");
    self:addChild(self.m_bgLabel);
    self.m_label = new(Text, name);
    self.m_label:setAlign(kAlignCenter);
    self.m_bgLabel:addChild(self.m_label);
    self:initialize();
end

DealerItem.initialize = function(self)--override protected
	if(self.m_dealer) then
		if(self.m_id==14) then
			self.m_dealer:setPos(-As3Kit.getNodeWidth(self.m_dealer) * 0.5, 17-110);
		else
			self.m_dealer:setPos(-As3Kit.getNodeWidth(self.m_dealer) * 0.5, 20-110);
		end
	end
    local wLabel = self.m_bgLabel:getSize();
    local x = -wLabel * 0.5;
	if(self.m_id==2) then
        self.m_bgLabel:setPos(x, 160-110);
	elseif(self.m_id==4) then
        self.m_bgLabel:setPos(x, 163-110);
		self.m_dealer:setPos(nil, 25-110);
	elseif(self.m_id==5) then
		self.m_bgLabel:setPos(x, 167.5-110);
	elseif(self.m_id==14) then
		self.m_bgLabel:setPos(x, 160.5-110);
	else
		self.m_bgLabel:setPos(x, 160-110);
	end
end

DealerItem.getId = function(self)--public
	return self.m_id;
end

DealerItem.setId = function(self, id)
    self.m_id = id;
end

DealerItem.setLabelEnable = function(self, boolean)--public
    local index = 1;
    if(boolean) then
        index = 1;
    else
        index = 2;
    end
    self.m_bgLabel:setFile(self.m_texLabel[index]);
    local r,g,b = RGBKit.getRGB(self.m_texColor[index]);
    self.m_label:setColor(r, g, b);
end
