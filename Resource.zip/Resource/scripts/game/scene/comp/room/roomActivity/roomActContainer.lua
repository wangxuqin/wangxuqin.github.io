require("game/scene/comp/room/superLotto/superLottoEntry");

RoomActContainer = class(Node, false);

RoomActContainer.ctor = function(self, w, h)
	super(self);

	self.m_mWidth = 0;
	self.m_mHeight = 0;
	self.m_container = nil;
	self.m_treasuerBox = nil;
	self.m_superLotto = nil;
	self.m_activityEntry = nil;
	self.m_touchQuad = nil;
	self.m_background = nil;
	self.m_actArr = nil;
	self.m_actNum = 0;
	self.m_currentIndex = 0;
	self.m_nextIndex = 0;
	self.m_intervalNum = 0;
	self.m_intervalNum1 = 0;

	self.m_mWidth = w;
	self.m_mHeight = h;
	self:setSize(self.m_mWidth, self.m_mHeight);

	self.m_container = new(Node);
	self:addChild(self.m_container);

	self.m_background = new(Image, "common/common_white_background.png");
	self.m_background:setScale(2.8);
	self.m_container:addChild(self.m_background);
	self.m_background:setTransparency(0);
	self.m_background:setPos(3, 4);
	self.m_background:setPickable(false);

	self.m_touchQuad = new(Node);
	self.m_touchQuad:setSize(10, 10);
	self.m_touchQuad:setTransparency(0);
	self.m_container:addChild(self.m_touchQuad);
	self.m_touchQuad:setEventTouch(self, self.actContainerTouch);

--	self.m_treasuerBox = new TreasureBox();
--	self.m_treasuerBox.touchable = false;

	self.m_superLotto = new(SuperLottoEntry);
	self.m_superLotto:setPickable(false);

--	self.m_activityEntry = new RoomActActivityIcon();
--	self.m_activityEntry.touchable = false;

	self.m_actArr = {};

	self:addEventAndDataList();
end

RoomActContainer.dtor = function(self)
	self:removeFromStageHandler();
	self:delEventAndDataList();
end

RoomActContainer.addEventAndDataList = function(self)
	if(self.m_eventList == nil) then
		self.m_eventList =
		{
			{ UIEvent, UIEvent.s_cmd.ROOM_ACTIVITY_TREASURE_BOX_FINISHED, "treasureBoxFinished" },
			{ UIEvent, UIEvent.s_cmd.SYSTEM_NOTICE_TASK_FINISHED, "systemNoticeTaskFinished" },
			{ UIEvent, UIEvent.s_cmd.ROOM_ACTIVITY_USER_RECEIVED_REWARD, "userReceivedReward" },
		};
		EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
	end
	if(self.m_datalist == nil) then
		self.m_datalist =
		{
			{ ModelKeys.ROOM_LOGIN_SUCC_DATA, self, self.loginSuccHandler },
		};
		Model.watchDataList(self.m_datalist);
	end
end

RoomActContainer.delEventAndDataList = function(self)
	if(self.m_eventList ~= nil) then
		EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
		self.m_eventList = nil;
	end
	if(self.m_datalist ~= nil) then
		Model.unwatchDataList(self.m_datalist);
		self.m_datalist = nil;
	end
end

RoomActContainer.draw = function(self)
--?	self.m_touchQuad.width = self.m_treasuerBox.width + 20;
--?	self.m_touchQuad.height = self.m_treasuerBox.height + 20;
end

RoomActContainer.loginSuccHandler = function(self, data)
	if(data ~= nil) then
		self:removeFromStageHandler();
		local userData = Model.getData(ModelKeys.USER_DATA);
		local loginSuccData = data;
		self.m_actNum = 0;
--		if(userData and self.m_treasuerBox and TreasureBox.checkEnabled(loginSuccData)) then
--			self.m_actArr.push(self.m_treasuerBox);
--			self.m_treasuerBox.visible = false;
--			self.m_container.addChild(self.m_treasuerBox);
--			self.m_actNum++;
--		end
		if(userData and self.m_superLotto and SuperLottoEntry.checkEnabled(loginSuccData)) then
			table.insert(self.m_actArr, self.m_superLotto);
			self.m_superLotto:setVisible(false);
			self.m_container:addChild(self.m_superLotto);
			self.m_actNum = self.m_actNum + 1;
		end
--		if(userData and self.m_activityEntry and RoomActActivityIcon.checkEnabled(loginSuccData)) then
--			self.m_actArr.push(self.m_activityEntry);
--			self.m_activityEntry.visible = false;
--			self.m_container.addChild(self.m_activityEntry);
--			self.m_actNum++;
--		end
		if(self.m_actNum > 0) then
			self.m_touchQuad:setPickable(true);
		else
			self.m_touchQuad:setPickable(false);
		end
		self:startAction();
	end
end

RoomActContainer.removeFromStageHandler = function(self)
	self:stopAction();

	clearInterval(self.m_intervalNum1);
	self.m_intervalNum1 = 0;
	self.m_background:setTransparency(0);

	if(self.m_actArr == nil) then
		return;
	end
--	local len = #self.m_actArr;
--	for i=1,len do
--		self.m_actArr[i]:removeFromParent();
--	end
	self.m_actArr = {};
	self.m_actNum = 0;
end

RoomActContainer.startAction = function(self)
	if(self.m_actArr == nil) then
		return;
	end
	for i=1,#self.m_actArr do
		if(i == 1) then
			self.m_actArr[i]:setVisible(true);
			self.m_actArr[i]:setTransparency(1);
--			self.m_actArr[i]:setPickable(true);
			self.m_currentIndex = 1;
		else
			self.m_actArr[i]:setVisible(false);
		end
	end
	if(#self.m_actArr > 1) then
		self.m_intervalNum = setInterval(self.actionPlay, self, 30000);
	end
end

RoomActContainer.actionPlay = function(self)
	if(self.m_actArr ~= nil and #self.m_actArr > 0) then
		local fade = new(ActionFadeTo, 1, 0);
		local onFadeEnd = new(ActionCallFuncN, self, function(self)
			self.m_actArr[self.m_currentIndex]:setVisible(false);
			self.m_nextIndex = self.m_currentIndex + 1;
			if(self.m_nextIndex > #self.m_actArr) then
				self.m_nextIndex = 1;
			end
			self.m_actArr[self.m_nextIndex]:setVisible(true);
			self.m_actArr[self.m_nextIndex]:setTransparency(0);
			local fade = new(ActionFadeTo, 1, 1);
			local onFadeEnd = new(ActionCallFuncN, self, function(self)
				self.m_currentIndex = self.m_nextIndex;
			end);
			local action = new(ActionSequence, fade, onFadeEnd);
			action:apply(self.m_actArr[self.m_nextIndex]);
		end);
		local action = new(ActionSequence, fade, onFadeEnd);
		action:apply(self.m_actArr[self.m_currentIndex]);
	end
end

RoomActContainer.stopAction = function(self)
	clearInterval(self.m_intervalNum);
	if(self.m_actArr ~= nil) then
		for i=1,#self.m_actArr do
			ActionBase.stopAllActions(self.m_actArr[i]);
		end
	end
end

RoomActContainer.actContainerTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
	TouchHelper.catch(self, finger_action, x, y);
	if(TouchHelper.isClick(self)) then
		SoundManager.playButtonClickSound();
		--宝箱可领奖的时候点击直接领奖
		if(self.m_treasuerBox and self.m_treasuerBox:getVisible() and TreasureBox and TreasureBox.remainTime <= 0 and not TreasureBox.isFinished) then
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_ACTIVITY_TREASURE_BOX_RECEIVE_REWARD);
		else
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_ACTIVITY_PAGE_OPEN);
		end
	end
end

RoomActContainer.treasureBoxFinished = function(self)
	self:stopAction();
	if(self.m_actArr ~= nil) then
		for i=1,#self.m_actArr do
			if(typeof(self.m_actArr[i], TreasureBox)) then
				self.m_actArr[i]:setVisible(true);
				self.m_actArr[i]:setTransparency(1);
			else
				self.m_actArr[i]:setVisible(false);
			end
		end
	end
end

RoomActContainer.systemNoticeTaskFinished = function(self)
	self:stopAction();
	if(self.m_actArr ~= nil) then
		for i=1,#self.m_actArr do
			if(typeof(self.m_actArr[i], RoomActActivityIcon)) then
				self.m_actArr[i]:setVisible(true);
				self.m_actArr[i]:setTransparency(1);
			else
				self.m_actArr[i]:setVisible(false);
			end
		end
		if(self.m_intervalNum1 == 0 and StateMachine.getInstance():getCurrentState() == States.Room) then
			local target = 1;
			self.m_intervalNum1 = setInterval(function(self)
				local fade = new(ActionFadeTo, 0.8, target);
				local onEnd = new(ActionCallFuncN, self, function(self, node)
					if(node:getTransparency() >= 1) then
						target = 0;
					else
						target = 1;
					end
				end);
				local action = new(ActionSequence, fade, onEnd);
				action:apply(self.m_background);
			end,1600);
		end
	end
end

RoomActContainer.userReceivedReward = function(self)
	self:startAction();
	clearInterval(self.m_intervalNum1);
	self.m_intervalNum1 = 0;
	self.m_background:setTransparency(0);
end
