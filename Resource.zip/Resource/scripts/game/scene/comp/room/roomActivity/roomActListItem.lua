require("view/room/layout_room_act_list_item");

RoomActListItem = class(Node, false);

RoomActListItem.INVALIDATION_CHIPS_DATA = "INVALIDATION_CHIPS_DATA";

RoomActListItem.ctor = function(self, id, width, height)
	super(self);

	self.m_mWidth = 0;
	self.m_maxWidth = 0;
	self.m_mHeight = 0;
	self.m_data = nil;
	self.m_touchQuad = nil;
	self.m_iconContainer = nil;
	self.m_imageLoader = nil;
	self.m_treasureBoxIcon = nil;
	self.m_superLotto = nil;
	self.m_superLottoIcon = nil;
	self.m_superLottoChips = nil;
	self.m_progressDesc = nil;
	self.m_actTilte = nil;
	self.m_tipLabel = nil;
	self.m_rewardButton = nil;
	self.m_progressBar = nil;
	self.m_partLine = nil;
	self.m_hotActImage = nil;
	self.m_newActImage = nil;
	self.m_actID = 0;

	self.m_actID = id;
	self.m_mWidth = width;
	self.m_mHeight = height;
	self:setSize(self.m_mWidth, self.m_mHeight);

	self:initialize();
	self:addEventAndDataList();
	self:addToStageHandler();
end

RoomActListItem.dtor = function(self)
	self:delEventAndDataList();
	self:removeFromStageHandler();
end

RoomActListItem.addEventAndDataList = function(self)
	if(self.m_eventList == nil) then
		self.m_eventList =
		{
		};
		EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
	end
end

RoomActListItem.delEventAndDataList = function(self)
	if(self.m_eventList ~= nil) then
		EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
		self.m_eventList = nil;
	end
end

RoomActListItem.initialize = function(self)
	self.m_root = SceneLoader.load(layout_room_act_list_item);
	self:addChild(self.m_root);

	self.m_touchQuad = self.m_root:getNodeByName("item");
	self.m_touchQuad:setEventTouch(self, self.touchHandler);

	self.m_iconContainer = self.m_root:getNodeByName("item.icon_container");

	self.m_imageLoader = new(UrlImage, "room/room_act_disable_icon.png");
	self.m_imageLoader:setSize(50, 50);
--	self.m_imageLoader.addEventListener(Event.COMPLETE, loadImageCompleteHandler);
	self.m_imageLoader:setPickable(false);

	if(self.m_actID == 0) then
		self.m_treasureBoxIcon = new(TreasureBox);
		self.m_treasureBoxIcon:setPickable(false);
		self.m_iconContainer:addChild(self.m_treasureBoxIcon);
	elseif(self.m_actID == 1) then
		self.m_superLotto = new(Node);
		self.m_superLottoIcon = new(Image, "room/superlotto/lotto-icon.png");
		self.m_superLottoIcon:setScale(0.7);
		self.m_superLotto:addChild(self.m_superLottoIcon);
		self.m_superLottoIcon:setPos(0, 0);
		self.m_superLottoChips = new(Text, "......", nil, nil, kTextAlignCenter, nil, 16, 0xff, 0xcc, 0x00);
		self.m_superLotto:addChild(self.m_superLottoChips);

		self.m_iconContainer:addChild(self.m_superLotto);
		self.m_superLotto:setPickable(false);
	else
		self.m_iconContainer:addChild(self.m_imageLoader);
	end

	self.m_progressDesc = self.m_root:getNodeByName("item.progress_desc");
	self.m_progressDesc:setPickable(false);

	self.m_actTilte = self.m_root:getNodeByName("item.act_title");
	self.m_actTilte:setPickable(false);

	self.m_tipLabel = self.m_root:getNodeByName("item.tip_label");
	self.m_tipLabel:setText(STR_ACTIVITY_ACTIVITY_TIP_VIEW_DETAIL);
	self.m_tipLabel:setPickable(false);

	self.m_rewardButton = self.m_root:getNodeByName("item.btn_reward");
	self.m_rewardButton:setVisible(false);
	local label = self.m_root:getNodeByName("item.btn_reward.label");
	label:setText(STR_LOGIN_DRAW_REWARD);
	self.m_rewardButton:setOnClick(self, self.rewardBtnTriggered);

	self.m_progressBar = new(ProgressBar, 150, nil, "activity/room_act_progress_back.png", "activity/room_act_progress_up.png", 7, 7, 6, 6);
	self.m_progressBar:setMax(1);
	self.m_progressBar:setProgress(0);
	self:addChild(self.m_progressBar);
	self.m_progressBar:setVisible(false);

	self.m_hotActImage = self.m_root:getNodeByName("item.hot_act");
	self.m_hotActImage:setVisible(false);

	self.m_newActImage = self.m_root:getNodeByName("item.new_act");
	self.m_newActImage:setVisible(false);
end

RoomActListItem.addToStageHandler = function(self)
	if(self.m_actID == 1 and self.m_superLottoChips ~= nil) then
		Model.watchData(ModelKeys.LOTTO_POOL, self, self.lottoPoolChange, false);
	end
end

RoomActListItem.removeFromStageHandler = function(self)
	Model.unwatchData(ModelKeys.LOTTO_POOL, self, self.lottoPoolChange);
end

RoomActListItem.lottoPoolChange = function(self, newValue)
	self.m_superLottoChips:setText(Formatter.formatBigNumber(newValue));
	self:draw();
end

RoomActListItem.draw = function(self)
	if(self.m_data) then
		if(self.m_data.activityData and self.m_data.activityData.roomActImageUrl) then
			self.m_imageLoader:setUrl(self.m_data.activityData.roomActImageUrl);
		else
			self.m_imageLoader:setFile("room/room_act_disable_icon.png");
		end

		if(self.m_data.hasRewardBtn) then
			self.m_rewardButton:setVisible(true);
		else
			self.m_rewardButton:setVisible(false);
		end

		self.m_actTilte:setText(self.m_data.actName);
		if(self.m_data.hasProgress) then
			self.m_progressBar:setVisible(true);
			self.m_progressDesc:setVisible(true);
			local count = "";
			local target = "";
			if(self.m_data.count > 10000) then
				count = Formatter.formatBigNumber(self.m_data.count, false);
			else
				count = tostring(self.m_data.count);
			end

			if(self.m_data.target > 10000) then
				target = Formatter.formatBigNumber(self.m_data.target,false);
			else
				target = tostring(self.m_data.target);
			end
			self.m_progressDesc:setText(count .. "/" .. target);
			if(self.m_data.count < self.m_data.target) then
				self.m_progressBar:setProgress(self.m_data.count / self.m_data.target);
--				if(self.m_progressBar.value == 0) then
--				{
--					self.m_progressBar.isEnabled = false;
--				}
--				else
--				{
--					self.m_progressBar.isEnabled = true;
--				}
			else
--				self.m_progressBar.isEnabled = true;
				self.m_rewardButton:setVisible(true);
				self.m_progressBar:setProgress(1);
			end
		else
			self.m_progressBar:setVisible(false);
			self.m_progressDesc:setVisible(false);
		end

		local isPro = self.m_progressDesc:getVisible();
		if(self.m_data.isHotRoomAct) then
			self.m_hotActImage:setVisible(true);
			self.m_progressDesc:setVisible(false);
		else
			self.m_hotActImage:setVisible(false);
			self.m_progressDesc:setVisible(isPro);
		end

		isPro = self.m_progressDesc:getVisible();
		if(self.m_data.isNewRoomAct) then
			self.m_newActImage:setVisible(true);
			self.m_progressDesc:setVisible(false);
		else
			self.m_newActImage:setVisible(false);
			self.m_progressDesc:setVisible(isPro);
		end
	end

	local w,h = self.m_iconContainer:getSize();
	if(self.m_progressDesc:getVisible() or self.m_hotActImage:getVisible() or self.m_newActImage:getVisible()) then
		if(self.m_progressDesc:getVisible()) then
			self.m_iconContainer:setPos((90 - w) * 0.5, (self.m_mHeight - (h + ToolKit.getNodeHeight(self.m_progressDesc) + 4)) * 0.5);
		elseif(self.m_hotActImage:getVisible()) then
			self.m_iconContainer:setPos((90 - w) * 0.5, (self.m_mHeight - (h + ToolKit.getNodeHeight(self.m_hotActImage) + 4)) * 0.5);
		elseif(self.m_newActImage:getVisible()) then
			self.m_iconContainer:setPos((90 - w) * 0.5, (self.m_mHeight - (h + ToolKit.getNodeHeight(self.m_hotActImage) + 4)) * 0.5);
		end
	else
		self.m_iconContainer:setPos((90 - w) * 0.5, (self.m_mHeight - h) * 0.5);
	end

	if(self.m_progressDesc:getVisible()) then
		local _,y = self.m_iconContainer:getPos();
		self.m_iconContainer:setPos(nil, y + 6);
	end

	if(self.m_actID == 0) then
		local _,y = self.m_iconContainer:getPos();
		self.m_iconContainer:setPos(nil, y + 6);
	end

	local x = (90 - ToolKit.getNodeWidth(self.m_progressDesc)) * 0.5;
	local y = ToolKit.getNodeY(self.m_iconContainer) + ToolKit.getNodeHeight(self.m_iconContainer);
	self.m_progressDesc:setPos(x, y);

	local x = (90 - ToolKit.getNodeWidth(self.m_hotActImage)) * 0.5;
	local y = ToolKit.getNodeY(self.m_iconContainer) + ToolKit.getNodeHeight(self.m_iconContainer) + 4;
	self.m_hotActImage:setPos(x, y);

	local x = (90 - ToolKit.getNodeWidth(self.m_newActImage)) * 0.5;
	local y = ToolKit.getNodeY(self.m_iconContainer) + ToolKit.getNodeHeight(self.m_iconContainer) + 4;
	self.m_newActImage:setPos(x, y);

	if(self.m_actID == 1) then
		local _,y = self.m_iconContainer:getPos();
		self.m_iconContainer:setPos(nil, y - 8);
		self.m_actTilte:setPos(90, (self.m_mHeight - (ToolKit.getNodeHeight(self.m_actTilte) + ToolKit.getNodeHeight(self.m_tipLabel) + 8)) * 0.5);
	else
		self.m_actTilte:setPos(90, ToolKit.getNodeY(self.m_iconContainer) - 8);
	end

	if(self.m_progressBar:getVisible()) then
		self.m_tipLabel:setPos(ToolKit.getNodeX(self.m_actTilte), ToolKit.getNodeY(self.m_iconContainer) + ToolKit.getNodeHeight(self.m_iconContainer) - ToolKit.getNodeHeight(self.m_tipLabel));

		if(self.m_progressDesc:getVisible()) then
			local x = ToolKit.getNodeX(self.m_actTilte);
			local y = ToolKit.getNodeY(self.m_progressDesc) + (ToolKit.getNodeHeight(self.m_progressDesc) - ToolKit.getNodeHeight(self.m_progressBar)) * 0.5;
			self.m_progressBar:setPos(x, y);
		elseif(self.m_hotActImage:getVisible()) then
			self.m_progressBar:setPos(nil, ToolKit.getNodeY(self.m_hotActImage) + (ToolKit.getNodeHeight(self.m_hotActImage) - ToolKit.getNodeHeight(self.m_progressBar)) * 0.5);
		elseif(self.m_newActImage:getVisible()) then
			self.m_progressBar:setPos(nil, ToolKit.getNodeY(self.m_newActImage) + (ToolKit.getNodeHeight(self.m_newActImage) - ToolKit.getNodeHeight(self.m_progressBar)) * 0.5);
		end
	else
		if(self.m_actID == 1) then
			self.m_tipLabel:setPos(ToolKit.getNodeX(self.m_actTilte), ToolKit.getNodeY(self.m_actTilte) + ToolKit.getNodeHeight(self.m_actTilte) + 8);
		else
			self.m_tipLabel:setPos(ToolKit.getNodeX(self.m_actTilte), ToolKit.getNodeY(self.m_iconContainer) + ToolKit.getNodeHeight(self.m_iconContainer) - ToolKit.getNodeHeight(self.m_tipLabel));
		end
	end

	self.m_rewardButton:setPos(self.m_mWidth - ToolKit.getNodeWidth(self.m_rewardButton) - 12, (self.m_mHeight - ToolKit.getNodeHeight(self.m_rewardButton)) * 0.5);

	if(self.m_actID == 0) then
		self.m_tipLabel:setVisible(false);
		self.m_actTilte:setPos(nil, (self.m_mHeight - ToolKit.getNodeHeight(self.m_actTilte)) * 0.5);

		if(TreasureBox.remainTime <= 0 and not TreasureBox.isFinished) then
			self.m_rewardButton:setVisible(true);
		else
			self.m_rewardButton:setVisible(false);
		end
	end
	if(self.m_actID == 1) then
		local x = (ToolKit.getNodeWidth(self.m_superLottoIcon) - ToolKit.getNodeWidth(self.m_superLottoChips)) * 0.5;
		local y = ToolKit.getNodeHeight(self.m_superLottoIcon) + 6;
		self.m_superLottoChips:setPos(x, y);
	end

	local text = self.m_actTilte:getText();
	if(self.m_rewardButton:getVisible()) then
		Formatter.spliceSingleLineLongString(self.m_actTilte:getText(), ToolKit.getNodeX(self.m_rewardButton) - ToolKit.getNodeX(self.m_actTilte) - 16, self.m_actTilte);
	else
		self.m_actTilte:setText(text);
		Formatter.spliceSingleLineLongString(self.m_actTilte:getText(), self.m_mWidth - ToolKit.getNodeX(self.m_actTilte) - 30, self.m_actTilte);
	end
end

RoomActListItem.getData = function(self)
	return self.m_data;
end

RoomActListItem.setData = function(self, value)
	self.m_data = value;
	self:draw();
end

RoomActListItem.touchHandler = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
	TouchHelper.catch(self, finger_action, x, y);
	if(TouchHelper.isClick(self)) then
		SoundManager.playButtonClickSound();
		if(self.m_actID == 0) then
			if(TreasureBox.isFinished) then
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP,
					{["message"]=STR_ROOM_TREASURE_BOX_FINISHED});
			elseif(not TreasureBox.isSitDown) then
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP,
					{["message"]=STR_ROOM_TREASURE_BOX_NOT_SIT_DOWN});
			elseif(TreasureBox.remainTime > 0) then
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP,
					{["message"]=StringKit.substitute(STR_ROOM_TREASURE_BOX_NOT_REWARD, Formatter.secondTo0M(TreasureBox.remainTime), 
						Formatter.secondTo0S(TreasureBox.remainTime), TreasureBox.reward), ["key"]=STR_ROOM_TREASURE_BOX_NOT_REWARD});
			elseif(TreasureBox.remainTime == 0) then
				self:rewardBtnTriggered();
			end
		elseif(self.m_actID == 1) then
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_SUPER_LOTTO_POPUP);
		elseif(self.m_actID == 2) then
			if(self.m_data.activityData.actId==17) then
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.DIDMOND_WINNER_REWARD_POPUP);
			else
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_ACT_NEWEST, 0);
			end
		elseif(self.m_actID == 3) then
			if(self.m_data.activityData.actId==17) then
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.DIDMOND_WINNER_REWARD_POPUP);
			else
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_ACT_NEWEST, 1);
			end
		elseif(self.m_actID == 4) then
			if(self.m_data.activityData.actId==17) then
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.DIDMOND_WINNER_REWARD_POPUP);
			else
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_ACT_NEWEST, 2);
			end
		end
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_ACTIVITY_PAGE_HIDE);
	end
end

--领奖按钮
RoomActListItem.rewardBtnTriggered = function(self)
	if(self.m_actID == 0) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_ACTIVITY_TREASURE_BOX_RECEIVE_REWARD);
	elseif(self.m_actID == 2) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_ACT_NEWEST, 0);
	elseif(self.m_actID == 3) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_ACT_NEWEST, 1);
	elseif(self.m_actID == 4) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_ACT_NEWEST, 2);
	end
	self.m_rewardButton:setVisible(false);
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_ACTIVITY_USER_RECEIVED_REWARD);
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.ROOM_ACTIVITY_PAGE_HIDE);
end

--RoomActListItem.loadImageCompleteHandler = function(self, evt)
--	local container:DisplayObjectContainer = evt.target as DisplayObjectContainer;
--	if(container and container.numChildren > 0)
--	{				
--		local image:Image = container.getChildAt(0) as Image;
--		if(image)
--		{
--			--image.smoothing = TextureSmoothing.BILINEAR;
--			image.scaleX = RuntimeInfo.instance.layoutScale;
--			image.scaleY = RuntimeInfo.instance.layoutScale;
--					
--			invalidate(INVALIDATION_FLAG_DATA);
--		}
--	}
--end

RoomActListItem.getActID = function(self)
	return self.m_actID;
end
