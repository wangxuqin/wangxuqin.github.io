RoomActListData = class();

RoomActListData.ctor = function(self)
	self.actId = -1;
	self.actName = "";
	self.hasProgress = false;
	self.count = -1;--凡是表示筹码数的应该用number类型，int类型会溢出
	self.target = 0;
	self.hasRewardBtn = false;
	self.progerssString = "";
	self.isHotRoomAct = false;
	self.isNewRoomAct = false;
	self.activityData = nil;
end
