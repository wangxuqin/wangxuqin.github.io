TableLight = class(Image);

TableLight.ctor = function (self, file)
    self.m_sizeX,self.m_sizeY = self:getSize();
    self:setPos((1280 - self.m_sizeX)/2 , 720/2-35);
    self.m_posX,self.m_posY = self:getPos();
    self.m_rotSeq = anim_alloc_id();
    self.m_scaleSeq = anim_alloc_id();
    self.m_tempAngle = 0;
    self.m_tempScale = 1;
end

TableLight.rotation = function (self,seatPos)
    local angle = 0;
    if seatPos then
        if  seatPos.y == self.m_posY then		
            if seatPos.x > self.m_posX then
                angle = - math.pi * 0.5;  
            else
                angle = math.pi * 0.5;		
            end
        elseif seatPos.x == self.m_posX then
		    if seatPos.y > self.m_posY then  
                angle = 0
            else
                angle = math.pi;
            end
        else
		    angle = math.atan((self.m_posX - seatPos.x) / (seatPos.y - self.m_posY));
		    if seatPos.x > self.m_posX then
		        if angle > 0 then 
			        angle = - math.pi + angle
                end
		    else
		        if angle <= 0 then 
			        angle = math.pi + angle;
                end
		    end
        end
    end

    if math.abs(self.m_tempAngle - angle) > math.pi then
        if angle > math.pi then
            angle = angle - 2 * math.pi; 
        end
    else
        if angle > math.pi + self.m_tempAngle then
            angle = angle - 2 * math.pi; 
        end
    end

	angle = angle * 360 / (math.pi * 2) + 10;
    scale = math.sqrt((seatPos.x - self.m_posX) * (seatPos.x - self.m_posX) + (seatPos.y - self.m_posY) * (seatPos.y - self.m_posY)) / self.m_sizeY * 0.8;
    
    local animRot = {};
    if self.m_rotSeq then
        animRot = self:addPropRotate(self.m_rotSeq,0, 300, 0, self.m_tempAngle, angle, 2, self.m_sizeX / 2 , 0)
	end
    local animScale = {}
    if self.m_scaleSeq then
       animScale = self:addPropScale(self.m_scaleSeq, 0, 300, 0, 1, 1, self.m_tempScale, scale, 2, self.m_sizeX / 2 , 0)
    end

    if animRot then
        animRot:setEvent(self,function (self)
            self:removeProp(self.m_rotSeq);
            self:addPropRotateSolid(self.m_rotSeq,angle, 2, self.m_sizeX / 2 , 0);
        end)
    end

    self.m_tempAngle = angle;
    self.m_tempScale = scale;
end
