require("game/scene/comp/room/handCard");
DealCardManager = {};

DealCardManager.TAG = "DealCardManager";

DealCardManager.DEALER_POS = {x = 640, y = 180}; 
DealCardManager.MY_DEAL_CARD_DURATION = 150;
DealCardManager.DEAL_CARD_DURATION = DealCardManager.MY_DEAL_CARD_DURATION / 1000;
DealCardManager.DEAL_SECOND_CARD_DEALY = 0;

DealCardManager.initialize = function (self, scene)
    self.m_leftCard = {};
    self.m_rightCard = {};
    self.m_scene = scene;

    for i = 1, 9 do 
        self.m_leftCard[i] = new(Image,"room/room-deal-hand-card-1.png");

        self.m_leftCard[i]:setTransparency(1);
        self.m_leftCard[i]:setVisible(false);
        self.m_leftCard[i]:setPickable(false);

        self.m_rightCard[i] = new(Image,"room/room-deal-hand-card-2.png");

        self.m_rightCard[i]:setTransparency(1);
        self.m_rightCard[i]:setVisible(false);
        self.m_rightCard[i]:setPickable(false);

        self.m_scene:addChild(self.m_leftCard[i]);
        self.m_scene:addChild(self.m_rightCard[i]);       
    end
end

DealCardManager.dealCard = function (self,userSeat,cardIndex)
--	Log.d(DealCardManager.TAG, "seat:" .. userSeat.m_positionId .. ",cardIndex=" .. cardIndex);
    local xOffset = 140;
    local yOffset = 52;
    if userSeat:isSelf() then
        if cardIndex == 1 then
			local card = self.m_leftCard[userSeat.m_positionId];
            card:setVisible(true);

			KTween.remove(card);
			KTween.to(card, DealCardManager.MY_DEAL_CARD_DURATION + DealCardManager.DEAL_SECOND_CARD_DEALY,
				{
					startX = DealCardManager.DEALER_POS.x,
					startY = DealCardManager.DEALER_POS.y,
					x = SeatManager.m_dealCardPositionV[5].x+xOffset,
					y = SeatManager.m_dealCardPositionV[5].y+yOffset,
					startScale = 1,
					scale = 3.5,
					startAlpha = 0,
					alpha = 1,
					onComplete = self.onAnimLeftEnd,
					onCompleteParams = self,
				});
            self.m_animLeftEndInfo = {card,1};
        else
			local card = self.m_rightCard[userSeat.m_positionId];
            card:setVisible(true);

			KTween.remove(card);
			KTween.to(card, DealCardManager.MY_DEAL_CARD_DURATION,
				{
					delay = DealCardManager.DEAL_SECOND_CARD_DEALY,
					startX = DealCardManager.DEALER_POS.x,
					startY = DealCardManager.DEALER_POS.y,
					x = SeatManager.m_dealCardPositionV[5].x+xOffset + 4,
					y = SeatManager.m_dealCardPositionV[5].y+yOffset - 4,
					startScale = 1,
					scale = 3.5,
					startAlpha = 0,
					alpha = 1,
					onComplete = self.onAnimRightEnd,
					onCompleteParams = self,
				});
            self.m_animRightEndInfo = {card,2};
        end
    else
        if cardIndex == 1 then
			local card = self.m_leftCard[userSeat.m_positionId];
            card:setVisible(true);

			KTween.remove(card);
			KTween.to(card, DealCardManager.MY_DEAL_CARD_DURATION,
						{
							startX = DealCardManager.DEALER_POS.x,
							startY = DealCardManager.DEALER_POS.y,
							x = SeatManager.m_dealCardPositionV[userSeat.m_positionId].x + 4,
							y = SeatManager.m_dealCardPositionV[userSeat.m_positionId].y - 4,
							startAlpha = 0,
							alpha = 1,
						});
        else
			local card = self.m_rightCard[userSeat.m_positionId];
            card:setVisible(true);

			KTween.remove(card);
			KTween.to(card, DealCardManager.MY_DEAL_CARD_DURATION,
						{
							startX = DealCardManager.DEALER_POS.x,
							startY = DealCardManager.DEALER_POS.y,
							x = SeatManager.m_dealCardPositionV[userSeat.m_positionId].x + 4,
							y = SeatManager.m_dealCardPositionV[userSeat.m_positionId].y - 4,
							startAlpha = 0,
							alpha = 1,
						});
        end
    end

end


--����Ҫ��Ҫд��һ��----------------------------------
DealCardManager.onAnimLeftEnd = function (self)
    self.m_animLeftEndInfo[1]:setVisible(false);
    if SeatManager.selfInGame then
        SeatManager:getSelfSeat():getHandCard().m_handCard[1]:setVisible(true);
        SeatManager:getSelfSeat():getHandCard().m_handCard[1]:showBack();
        --SeatManager:getSelfSeat().m_handCard:setHandCardShowingPosition(DealCardManager.DEALER_POS.x+20,DealCardManager.DEALER_POS.y+300);
    end
end

DealCardManager.onAnimRightEnd = function (self)
    self.m_animRightEndInfo[1]:setVisible(false);
    if SeatManager.selfInGame then
        SeatManager:getSelfSeat():getHandCard().m_handCard[2]:setVisible(true);
        SeatManager:getSelfSeat():getHandCard().m_handCard[2]:showBack();
    end

    local selfSeat = SeatManager:getSelfSeat();
    if(selfSeat and selfSeat.m_handCard) then
        selfSeat.m_handCard:flipHandCard();
    end
    self.m_roundEnd = true;
end
------------------------------------------------------

--DealCardManager.visibleDealCard = function (self, positionId)
--    self.m_leftCard[positionId]:setVisible(true);   
--    self.m_rightCard[positionId]:setVisible(true);
--    self.m_leftCard[positionId]:addPropTransparency(0, kAnimNormal, 16, 0, 0, 0);
--    self.m_rightCard[positionId]:addPropTransparency(0, kAnimNormal, 16, 0, 0, 0);
--end

DealCardManager.showDealCard = function (self, positionId)
    self.m_leftCard[positionId]:setVisible(true);
    self.m_leftCard[positionId]:setTransparency(1);
    self.m_leftCard[positionId]:setPos(SeatManager.m_dealCardPositionV[positionId].x,SeatManager.m_dealCardPositionV[positionId].y);

    self.m_rightCard[positionId]:setVisible(true);
    self.m_rightCard[positionId]:setTransparency(1);
    self.m_rightCard[positionId]:setPos(SeatManager.m_dealCardPositionV[positionId].x + 4,SeatManager.m_dealCardPositionV[positionId].y - 4);
end

DealCardManager.hideDealCard = function (self, positionId)
    self.m_leftCard[positionId]:setVisible(false);
    self.m_rightCard[positionId]:setVisible(false);
end

--����
DealCardManager.foldCard = function (self,positionId)
	local leftCard = self.m_leftCard[positionId];
	local rightCard = self.m_rightCard[positionId];
	if(positionId == 5) then
		KTween.remove(leftCard);
		KTween.to(leftCard, DealCardManager.MY_DEAL_CARD_DURATION,
			{
				startX = SeatManager.m_dealCardPositionV[positionId].x,
				startY = SeatManager.m_dealCardPositionV[positionId].y,
				x = DealCardManager.DEALER_POS.x,
				y = DealCardManager.DEALER_POS.y,
				startAlpha = 1,
				alpha = 0.2,
			});
		KTween.remove(rightCard);
		KTween.to(rightCard, DealCardManager.MY_DEAL_CARD_DURATION,
			{
				startX = SeatManager.m_dealCardPositionV[positionId].x,
				startY = SeatManager.m_dealCardPositionV[positionId].y,
				x = DealCardManager.DEALER_POS.x,
				y = DealCardManager.DEALER_POS.y,
				startAlpha = 1,
				alpha = 0.2,
				onComplete = self.onFoldEnd,
				onCompleteParams = self,
			});
	else
		KTween.remove(leftCard);
		KTween.to(leftCard, DealCardManager.MY_DEAL_CARD_DURATION,
			{
				startX = SeatManager.m_dealCardPositionV[positionId].x,
				startY = SeatManager.m_dealCardPositionV[positionId].y,
				x = DealCardManager.DEALER_POS.x,
				y = DealCardManager.DEALER_POS.y,
				startAlpha = 1,
				alpha = 0.2,
			});
		KTween.remove(rightCard);
		KTween.to(rightCard, DealCardManager.MY_DEAL_CARD_DURATION,
			{
				startX = SeatManager.m_dealCardPositionV[positionId].x,
				startY = SeatManager.m_dealCardPositionV[positionId].y,
				x = DealCardManager.DEALER_POS.x,
				y = DealCardManager.DEALER_POS.y,
				startAlpha = 1,
				alpha = 0.2,
				onComplete = self.onFoldEnd,
				onCompleteParams = self,
			});
	end
	self.m_foldCardId = positionId;
end

DealCardManager.onFoldEnd = function (self)
    if self.m_foldCardId == 5 then
        self.m_leftCard[self.m_foldCardId]:setVisible(false);
        self.m_rightCard[self.m_foldCardId]:setVisible(false);
        self.m_leftCard[self.m_foldCardId]:removeProp(self.m_myLeftSeqTrans);
        self.m_leftCard[self.m_foldCardId]:removeProp(self.m_myLeftSeqAlpha);
        self.m_rightCard[self.m_foldCardId]:removeProp(self.m_myRightSeqTrans);
        self.m_rightCard[self.m_foldCardId]:removeProp(self.m_myRightSeqAlpha);
    else
        self:hideDealCard(self.m_foldCardId);
    end
end

DealCardManager.moveDealCardToSeat = function (self, userSeat)
--	Log.d(DealCardManager.TAG, "moveDealCardToSeat:" .. tostring(self.m_leftCard));
	if(self.m_leftCard) then
		KTween.remove(self.m_leftCard[userSeat.m_positionId]);
		KTween.to(self.m_leftCard[userSeat.m_positionId], DealCardManager.MY_DEAL_CARD_DURATION * 2,
			{
				startX = SeatManager.m_dealCardPositionV[userSeat.m_positionId].x,
				startY = SeatManager.m_dealCardPositionV[userSeat.m_positionId].y,
				x = SeatManager.m_seatPositionV[userSeat.m_positionId].x + UserSeat.SEAT_WIDTH * 0.5 - 12, 
				y = SeatManager.m_seatPositionV[userSeat.m_positionId].y + UserSeat.SEAT_HEIGHT * 0.5 - 16,
			});

		KTween.remove(self.m_rightCard[userSeat.m_positionId]);
		KTween.to(self.m_rightCard[userSeat.m_positionId], DealCardManager.MY_DEAL_CARD_DURATION * 2,
			{
				startX = SeatManager.m_dealCardPositionV[userSeat.m_positionId].x,
				startY = SeatManager.m_dealCardPositionV[userSeat.m_positionId].y,
				x = SeatManager.m_seatPositionV[userSeat.m_positionId].x + UserSeat.SEAT_WIDTH * 0.5 - 12, 
				y = SeatManager.m_seatPositionV[userSeat.m_positionId].y + UserSeat.SEAT_HEIGHT * 0.5 - 16,
				onComplete = self.onMoveToSeatEnd,
				onCompleteParams = self,
			});

		self.m_moveToSeatUser = userSeat;
	end
end

DealCardManager.onMoveToSeatEnd = function (self)
    self.m_leftCard[self.m_moveToSeatUser.m_positionId]:setVisible(false);
    self.m_rightCard[self.m_moveToSeatUser.m_positionId]:setVisible(false);

	self.m_moveToSeatUser.m_handCard:showHandCard();
	self.m_moveToSeatUser.m_handCard:resetHandCardPosition();
	self.m_moveToSeatUser.m_handCard.m_handCard[1]:showBack();
	self.m_moveToSeatUser.m_handCard.m_handCard[2]:showBack();
    self.m_moveToSeatUser.m_handCard:flipHandCard();
end

DealCardManager.dealAllCardComplete = function (self)
    
end

DealCardManager.resetPosition = function (self)
    for i = 1, 9 do
        if self.m_leftCard[i] ~= nil and self.m_leftCard[i].m_seqTrans ~= nil then
--			Log.d(DealCardManager.TAG, "removeprop left");
            self.m_leftCard[i]:removeProp(self.m_leftCard[i].m_seqTrans);
			self.m_leftCard[i].m_seqTrans = nil;
        end
        if self.m_rightCard[i] ~= nil and self.m_rightCard[i].m_seqTrans ~= nil then
--			Log.d(DealCardManager.TAG, "removeprop right");
            self.m_rightCard[i]:removeProp(self.m_rightCard[i].m_seqTrans);
			self.m_rightCard[i].m_seqTrans = nil;
        end
		if(self.m_leftCard[i]) then
			KTween.remove(self.m_leftCard[i]);
		end
		if(self.m_rightCard[i]) then
			KTween.remove(self.m_rightCard[i]);
		end
    end
end

DealCardManager.refresh = function (self)
    for i = 1, 9 do
        if self.m_leftCard ~= nil then
            self.m_leftCard[i]:setVisible(false);
        end
        
        if self.m_rightCard ~= nil then
            self.m_rightCard[i]:setVisible(false);
        end

        if self.m_leftCard[i] ~= nil and self.m_leftCard[i].m_seqAlpha ~= nil then
            self.m_leftCard[i]:removeProp(self.m_leftCard[i].m_seqAlpha);
        end

        if self.m_rightCard[i] ~= nil and self.m_rightCard[i].m_seqAlpha ~= nil then
            self.m_rightCard[i]:removeProp(self.m_rightCard[i].m_seqAlpha);
        end

        if  self.m_leftCard[i] and self.m_rightCard[i] and self.m_leftCard[i].m_seqScale then
            self.m_leftCard[i]:removeProp(self.m_leftCard[i].m_seqScale);
            self.m_rightCard[i]:removeProp(self.m_rightCard[i].m_seqScale);
        end
    end
end

DealCardManager.cleanUp = function (self)
    if self.m_roundEnd == true then
        self:resetPosition();
        self:refresh();
    end
end