require("view/room/layout_room_calculator");
require("game/scene/comp/room/calculator/cardTypeUnit");

CalculatorPanel = class(Node, false);

CalculatorPanel.CARD_TYPE = {
	{0x040A, 0x040B, 0x040C, 0x040D, 0x040E}, 
	{0x0308, 0x0309, 0x030A, 0x030B, 0x030C}, 
	{0x040E, 0x030E, 0x020E, 0x010E, 0x040C}, 
	{0x040D, 0x030D, 0x020D, 0x040A, 0x030A}, 
	{0x030E, 0x030C, 0x0309, 0x0308, 0x0306}, 
	{0x0306, 0x0207, 0x0408, 0x0109, 0x030A}, 
	{0x030C, 0x020C, 0x040C, 0x030E, 0x0108}, 
	{0x040E, 0x020E, 0x030C, 0x010C, 0x0308},
};

CalculatorPanel.ctor = function(self, triggeredButton, scene)
	super(self)
    self.m_root                 = SceneLoader.load(layout_room_calculator);

    self.m_scene                = scene;
    self.m_ratio                = self:getDefaultRatio();
    self.m_maxIndex             = -1;
    self.m_units = {};
    for i=1,#self.CARD_TYPE do
        local item = self.m_root:getNodeByName("bg.unit_container.item"..i);
		self.m_units[i] = new(CardTypeUnit, CalculatorPanel.CARD_TYPE[i], STR_ROOM_CARD_TYPE[12 - i]);
		item:addChild(self.m_units[i]);
	end
	self.m_txtTitle = self.m_root:getNodeByName("bg.txt_title");
	self.m_txtTitle:setPickable(false);

	--添加桌面滑动事件监听器
    if triggeredButton ~= nil then
        triggeredButton:setOnClick(self, self.buttonTriggeredHandler);
    end

    self:addEventList();
    self:watchData();
    self:setRatio(self.m_ratio);

    self:setSize(self.m_root:getSize());
    self:addChild(self.m_root);
end

CalculatorPanel.dtor = function(self)
    self:unwatchData();
    self:removeEventList();
    Node.dtor(self);
end

CalculatorPanel.addEventList = function(self)
    if self.m_eventList == nil then
        self.m_eventList = {
            {UIEvent, UIEvent.s_cmd.ROOM_CLEAR_CALCULATOR,   "onClearCalculator"};
            {UIEvent, UIEvent.s_cmd.TOUCH_ROOM_SCENE_BG,     "onTouchRoomSceneBg"};  --触摸房间背景
            {UIEvent, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM, "onRemoveFromStage"};--侦听被迫离开房间事件
        };
    end
    EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
end

CalculatorPanel.removeEventList = function(self)
    if self.m_eventList ~= nil then
        EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
    end
    self.m_eventList = nil;
end

CalculatorPanel.watchData = function(self)
    Model.watchData(ModelKeys.ROOM_CALCULATOR_DATA,self, self.setRatio);
	Model.watchData(ModelKeys.ROOM_CARD_TYPE,      self, self.setCardType, false);
end

CalculatorPanel.unwatchData = function(self)
    Model.unwatchData(ModelKeys.ROOM_CALCULATOR_DATA,self, self.setRatio);
	Model.unwatchData(ModelKeys.ROOM_CARD_TYPE,      self, self.setCardType);
end

--[Comment]
--设置概率
CalculatorPanel.setRatio = function(self, data)
	self.m_ratio = data or self:getDefaultRatio();
    for i=1,#self.CARD_TYPE do
		self.m_units[i]:setProbability(self.m_ratio[i]);
	end
	
    local maxValue = math.max(unpack(self.m_ratio));
	
    if maxValue ~= 0 then
        index = ArrayKit.indexOf(self.m_ratio, maxValue);
		self:updateMaxRatioTip(index);
	else
		self:updateMaxRatioTip(-1);
	end
end

--设置牌桌上的最大概率 
CalculatorPanel.setRoomMaxRatioTip = function(self, index)
	if not TutotiaKit.isTutotia() then
        local str = string.format("%s:%.1f%%", STR_ROOM_CARD_TYPE[12 - index], self.m_ratio[index]);
		EventDispatcher.getInstance():dispatch(
            UIEvent.s_event,
            UIEvent.s_cmd.SHOW_ROOM_MAX_CARD_TIP, str
        );
	end
end

-- 算牌器数据清零
CalculatorPanel.onClearCalculator = function(self) 
    self:reset();
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_ROOM_MAX_CARD_TIP);
end

CalculatorPanel.setCardType = function(self, cardType) 
    self.m_ratio = self:getDefaultRatio();
	
    local index = 12 - cardType;
	if index >= 1 and index <= 8 then
		self.m_ratio[index] = 100.0;
		self:updateMaxRatioTip(index);
	else
		self:updateMaxRatioTip(-1);
	end
    
    for i=1,#self.CARD_TYPE do
		self.m_units[i]:setProbability(self.m_ratio[i]);
	end
end

CalculatorPanel.updateMaxRatioTip = function(self, index) 
	self.m_maxIndex = index;
    self:normalize();
    if self.m_maxIndex ~= -1 then
        self.m_units[self.m_maxIndex]:hightLight();
        self:setRoomMaxRatioTip(self.m_maxIndex);
    end

end

CalculatorPanel.reset = function(self)
    self.m_ratio = self:getDefaultRatio();
    if self.m_units ~= nil then
        for i = 1, #self.CARD_TYPE do
            self.m_units[i]:setProbability(self.m_ratio[i]);
            self.m_units[i]:normalize();
        end
    end
end

CalculatorPanel.normalize = function(self)
    if self.m_units ~= nil then
        for i = 1, #self.CARD_TYPE do
            self.m_units[i]:normalize();
        end
    end
end

--[Comment]
--获取默认概率
CalculatorPanel.getDefaultRatio = function(self)
   local ret = {}
   for i = 1, #self.CARD_TYPE do
        ret[i] = 0.0;
   end
   return ret;
end

CalculatorPanel.buttonTriggeredHandler = function(self)
	local parent = self:getParent();
    
    if parent ~= nil then
        if self.__moveWidth == nil then
            self.__moveWidth, _ = parent:getSize();
        end
        KTween.remove(parent);
        if parent:getVisible() then
		    KTween.to(parent, 300, {startX = self.__moveWidth, x = 0, startAlpha = 1, alpha = 0.8, delay = 100, onComplete = self.completeHandler, obj = self});
	    else
            parent:setVisible(true);
		    KTween.to(parent, 400, {startX = 0, x = self.__moveWidth, startAlpha = 0.8, alpha = 1, delay = 150});
	    end
    end
end



CalculatorPanel.completeHandler = function(self)
    local parent = self:getParent();
    if parent ~= nil then
        parent:setVisible(false);
        KTween.remove(parent);
    end
end 

CalculatorPanel.onTouchRoomSceneBg = function(self, data)
    if data ~= nil and data.finger_action == kFingerDown then
        local parent = self:getParent();
        if parent ~= nil and parent:getVisible() then
            self:buttonTriggeredHandler();
        end
    end
end
 
CalculatorPanel.onRemoveFromStage = function(self, data)
    local parent = self:getParent();
    if parent ~= nil then
        if parent:getVisible() then
            KTween.remove(parent);
		    KTween.to(parent, 300, {startX = self.__moveWidth, x = 0, startAlpha = 1, alpha = 0.8, delay = 100, onComplete = self.completeHandler, obj = self});
	    end
    end
end