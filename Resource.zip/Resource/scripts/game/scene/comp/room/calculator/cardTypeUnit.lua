require("view/room/layout_room_calculator_unit");
--算牌器

--[Comment]
--算牌器单元
CardTypeUnit = class(Node, false);

CardTypeUnit.ctor = function(self, cards, cardType) 
	super(self);
	self.m_cards                    = cards;
	self.m_cardType                 = cardType;
    self.m_root                     = SceneLoader.load(layout_room_calculator_unit);--边框
    self.m_imgFrame                 = self.m_root:getNodeByName("container.img_frame");

    for i=1,5 do
        local item = self.m_root:getNodeByName("container.card_container.item"..i);
		local card = new(PokerCard, self.m_cards[i]);
        card:setScale(0.5);
		item:addChild(card);
	end

    self.m_txtCard                  = self.m_root:getNodeByName("container.img_overlay.txt_card");
    self.m_greyOverlayTexture       = "room/calculator/calculator-grey-overlay.png";
	self.m_yellowOverlayTexture     = "room/calculator/calculator-yellow-overlay.png";
	self.m_imgOverlay               = self.m_root:getNodeByName("container.img_overlay");
    self.m_txtTitle                 = self.m_root:getNodeByName("container.txt_title");--成牌概率
    self.m_txtProbability           = self.m_root:getNodeByName("container.txt_probability");
    
    self.m_txtCard:setText(self.m_cardType);
    self.m_txtTitle:setText(STR_ROOM_TYPE_PROBABILITY);
    self.m_imgFrame:setVisible(false);
    self:setPickable(false);
    self:initFontStyle();
    self:setSize(self.m_root:getSize());
    self:addChild(self.m_root);
end

CardTypeUnit.setProbability = function(self, value)
	self.m_txtProbability:setText(string.format("%.1f%%", value));
end

CardTypeUnit.hightLight = function(self)
	self.m_imgFrame:setVisible(true);
	self.m_imgOverlay:setFile(self.m_yellowOverlayTexture);
	self:setFontStyle(self.m_txtTitle,          self.m_yellowSmall);
	self:setFontStyle(self.m_txtCard,           self.m_yellowMiddle);
	self:setFontStyle(self.m_txtProbability,    self.m_yellowLarge);
end

CardTypeUnit.normalize = function(self)
	self.m_imgFrame:setVisible(false);
	self.m_imgOverlay:setFile(self.m_greyOverlayTexture);
	self:setFontStyle(self.m_txtTitle,          self.m_greySmall);
	self:setFontStyle(self.m_txtCard,           self.m_greyMiddle);
	self:setFontStyle(self.m_txtProbability,    self.m_greyLarge);
end

CardTypeUnit.setFontStyle = function(self, text, style)
    if text ~= nil then
        text:setFontSize(style[1]);
        text:setColor(RGBKit.getRGB(style[2]));
    end
end

CardTypeUnit.initFontStyle = function(self)
    self.m_yellowSmall      = {20, 0xffc000};
	self.m_yellowMiddle     = {20, 0x652d04};
	self.m_yellowLarge      = {28, 0xffc000};
			
	self.m_greySmall        = {20, 0x8d9a9d};
	self.m_greyMiddle       = {20, 0xc0cacc};
	self.m_greyLarge        = {28, 0x8d9a9d};
end