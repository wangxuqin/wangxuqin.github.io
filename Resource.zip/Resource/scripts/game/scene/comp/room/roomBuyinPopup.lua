----------------------------------------------------------
-- 买入坐下的对话框

require("view/room/layout_buyin_popup");

RoomBuyinPopup = class(PopupDialog, false);

RoomBuyinPopup.ctor = function(self)
    super(self, layout_buyin_popup, true);
    local bg_slider = self.m_root:getNodeByName("bg.slider.bg_slider");
    for i=1,33 do
        local img = new(Image, "common/slider_track_middle.png");
        img:setPos(i*12);
        bg_slider:addChild(img);
    end
    self.m_thumb = self.m_root:getNodeByName("bg.slider.thumb");
end

RoomBuyinPopup.onPopupEnd = function(self)
    -- 添加控件响应
    local btn = self.m_root:getNodeByName("bg.btn_close");

    if btn then
        btn:setOnClick(self, self.onBtnClickClose);
    end
    self.m_thumb:setEventTouch(self, self.onTouchThumb);
    local btn = self.m_root:getNodeByName("bg.btn_min");
    btn:setOnClick(self, self.onBtnClickMin);
    
    local btn = self.m_root:getNodeByName("bg.btn_max");
    btn:setOnClick(self, self.onBtnClickMax);
    
    local btn = self.m_root:getNodeByName("bg.btn_confirm");
    btn:setOnClick(self, self.onBtnClickConfirm);
end

RoomBuyinPopup.update = function(self, data)
    self.m_minBuy = data.minBuyIn;
    self.m_maxBuy = data.maxBuyIn;
    self.m_money  = data.money;
    self.m_seatId = data.seatId;
    self.m_curBuy = math.modf(self.m_maxBuy/2);

    local tx = self.m_root:getNodeByName("bg.cur_prop");
    local s = RoomBuyinPopup.convertToString(self.m_money);
    tx:setText("$" .. s);
    local tx = self.m_root:getNodeByName("bg.min_buy");
    local s = RoomBuyinPopup.convertToString(self.m_minBuy);
    tx:setText("$" .. s);
    local tx = self.m_root:getNodeByName("bg.max_buy");
    local s = RoomBuyinPopup.convertToString(self.m_maxBuy);
    tx:setText("$" .. s);
    local tx = self.m_root:getNodeByName("bg.slider.thumb.View1.cur_buy");
    local s = RoomBuyinPopup.convertToString(self.m_curBuy);
    tx:setText("$" .. s);
    
    local checkGroup = self.m_root:getNodeByName("bg.check_view.check_autobuyin");
    checkGroup:setChecked(1, true);

    self:updateThumb();
end

RoomBuyinPopup.onBtnClickClose = function(self)
    self:close();
    if(self.m_callback) then
        self.m_callback(self.m_objCallback, {result=DialogCallback.CLOSE});
    end
end

--[Comment]
-- 转换数字到字符串
-- 规则: [0-10,000): 纯显示，[10,000-10,000,000): 显示成K，[10,000,000-10,000,000,000): 显示成M
RoomBuyinPopup.convertToString = function(n)
    local s = nil;
    if(n < 10000) then
        s = tostring(math.modf(n));
    elseif(n < 10000000) then
        s = string.format("%.1fK", n/1000);
    elseif(n < 10000000000) then
        s = string.format("%.1fM", n/1000000);
    else
        s = string.format("%.1fM", n/1000000);
    end
    return s;
end

RoomBuyinPopup.onTouchThumb = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
    if(finger_action == kFingerDown) then
        local parent = self.m_thumb:getParent();
        self.m_xDown,self.m_yDown = parent:convertSurfacePointToView(x, y);
        local xx,yy = self.m_thumb:getPos();
        self.m_xDown = self.m_xDown - xx;
        self.m_yDown = self.m_yDown - yy;
    elseif(finger_action == kFingerMove) then
        local parent = self.m_thumb:getParent();
        local xx,yy = parent:convertSurfacePointToView(x, y);
        xx = xx - self.m_xDown;
        local cxParent = parent:getSize();
        local cx = self.m_thumb:getSize();
        if(xx < 0) then
            xx = 0;
        elseif(xx+cx > cxParent) then
            xx = cxParent - cx;
        end
        --更新数据
        self.m_curBuy = self.m_minBuy + xx * (self.m_maxBuy - self.m_minBuy) / (cxParent - cx);
        self.m_curBuy = self.m_curBuy - self.m_curBuy % self.m_minBuy;--当前买入的值是最小买入的整数倍
        if(self.m_curBuy > self.m_money) then
            self.m_curBuy = self.m_money;
        end
        -- 更新界面
        self:updateThumb();
    elseif(finger_action == kFingerUp) then
    end
end

RoomBuyinPopup.updateThumb = function(self)
    local parent = self.m_thumb:getParent();
    local cxParent = parent:getSize();
    local cx = self.m_thumb:getSize();
    local xx = (self.m_curBuy - self.m_minBuy) * (cxParent - cx) / (self.m_maxBuy - self.m_minBuy);
    self.m_thumb:setPos(xx);
    local tx = self.m_root:getNodeByName("bg.slider.thumb.View1.cur_buy");
    local s = RoomBuyinPopup.convertToString(self.m_curBuy);
    tx:setText("$" .. s);
end

RoomBuyinPopup.onBtnClickMin = function(self)
    self.m_curBuy = self.m_minBuy;
    self:updateThumb();
end

RoomBuyinPopup.onBtnClickMax = function(self)
    self.m_curBuy = self.m_maxBuy;
    if(self.m_curBuy > self.m_money) then
        self.m_curBuy = self.m_money;
    end
    self:updateThumb();
end

RoomBuyinPopup.onBtnClickConfirm = function(self)
    local checkGroup = self.m_root:getNodeByName("bg.check_view.check_autobuyin");
    local checked = checkGroup:isChecked(1) and true or false;
    CookieService.setBoolean(CookieKeys.AUTO_BUY_IN, checked);
    self:close();
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.USER_BUY_IN, {
        ["seatId"]      = self.m_seatId, 
        ["buyinChips"]  = self.m_curBuy
    });
end