-----------------------------------------------------
require("view/room/layout_game_review");
require("game/scene/comp/room/gameReview/gameReviewTableRender");

GameReviewPopUp = class(PopupDialog, false);

GameReviewPopUp.ctor = function(self)-- popUpWidth:int=900, popUpHeight:int=580, headerHeight:Number=64, bottomHeight:Number=32)
	super(self, layout_game_review, true);

    self.m_title = nil;--:Label;
    self.m_nextButton = nil;--:Button;
    self.m_perButton = nil;--:Button;
    self.m_checkDetailButton = nil;--:Button;
    self.m_gameList = {};--:List;
    self.m_listCollection = nil;--:ListCollection;

    self:initialize();
end

GameReviewPopUp.initialize = function(self)--override protected
    --本地化
    local allLocalization =
    {
        { "bg.title", STR_ROOM_GAME_REVIEW_POP_UP_TITLE },
        { "bg.btn_detail.text", STR_ROOM_GAME_REVIEW_POP_UP_CHECK_BTN },
    };
    for _,v in pairs(allLocalization) do
        local view = self.m_root:getNodeByName(v[1]);
        view:setText(v[2]);
    end
    --下一个的按钮水平翻转
    local btn = self.m_root:getNodeByName("bg.btn_next");
    btn:addPropScaleSolid(0, -1, 1, kCenterDrawing, 0, 0);
	local wBtn,hBtn = btn:getSize();

	--来自roomScene的牌局数据
	local mask = self.m_root:getNodeByName("bg.mask");
	local wMask,hMask = mask:getSize();
	local wScroll,hScroll = wMask-wBtn-wBtn, hMask;
	local scroll = new(ScrollView2, wBtn, 0, wScroll, hScroll, true);
	scroll:setDirection(kHorizontal);
--	scroll:setOnScroll(self, self.__onScrolling);
--	if(scroll.setOnScrollEnd) then
--		scroll:setOnScrollEnd(self, self.__onScrollEnd);
--	end
	self.m_gameList = scroll;
	mask:addChild(scroll);
	local numGameReview = #RoomScene.gameReviewVct;
	self.m_numGameReview = numGameReview;
	if(numGameReview > 0) then
		--菊花
		local wDialog,hDialog = self:getDialog():getSize();
		self.m_miniLoad = AtomAnimManager.getInstance():playAnim("atomAnimTable/common/anim_common_miniLoad", self:getDialog(), wDialog/2, hDialog/2, false);
		self.m_animFillGameList = new(AnimInt, kAnimRepeat, 0, numGameReview, 1, 0);
		self.m_animFillGameList:setEvent(self, self.__fillGameList);
		self.m_idxGameReview = 1;
		self.m_gameList:setPickable(false);
	else
--??		JuhuaAndHintManager.showHint(background,Localization.getText("ROOM.GAME_REVIEW_POP_UP_NO_REVIEW_TIPS"),false);
	end
end

GameReviewPopUp.__onScrolling = function(self)
end

GameReviewPopUp.__onScrollEnd = function(self)
	Log.d("gamereview", "scroll end");
end

GameReviewPopUp.__endLoading = function(self)
	if(self.m_animFillGameList) then
		delete(self.m_animFillGameList);
		self.m_animFillGameList = nil;
	end
	if(self.m_miniLoad) then
		self.m_miniLoad:release();
		self.m_miniLoad = nil;
	end
end

GameReviewPopUp.__fillGameList = function(self)
	if(self.m_idxGameReview > self.m_numGameReview) then
		self:__endLoading();
		self.m_gameList:setPickable(true);
	else
		local wScroll,hScroll = self.m_gameList:getSize();
		local i = self.m_idxGameReview;
		local v = RoomScene.gameReviewVct[i];
		local t = new(GameReviewTableRender);
		t:setSize(wScroll, hScroll);
		t:setPos(wScroll * (i-1));
		t:setData(v);
		self.m_gameList:addChild(t);
		self.m_idxGameReview = self.m_idxGameReview + 1;
--		local adapter = new(Adapter, GameReviewTableRender, RoomScene.gameReviewVct);
--		self.m_gameList:setAdapter(adapter);
--		self.m_idxGameReview = self.m_numGameReview + 1;
	end
end

GameReviewPopUp.close = function(self)
	self:__endLoading();
	PopupDialog.close(self);
end

GameReviewPopUp.onPopupEnd = function(self)
	--事件响应
	local btn = self.m_root:getNodeByName("bg.btn_close");
	btn:setOnClick(self, self.__onBtnClickClose);
	local btn = self.m_root:getNodeByName("bg.btn_prev");
	btn:setOnClick(self, self.perBtnTriggered);
	local btn = self.m_root:getNodeByName("bg.btn_next");
	btn:setOnClick(self, self.nextBtnTriggered);
	local btn = self.m_root:getNodeByName("bg.btn_detail");
	btn:setOnClick(self, self.checkDetailBtnTriggered);
end

GameReviewPopUp.__onBtnClickClose = function(self)
	self:close();
end

GameReviewPopUp.checkDetailBtnTriggered = function(self)--private
	if(#RoomScene.gameReviewVct > 0) then
--??		self.m_gamePlayListPopUp.show(GameRoomScreen.gameReviewVct[self.m_gameList.horizontalPageIndex]);
		local idx = 1;
		local scroller = self.m_gameList:getScroller();
		if(scroller and scroller.scrollingModel) then
			local wScroll = self.m_gameList:getSize();
			local x = scroller.scrollingModel.getContentPosition();
			if(x > 0) then
				x = 0;
			end
			idx = math.modf(((-x) + wScroll/2) / wScroll) + 1;
		end
		if(RoomScene.gameReviewVct[idx]) then
			EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_GAME_REVIEW_DETAIL, RoomScene.gameReviewVct[idx]);
		end
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_ROOM_GAME_REVIEW_POP_UP_NO_REVIEW_TIPS);
	end
end

GameReviewPopUp.perBtnTriggered = function(self)--private
--	if(self.m_gameList.horizontalPageIndex > 0) then
--		self.m_gameList.scrollToPageIndex(self.m_gameList.horizontalPageIndex - 1,0,1);
--	end
--	Log.d("gamereview", string.format("curpage=%d,curIndex=%d", self.m_gameList:getCurPage(), self.m_gameList:getCurIndex()));
end

GameReviewPopUp.nextBtnTriggered = function(self)--private
--	if(self.m_gameList.horizontalPageIndex < self.m_gameList.dataProvider.data.length - 1) then
--		self.m_gameList.scrollToPageIndex(self.m_gameList.horizontalPageIndex + 1,0,1);
--	end
end
