----------------------------------------------------------------
require("view/room/layout_game_review_detail");
require("game/scene/comp/room/gameReview/smallPokerCard");
require("game/scene/comp/room/gameReview/gameReviewPlayerListItemRender");

GameReviewListInfoPopUp = class(PopupDialog, false);

GameReviewListInfoPopUp.ctor = function(self)
	super(self, layout_game_review_detail, true);

	self.m_topHeight = 0;
	self.m_bottomHeight = 0;
	self.m_itemWidth = 0;
	self.m_backgroundBack = nil;
	self.m_backgroundUp = nil;
	self.m_closeButton = nil;
	self.m_greenBackgroundDark = nil;
	self.m_grayBackgroundDark = nil;
	self.m_gameReviewList = nil;
	self.m_listCollection = nil;
	--top label
	self.m_topLabel1 = nil;
	self.m_topLabel2 = nil;
	self.m_topLabel3 = nil;
	self.m_topLabel4 = nil;
	self.m_topLabel5 = nil;
	self.m_topLabel6 = nil;
	--bottom label
	self.m_publicCardLabel = nil;
	self.m_publicCardNumArr = nil;
	self.m_publicCard = nil;

	self.m_mWidth,self.m_mHeight = self:getDialog():getSize();
	self.m_topHeight = 50;
	self.m_bottomHeight = 80;
	self.m_itemWidth = self.m_mWidth / 6;

	self:initialize();
end

GameReviewListInfoPopUp.draw = function(self)
	for i=1,#self.m_publicCardNumArr do
		if(self.m_publicCardNumArr[i] ~= 0) then
			self.m_publicCard[i]:setCard(self.m_publicCardNumArr[i]);
			self.m_publicCard[i]:showCard();
			self.m_publicCard[i]:setPos(nil, self.m_mHeight - self.m_bottomHeight/2);
			if(i == 1) then
				self.m_publicCard[i]:setPos(self.m_itemWidth * 3 + (self.m_itemWidth - 56) * 0.5);
			elseif(i == 2 or i == 3) then
				self.m_publicCard[i]:setPos(As3Kit.getNodeX(self.m_publicCard[i - 1]) + 28);
			elseif(i == 4) then
				self.m_publicCard[i]:setPos(self.m_itemWidth * 4 + self.m_itemWidth * 0.5);
			elseif(i == 5) then
				self.m_publicCard[i]:setPos(self.m_itemWidth * 5 + self.m_itemWidth * 0.5);
			end
		end
	end
end

GameReviewListInfoPopUp.initialize = function(self)
	--本地化
	local allLocalizations =
	{
		{"bg.top_label1", STR_ROOM_GAME_REVIEW_LIST_TOP_LABEL1},
		{"bg.top_label2", STR_ROOM_GAME_REVIEW_LIST_TOP_LABEL2},
		{"bg.top_label3", STR_ROOM_GAME_REVIEW_LIST_TOP_LABEL3},
		{"bg.top_label4", STR_ROOM_GAME_REVIEW_LIST_TOP_LABEL4},
		{"bg.top_label5", STR_ROOM_GAME_REVIEW_LIST_TOP_LABEL5},
		{"bg.top_label6", STR_ROOM_GAME_REVIEW_LIST_TOP_LABEL6},
		{"bg.public_card_label", STR_ROOM_GAME_REVIEW_POP_UP_PUBLIC_CARD_TEXT},
	};
	for _,v in pairs(allLocalizations) do
		local tx = self.m_root:getNodeByName(v[1]);
		tx:setText(v[2]);
	end
	self.m_publicCardNumArr = {};
	self.m_publicCard = {};
	for i=1,5 do
		self.m_publicCard[i] = new(SmallPokerCard);
		self.m_publicCard[i]:setVisible(false);
		self:getDialog():addChild(self.m_publicCard[i]);
	end
end

GameReviewListInfoPopUp.onPopupEnd = function(self)
	--添加事件响应
	local btn = self.m_root:getNodeByName("bg.btn_close");
	btn:setOnClick(self, self.closeButtonHandler);
end

GameReviewListInfoPopUp.closeButtonHandler = function(self)
	self:close();
end

GameReviewListInfoPopUp.update = function(self, data)
	for i=1,#data.playerList do
		data.playerList[i].beforeFlopOperation = data.beforeFlopOperation;
		data.playerList[i].flopCardOperation = data.flopCardOperation;
		data.playerList[i].turnCardOperation = data.turnCardOperation;
		data.playerList[i].riverCardOperation = data.riverCardOperation;
		data.playerList[i].gameOverData = data.gameOverData;
		data.playerList[i].selfSeatId = data.selfSeatId;
		data.playerList[i].selfCard1 = data.selfHandCard1;
		data.playerList[i].selfCard2 = data.selfHandCard2;
	end

	if(self.m_gameReviewList == nil) then
		local bg = self.m_root:getNodeByName("bg");
		local wBG,hBG = bg:getSize();
		self.m_gameReviewList = new(ScrollView2, 2, self.m_topHeight, wBG-4, hBG-self.m_topHeight-self.m_bottomHeight, true);
		self:getDialog():addChild(self.m_gameReviewList);
	end
	self.m_gameReviewList:removeAllChildren();
	local wScroll = self.m_gameReviewList:getSize();
	for i=1,#data.playerList do
		local item = new(GameReviewPlayerListItemRender);
		item:setData(data.playerList[i], wScroll);
		self.m_gameReviewList:addChild(item);
	end

	self.m_publicCardNumArr = data.publicCardArr;
	self:draw();
end
