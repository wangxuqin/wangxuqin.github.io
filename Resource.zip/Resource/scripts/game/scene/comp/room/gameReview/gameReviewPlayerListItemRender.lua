GameReviewPlayerListItemRender = class(Node, false);

GameReviewPlayerListItemRender.ctor = function(self)
	super(self);

	self.m_data = nil;
	self.m_index = 0;
	self.m_owner = nil;
	self.m_isSelect = false;
	self.m_mWidth = 0;
	self.m_mHeight = 0;
	self.m_itemWidth = 0;
	self.m_maxHeight = 0;
	self.m_nameLabel = nil;
	self.m_chipsLabel = nil;
	self.m_handCard1 = nil;
	self.m_handCard2 = nil;
	self.m_winnerIcon = nil;
	self.m_partLine = nil;
	self.m_operationLabel1 = nil;
	self.m_operationLabel2 = nil;
	self.m_operationLabel3 = nil;
	self.m_operationLabel4 = nil;
	self.m_operationLabelArr = nil;

	self.m_operationLabelArr = STR_ROOM_OPERATION_TYPE;

	self.m_mHeight = 90;
	self:setSize(nil, self.m_mHeight);
	self.m_itemWidth = 150;
	self:initialize();
end

GameReviewPlayerListItemRender.draw = function(self, wParent, hParent)
	if(wParent) then
		self.m_mWidth = wParent;
	end
	if(hParent) then
		self.m_mHeight = hParent;
	end
	if(self.m_data) then
		self.m_nameLabel:setText(self.m_data.name);
		Formatter.spliceSingleLineLongString(self.m_data.name, self.m_itemWidth - 16, self.m_nameLabel);

		if(self.m_data.isWin) then
			self.m_winnerIcon:setVisible(true);
--			self.m_chipsLabel.textRendererProperties.textFormat = TextFormatManager.instance.gameReviewWinChipLabelFmt;
			self.m_chipsLabel:setText("+" .. STR_COMMON_CURRENCY_LABEL .. Formatter.formatBigNumber(self.m_data.winChip));
			self.m_winnerIcon:removeProp(0);
			if(self.m_data.isBigWinner) then
				self.m_winnerIcon:addPropScaleSolid(0, 1, 1, kCenterDrawing, 0, 0);
			else
				self.m_winnerIcon:addPropScaleSolid(0, 0.7, 0.7, kCenterDrawing, 0, 0);
			end
		else
			self.m_winnerIcon:setVisible(false);
--			self.m_chipsLabel.textRendererProperties.textFormat = TextFormatManager.instance.gameReviewListContentdarkFmt;
			self.m_chipsLabel:setText("-" .. STR_COMMON_CURRENCY_LABEL .. Formatter.formatBigNumber(self.m_data.betInChips));
		end

		--发前三张牌之前
		local i = 1;
		while(i <= #self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct) do
			if(i > #self.m_operationLabel1) then
				local label1 = new(Text, "0", nil, nil, nil, nil, 20, 0xb2, 0xd7, 0xa1);
				self:addChild(label1);
				table.insert(self.m_operationLabel1, label1);
			else
				self.m_operationLabel1[i]:setText("");
			end
			self.m_operationLabel1[i]:setVisible(true);
			local oprType = self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].operationType;
			local text = "";
			if(oprType == OperationResultData.SEAT_WAIT) then
				text = self.m_operationLabelArr[1];--"等待下一轮";
			elseif(oprType == OperationResultData.SEAT_READY) then
				text = self.m_operationLabelArr[2];--"等待下注";
			elseif(oprType == OperationResultData.SEAT_FOLD) then
				text = self.m_operationLabelArr[3];--"弃牌";
			elseif(oprType == OperationResultData.SEAT_ALLIN) then
				text = self.m_operationLabelArr[4] .. tostring(i <= 1 and self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].betInChips or self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].betInChips - self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i - 1].betInChips);
			elseif(oprType == OperationResultData.SEAT_CALL) then
				text = self.m_operationLabelArr[5] .. tostring(i <= 1 and self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].betInChips or self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].betInChips - self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i - 1].betInChips);
			elseif(oprType == OperationResultData.SEAT_SMALLBLIND) then
				text = self.m_operationLabelArr[6] .. self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_BIGBLIND) then
				text = self.m_operationLabelArr[7] .. self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_CHECK) then
				text = self.m_operationLabelArr[8];
			elseif(oprType == OperationResultData.SEAT_RAISE) then
				text = self.m_operationLabelArr[9] .. tostring(i <= 1 and self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].betInChips or self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].betInChips - self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i - 1].betInChips);
			elseif(oprType == OperationResultData.MUST_RAISE) then
				text = self.m_operationLabelArr[5] .. self.m_data.beforeFlopOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			end
			self.m_operationLabel1[i]:setText(text);
			self.m_operationLabel1[i]:setPos(self.m_itemWidth * 2 + 8, (i-1) * (4 + As3Kit.getNodeHeight(self.m_operationLabel1[i])));
			i = i + 1;
		end
		if(i > 1) then
			local h = As3Kit.getNodeY(self.m_operationLabel1[i-1]) + As3Kit.getNodeHeight(self.m_operationLabel1[i-1]);
			if(h > self.m_maxHeight) then
				self.m_maxHeight = h;
			end
		end

		--发前三张牌
		local i = 1;
		while(i <= #self.m_data.flopCardOperation[self.m_data.seatId].gameBetDataVct) do
			if(i > #self.m_operationLabel2) then
				local label1 = new(Text, "0", nil, nil, nil, nil, 20, 0xb2, 0xd7, 0xa1);
				self:addChild(label1);
				table.insert(self.m_operationLabel2, label1);
			else
				self.m_operationLabel2[i]:setText("");
			end

			self.m_operationLabel2[i]:setVisible(true);
			local oprType = self.m_data.flopCardOperation[self.m_data.seatId].gameBetDataVct[i].operationType;
			local text = "";
			if(oprType == OperationResultData.SEAT_WAIT) then
				text = self.m_operationLabelArr[1];--"等待下一轮";
			elseif(oprType == OperationResultData.SEAT_READY) then
				text = self.m_operationLabelArr[2];--"等待下注";
			elseif(oprType == OperationResultData.SEAT_FOLD) then
				text = self.m_operationLabelArr[3];--"弃牌";
			elseif(oprType == OperationResultData.SEAT_ALLIN) then
				text = self.m_operationLabelArr[4] .. self.m_data.flopCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_CALL) then
				text = self.m_operationLabelArr[5] .. self.m_data.flopCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_SMALLBLIND) then
				text = self.m_operationLabelArr[6] .. self.m_data.flopCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_BIGBLIND) then
				text = self.m_operationLabelArr[7] .. self.m_data.flopCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_CHECK) then
				text = self.m_operationLabelArr[8];
			elseif(oprType == OperationResultData.SEAT_RAISE) then
				text = self.m_operationLabelArr[9] .. self.m_data.flopCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.MUST_RAISE) then
				text = self.m_operationLabelArr[5] .. self.m_data.flopCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			end
			self.m_operationLabel2[i]:setText(text);
			self.m_operationLabel2[i]:setPos(self.m_itemWidth * 3 + 8, (i-1) * (4 + As3Kit.getNodeHeight(self.m_operationLabel2[i])));
			i = i + 1;
		end
		if(i > 1) then
			local h = As3Kit.getNodeY(self.m_operationLabel2[i-1]) + As3Kit.getNodeHeight(self.m_operationLabel2[i-1]);
			if(h > self.m_maxHeight) then
				self.m_maxHeight = h;
			end
		end

		--发转牌
		local i = 1;
		while(i <= #self.m_data.turnCardOperation[self.m_data.seatId].gameBetDataVct) do
			if(i > #self.m_operationLabel3) then
				local label1 = new(Text, "0", nil, nil, nil, nil, 20, 0xb2, 0xd7, 0xa1);
				self:addChild(label1);
				table.insert(self.m_operationLabel3, label1);
			else
				self.m_operationLabel3[i]:setText("");
			end

			self.m_operationLabel3[i]:setVisible(true);
			local oprType = self.m_data.turnCardOperation[self.m_data.seatId].gameBetDataVct[i].operationType;
			local text = "";
			if(oprType == OperationResultData.SEAT_WAIT) then
				text = self.m_operationLabelArr[1];--"等待下一轮";
			elseif(oprType == OperationResultData.SEAT_READY) then
				text = self.m_operationLabelArr[2];--"等待下注";
			elseif(oprType == OperationResultData.SEAT_FOLD) then
				text = self.m_operationLabelArr[3];--"弃牌";
			elseif(oprType == OperationResultData.SEAT_ALLIN) then
				text = self.m_operationLabelArr[4] .. self.m_data.turnCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_CALL) then
				text = self.m_operationLabelArr[5] .. self.m_data.turnCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_SMALLBLIND) then
				text = self.m_operationLabelArr[6] .. self.m_data.turnCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_BIGBLIND) then
				text = self.m_operationLabelArr[7] .. self.m_data.turnCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_CHECK) then
				text = self.m_operationLabelArr[8];
			elseif(oprType == OperationResultData.SEAT_RAISE) then
				text = self.m_operationLabelArr[9] .. self.m_data.turnCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.MUST_RAISE) then
				text = self.m_operationLabelArr[5] .. self.m_data.turnCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			end
			self.m_operationLabel3[i]:setText(text);
			self.m_operationLabel3[i]:setPos(self.m_itemWidth * 4 + 8, (i-1) * (4 + As3Kit.getNodeHeight(self.m_operationLabel3[i])));
			i = i + 1;
		end
		if(i > 1) then
			local h = As3Kit.getNodeY(self.m_operationLabel3[i-1]) + As3Kit.getNodeHeight(self.m_operationLabel3[i-1]);
			if(h > self.m_maxHeight) then
				self.m_maxHeight = h;
			end
		end

		--发河牌
		local i = 1;
		while(i <= #self.m_data.riverCardOperation[self.m_data.seatId].gameBetDataVct) do
			if(i > #self.m_operationLabel4) then
				local label1 = new(Text, "0", nil, nil, nil, nil, 20, 0xb2, 0xd7, 0xa1);
				self:addChild(label1);
				table.insert(self.m_operationLabel4, label1);
			else
				self.m_operationLabel4[i]:setText("");
			end

			self.m_operationLabel4[i]:setVisible(true);
			local oprType = self.m_data.riverCardOperation[self.m_data.seatId].gameBetDataVct[i].operationType;
			local text = "";
			if(oprType == OperationResultData.SEAT_WAIT) then
				text = self.m_operationLabelArr[1];--"等待下一轮";
			elseif(oprType == OperationResultData.SEAT_READY) then
				text = self.m_operationLabelArr[2];--"等待下注";
			elseif(oprType == OperationResultData.SEAT_FOLD) then
				text = self.m_operationLabelArr[3];--"弃牌";
			elseif(oprType == OperationResultData.SEAT_ALLIN) then
				text = self.m_operationLabelArr[4] .. self.m_data.riverCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_CALL) then
				text = self.m_operationLabelArr[5] .. self.m_data.riverCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_SMALLBLIND) then
				text = self.m_operationLabelArr[6] .. self.m_data.riverCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_BIGBLIND) then
				text = self.m_operationLabelArr[7] .. self.m_data.riverCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.SEAT_CHECK) then
				text = self.m_operationLabelArr[8];
			elseif(oprType == OperationResultData.SEAT_RAISE) then
				text = self.m_operationLabelArr[9] .. self.m_data.riverCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			elseif(oprType == OperationResultData.MUST_RAISE) then
				text = self.m_operationLabelArr[5] .. self.m_data.riverCardOperation[self.m_data.seatId].gameBetDataVct[i].betInChips;
			end
			self.m_operationLabel4[i]:setText(text);
			self.m_operationLabel4[i]:setPos(self.m_itemWidth * 5 + 8, (i-1) * (4 + As3Kit.getNodeHeight(self.m_operationLabel4[i])));
			i = i + 1;
		end
		if(i > 1) then
			local h = As3Kit.getNodeY(self.m_operationLabel4[i-1]) + As3Kit.getNodeHeight(self.m_operationLabel4[i-1]);
			if(h > self.m_maxHeight) then
				self.m_maxHeight = h;
			end
		end

		if(self.m_maxHeight > self.m_mHeight) then
			self.m_mHeight = self.m_maxHeight;
		end
		self:setSize(self.m_mWidth, self.m_mHeight);

		self.m_partLine:setSize(self.m_mWidth);
		self.m_partLine:setPos(6, self.m_mHeight - As3Kit.getNodeHeight(self.m_partLine));

		--玩家手牌
		self.m_handCard1:showCardBack();
		self.m_handCard2:showCardBack();
		for i=1,#self.m_data.gameOverData.playerList do
			if(self.m_data.gameOverData.playerList[i].seatId == self.m_data.seatId) then
				self.m_handCard1:setCard(self.m_data.gameOverData.playerList[i].card1);
				self.m_handCard1:showCard();
				self.m_handCard2:setCard(self.m_data.gameOverData.playerList[i].card2);
				self.m_handCard2:showCard();
			end
		end

		if(self.m_data.seatId == self.m_data.selfSeatId) then
			self.m_handCard1:setCard(self.m_data.selfCard1);
			self.m_handCard1:showCard();
			self.m_handCard2:setCard(self.m_data.selfCard2);
			self.m_handCard2:showCard();
		end
		self.m_nameLabel:setPos(12, 6);
		self.m_chipsLabel:setPos(As3Kit.getNodeX(self.m_nameLabel), As3Kit.getNodeY(self.m_nameLabel) + As3Kit.getNodeHeight(self.m_nameLabel) + 6);
		self.m_winnerIcon:setPos(self.m_itemWidth - As3Kit.getNodeWidth(self.m_winnerIcon) * 0.5, (self.m_mHeight - As3Kit.getNodeHeight(self.m_winnerIcon)) * 0.5);
		self.m_handCard1:setPos(self.m_itemWidth + (self.m_itemWidth - As3Kit.getNodeWidth(self.m_handCard1) - 10) * 0.5, (self.m_mHeight - As3Kit.getNodeHeight(self.m_handCard1)) * 0.5);
		self.m_handCard2:setPos(As3Kit.getNodeX(self.m_handCard1) + 24, As3Kit.getNodeY(self.m_handCard1));
	end
end

GameReviewPlayerListItemRender.initialize = function(self)
	self.m_nameLabel = new(Text, "0", nil, nil, nil, nil, 20, 0xe3, 0xf4, 0xdc);
	self:addChild(self.m_nameLabel);

	self.m_chipsLabel = new(Text, "0", nil, nil, nil, nil, 20, 0x98, 0xa8, 0x92);
	self:addChild(self.m_chipsLabel);

	self.m_operationLabel1 = {};
	local label1 = new(Text, "0", nil, nil, nil, nil, 20, 0xb2, 0xd7, 0xa1);
	self:addChild(label1);
	label1:setVisible(false);
	table.insert(self.m_operationLabel1, label1);

	self.m_operationLabel2 = {};
	local label2 = new(Text, "0", nil, nil, nil, nil, 20, 0xb2, 0xd7, 0xa1);
	self:addChild(label2);
	label2:setVisible(false);
	table.insert(self.m_operationLabel2, label2);

	self.m_operationLabel3 = {};
	local label3 = new(Text, "0", nil, nil, nil, nil, 20, 0xb2, 0xd7, 0xa1);
	self:addChild(label3);
	label3:setVisible(false);
	table.insert(self.m_operationLabel3, label3);

	self.m_operationLabel4 = {};
	local label4 = new(Text, "0", nil, nil, nil, nil, 20, 0xb2, 0xd7, 0xa1);
	self:addChild(label4);
	label4:setVisible(false);
	table.insert(self.m_operationLabel4, label4);

	self.m_handCard1 = new(SmallPokerCard);
	self:addChild(self.m_handCard1);
	self.m_handCard1:showCardBack();

	self.m_handCard2 = new(SmallPokerCard);
	self:addChild(self.m_handCard2);
	self.m_handCard2:showCardBack();

	self.m_winnerIcon = new(Image, "room/game_review_winner_icon.png");
	self:addChild(self.m_winnerIcon);
	self.m_winnerIcon:setVisible(false);

	self.m_partLine = new(Image, "room/game_review_list_page_background_part_line.png");
	self:addChild(self.m_partLine);
end

GameReviewPlayerListItemRender.refrash = function(self)
	for i=1,#self.m_operationLabel1 do
		self.m_operationLabel1[i]:removeFromParent(true);
	end
	self.m_operationLabel1 = {};

	for i=1,#self.m_operationLabel2 do
		self.m_operationLabel2[i]:removeFromParent(true);
	end
	self.m_operationLabel2 = {};

	for i=1,#self.m_operationLabel3 do
		self.m_operationLabel3[i]:removeFromParent(true);
	end
	self.m_operationLabel3 = {};

	for i=1,#self.m_operationLabel4 do
		self.m_operationLabel4[i]:removeFromParent(true);
	end
	self.m_operationLabel4 = {};
end

GameReviewPlayerListItemRender.getData = function(self)
	return self.m_data;
end

GameReviewPlayerListItemRender.setData = function(self, value, wParent, hParent)
	if(value == nil) then
		return;
	end
	self:refrash();
	self.m_data = value;
	self:draw(wParent, hParent);
end

GameReviewPlayerListItemRender.getIndex = function(self)
	return self.m_index;
end

GameReviewPlayerListItemRender.setIndex = function(self, value)
	self.m_index = value;
end

GameReviewPlayerListItemRender.getOwner = function(self)
	return self.m_owner;
end

GameReviewPlayerListItemRender.setOwner = function(self, value)
	self.m_owner = value;
end

GameReviewPlayerListItemRender.getIsSelected = function(self)
	return self.m_isSelect;
end

GameReviewPlayerListItemRender.setIsSelected = function(self, value)
	self.m_isSelect = value;
end
