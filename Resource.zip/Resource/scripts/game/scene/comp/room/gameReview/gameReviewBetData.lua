----------------------------------------------------
GameReviewBetData = class();

GameReviewBetData.ctor = function(self)
    self.gameBetDataVct = {};
end
