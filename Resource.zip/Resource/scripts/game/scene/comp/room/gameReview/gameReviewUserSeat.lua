-----------------------------------------------------------
GameReviewUserSeat = class(Node, false);

GameReviewUserSeat.SEAT_POSITION_UP = "SEAT_POSITION_UP";
GameReviewUserSeat.SEAT_POSITION_RIGHT_TOP = "SEAT_POSITION_RIGHT_TOP";
GameReviewUserSeat.SEAT_POSITION_RIGHT_DOWN = "SEAT_POSITION_RIGHT_DOWN";
GameReviewUserSeat.SEAT_POSITION_BOTTOM = "SEAT_POSITION_BOTTOM";
GameReviewUserSeat.SEAT_POSITION_LEFT_TOP = "SEAT_POSITION_LEFT_TOP";
GameReviewUserSeat.SEAT_POSITION_LEFT_DOWN = "SEAT_POSITION_LEFT_DOWN";

GameReviewUserSeat.ctor = function(self)
	super(self);

    self.m_data = nil;--:GameReviewData;
    self.m_seatId = 0;
    self.m_seatPostion = "";
    self.m_infoSprite = nil;--:Sprite;
    self.m_handCardLeft = nil;--:PokerCard;
    self.m_handCardRight = nil;--:PokerCard;
    self.m_loseChipBackground = nil;--:Scale9Textures;
    self.m_winChipBackground = nil;--:Scale9Textures;
    self.m_labelBackground = nil;--:Scale9Image;
    self.m_winnerIcon = nil;--:Image;
    self.m_winnerIconIsSmall = false;
    self:initialize();
end

GameReviewUserSeat.draw = function(self)--override protected
	if(self.m_data) then
		self.m_handCardLeft:refresh();
		self.m_handCardLeft:showBack();
		self.m_handCardRight:refresh();
		self.m_handCardRight:showBack();
		local len1 = #self.m_data.playerList;
		local len2 = #self.m_data.gameOverData.playerList;
        for i=1,len1 do
            for j=1,len2 do
				if(self.m_data.playerList[i] and self.m_data.gameOverData.playerList[j].seatId == self.m_seatId and self.m_data.playerList[i].seatId == self.m_seatId) then
					self.m_handCardLeft:setCard(self.m_data.gameOverData.playerList[j].card1);
					self.m_handCardLeft:showCard();
					self.m_handCardRight:setCard(self.m_data.gameOverData.playerList[j].card2);
					self.m_handCardRight:showCard();

					if(not self.m_data.playerList[i].isWin) then
						self.m_handCardLeft:showFadeCard();
						self.m_handCardRight:showFadeCard();
					end
				end
			end

			if(self.m_seatId == self.m_data.playerList[i].seatId and self.m_data.playerList[i].seatId == self.m_data.selfSeatId and not self.m_data.playerList[i].isWin) then
				self.m_handCardLeft:setCard(self.m_data.selfHandCard1);
				self.m_handCardLeft:showCard();
				self.m_handCardRight:setCard(self.m_data.selfHandCard2);
				self.m_handCardRight:showCard();

				self.m_handCardLeft:showFadeCard();
				self.m_handCardRight:showFadeCard();
			end

			if(self.m_data.playerList[i].seatId == self.m_seatId and self.m_data.playerList[i].isWin) then
				self.m_labelBackground:setFile(self.m_winChipBackground);
				self.m_winnerIcon:setVisible(true);
				if(self.m_data.playerList[i].isBigWinner) then
--					self.m_winnerIcon.scaleX = self.m_winnerIcon.scaleY = 1;
                    self.m_winnerIcon:addPropScaleSolid(0, 1, 1, kCenterDrawing, 0, 0);
					if(self.m_handCardLeft:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card1) == self.m_handCardLeft:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card1) == self.m_handCardLeft.variety) then
						self.m_handCardLeft:hightLightCard();
					elseif(self.m_handCardLeft:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card2) == self.m_handCardLeft:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card2) == self.m_handCardLeft.variety) then
						self.m_handCardLeft:hightLightCard();
					elseif(self.m_handCardLeft:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card3) == self.m_handCardLeft:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card3) == self.m_handCardLeft.variety) then
						self.m_handCardLeft:hightLightCard();
					elseif(self.m_handCardLeft:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card4) == self.m_handCardLeft:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card4) == self.m_handCardLeft.variety) then
						self.m_handCardLeft:hightLightCard();
					elseif(self.m_handCardLeft:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card5) == self.m_handCardLeft:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card5) == self.m_handCardLeft.variety) then
						self.m_handCardLeft:hightLightCard();
					end

					if(self.m_handCardRight:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card1) == self.m_handCardRight:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card1) == self.m_handCardRight.variety) then
						self.m_handCardRight:hightLightCard();
					elseif(self.m_handCardRight:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card2) == self.m_handCardRight:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card2) == self.m_handCardRight.variety) then
						self.m_handCardRight:hightLightCard();
					elseif(self.m_handCardRight:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card3) == self.m_handCardRight:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card3) == self.m_handCardRight.variety) then
						self.m_handCardRight:hightLightCard();
					elseif(self.m_handCardRight:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card4) == self.m_handCardRight:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card4) == self.m_handCardRight.variety) then
						self.m_handCardRight:hightLightCard();
					elseif(self.m_handCardRight:getCardValue() ~= 0 and PokerCard:getCardValue2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card5) == self.m_handCardRight:getCardValue() and PokerCard:getCardVariety2(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card5) == self.m_handCardRight.variety) then
						self.m_handCardRight:hightLightCard();
					end
				else
                    self.m_winnerIcon:addPropScaleSolid(0, 0.8, 0.8, kCenterDrawing, 0, 0);
				end
			elseif(self.m_data.playerList[i].seatId == self.m_seatId) then
				self.m_labelBackground:setFile(self.m_loseChipBackground);
				self.m_winnerIcon:setVisible(false);
			end
		end
	end

	self.m_winnerIcon:addPropRotateSolid(0, -45 / 2, kCenterDrawing, 0, 0);
	if(self.m_seatPostion == GameReviewUserSeat.SEAT_POSITION_UP) then
		local x = -37;
		local y = -102;
        self.m_labelBackground:setPos(x, y);
		local x = -63;
		local y = -42;
        self.m_winnerIcon:setPos(x, y);
	elseif(self.m_seatPostion == GameReviewUserSeat.SEAT_POSITION_RIGHT_TOP) then
		local x = -40;
		local y = -103;
        self.m_labelBackground:setPos(x, y);
		self.m_winnerIcon:removeProp(0);
		self.m_winnerIcon:addPropRotateSolid(0, 45 / 2, kCenterDrawing, 0, 0);
		local x = 32;
		local y = -24;
        self.m_winnerIcon:setPos(x, y);
	elseif(self.m_seatPostion == GameReviewUserSeat.SEAT_POSITION_RIGHT_DOWN) then
		local x = -40;
		local y = 40;
        self.m_labelBackground:setPos(x, y);
		self.m_winnerIcon:removeProp(0);
		self.m_winnerIcon:addPropRotateSolid(0, 45 / 2, kCenterDrawing, 0, 0);
		local x = 32;
		local y = -24;
        self.m_winnerIcon:setPos(x, y);
	elseif(self.m_seatPostion == GameReviewUserSeat.SEAT_POSITION_BOTTOM) then
		local x = -40;
		local y = 40;
        self.m_labelBackground:setPos(x, y);
		local x = -60;
		local y = -40;
        self.m_winnerIcon:setPos(x, y);
	elseif(self.m_seatPostion == GameReviewUserSeat.SEAT_POSITION_LEFT_TOP) then
		local x = -40;
		local y = -104;
        self.m_labelBackground:setPos(x, y);
		local x = -60;
		local y = -40;
        self.m_winnerIcon:setPos(x, y);
	elseif(self.m_seatPostion == GameReviewUserSeat.SEAT_POSITION_LEFT_DOWN) then
		local x = -40;
		local y = 40;
        self.m_labelBackground:setPos(x, y);
		local x = -60;
		local y = -40;
        self.m_winnerIcon:setPos(x, y);
	end
end

GameReviewUserSeat.initialize = function(self)--override protected
	self.m_loseChipBackground = "room/game_review_lose_chip_background.png";
	self.m_winChipBackground = "room/game_review_win_chip_background.png";

	self.m_infoSprite = new(Node);
	self:addChild(self.m_infoSprite);

	self.m_handCardLeft = new(PokerCard);
	self.m_infoSprite:addChild(self.m_handCardLeft);
	self.m_handCardLeft:showBack();
	self.m_handCardLeft:addPropScaleSolid(0, 0.6, 0.6, kCenterDrawing, 0, 0);

	self.m_handCardRight = new(PokerCard);
	self.m_infoSprite:addChild(self.m_handCardRight);
	self.m_handCardRight:setPos(24);
	self.m_handCardRight:addPropScaleSolid(0, 0.6, 0.6, kCenterDrawing, 0, 0);
	self.m_handCardRight:showBack();

	self.m_winnerIcon = new(Image, "room/game_review_winner_icon.png");
	self.m_infoSprite:addChild(self.m_winnerIcon);
	self.m_winnerIcon:setVisible(false);
	self.m_winnerIcon:addPropRotateSolid(0, -45 / 2, kCenterDrawing, 0, 0);

	self.m_labelBackground = new(Image, self.m_loseChipBackground, nil, nil, 5, 5, 5, 5);
	self.m_infoSprite:addChild(self.m_labelBackground);
	self.m_labelBackground:setSize(100, 60);
end

GameReviewUserSeat.getData = function(self)--public
	return self.m_data;
end

GameReviewUserSeat.setData = function(self, value)--public
	self.m_data = value;
	self:draw();
end

GameReviewUserSeat.getSeatId = function(self)--public
	return self.m_seatId;
end

GameReviewUserSeat.setSeatId = function(self, value)--public
	self.m_seatId = value;
end

GameReviewUserSeat.getSeatPostion = function(self)--public
	return self.m_seatPostion;
end

GameReviewUserSeat.setSeatPostion = function(self, value)--public
	self.m_seatPostion = value;
end
