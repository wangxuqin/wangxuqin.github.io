require("game/scene/comp/room/gameReview/gameReviewPublicCard");
require("game/scene/comp/room/gameReview/gameReviewUserSeat");
require("game/scene/comp/room/gameReview/gameReviewUserSeatLabel");

GameReviewTableRender = class(Node, false);

GameReviewTableRender.ctor = function(self, data)
    super(self);

    self.m_data = nil;
    self.m_index = 0;
    self.m_owner = nil;
    self.m_isSelected = false;
    self.m_gameTable = nil;
    self.m_timeSprite = nil;
    self.m_timeBackground = nil;
    self.m_timeDateLabel = nil;
    self.m_timeHourLabel = nil;
    self.m_publicCard = nil;
    self.m_seatPositionVct = nil;
    self.m_seatLabelPositionVct = nil;
    self.m_paddingLeft = 0;
    self.m_paddingTop = 0;
    self.m_userSeatVct = nil;
    self.m_userSeatLabelVct = nil;

	self:setSize(804);
    self:initialize();
	if(data) then
		self:setData(data);
	end
end

GameReviewTableRender.getData = function(self)
	return self.m_data;
end

GameReviewTableRender.setData = function(self, value)
	if(value) then
		self.m_data = value;
		self:draw();
	end
end

GameReviewTableRender.getIndex = function(self)
	return self.m_index;
end

GameReviewTableRender.setIndex = function(self, value)
	self.m_index = value;
end

GameReviewTableRender.getOwner = function(self)
	return self.m_owner;
end

GameReviewTableRender.setOwner = function(self, value)
	self.m_owner = value;
end

GameReviewTableRender.getIsSelected = function(self)
	return self.m_isSelected;
end

GameReviewTableRender.setIsSelected = function(self, value)
	self.m_isSelected = value;
end

GameReviewTableRender.draw = function(self)
	if(self.m_data) then
		self:refresh();
        for i=1,#self.m_data.playerList do
			if(self.m_data.playerList[i]) then
				local seatId = self.m_data.playerList[i].seatId;
				local dis = 5 - self.m_data.selfSeatId;
				local index = (self.m_data.playerList[i].seatId - 1 + dis + 9) % 9 + 1;--??

				local position = nil;
				if(index == 1 or index == 9) then
					position = GameReviewUserSeat.SEAT_POSITION_UP;
				elseif(index == 2) then
					position = GameReviewUserSeat.SEAT_POSITION_RIGHT_TOP;
				elseif(index == 3) then
					position = GameReviewUserSeat.SEAT_POSITION_RIGHT_DOWN;
				elseif(index == 4 or index == 5 or index == 6) then
					position = GameReviewUserSeat.SEAT_POSITION_BOTTOM;
				elseif(index == 7) then
					position = GameReviewUserSeat.SEAT_POSITION_LEFT_DOWN;
				elseif(index == 8) then
					position = GameReviewUserSeat.SEAT_POSITION_LEFT_TOP;
				else
					Log.e("gamereview", "invalid index: " .. tostring(index));
				end
				if(position) then
					self.m_userSeatVct[seatId]:setSeatPostion(position);
					self.m_userSeatLabelVct[seatId]:setSeatPostion(position);
				end

				self.m_userSeatVct[seatId]:setVisible(true);
				self.m_userSeatVct[seatId]:setData(self.m_data);
				self.m_userSeatVct[seatId]:setPos(self.m_seatPositionVct[index].x + 28, self.m_seatPositionVct[index].y + 37);

				self.m_userSeatLabelVct[seatId]:setVisible(true);
				self.m_userSeatLabelVct[seatId]:setData(self.m_data);
				self.m_userSeatLabelVct[seatId]:setPos(self.m_seatLabelPositionVct[index].x - 55, self.m_seatLabelPositionVct[index].y);
			end
		end

		self.m_publicCard:showPublicCard(self.m_data.publicCardArr);
		if(#self.m_data.gameOverData.chipsPotsInfo > 0) then
			self.m_publicCard:hightLightPublicCard(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card1);
			self.m_publicCard:hightLightPublicCard(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card2);
			self.m_publicCard:hightLightPublicCard(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card3);
			self.m_publicCard:hightLightPublicCard(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card4);
			self.m_publicCard:hightLightPublicCard(self.m_data.gameOverData.chipsPotsInfo[1].winner[1].card5);
		end
	end

    local w1,h1 = self:getSize();
    local w2,h2 = self.m_gameTable:getSize();
	self.m_gameTable:setPos((w1 - w2) * 0.5, (h1 - h2) * 0.5);

	self.m_timeDateLabel:setText(tostring(self.m_data.gameStartTime1));
	self.m_timeHourLabel:setText(tostring(self.m_data.gameStartTime2));
	self.m_timeDateLabel:setPos((As3Kit.getNodeWidth(self.m_timeBackground) - As3Kit.getNodeWidth(self.m_timeDateLabel)) * 0.5, 10);
	self.m_timeHourLabel:setPos((As3Kit.getNodeWidth(self.m_timeBackground) - As3Kit.getNodeWidth(self.m_timeHourLabel)) * 0.5, 30);
	local x = As3Kit.getNodeX(self.m_gameTable) + (As3Kit.getNodeWidth(self.m_gameTable) - As3Kit.getNodeWidth(self.m_timeBackground)) * 0.5;
	local y = 56;
	self.m_timeSprite:setPos(x, y);

	self.m_publicCard:setPos((As3Kit.getNodeWidth(self) - As3Kit.getNodeWidth(self.m_publicCard)) * 0.5 + 30, (As3Kit.getNodeHeight(self) - As3Kit.getNodeHeight(self.m_publicCard)) * 0.5 + 37);
end

GameReviewTableRender.initialize = function(self)
	self.m_gameTable = new(Image, "room/table.png");
	self:addChild(self.m_gameTable);
    self.m_gameTable:addPropScaleSolid(0, 0.75, 0.75, kCenterDrawing, 0, 0);
	self.m_paddingLeft = As3Kit.getNodeX(self.m_gameTable) + 50;
	self.m_paddingTop = As3Kit.getNodeY(self.m_gameTable) + 40;

	self.m_timeSprite = new(Node);
	self:addChild(self.m_timeSprite);

	self.m_timeBackground = new(Image, "room/game_review_time_background.png", nil, nil, 12, 12, 13, 13);
	self.m_timeSprite:addChild(self.m_timeBackground);
	self.m_timeBackground:setSize(160);

	self.m_publicCard = new(GameReviewPublicCard);
	self:addChild(self.m_publicCard);

	--牌坐标
	self.m_seatPositionVct = {};
	self.m_seatPositionVct[1] = new(Point, 472 + self.m_paddingLeft, 40  + self.m_paddingTop);
	self.m_seatPositionVct[2] = new(Point, 630 + self.m_paddingLeft, 104 + self.m_paddingTop);
	self.m_seatPositionVct[3] = new(Point, 630 + self.m_paddingLeft, 228 + self.m_paddingTop);
	self.m_seatPositionVct[4] = new(Point, 472 + self.m_paddingLeft, 282 + self.m_paddingTop);
	self.m_seatPositionVct[5] = new(Point, 310 + self.m_paddingLeft, 282 + self.m_paddingTop);
	self.m_seatPositionVct[6] = new(Point, 130 + self.m_paddingLeft, 282 + self.m_paddingTop);
	self.m_seatPositionVct[7] = new(Point, 0   + self.m_paddingLeft, 228 + self.m_paddingTop);
	self.m_seatPositionVct[8] = new(Point, 0   + self.m_paddingLeft, 104 + self.m_paddingTop);
	self.m_seatPositionVct[9] = new(Point, 130 + self.m_paddingLeft, 40  + self.m_paddingTop);
			
	--文字坐标
	self.m_seatLabelPositionVct = {};
	self.m_seatLabelPositionVct[1] = new(Point, self.m_seatPositionVct[1].x + 42, self.m_seatPositionVct[1].y - 60);
	self.m_seatLabelPositionVct[2] = new(Point, self.m_seatPositionVct[2].x + 42, self.m_seatPositionVct[2].y - 60);
	self.m_seatLabelPositionVct[3] = new(Point, self.m_seatPositionVct[3].x + 42, self.m_seatPositionVct[3].y - 20);
	self.m_seatLabelPositionVct[4] = new(Point, self.m_seatPositionVct[4].x + 42, self.m_seatPositionVct[4].y - 26);
	self.m_seatLabelPositionVct[5] = new(Point, self.m_seatPositionVct[5].x + 42, self.m_seatPositionVct[5].y - 26);
	self.m_seatLabelPositionVct[6] = new(Point, self.m_seatPositionVct[6].x + 42, self.m_seatPositionVct[6].y - 26);
	self.m_seatLabelPositionVct[7] = new(Point, self.m_seatPositionVct[7].x + 42, self.m_seatPositionVct[7].y - 20);
	self.m_seatLabelPositionVct[8] = new(Point, self.m_seatPositionVct[8].x + 42, self.m_seatPositionVct[8].y - 60);
	self.m_seatLabelPositionVct[9] = new(Point, self.m_seatPositionVct[9].x + 42, self.m_seatPositionVct[9].y - 60);

	self.m_userSeatVct = {};
    for i=1,9 do
		self.m_userSeatVct[i] = new(GameReviewUserSeat);
		self.m_userSeatVct[i]:setSeatId(i);
		self.m_userSeatVct[i]:setPos(self.m_seatPositionVct[i].x, self.m_seatPositionVct[i].y);
		self.m_userSeatVct[i]:setVisible(false);
		self:addChild(self.m_userSeatVct[i]);
	end

	self.m_userSeatLabelVct = {};
    for i=1,9 do
		self.m_userSeatLabelVct[i] = new(GameReviewUserSeatLabel);
		self.m_userSeatLabelVct[i]:setMySeatid(i);
		self.m_userSeatLabelVct[i]:setPos(self.m_seatLabelPositionVct[i].x, self.m_seatLabelPositionVct[i].y);
		self.m_userSeatLabelVct[i]:setVisible(false);
		self:addChild(self.m_userSeatLabelVct[i]);
	end

	self.m_timeDateLabel = new(Text, "0", nil, nil, nil, nil, 20, 0xf5, 0xf5, 0xf5);
	self.m_timeSprite:addChild(self.m_timeDateLabel);
	self.m_timeHourLabel = new(Text, "0", nil, nil, nil, nil, 24, 0xf5, 0xf5, 0xf5);
	self.m_timeSprite:addChild(self.m_timeHourLabel);
end

GameReviewTableRender.refresh = function(self)
    for i=1,9 do
		self.m_userSeatVct[i]:setVisible(false);
		self.m_userSeatVct[i]:setData(nil);

		self.m_userSeatLabelVct[i]:setVisible(false);
		self.m_userSeatLabelVct[i]:setData(nil);
	end
	self.m_publicCard:refresh();
end
