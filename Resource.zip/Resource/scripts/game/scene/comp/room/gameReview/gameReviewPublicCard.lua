-------------------------------------------------------------
GameReviewPublicCard = class(Node, false);

GameReviewPublicCard.ctor = function(self)
    super(self);
    self.m_publicCardV = nil;--:Vector.<PokerCard>;
    self.m_container = nil;--:Sprite;
	self:initialize();
end

GameReviewPublicCard.initialize = function(self)--override protected
	self.m_container = new(DrawingEmpty);
	self.m_container:setPickable(false);
	self:addChild(self.m_container);

	self.m_publicCardV = {};--new Vector.<PokerCard>(5);
    for i=1,5 do
		self.m_publicCardV[i] = new(PokerCard);
--		self.m_publicCardV[i].scaleX = self.m_publicCardV[i].scaleY = 0.6;
        self.m_publicCardV[i]:addPropScaleSolid(0, 0.6, 0.6, kCenterDrawing, 0, 0);
		self.m_publicCardV[i]:setPos((i-1) * (PokerCard.CARD_WIDTH * 0.6 + 8));
		self.m_publicCardV[i]:setVisible(false);
		self.m_container:addChild(self.m_publicCardV[i]);
	end

	self:setSize(PokerCard.CARD_WIDTH * 0.6 * 5 + 40, PokerCard.CARD_HEIGHT * 0.6);
end

GameReviewPublicCard.showPublicCard = function(self, cardArr)--public
	if (cardArr and #cardArr > 0) then
        for i=1,#cardArr do
			if(cardArr[i] ~= 0) then
				self.m_publicCardV[i]:setCard(cardArr[i]);
				self.m_publicCardV[i]:showCard();
			end
		end
	end
end

GameReviewPublicCard.refresh = function(self)--public
    for i=1,5 do
		self.m_publicCardV[i]:setVisible(false);
		self.m_publicCardV[i]:removeCardOverlay();
		self.m_publicCardV[i]:refresh();
	end
end

GameReviewPublicCard.cleanUp = function(self)--public
    for i=1,5 do
		self.m_publicCardV[i]:setVisible(false);
		self.m_publicCardV[i]:cleanUp();
	end
end

GameReviewPublicCard.hightLightPublicCard = function(self, cardUint)--public
	local value   = bit.band(cardUint, 0xFF);
	local variety = bit.brshift(cardUint, 8);
    for i=1,5 do
		if(self.m_publicCardV[i].m_cardValue == value and self.m_publicCardV[i].m_cardType == variety) then
			self.m_publicCardV[i]:showHighLight();
			break;
		end
	end
end
