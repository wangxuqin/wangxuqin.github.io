---------------------------------------------------
SmallPokerCard = class(Node, false);

SmallPokerCard.VARIETY_DIAMOND = 1;--方块
SmallPokerCard.VARIETY_CLUB    = 2;--梅花
SmallPokerCard.VARIETY_HEART   = 3;--红桃
SmallPokerCard.VARIETY_SPADE   = 4;--黑桃
SmallPokerCard.CARD_WIDTH = 80;
SmallPokerCard.CARD_HEIGHT = 108;

SmallPokerCard.ctor = function(self)
	super(self);

    --牌正面
    self.m_atlas = nil;--:TextureAtlas;
    self.m_upSprite = nil;--:Sprite;
    self.m_upSkin = nil;--:Image;
    self.m_background = nil;--:Image;
    self.m_number = nil;--:Image;
    self.m_smallVariety = nil;--:Image;
    self.m_cardUint = 0x0;--牌值
    self.m_srcCardX = 0;
    self.m_srcCardY = 0;
    self.m_timeout = 0;
    self.m_value = 0;
    self.m_variety = 0;
    self.m_flipping = false;
    --牌背
    self.m_backSprite = nil;--:Sprite;
    self.m_back = nil;--:Image;

	--正面
	self.m_upSprite = new(Node);

	--白色背景
	self.m_background = new(Image, "room/poker-background.png");
	self.m_background:setAlign(kAlignCenter);
	self.m_background:addPropScaleSolid(0, 0.5, 0.5, kCenterDrawing, 0, 0);
	self.m_upSprite:addChild(self.m_background);

	--数字
	self.m_number = new(Image, "room/poker-red-14.png");
	self.m_number:setAlign(kAlignCenter);
	self.m_number:addPropScaleSolid(0, 0.8, 0.8, kCenterDrawing, 0, 0);
	self.m_number:setPos(nil, -13);
	self.m_upSprite:addChild(self.m_number);

	--小花色
	self.m_smallVariety = new(Image, "room/poker-small-heart.png");
	self.m_smallVariety:setAlign(kAlignCenter);
	self.m_smallVariety:addPropScaleSolid(0, 0.9, 0.9, kCenterDrawing, 0, 0);
	self.m_smallVariety:setPos(nil, 11);
	self.m_upSprite:addChild(self.m_smallVariety);

    self.m_upSprite:setVisible(false);
    self:addChild(self.m_upSprite);

	--高亮
	self.m_upSkin = new(Image, "room/poker-hight-light.png");
	self.m_upSkin:setAlign(kAlignCenter);
	self.m_upSkin:addPropScaleSolid(0, 0.5, 0.5, kCenterDrawing, 0, 0);
    self.m_upSkin:setVisible(false);
    self:addChild(self.m_upSkin);

	--牌背
	self.m_backSprite = new(Node);
	self.m_back = new(Image, "room/poker-back.png");
	self.m_back:setAlign(kAlignCenter);
	self.m_back:setPos(4);
	self.m_back:addPropScaleSolid(0, 0.5, 0.5, kCenterDrawing, 0, 0)
	self.m_backSprite:addChild(self.m_back);

    self.m_backSprite:setVisible(false);
    self:addChild(self.m_backSprite);
end

SmallPokerCard.setCard = function(self, cardUint)--public
	if (self.m_cardUint == cardUint) then
		return;
    end
	self.m_cardUint = cardUint;

	self.m_value = self:getCardValue(self.m_cardUint);
	self.m_variety = self:getCardVariety(self.m_cardUint);
	local dir = "room/gamereview";
	if(self.m_variety == SmallPokerCard.VARIETY_DIAMOND) then
		self.m_number:setFile(dir .. "/poker-red-" .. self.m_value .. ".png");
		self.m_smallVariety:setFile(dir .. "/poker-small-diamond.png");
	elseif(self.m_variety == SmallPokerCard.VARIETY_HEART) then
		self.m_number:setFile(dir .. "/poker-red-" .. self.m_value .. ".png");
		self.m_smallVariety:setFile(dir .. "/poker-small-heart.png");
	elseif(self.m_variety == SmallPokerCard.VARIETY_CLUB) then
		self.m_number:setFile(dir .. "/poker-black-" .. self.m_value .. ".png");
		self.m_smallVariety:setFile(dir .. "/poker-small-club.png");
	elseif(self.m_variety == SmallPokerCard.VARIETY_SPADE) then
		self.m_number:setFile(dir .. "/poker-black-" .. self.m_value .. ".png");
		self.m_smallVariety:setFile(dir .. "/poker-small-spade.png");
    end
end

SmallPokerCard.showCard = function(self)--public
    self:setVisible(true);
    self.m_backSprite:setVisible(false);
    self.m_upSprite:setVisible(true);
end

-- 显示牌背
SmallPokerCard.showCardBack = function(self)--public
    self:setVisible(true);
    self.m_upSprite:setVisible(false);
    self.m_backSprite:setVisible(true);
end

--淡化牌
SmallPokerCard.fadeCard = function(self)--public
	self.m_upSkin:setFile("room/poker-dark-light.png");
	self.m_upSkin:setPos(-1, -1);
	self.m_upSkin:setVisible(true);
end

--牌面值 
-- @param card
-- @return 
SmallPokerCard.getCardValue = function(self, cardUint)--public static
	return bit.band(cardUint, 0xFF);
end

--牌的花色 
-- @param card
-- @return 
SmallPokerCard.getCardVariety = function(self, cardUint)--public static
	return bit.brshift(cardUint, 8);
end

SmallPokerCard.getValue = function(self)--public
	return self.m_value;
end

SmallPokerCard.getVariety = function(self)--public
	return self.m_variety;
end
