----------------------------------------------------------------
GameReviewUserSeatLabel = class(Node, false);

GameReviewUserSeatLabel.SEAT_POSITION_UP = "SEAT_POSITION_UP";
GameReviewUserSeatLabel.SEAT_POSITION_RIGHT_TOP = "SEAT_POSITION_RIGHT_TOP";
GameReviewUserSeatLabel.SEAT_POSITION_RIGHT_DOWN = "SEAT_POSITION_RIGHT_DOWN";
GameReviewUserSeatLabel.SEAT_POSITION_BOTTOM = "SEAT_POSITION_BOTTOM";
GameReviewUserSeatLabel.SEAT_POSITION_LEFT_TOP = "SEAT_POSITION_LEFT_TOP";
GameReviewUserSeatLabel.SEAT_POSITION_LEFT_DOWN = "SEAT_POSITION_LEFT_DOWN";

GameReviewUserSeatLabel.ctor = function(self)
	super(self);

    self.m_mySeatid = 0;
    self.m_data = nil;
    self.m_seatPostion = "";
    self.m_nameLabel = nil;
    self.m_chipsLabel = nil;
    self.m_cardTypeLabel = nil;

	self:setSize(100,100);
	self:initialize();
end

GameReviewUserSeatLabel.draw = function(self)
	if(self.m_seatPostion == GameReviewUserSeatLabel.SEAT_POSITION_UP) then
		self.m_nameLabel:setPos(0, 0);
		self.m_chipsLabel:setPos(As3Kit.getNodeX(self.m_nameLabel), As3Kit.getNodeY(self.m_nameLabel) + As3Kit.getNodeHeight(self.m_nameLabel) + 4);
		self.m_cardTypeLabel:setPos(As3Kit.getNodeX(self.m_nameLabel), 140);
	
    elseif(self.m_seatPostion == GameReviewUserSeatLabel.SEAT_POSITION_RIGHT_TOP) then
		self.m_nameLabel:setPos(0, 0);
		self.m_chipsLabel:setPos(As3Kit.getNodeX(self.m_nameLabel), As3Kit.getNodeY(self.m_nameLabel) + As3Kit.getNodeHeight(self.m_nameLabel) + 4);
		self.m_cardTypeLabel:setPos(-30 - As3Kit.getNodeWidth(self.m_cardTypeLabel), 80);
	
    elseif(self.m_seatPostion == GameReviewUserSeatLabel.SEAT_POSITION_RIGHT_DOWN) then
		self.m_nameLabel:setPos(0, 100);
		self.m_chipsLabel:setPos(As3Kit.getNodeX(self.m_nameLabel), As3Kit.getNodeY(self.m_nameLabel) + As3Kit.getNodeHeight(self.m_nameLabel) + 4);
		self.m_cardTypeLabel:setPos(-30 - As3Kit.getNodeWidth(self.m_cardTypeLabel), 50);
	
    elseif(self.m_seatPostion == GameReviewUserSeatLabel.SEAT_POSITION_BOTTOM) then
		self.m_nameLabel:setPos(0, 110);
		self.m_chipsLabel:setPos(As3Kit.getNodeX(self.m_nameLabel), As3Kit.getNodeY(self.m_nameLabel) + As3Kit.getNodeHeight(self.m_nameLabel) + 4);
		self.m_cardTypeLabel:setPos(0, 0);
	
    elseif(self.m_seatPostion == GameReviewUserSeatLabel.SEAT_POSITION_LEFT_TOP) then
		self.m_nameLabel:setPos(0, 0);
		self.m_chipsLabel:setPos(As3Kit.getNodeX(self.m_nameLabel), As3Kit.getNodeY(self.m_nameLabel) + As3Kit.getNodeHeight(self.m_nameLabel) + 4);
		self.m_cardTypeLabel:setPos(70, 80);
	
    elseif(self.m_seatPostion == GameReviewUserSeatLabel.SEAT_POSITION_LEFT_DOWN) then
		self.m_nameLabel:setPos(0, 100);
		self.m_chipsLabel:setPos(As3Kit.getNodeX(self.m_nameLabel), As3Kit.getNodeY(self.m_nameLabel) + As3Kit.getNodeHeight(self.m_nameLabel) + 4);
		self.m_cardTypeLabel:setPos(70, 50);
	end
end

GameReviewUserSeatLabel.initialize = function(self)
	self.m_nameLabel = new(Text, "0", nil, nil, nil, nil, 16, 0x7f, 0x90, 0xa3);
	self.m_nameLabel:setAlign(kAlignTop);
	self:addChild(self.m_nameLabel);

	self.m_chipsLabel = new(Text, "0", nil, nil, kTextAlignCenter, nil, 16, 0x7f, 0x90, 0xa3);
	self.m_chipsLabel:setAlign(kAlignTop);
	self:addChild(self.m_chipsLabel);

	self.m_cardTypeLabel = new(Text, STR_ROOM_OPERATION_TYPE[3], nil, nil, kTextAlignCenter, nil, 20, 0x50, 0xaa, 0x29);
	self.m_cardTypeLabel:setAlign(kAlignTop);
	self:addChild(self.m_cardTypeLabel);
end

GameReviewUserSeatLabel.setData = function(self, data)--public
	self.m_data = data;

	if(self.m_data) then
		local len1 = #self.m_data.playerList;
		local len2 = #self.m_data.gameOverData.playerList;
		self.m_cardTypeLabel:setText(STR_ROOM_OPERATION_TYPE[3]);
		self.m_cardTypeLabel:setVisible(true);
        for i=1,len1 do
			if(self.m_data.playerList[i].isWin and self.m_data.playerList[i].seatId == self.m_data.selfSeatId and self.m_data.selfSeatId == self:getMySeatid() and self.m_cardTypeLabel:getText() == STR_ROOM_OPERATION_TYPE[3]) then
				self.m_cardTypeLabel:setVisible(false);
			elseif(self.m_data.playerList[i].isWin and self.m_data.playerList[i].seatId == self:getMySeatid() and self.m_cardTypeLabel:getText() == STR_ROOM_OPERATION_TYPE[3]) then
				self.m_cardTypeLabel:setVisible(false);
			end

			if(self.m_data.playerList[i].seatId == self:getMySeatid() and self.m_data.playerList[i].isWin) then
				self.m_chipsLabel:setFontSize(20);
                self.m_chipsLabel:setColor(0xff, 0xcc, 0x00);
				self.m_chipsLabel:setText("+" .. STR_COMMON_CURRENCY_LABEL .. Formatter.formatBigNumber(self.m_data.playerList[i].winChip,false));
				self.m_nameLabel:setText(self.m_data.playerList[i] and self.m_data.playerList[i].name or "");
--??				Formatter.spliceSingleLineLongString(self.m_nameLabel.text,100,self.m_nameLabel);
			elseif(self.m_data.playerList[i].seatId == self:getMySeatid()) then
				self.m_chipsLabel:setFontSize(20);
                self.m_chipsLabel:setColor(0x98, 0xa8, 0x92);
				self.m_chipsLabel:setText("-" .. STR_COMMON_CURRENCY_LABEL .. Formatter.formatBigNumber(self.m_data.playerList[i].betInChips,false));
				self.m_nameLabel:setText(self.m_data.playerList[i] and self.m_data.playerList[i].name or "");
--??				Formatter.spliceSingleLineLongString(self.m_nameLabel.text,100,self.m_nameLabel);
			end

            for j=1,len2 do
				if(self.m_data.playerList[i] and self.m_data.gameOverData.playerList[j].seatId == self:getMySeatid() and self.m_data.playerList[i].seatId == self:getMySeatid()) then
					if(self.m_data.gameOverData.playerList[j].cardType > 0 and self.m_data.gameOverData.playerList[j].cardType < 11) then
						self.m_cardTypeLabel:setVisible(true);
						self.m_cardTypeLabel:setText(STR_ROOM_CARD_TYPE[self.m_data.gameOverData.playerList[j].cardType]);
					else
						self.m_cardTypeLabel:setVisible(false);
					end
				end
			end
		end
		self:draw();
	end
end

GameReviewUserSeatLabel.getMySeatid = function(self)--public
	return self.m_mySeatid;
end

GameReviewUserSeatLabel.setMySeatid = function(self, value)--public
	self.m_mySeatid = value;
end

GameReviewUserSeatLabel.getSeatPostion = function(self)--public
	return self.m_seatPostion;
end

GameReviewUserSeatLabel.setSeatPostion = function(self, value)--public
	self.m_seatPostion = value;
end
