require("view/room/layout_room_exp");
--[Comment]
--经验动画
ExpSprite = class(Node)
ExpSprite.ctor = function(self)
    self.m_root         = SceneLoader.load(layout_room_exp);
    self.m_imgExp       = self.m_root:getNodeByName("container.img_exp");
    self.m_txtExp       = self.m_root:getNodeByName("container.txt_exp");
    self.m_getExpImg    = "room/exp/room-user-increase-exp.png";    --获取经验时的图片
    self.m_lostExpImg   = "room/exp/room-user-decrease-exp.png";    --失去经验时的图片
    self.m_getExpColor  = 0xFF7F01;   --获取经验时，文字的颜色
    self.m_lostExpColor = 0x797876;   --失去经验时，文字的颜色
    self:setSize(self.m_root:getSize());
    self:addChild(self.m_root);
end

ExpSprite.dtor = function(self)
    Node.dtor(self);
end

ExpSprite.setParentVisible = function(self, visible)
     local parent = self:getParent();
     if parent ~= nil then 
        parent:setVisible(visible);
     end
end

ExpSprite.setExp = function(self, exp)
    self.m_exp = exp;
    local Y = 114;
    KTween.remove(self);
    if exp > 0 then
        self.m_imgExp:setFile(self.m_getExpImg);
        self.m_txtExp:setColor(RGBKit.getRGB(self.m_getExpColor));
        self.m_txtExp:setText("+"..exp);
        KTween.to(self, 1600, {startY = Y, y = 0,easeType = EaseType.SinOut, onComplete = self.onComplete, obj = self, delay = 500});
    elseif exp < 0 then
        self.m_imgExp:setFile(self.m_lostExpImg);
        self.m_txtExp:setColor(RGBKit.getRGB(self.m_lostExpColor));
        self.m_txtExp:setText(tostring(exp));
        KTween.to(self, 1600, {startY = 0, y = Y,easeType = EaseType.SinOut, onComplete = self.onComplete, obj = self, delay = 500});
    end

    if exp ~= 0 then
       self:setParentVisible(true);
    end
end

ExpSprite.onComplete = function(self)
    self:setParentVisible(false);
end