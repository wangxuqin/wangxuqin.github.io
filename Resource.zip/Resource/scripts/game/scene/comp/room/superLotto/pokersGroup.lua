----------------------------------------------------
PokersGroup = class(Node, false);

PokersGroup.ctor = function(self, cardsArray)
	super(self);

	self.m_sprite = new(Node);
	self:addChild(self.m_sprite);
	for i=1,5 do
		local poker = new(PokerCard);
		poker:setCard(cardsArray[i]);
		local x = 40 + 24 * (i-1);
		local y = 0;
		if(i == 1) then
			y = 60;
		elseif(i == 2) then
			y = 54;
		elseif(i == 3) then
			y = 54;
		elseif(i == 4) then
			y = 54;
		elseif(i == 5) then
			y = 60;
		end
		poker:setPos(x-80, y-54);
		poker:setRotate((i - 3) * 10);
		self.m_sprite:addChild(poker);
	end

	self.m_sprite:setScale(0.65);
	self.m_sprite:setSize(116, 86);
	self:addChild(self.m_sprite);

	self.m_cardTypeLabel = new(TextView, "0", 200, 50, nil, nil, 20, 0xad, 0xc5, 0xef);
	self:addChild(self.m_cardTypeLabel);

	self:setPickable(false);
	self:draw();
end

PokersGroup.draw = function(self)
	local w = 108;--self.m_cardTypeLabel:getSize();
	local w2,h2 = self.m_sprite:getSize();
	local x = ToolKit.layoutCenter(0, w2, w);
	local y = h2;
	self.m_cardTypeLabel:setPos(x, y);
end

PokersGroup.setDistributionScale = function(self, cardType, prizePercent)
	self.m_cardTypeLabel:setText(StringKit.substitute(STR_LOTTO_REWARD_TYPE_POT, cardType, prizePercent));
	self:draw();
end
