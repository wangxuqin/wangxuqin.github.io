SuperLottoEntry = class(Node, false);

SuperLottoEntry.ERROR_CODE_SYSTEM_ERROR			= 0x9431;
SuperLottoEntry.ERROR_CODE_MOENY_NOT_ENOUGH		= 0x9432;
SuperLottoEntry.ERROR_CODE_NOT_IN_SEAT			= 0x9433;

SuperLottoEntry.checkEnabled = function(loginSuccData)
	local userData = Model.getData(ModelKeys.USER_DATA);
	local isSupport = userData["superLotto"];
	return isSupport ~= nil and isSupport ~= 0 and loginSuccData.roomType == LoginSuccData.ROOM_TYPE_NORMAL and loginSuccData.smallBlind >= SuperLottoEntry:getMinSmallBlind();
end

SuperLottoEntry.getMinSmallBlind = function(self)
	local userData = Model.getData(ModelKeys.USER_DATA);
	if(userData ~= nil and userData["superLottoSB"] ~= nil) then
		return userData["superLottoSB"];
	end
	return 0;
end

SuperLottoEntry.ctor = function(self)
	super(self);

	self.m_poolLabel = nil;--奖池
	self.m_lottoIcon = nil;--图标
	self.m_oldValue = 0;--旧值
	self.m_turningImage = nil;--买入成功发光

	self:initialize();
	self:addEventAndDataList();
	self:draw();
	self:setEventTouch(self, self.touchHandler);
end

SuperLottoEntry.dtor = function(self)
	self:delEventAndDataList();
end

SuperLottoEntry.addEventAndDataList = function(self)
	if(self.m_datalist == nil) then
		self.m_datalist =
		{
			{ ModelKeys.LOTTO_POOL, self, self.lottoPoolChange, false, },
			{ ModelKeys.LOTTO_IS_CURRENT_BUY, self, self.isCurrentBuy, },
		};
		Model.watchDataList(self.m_datalist);
	end
end

SuperLottoEntry.delEventAndDataList = function(self)
	if(self.m_datalist ~= nil) then
		Model.unwatchDataList(self.m_datalist);
		self.m_datalist = nil;
	end
end

SuperLottoEntry.touchHandler = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
	TouchHelper.catch(self, finger_action, x, y);
	if(TouchHelper.isClick(self)) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_SUPER_LOTTO_POPUP);
	end
end

SuperLottoEntry.draw = function(self)
	self.m_poolLabel:setPos(nil, As3Kit.getNodeHeight(self.m_lottoIcon));

	if (As3Kit.getNodeWidth(self.m_poolLabel) > As3Kit.getNodeWidth(self.m_lottoIcon)) then
		self.m_poolLabel:setPos(0);
		self.m_lottoIcon:setPos((As3Kit.getNodeWidth(self.m_poolLabel) - As3Kit.getNodeWidth(self.m_lottoIcon)) * 0.5);
		self:setSize(As3Kit.getNodeWidth(self.m_poolLabel), As3Kit.getNodeHeight(self.m_lottoIcon) + As3Kit.getNodeHeight(self.m_poolLabel));
	else
		self.m_lottoIcon:setPos(0);
		self.m_poolLabel:setPos((As3Kit.getNodeWidth(self.m_lottoIcon) - As3Kit.getNodeWidth(self.m_poolLabel)) * 0.5);
		self:setSize(As3Kit.getNodeWidth(self.m_lottoIcon), As3Kit.getNodeHeight(self.m_lottoIcon) + As3Kit.getNodeHeight(self.m_poolLabel));
	end
	local w,h = self:getSize();
	self:setPos(64 - w, 64 - h);
end

SuperLottoEntry.initialize = function(self)
	self.m_turningImage = new(TurningImage, "top-tip-turn.png", 180 * 2 / 60);
	self.m_turningImage:setScale(1.25);
	self.m_turningImage:setPickable(false);
	self.m_turningImage:setVisible(false);
	self.m_turningImage:stopRotate();
	self:addChild(self.m_turningImage);

	self.m_lottoIcon = new(Image, "room/superlotto/lotto-icon.png");
	self:addChild(self.m_lottoIcon);

	self.m_poolLabel = new(Text, "......", nil, nil, kTextAlignTop, nil, 22, 0xff, 0xcc, 0x00, true);
	self:addChild(self.m_poolLabel);
end

--购买成功回调函数，播放旋转图片 
-- @param value
SuperLottoEntry.isCurrentBuy = function(self, value)
	if (value) then
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_LOTTO_BUY_NEXT_SUCCEED);

		local x = As3Kit.getNodeX(self.m_lottoIcon) + As3Kit.getNodeWidth(self.m_lottoIcon) * 0.5;
		local y = As3Kit.getNodeY(self.m_lottoIcon) + As3Kit.getNodeHeight(self.m_lottoIcon) * 0.5;
		self.m_turningImage:setPos(x, y);
		self.m_turningImage:startRotate();
		self.m_turningImage:setVisible(true);
		local delay = new(ActionDelayTime, 3.5);
		local call = new(ActionCallFuncN, self, function(self, node)
			node:setVisible(false);
			node:stopRotate();
		end);
		local action = new(ActionSequence, delay, call);
		action:apply(self.m_turningImage);
	end
end

SuperLottoEntry.lottoPoolChange = function(self, newValue)
	newValue = newValue or 0;
	--数值增长动画
	local start = self.m_oldValue;
	local action = new(ActionCallFuncFrame, 0.75, self, function(self, progress)
		self:setOldValue(start + (newValue - start) * progress);
	end);
	action:apply(self);
end

SuperLottoEntry.setOldValue = function(self, value)
	self.m_oldValue = math.floor(value);
	if(value - self.m_oldValue >= 0.5) then
		self.m_oldValue = self.m_oldValue + 1;
	end
	self.m_poolLabel:setText(STR_COMMON_NUMBER_CURRENCY_LABEL .. Formatter.formatNumberWithSplit(self.m_oldValue));
	self:draw();
end

SuperLottoEntry.getOldValue = function(self)
	return self.m_oldValue;
end
