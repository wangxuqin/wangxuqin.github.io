-----------------------------------------------------------------
LottoRuleScrollContainer = class();

LottoRuleScrollContainer.ctor = function(self, node)
	self.m_sPadding = 0;
	self.m_sWidth = 0;
	self.m_sHeight = 0;
	self.m_scrollContainer = nil;
	self.m_rewardLabel = nil;
	self.m_tipsLabel = nil;

	self.m_sPadding = 16;
	self.m_sWidth = w;
	self.m_sHeight = h;

	self.m_container = node;
	self:initialize();
end

LottoRuleScrollContainer.initialize = function(self)
	--获奖条件
	self.m_rewardLabel = self.m_container:getNodeByName("reward");
	self.m_rewardLabel:setText(STR_LOTTO_RULE_REWARD);
	--注
	self.m_tipsLabel = self.m_container:getNodeByName("tips");
	self.m_tipsLabel:setText(STR_LOTTO_RULE_TIPS);

	local w,h = self.m_rewardLabel:getSize();
	self.m_tipsLabel:setPos(nil, ToolKit.getNodeY(self.m_rewardLabel) + h + self.m_sPadding);
end

LottoRuleScrollContainer.setVisible = function(self, visible)
	if(self.m_container ~= nil) then
		self.m_container:setVisible(visible);
	end
end
