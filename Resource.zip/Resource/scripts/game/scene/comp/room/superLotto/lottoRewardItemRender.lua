LottoRewardItemRender = class(Node, false);

LottoRewardItemRender.sWidth = 0;
LottoRewardItemRender.sHeight = 0;

LottoRewardItemRender.ctor = function(self)
	super(self);

	self.m_sPaddingX = 0;
	self.m_sPhotoWidth = 0;
	self.m_sPhotoHeight = 0;
	self.m_data = nil;
	self.m_index = 0;
	self.m_owner = nil;
	self.m_photoLoader = nil;
	self.m_cardType = nil;
	self.m_name = nil;
	self.m_money = nil;
	self.m_division = nil;

	self.m_sPaddingX = 16;
	self.m_sPhotoWidth = 50;
	self.m_sPhotoHeight = 50;
	self:initialize();
end

LottoRewardItemRender.init = function(w, h)
	LottoRewardItemRender.sWidth = w;
	LottoRewardItemRender.sHeight = h;
end

LottoRewardItemRender.initialize = function(self)
	self:setSize(LottoRewardItemRender.sWidth, LottoRewardItemRender.sHeight);
	local w,h = LottoRewardItemRender.sWidth, LottoRewardItemRender.sHeight;
	--头像
	self.m_photoLoader = new(UrlImage, "room/room-default-male-photo.png");
	self.m_photoLoader:setSize(self.m_sPhotoWidth, self.m_sPhotoHeight);
	self.m_photoLoader:setPos(self.m_sPaddingX, (h - self.m_sPhotoHeight) / 2);
	self:addChild(self.m_photoLoader);

	--牌型
	self.m_cardType = new(CardType, 0.5, -12);
	self.m_cardType:setPos(w - self.m_sPaddingX - ToolKit.getNodeWidth(self.m_cardType)-20, (h - ToolKit.getNodeHeight(self.m_cardType)) / 2);
	self:addChild(self.m_cardType);

	--获奖人名
	self.m_name = new(Text, "0", nil, nil, nil, nil, 24, 0xad, 0xc5, 0xef);
	self.m_name:setPickable(false);
	self.m_name:setPos(ToolKit.getNodeX(self.m_photoLoader) + self.m_sPaddingX + self.m_sPhotoWidth);
	self.m_name:setSize(ToolKit.getNodeX(self.m_cardType) - ToolKit.getNodeX(self.m_name) - self.m_sPaddingX);
	self:addChild(self.m_name);

	--赢得奖池
	self.m_money = new(Text, "0", nil, nil, nil, nil, 20, 0xad, 0xc5, 0xef);
	self.m_money:setPickable(false);
	local x = self.m_name:getPos();
	self.m_money:setPos(x);
	self:addChild(self.m_money);

	--分割线
	self.m_division = new(Image, "room/superlotto/lotto-reward-split-line.png");
	self.m_division:setSize(LottoRewardItemRender.sWidth);
	self.m_division:setPos(nil, LottoRewardItemRender.sHeight - ToolKit.getNodeHeight(self.m_division));
	self:addChild(self.m_division);
end

LottoRewardItemRender.draw = function(self)
	if(self.m_data ~= nil) then
		--处理头像
		if (string.len(self.m_data.photoUrl) <= 5) then
			local guestPhotoTexture = "userinfo/imgface_" .. self.m_data.photoUrl .. ".jpg";
			if (ToolKit.isFileExist(guestPhotoTexture)) then
				self.m_photoLoader:setFile(guestPhotoTexture);--获取游客头像
			else
				self.m_photoLoader:setFile("room/room-default-male-photo.png");
			end
		else
--			self.m_photoLoader:setFile("room/room-default-male-photo.png");
			self.m_photoLoader:setUrl(self.m_data.photoUrl);
		end

		--如果没有cache则拉取头像
--?		if (!PhotoCache.instance.hasCache(self.m_data.uid + "_50") and self.m_data.photoUrl.length > 5)
--?		{
--?			self.m_photoLoader.data = {"key":self.m_data.uid + "_50", "url":self.m_data.photoUrl};
--?		}

		self.m_cardType:setCards(self.m_data.cards);

--?		Formatter.spliceSingleLineLongString(self.m_data.userName, self.m_name.width, self.m_name, TextFieldAutoSize.LEFT);
		self.m_name:setText(self.m_data.userName);
		self.m_money:setText(StringKit.substitute(STR_LOTTO_REWARD_LIST_MONEY, STR_COMMON_CURRENCY_LABEL .. Formatter.formatNumberWithSplit(self.m_data.money)));
	end

--	self.m_name.width = self.m_cardType.x - self.m_name.x - self.m_sPaddingX;
--	self.m_money.width = self.m_name.width;

	local w,h = self:getSize();
	local sPaddingY = (h - ToolKit.getNodeHeight(self.m_name) - ToolKit.getNodeHeight(self.m_money)) / 5;
	self.m_name:setPos(nil, sPaddingY * 2);
	self.m_money:setPos(nil, ToolKit.getNodeY(self.m_name) + ToolKit.getNodeHeight(self.m_name) + sPaddingY);
end

LottoRewardItemRender.getData = function(self)
	return self.m_data;
end

LottoRewardItemRender.setData = function(self, value)
	if(self.m_data == value) then
		return;
	end
	self.m_data = value;
	self:draw();
end

LottoRewardItemRender.getIndex = function(self)
	return self.m_index;
end

LottoRewardItemRender.setIndex = function(self, value)
	self.m_index = value;
end

LottoRewardItemRender.getOwner = function(self)
	return self.m_owner;
end

LottoRewardItemRender.setOwner = function(self, value)
	self.m_owner = value;
end

LottoRewardItemRender.getIsSelected = function(self)
	return false;
end

LottoRewardItemRender.setIsSelected = function(self, value)
end
