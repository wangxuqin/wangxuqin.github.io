--------------------------------------------------------
require("view/room/layout_super_lotto");
require("game/scene/comp/room/superLotto/lottoBuyInContainer");
require("game/scene/comp/room/superLotto/lottoRuleScrollContainer");
require("game/scene/comp/room/superLotto/lottoRewardList");

SuperLottoPopUp = class(PopupDialog, false);

SuperLottoPopUp.ctor = function(self)--public
	super(self, layout_super_lotto, true);

	self.m_currentPool = nil;
	self.m_poolLabel = nil;--奖池数值
	self.m_coinIcon = nil;--金币图标
	self.m_helpButton = nil;--帮助按钮
	self.m_returnButton = nil;--返回按钮
	self.m_oldValue = 0;--旧值
	self.m_rewardListBtn = nil;--获奖名单按钮
	self.m_closeBtn = nil;
	self.m_content = nil;--内容
	self.m_buyinContainer = nil;--买入容器
	self.m_rulesContainer = nil;--规则容器
	self.m_rewardContainer = nil;--获奖名单

	self:initialize();
	self:addEventAndWatch();
end

SuperLottoPopUp.dtor = function(self)
	self:removeEventAndWatch();
	if(self.m_buyinContainer ~= nil) then
		delete(self.m_buyinContainer);
		self.m_buyinContainer = nil;
	end
end

SuperLottoPopUp.addEventAndWatch = function(self)
	if(self.m_eventList == nil) then
		self.m_eventList =
		{
			{UIEvent, UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM, "onPassiveLeaveRoom"};
		};
	end
	EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
	if(self.m_watchDataList == nil) then
		self.m_watchDataList =
		{
			{ModelKeys.LOTTO_POOL, self, self.lottoPoolChange},
		};
	end
	Model.watchDataList(self.m_watchDataList);
end

SuperLottoPopUp.removeEventAndWatch = function(self)
	if(self.m_eventList ~= nil) then
		EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
		self.m_eventList = nil;
	end
	if(self.m_watchDataList ~= nil) then
		Model.unwatchDataList(self.m_watchDataList);
		self.m_watchDataList = nil;
	end
end

SuperLottoPopUp.onPassiveLeaveRoom = function(self)
	self:close();
end

SuperLottoPopUp.draw = function(self)
	local w,h = self:getDialog():getSize();
	local x = (w - (ToolKit.getNodeWidth(self.m_currentPool) + ToolKit.getNodeWidth(self.m_poolLabel) + 12)) * 0.5;
	local y = ToolKit.layoutCenter(ToolKit.getNodeHeight(self.m_coinIcon), 72, ToolKit.getNodeHeight(self.m_currentPool));
	self.m_currentPool:setPos(x, y);
	local x = ToolKit.getNodeX(self.m_currentPool) + ToolKit.getNodeWidth(self.m_currentPool) + 12;
	local y = ToolKit.layoutCenter(ToolKit.getNodeHeight(self.m_coinIcon), 72, ToolKit.getNodeHeight(self.m_poolLabel));
	self.m_poolLabel:setPos(x, y);
end

SuperLottoPopUp.initialize = function(self)
	--金币
	self.m_coinIcon = self.m_root:getNodeByName("lotto.coin_icon");
	-- right part
--	local rightBg = self.m_root:getNodeByName("lotto.bg_right");
--	rightBg:setScale(-1, 1);
	--黄点
--	local dot:Image = new Image(atlas.getTexture("lotto-title-dot"));
--	dot.pivotX = dot.width * 0.5;
--	dot.pivotY = dot.height * 0.5;
--	local quadBatch:QuadBatch = new QuadBatch();
--	quadBatch.x = layoutScale(67);
--	quadBatch.y = background.y + layoutScale(9);
--	bgSprite.addChild(quadBatch);
--	for (local i:int = 0; i < 29; i++) 
--	{
--		dot.x = layoutScale(10) + i * layoutScale(20);
--		quadBatch.addImage(dot);
--	}
--	for (i = 0; i < 29; i++) 
--	{
--		dot.x = layoutScale(10) + i * layoutScale(20);
--		dot.y = layoutScale(55);
--		quadBatch.addImage(dot);
--	}
--	for (i = 0; i < 2; i++)
--	{
--		dot.x = 0;
--		dot.y = layoutScale(18) * (i + 1);
--		quadBatch.addImage(dot);
--	}
--	for (i = 0; i < 2; i++)
--	{
--		dot.x = layoutScale(577);
--		dot.y = layoutScale(18) * (i + 1);
--		quadBatch.addImage(dot);
--	}

	--内容容器
	self.m_content = self.m_root:getNodeByName("lotto.content");
	--帮助按钮
	self.m_helpButton = self.m_root:getNodeByName("lotto.btn_help");
	--返回按钮
	self.m_returnButton = self.m_root:getNodeByName("lotto.btn_return");
	self.m_returnButton:setVisible(false);
	--获奖名单
	self.m_rewardListBtn = self.m_root:getNodeByName("lotto.btn_rewardlist");
	local label = self.m_root:getNodeByName("lotto.btn_rewardlist.label");
	label:setText(STR_LOTTO_REWARD_LIST_TITLE);
	--关闭按钮
	self.m_closeBtn = self.m_root:getNodeByName("lotto.btn_close");
	--当前奖池
	self.m_currentPool = self.m_root:getNodeByName("lotto.current_pool");
	self.m_currentPool:setText(STR_LOTTO_CURRENT_POOL);
	--奖池
	self.m_poolLabel = self.m_root:getNodeByName("lotto.pool_label");
	--初始化内容容器
	self.m_buyinContainer = new(LottoBuyInContainer, self.m_root:getNodeByName("lotto.content.buyinContainer"));
	self.m_rulesContainer = new(LottoRuleScrollContainer, self.m_root:getNodeByName("lotto.content.ruleContainer"));
	self.m_rewardContainer = nil;
end

SuperLottoPopUp.onPopupEnd = function(self)
	--事件响应
	self.m_helpButton:setOnClick(self, self.helpBtnTriggeredHandler);
	self.m_returnButton:setOnClick(self, self.returnBtnTriggeredHandler);
	self.m_rewardListBtn:setOnClick(self, self.rewardListBtnTriggeredHandler);
	self.m_closeBtn:setOnClick(self, self.onPassiveLeaveRoom);
end

SuperLottoPopUp.returnBtnTriggeredHandler = function(self)
	for k,v in pairs(self.m_content:getChildren()) do
		v:setVisible(false);
	end
	self.m_buyinContainer:setVisible(true);

	self.m_helpButton:setVisible(true);
	self.m_returnButton:setVisible(false);
end

SuperLottoPopUp.rewardListBtnTriggeredHandler = function(self)
	for k,v in pairs(self.m_content:getChildren()) do
		v:setVisible(false);
	end
	if(self.m_rewardContainer == nil) then
		self.m_rewardContainer = new(LottoRewardList, 568, 348);
		self.m_rewardContainer:setVisible(false);
		self.m_content:addChild(self.m_rewardContainer);
	end
	if(self.m_rewardContainer ~= nil) then
		self.m_rewardContainer:setVisible(true);
	end

	self.m_helpButton:setVisible(false);
	self.m_returnButton:setVisible(true);
end

SuperLottoPopUp.helpBtnTriggeredHandler = function(self)
	for k,v in pairs(self.m_content:getChildren()) do
		v:setVisible(false);
	end
	if(self.m_rulesContainer ~= nil) then
		self.m_rulesContainer:setVisible(true);
	end

	self.m_helpButton:setVisible(false);
	self.m_returnButton:setVisible(true);
end

SuperLottoPopUp.lottoPoolChange = function(self, newValue)
	newValue = newValue or 0;
	--数值增长动画
	local start = self.m_oldValue;
	local action = new(ActionCallFuncFrame, 0.75, self, function(self, progress)
		self:setOldValue(start + (newValue - start) * progress);
	end);
	action:apply(self);
end

SuperLottoPopUp.setOldValue = function(self, value)
	self.m_oldValue = math.floor(value);
	if(value - self.m_oldValue >= 0.5) then
		self.m_oldValue = self.m_oldValue + 1;
	end
	self.m_poolLabel:setText(STR_COMMON_NUMBER_CURRENCY_LABEL .. Formatter.formatNumberWithSplit(self.m_oldValue));
	self:draw();
end

SuperLottoPopUp.getOldValue = function(self)
	return self.m_oldValue;
end
