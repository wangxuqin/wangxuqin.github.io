------------------------------------------------------------
require("game/scene/comp/room/superLotto/pokersGroup");

LottoBuyInContainer = class();

LottoBuyInContainer.ctor = function(self, node)
	self.m_buyLottoText = nil;
	self.m_autoBuyIn = nil;
	self.m_buyNextRound = nil;
	self.m_pokersGroup1 = nil;
	self.m_pokersGroup2 = nil;
	self.m_pokersGroup3 = nil;

	self.m_container = node;

	self:initialize();
	self:addEventAndDataList();
end

LottoBuyInContainer.dtor = function(self)
	self:delEventAndDataList();
end

LottoBuyInContainer.setVisible = function(self, visible)
	if(self.m_container ~= nil) then
		self.m_container:setVisible(visible);
	end
end

LottoBuyInContainer.addEventAndDataList = function(self)
	if(self.m_datalist == nil) then
		self.m_datalist =
		{
			{ ModelKeys.LOTTO_IS_NEXT_BUY, self, self.isNextRoundBuy },
			{ ModelKeys.LOTTO_IS_AUTO_BUY, self, self.isAutoBuyIn },
			{ ModelKeys.ROOM_EXTRA_LOGIN_INFO, self, self.extraLoginInfo },
		};
		Model.watchDataList(self.m_datalist);
	end
end

LottoBuyInContainer.delEventAndDataList = function(self)
	if(self.m_datalist ~= nil) then
		Model.unwatchDataList(self.m_datalist);
		self.m_datalist = nil;
	end
end

LottoBuyInContainer.initialize = function(self)
	local w,h = self.m_container:getSize();
	--买入说明
	self.m_buyLottoText = self.m_container:getNodeByName("lotto_text");
	--牌型说明
	self.m_pokersGroup1 = new(PokersGroup, {0x040A, 0x040B, 0x040C, 0x040D, 0x040E});
	self.m_pokersGroup1:setPos(16, 112);
	self.m_container:addChild(self.m_pokersGroup1);
	self.m_pokersGroup2 = new(PokersGroup, {0x0308, 0x0309, 0x030A, 0x030B, 0x030C});
	self.m_pokersGroup2:setPos(218, 112);
	self.m_container:addChild(self.m_pokersGroup2);
	self.m_pokersGroup3 = new(PokersGroup, {0x040E, 0x030E, 0x020E, 0x010E, 0x040C});
	self.m_pokersGroup3:setPos(420, 112);
	self.m_container:addChild(self.m_pokersGroup3);
	--自动买入
	self.m_autoBuyIn = self.m_container:getNodeByName("autobuyin.checkGroup.check");
	local label = self.m_container:getNodeByName("autobuyin.label");
	label:setText(STR_LOTTO_BUY_LOTTO_AUTO);
	self.m_autoBuyIn:setChecked(Model.getData(ModelKeys.LOTTO_IS_AUTO_BUY));
	local group = self.m_container:getNodeByName("autobuyin.checkGroup");
	group:setOnChange(self, self.autoBuyInChangeHandler);
	--购买本局
	self.m_buyNextRound = self.m_container:getNodeByName("btn_buyin");
	local label = self.m_container:getNodeByName("btn_buyin.label");
	label:setText(STR_LOTTO_BUY_NEXT_ROUND);
	self.m_buyNextRound:setOnClick(self, self.buyNextRoundTriggeredHandler);
end

LottoBuyInContainer.extraLoginInfo = function(self, data)
	if(data == nil) then
		return;
	end
	self.m_buyLottoText:setText(StringKit.substitute(STR_LOTTO_BUY_LOTTO_TEXT, Formatter.formatBigNumber(data.lottoPrice)));
	self.m_pokersGroup1:setDistributionScale(STR_ROOM_CARD_TYPE[11], data.royalFlushScale);
	self.m_pokersGroup2:setDistributionScale(STR_ROOM_CARD_TYPE[10], data.straightFlushScale);
	self.m_pokersGroup3:setDistributionScale(STR_ROOM_CARD_TYPE[9], data.fourKindScale);
end

LottoBuyInContainer.isAutoBuyIn = function(self, value)
	if(self.m_autoBuyIn ~= nil) then
		self.m_autoBuyIn:setChecked(value);
	end
end

LottoBuyInContainer.isNextRoundBuy = function(self, value)
	self.m_buyNextRound:setEnable(not value);
	local label = self.m_buyNextRound:getChildren()[1];
	label:setText(value and STR_LOTTO_BOUGHT_NEXT_ROUND or STR_LOTTO_BUY_NEXT_ROUND);
end

LottoBuyInContainer.buyNextRoundTriggeredHandler = function(self)
	if(SeatManager.selfInSeat) then
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.SUPER_LOTTO_BUY_NEXT);
		--设置按钮灰态
	else
		EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_LOTTO_NOT_IN_SEAT);
	end
end

LottoBuyInContainer.autoBuyInChangeHandler = function(self)
	if(self.m_autoBuyIn:isChecked()) then
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.SUPER_LOTTO_AUTO_BUY);
	else
		EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.SUPER_LOTTO_CANCEL_AUTO_BUY);
	end
end
