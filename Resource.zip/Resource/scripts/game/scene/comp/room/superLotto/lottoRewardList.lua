require("game/scene/comp/room/superLotto/lottoRewardItemRender");

LottoRewardList = class(Node, false);

LottoRewardList.ctor = function(self, w, h)
	super(self);

	self.m_sWidth = w;
	self.m_sHeight = h;
	self:setSize(w, h);
	self:initialize();

	self:addEventAndDataList();
	self:addedToStageHandler();
end

LottoRewardList.dtor = function(self)
	self:delEventAndDataList();
end

LottoRewardList.addEventAndDataList = function(self)
	if(self.m_datalist == nil) then
		self.m_datalist =
		{
			{ ModelKeys.LOTTO_REWARD_LIST, self, self.newRewardList },
		};
		Model.watchDataList(self.m_datalist);
	end
end

LottoRewardList.delEventAndDataList = function(self)
	if(self.m_datalist ~= nil) then
		Model.unwatchDataList(self.m_datalist);
		self.m_datalist = nil;
	end
end

LottoRewardList.addedToStageHandler = function(self)
	--显示菊花
	local w,h = self.m_loadingContainer:getSize();
	self.m_miniLoad = AtomAnimManager.getInstance():playAnim("atomAnimTable/common/anim_common_miniLoad", self.m_loadingContainer, w/2, h/2, false);
	HttpService.post({["mod"]="duojindao", ["act"]="getRewardUids"}, self.getCallback, self.getCallback, self.getCallback);

	self:resetPosition();
end

LottoRewardList.__endLoading = function(self)
	if(self.m_miniLoad ~= nil) then
		self.m_miniLoad:release();
		self.m_miniLoad = nil;
	end
end

LottoRewardList.getCallback = function(self, value)
	value = value or "";
	value = '{"ret":1,"rewardUids":[{"uid":1387122,"name":"∝再不疯狂我们就老了","url":"http://thirdapp3.qlogo.cn/qzopenapp/e3e6b4bc45ca4d19f1664d2bd17769a3dcc1ed53b64da7d3cfa59f1984de1ff9/50","lotteryMoney":903250,"type":9,"card1":1034,"card2":266,"card3":778,"card4":522,"card5":269,"time":"05-10 16:18:27","isfriend":0},{"uid":1270356,"name":"随缘","url":"http://thirdapp3.qlogo.cn/qzopenapp/a4ab68dc9934f2da3432d4732e50aa9d5bc9ced03c7218aeadd290c3cefe6905/50","lotteryMoney":819080,"type":9,"card1":514,"card2":258,"card3":1026,"card4":770,"card5":522,"time":"05-10 16:05:03","isfriend":0},{"uid":876594,"name":"    爽歪歪ˉ","url":"http://thirdapp3.qlogo.cn/qzopenapp/13675a92aec0dfe26603342e5dc0d52c0d89e2c7f12b63abb992ab5574ce2e53/50","lotteryMoney":2953560,"type":10,"card1":523,"card2":522,"card3":521,"card4":520,"card5":519,"time":"05-10 15:53:57","isfriend":0},{"uid":472829,"name":"灞氣╃じ帥帥","url":"http://thirdapp1.qlogo.cn/qzopenapp/7e1343368cdd9805b65c5fedd081ba1ac7f2c477e65160631c84b6f8c7ad5df3/50","lotteryMoney":703870,"type":9,"card1":259,"card2":515,"card3":1027,"card4":771,"card5":782,"time":"05-10 15:14:49","isfriend":0},{"uid":1340281,"name":"冰雪","url":"http://thirdapp1.qlogo.cn/qzopenapp/e3e6b4bc45ca4d193a9870b16b2ff88bf33bc09658861b0f8727daff57c77725/50","lotteryMoney":671330,"type":9,"card1":266,"card2":778,"card3":522,"card4":1034,"card5":524,"time":"05-10 15:05:42","isfriend":0},{"uid":360928,"name":"┈┾等伱嗳ωǒ↘","url":"http://thirdapp2.qlogo.cn/qzopenapp/36b63235a3d985e5c03215d70986494925343bbb1e0524b158146ba6b89da976/50","lotteryMoney":535440,"type":9,"card1":780,"card2":524,"card3":268,"card4":1036,"card5":777,"time":"05-10 14:41:49","isfriend":0},{"uid":360928,"name":"┈┾等伱嗳ωǒ↘","url":"http://thirdapp2.qlogo.cn/qzopenapp/36b63235a3d985e5c03215d70986494925343bbb1e0524b158146ba6b89da976/50","lotteryMoney":1881270,"type":10,"card1":525,"card2":524,"card3":523,"card4":522,"card5":521,"time":"05-10 14:28:33","isfriend":0},{"uid":1004471,"name":"天地狼尊","url":"http://thirdapp0.qlogo.cn/qzopenapp/cd1e3e8458dc491bbecb7719de7085d54e0498a17b16166463d0f8ab072d8015/50","lotteryMoney":552590,"type":9,"card1":776,"card2":264,"card3":520,"card4":1032,"card5":778,"time":"05-10 14:12:51","isfriend":0},{"uid":2178867,"name":"B，so","url":"http://thirdapp3.qlogo.cn/qzopenapp/0a3b931d6b2d6e4901832ae10a4e07cc0ac8ce6796e57a21f0acf188365eb81d/50","lotteryMoney":604570,"type":9,"card1":1030,"card2":262,"card3":774,"card4":518,"card5":1038,"time":"05-10 14:11:31","isfriend":0},{"uid":1004471,"name":"天地狼尊","url":"http://thirdapp0.qlogo.cn/qzopenapp/cd1e3e8458dc491bbecb7719de7085d54e0498a17b16166463d0f8ab072d8015/50","lotteryMoney":1822350,"type":10,"card1":781,"card2":780,"card3":779,"card4":778,"card5":777,"time":"05-10 13:46:49","isfriend":0},{"uid":1082491,"name":"乔丹不再飞","url":"http://thirdapp2.qlogo.cn/qzopenapp/8742d6cd742bfcfb7e89b60549d53e7d6ca9a03195167e356536d0aad3d28f90/50","lotteryMoney":2227590,"type":10,"card1":518,"card2":517,"card3":516,"card4":515,"card5":514,"time":"05-10 13:36:07","isfriend":0},{"uid":1262438,"name":"§啪嚓/yx","url":"http://thirdapp1.qlogo.cn/qzopenapp/d597256039151b481c4b7074eddb04717fb8f296e634244fc2c740229c19f308/50","lotteryMoney":708240,"type":9,"card1":517,"card2":773,"card3":1029,"card4":261,"card5":777,"time":"05-10 13:27:30","isfriend":0},{"uid":1824167,"name":"雾里看花","url":"http://thirdapp3.qlogo.cn/qzopenapp/1e1e6e6274bbe95b79416c17d059330d230c0d73aa4751c4d32c9d5bcf5d976a/50","lotteryMoney":717960,"type":9,"card1":261,"card2":773,"card3":1029,"card4":517,"card5":780,"time":"05-10 13:22:48","isfriend":0},{"uid":2205767,"name":"上帝的筆誤  ","url":"http://thirdapp3.qlogo.cn/qzopenapp/95dac2d0238d3f7bdc7c73ac69736062df331df9a7519842a320647d5959269f/50","lotteryMoney":398690,"type":9,"card1":772,"card2":260,"card3":516,"card4":1028,"card5":1035,"time":"05-10 13:22:46","isfriend":0},{"uid":562393,"name":"命里♉有时","url":"http://thirdapp2.qlogo.cn/qzopenapp/d8219673598dbd6f59cb73853c478aef0255b18c3698a6485e5ba68912586246/50","lotteryMoney":398690,"type":9,"card1":772,"card2":260,"card3":516,"card4":1028,"card5":526,"time":"05-10 13:22:46","isfriend":0},{"uid":648478,"name":"晓薇","url":"http://pyapp.qlogo.cn/campus/04b2b6be4f758ddb1fa38a25dd90719594277290fa2a4c3eb4966054fc6f62991c44693180d09aa2/50","lotteryMoney":805800,"type":9,"card1":516,"card2":772,"card3":1028,"card4":260,"card5":1035,"time":"05-10 13:17:08","isfriend":0},{"uid":1188541,"name":"青春～血色青春","url":"http://thirdapp0.qlogo.cn/qzopenapp/c3c8a59edd4f35dc069e3113caca06be4c225dd83df206911c6f38880de76119/50","lotteryMoney":669740,"type":9,"card1":515,"card2":771,"card3":1027,"card4":259,"card5":1034,"time":"05-10 12:58:38","isfriend":0},{"uid":1188541,"name":"青春～血色青春","url":"http://thirdapp0.qlogo.cn/qzopenapp/c3c8a59edd4f35dc069e3113caca06be4c225dd83df206911c6f38880de76119/50","lotteryMoney":555360,"type":9,"card1":1032,"card2":520,"card3":776,"card4":264,"card5":261,"time":"05-10 12:35:59","isfriend":0},{"uid":374262,"name":"︶ㄣ泛滥丶小青春︶ㄣ","url":"http://thirdapp1.qlogo.cn/qzopenapp/f804ebf18ceb24ca46c8da8f55d40b5cb2b556791dcb4f86da2f58b3171d90f5/50","lotteryMoney":597520,"type":9,"card1":262,"card2":774,"card3":1030,"card4":518,"card5":1034,"time":"05-10 12:32:56","isfriend":0},{"uid":337268,"name":"潇洒人生","url":"http://thirdapp3.qlogo.cn/qzopenapp/4296d9220a80af680067bd9bcca73735a8ebcdcf751adcf78f1ae26b4a9c7c34/50","lotteryMoney":612540,"type":9,"card1":260,"card2":772,"card3":516,"card4":1028,"card5":267,"time":"05-10 12:24:45","isfriend":0},{"uid":2198212,"name":"赵雨馨","url":"http://app.qlogo.cn/mbloghead/c39c2ec74715a57f0fee/50","lotteryMoney":574650,"type":9,"card1":1038,"card2":782,"card3":270,"card4":526,"card5":781,"time":"05-10 12:06:19","isfriend":0},{"uid":203575,"name":"Bruce","url":"http://thirdapp1.qlogo.cn/qzopenapp/7f7c2417913f508dd71b918546a939e6404c2df2e48317ed03f3359726cf175a/50","lotteryMoney":6557520,"type":11,"card1":270,"card2":269,"card3":268,"card4":267,"card5":266,"time":"05-10 09:37:01","isfriend":0},{"uid":1093458,"name":"/aiq天使的翅膀","url":"http://thirdapp1.qlogo.cn/qzopenapp/6d1ceeafb83651e067f32243bc37200965b767f096fc586f4a64f7b7c41cd41d/50","lotteryMoney":635040,"type":9,"card1":259,"card2":771,"card3":1027,"card4":515,"card5":1038,"time":"05-10 08:25:48","isfriend":0},{"uid":675796,"name":"财神爷","url":"http://thirdapp2.qlogo.cn/qzopenapp/884461b98a364a9169913afae308b11c6e3392a12083908630fefcdf32aaa90e/50","lotteryMoney":448360,"type":9,"card1":262,"card2":518,"card3":774,"card4":1030,"card5":267,"time":"05-10 06:50:52","isfriend":0},{"uid":187823,"name":"慕诗扬","url":"http://thirdapp3.qlogo.cn/qzopenapp/9a39e278ce662d46594ea5915a36251080cfa851efe9be4b24694d0ba484ff25/50","lotteryMoney":1862610,"type":10,"card1":1037,"card2":1036,"card3":1035,"card4":1034,"card5":1033,"time":"05-10 06:44:00","isfriend":0},{"uid":1093458,"name":"/aiq天使的翅膀","url":"http://thirdapp1.qlogo.cn/qzopenapp/6d1ceeafb83651e067f32243bc37200965b767f096fc586f4a64f7b7c41cd41d/50","lotteryMoney":561860,"type":9,"card1":1037,"card2":269,"card3":525,"card4":781,"card5":1035,"time":"05-10 06:14:53","isfriend":0},{"uid":799025,"name":"超","url":"http://thirdapp0.qlogo.cn/qzopenapp/86f59fd231035bc1302aee9575f67c0ac2fb7375cbf61540/50","lotteryMoney":532920,"type":9,"card1":770,"card2":514,"card3":258,"card4":1026,"card5":1037,"time":"05-10 05:47:38","isfriend":0},{"uid":1144525,"name":" JRx","url":"http://thirdapp1.qlogo.cn/qzopenapp/d8219673598dbd6f84d1378c63c1d2c702f1886cba409d37a772df024f2fc252/50","lotteryMoney":1844400,"type":10,"card1":1034,"card2":1033,"card3":1032,"card4":1031,"card5":1030,"time":"05-10 05:16:07","isfriend":0},{"uid":1270356,"name":"随缘","url":"http://thirdapp3.qlogo.cn/qzopenapp/a4ab68dc9934f2da3432d4732e50aa9d5bc9ced03c7218aeadd290c3cefe6905/50","lotteryMoney":2595780,"type":10,"card1":1030,"card2":1029,"card3":1028,"card4":1027,"card5":1026,"time":"05-10 05:14:38","isfriend":0},{"uid":288534,"name":"林宝坚尼","url":"http://app.qlogo.cn/mbloghead/1b81ad268d483e4e51f8/50","lotteryMoney":3169320,"type":10,"card1":1037,"card2":1036,"card3":1035,"card4":1034,"card5":1033,"time":"05-10 05:02:19","isfriend":0},{"uid":1270356,"name":"随缘","url":"http://thirdapp3.qlogo.cn/qzopenapp/a4ab68dc9934f2da3432d4732e50aa9d5bc9ced03c7218aeadd290c3cefe6905/50","lotteryMoney":1149650,"type":9,"card1":519,"card2":263,"card3":775,"card4":1031,"card5":1038,"time":"05-10 05:00:55","isfriend":0},{"uid":675796,"name":"财神爷","url":"http://thirdapp2.qlogo.cn/qzopenapp/884461b98a364a9169913afae308b11c6e3392a12083908630fefcdf32aaa90e/50","lotteryMoney":512770,"type":9,"card1":520,"card2":264,"card3":1032,"card4":776,"card5":523,"time":"05-10 03:31:09","isfriend":0},{"uid":530080,"name":"欧阳一心","url":"http://app.qlogo.cn/mbloghead/884ea993f0a5cb534d3e/50","lotteryMoney":398730,"type":9,"card1":1036,"card2":524,"card3":268,"card4":780,"card5":267,"time":"05-10 03:01:34","isfriend":0},{"uid":960832,"name":"@強￥者@","url":"http://thirdapp3.qlogo.cn/qzopenapp/a3ebefa77eb0c321d608f8a2da4ee636feae73bafe39c09bf4d96fe9e408f34b/50","lotteryMoney":441080,"type":9,"card1":268,"card2":524,"card3":780,"card4":1036,"card5":1033,"time":"05-10 03:01:19","isfriend":0},{"uid":1146415,"name":"澔","url":"http://thirdapp1.qlogo.cn/qzopenapp/d8219673598dbd6fc8e5f09dc440afdd68af433553feba245e7d61ec9fa25b69/50","lotteryMoney":323520,"type":9,"card1":258,"card2":514,"card3":1026,"card4":770,"card5":524,"time":"05-10 02:32:02","isfriend":0},{"uid":1517104,"name":"                      ¨","url":"http://thirdapp2.qlogo.cn/qzopenapp/30eb7b4d48340a14ec7d55304c9af65fe194c365d19f2e42c8c83d3e6c35ad8b/50","lotteryMoney":333160,"type":9,"card1":780,"card2":524,"card3":1036,"card4":268,"card5":774,"time":"05-10 02:26:24","isfriend":0},{"uid":2197237,"name":"┈煙炏╋┈","url":"http://thirdapp1.qlogo.cn/qzopenapp/02421c7a7300de7869c2c94c5023a5c3c2703be63a4c16448c87d727cf2f64a3/50","lotteryMoney":341740,"type":9,"card1":516,"card2":772,"card3":1028,"card4":260,"card5":1035,"time":"05-10 02:20:22","isfriend":0},{"uid":416844,"name":"‘箐蝽’赌明天","url":"http://thirdapp3.qlogo.cn/qzopenapp/27a87a80731bf0f8b376f52c5edb9cae30fa69ca89183c36c43990b1e01a1955/50","lotteryMoney":289050,"type":9,"card1":523,"card2":267,"card3":779,"card4":1035,"card5":778,"time":"05-10 01:53:54","isfriend":0},{"uid":1085859,"name":"给力芬","url":"http://thirdapp3.qlogo.cn/qzopenapp/df1df8bf63acb983443474aa2ee41ac7c08fc928318e6c690edaac41fa1532a4/50","lotteryMoney":278150,"type":9,"card1":1031,"card2":775,"card3":263,"card4":519,"card5":526,"time":"05-10 01:44:16","isfriend":0},{"uid":2271949,"name":"天之翼","url":"http://thirdapp0.qlogo.cn/qzopenapp/d8219673598dbd6fc50c881735b09369b3f4c49d69f0ad612e2e71e1680933e6/50","lotteryMoney":273330,"type":9,"card1":516,"card2":772,"card3":1028,"card4":260,"card5":1038,"time":"05-10 01:37:39","isfriend":0},{"uid":1146415,"name":"澔","url":"http://thirdapp1.qlogo.cn/qzopenapp/d8219673598dbd6fc8e5f09dc440afdd68af433553feba245e7d61ec9fa25b69/50","lotteryMoney":1118640,"type":10,"card1":780,"card2":779,"card3":778,"card4":777,"card5":776,"time":"05-10 01:34:41","isfriend":0},{"uid":100027207,"name":"王晨","url":"http://hdn.xnimg.cn/photos/hdn221/20130301/0105/tiny_sYoM_18ed00004fd9113e.jpg","lotteryMoney":319560,"type":9,"card1":1038,"card2":782,"card3":526,"card4":270,"card5":523,"time":"05-10 01:14:28","isfriend":0},{"uid":977928,"name":"德州扑克专业版甲骨文","url":"http://thirdapp0.qlogo.cn/qzopenapp/d8219673598dbd6f991cfa9302a53966e79e76c39ab68c52c5fb8a7637b5016d/50","lotteryMoney":6267520,"type":11,"card1":1038,"card2":1037,"card3":1036,"card4":1035,"card5":1034,"time":"05-10 00:39:05","isfriend":0},{"uid":1587514,"name":"刀仔","url":"http://thirdapp0.qlogo.cn/qzopenapp/e2de77820af75cb1f734a2fc280a566461ed930def30d4b282bb2fb319769fa7/50","lotteryMoney":546400,"type":9,"card1":518,"card2":774,"card3":262,"card4":1030,"card5":522,"time":"05-10 00:10:42","isfriend":0},{"uid":1401810,"name":"td","url":"http://thirdapp0.qlogo.cn/qzopenapp/27a87a80731bf0f8760e9957287b139ecd7c49c147bc1a6bc016fe5c86332db5/50","lotteryMoney":523740,"type":9,"card1":270,"card2":526,"card3":1038,"card4":782,"card5":268,"time":"05-10 00:02:05","isfriend":0},{"uid":1587514,"name":"刀仔","url":"http://thirdapp0.qlogo.cn/qzopenapp/e2de77820af75cb1f734a2fc280a566461ed930def30d4b282bb2fb319769fa7/50","lotteryMoney":542470,"type":9,"card1":261,"card2":773,"card3":1029,"card4":517,"card5":1038,"time":"05-09 23:57:58","isfriend":0}]}';

	if(value == "") then
		TopTipKit.badNetworkHandler();
		return;
	end
	local js = {};
	local flag = pcall(function()
		js = json.decode(value);
	end);
	if(not flag) then
		TopTipKit.badNetworkHandler();
		return;
	end

	if(js.ret ~= 1) then
		TopTipKit.badNetworkHandler();
		return;
	end

	Model.setData(ModelKeys.LOTTO_REWARD_LIST, js.rewardUids);
end

LottoRewardList.initialize = function(self)
	LottoRewardItemRender.init(self.m_sWidth, 88);
			
	self.m_list = new(ScrollView2, 0, 0, self.m_sWidth, self.m_sHeight, true);
	self:addChild(self.m_list);

	self.m_loadingContainer = new(Node);
	self.m_loadingContainer:setSize(self.m_sWidth, self.m_sHeight);
	self:addChild(self.m_loadingContainer);
end

LottoRewardList.newRewardList = function(self, value)
	if(value ~= nil) then
--		local data = {};
--		for i=1,#value do
--			local vo = new(SuperLottoVO);
--			vo:parse(value[i]);
--			data[i] = vo;
--		end
--		--刷新scrollview
--		self.m_list:removeAllChildren();
--		for i=1,#data do
--			local item = new(LottoRewardItemRender);
--			item:setData(data[i]);
--			self.m_list:addChild(item);
--		end
		--刷新scrollview
		self.m_list:removeAllChildren();
		self.m_list:setPickable(false);
		self.m_rewardList = value;
		self.m_idxList = 1;
		Scheduler.getInstance():scheduleUpdate(self, self.__frame);
	end
end

LottoRewardList.__frame = function(self)
	if(self.m_idxList > #self.m_rewardList) then
		self:__endLoading();
		self.m_list:setPickable(true);
		return;
	end
	local vo = new(SuperLottoVO);
	vo:parse(self.m_rewardList[self.m_idxList]);
	local item = new(LottoRewardItemRender);
	item:setData(vo);
	self.m_list:addChild(item);
	self.m_idxList = self.m_idxList + 1;
end

LottoRewardList.resetPosition = function(self)
	if(self.m_list) then
		self.m_list:gotoTop();
	end
end
