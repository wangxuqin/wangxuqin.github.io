-----------------------------------------------------------
--
require("view/common/layout_store");

StoreDialog = class(PopupDialog, false);

--若打开商城时需要确定子页面，则调用setSubPage(value:String)函数
--各个页面对应参数如下
StoreDialog.STORE_POP_UP_CHIPS_PAGE         = "STORE_POP_UP_CHIPS_PAGE";
StoreDialog.STORE_POP_UP_BY_PAGE            = "STORE_POP_UP_BY_PAGE";
StoreDialog.STORE_POP_UP_PROPS_PAGE         = "STORE_POP_UP_PROPS_PAGE";
StoreDialog.STORE_POP_UP_VIP_PAGE           = "STORE_POP_UP_VIP_PAGE";
StoreDialog.STORE_POP_UP_OWNER_PROPS_PAGE   = "STORE_POP_UP_OWNER_PROPS_PAGE";
StoreDialog.STORE_POP_UP_BUY_HISTORY_PAGE   = "STORE_POP_UP_BUY_HISTORY_PAGE";

StoreDialog.ctor = function(self)
    super(self, layout_store, true);
    --标题
    local title = self.m_root:getNodeByName("bg.title");
    if(title) then
        title:setText(STR_STORE_STORE_POP_UP_TITLE);
    end
    --用户金币
    local tx = self.m_root:getNodeByName("bg.mask.Image1.Image2.user_chip");
    if(tx) then
        tx:setText("22222");
    end
    --加入左边的tab
    local mask = self.m_root:getNodeByName("bg.mask");
    local cxMask, cyMask = mask:getSize();
    local countTab = 0;
    --商品类别子项
    local tab = new(ButtonTag);
    local textTable = {};
    for i=1,#STR_STORE_PRODUCT_CATEGORY_ITEM do
        textTable[#textTable+1] = STR_STORE_PRODUCT_CATEGORY_ITEM[i];
        countTab = countTab + 1;
    end
    --账户管理子项
    for i=1,#STR_STORE_ACCOUNT_MANAGE_ITEM do
        textTable[#textTable+1] = STR_STORE_ACCOUNT_MANAGE_ITEM[i];
        countTab = countTab + 1;
    end
    --textTable, bgImgFilePath, buttonFilePath1, buttonFilePath2, sizeX, sizeY,leftWidthBg, rightWidthBg, topWidthBg, bottomWidthBg,
    --                                        leftWidthBtn, rightWidthBtn, topWidthBtn, bottomWidthBtn
    tab:setButtonTagVerticalMul(textTable, "store/page_pop_up_tab_bg.png", "store/page_pop_up_tab_group_vernier.png", "store/page_pop_up_tab_group_vernier.png",
                                230, 366, 10,10,16,16, 12,12,4,29, true);
    tab:setLevel(100);
    local btnSlider = tab:getButtonSlider();
    btnSlider:setPos(-6);
    btnSlider:setSize(250);
    tab:setPos(0, 47);
    local item = tab:getImageBgVertical(5);
    item:setPos(0, 285);
    local item = tab:getImageBgVertical(6);
    item:setPos(0, 346);
    mask:addChild(tab);
    --插入各个页面(scrollview)
    for i=1,countTab do
        local view = tab:getView(i);
        mask:addChild(view);
        local scroll = new(ScrollView2, 230, 0, cxMask-230, cyMask, true);
        view:addChild(scroll);
        --test
--        for j=1,30 do
--            local text = new(Text, string.format("tab%02d,item%02d", i, j));
--            scroll:addChild(text);
--        end
    end
end

StoreDialog.onPopupEnd = function(self)
    --添加事件响应
    local closeBtn = self.m_root:getNodeByName("bg.btn_close");
    if(closeBtn) then
        closeBtn:setOnClick(self, self.onClickClose);
    end
end

StoreDialog.onClickClose = function(self)
    self:close();
end
