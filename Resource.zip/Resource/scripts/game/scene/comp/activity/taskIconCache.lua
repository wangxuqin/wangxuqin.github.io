TaskIconCache = {};

TaskIconCache.getInstance = function()
    if not TaskIconCache.s_instance then
	    TaskIconCache.s_instance = new(TaskIconCache.m_class);
    end
    return TaskIconCache.s_instance;
end

TaskIconCache.releaseInstance = function()
    delete(TaskIconCache.s_instance);
    TaskIconCache.s_instance = nil;
end


TaskIconCache.ctor = function(self)
	self.m_caches = {};
end
		
TaskIconCache.addIcon = function(self, taskVO, container, imageWidth, imageHeight)
	local key = self:getKey(taskVO.id);
	if self.m_caches[key] then
		local url = self:getIconUrl(taskVO);
		local img = new(UrlImage,defaultFile,url,nil,1);
		img:setSize(imageWidth, imageHeight);
        img:setAlign(kAlignCenter);
		container.addChild(img);
	else
	    local url = self:getIconUrl();
        local img = new(UrlImage,defaultFile,url,nil,1);
        img:setCallback(nil, function()
            self.m_caches[key] = true;
            container:addChild(img);
        end);
    end
}
				
TaskIconCache.getKey = function(self, id)
	return "task-icon-" + id;
end

TaskIconCache.getIconUrl = function(self, taskVO)
    local userData = Model.getData(ModelKeys.USER_DATA);
    local iconUrl = nil;
    if iconUrl ~= nil then
        iconUrl = userData.CNDURL .. "images/mobileTask/"..(taskVO.iconUrl ~= nil and taskVO.iconUrl or taskVO.id);
        if string.find(iconUrl,".png") == nil and string.find(iconUrl,".jpg") == nil then
		    iconUrl = iconUrl..".png";
	    end
    end
    return iconUrl;
end