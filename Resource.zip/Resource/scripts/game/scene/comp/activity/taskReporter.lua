TaskReporter = {};
TaskReporter.TAG = "TaskReporter";

TaskReporter.getInstance = function()
    if not TaskReporter.s_instance then
	    TaskReporter.s_instance = new(TaskReporter);
    end
    return TaskReporter.s_instance;
end

TaskReporter.releaseInstance = function()
    delete(TaskReporter.s_instance);
    TaskReporter.s_instance = nil;
end

TaskReporter.ctor = function(self) 
	self.m_currentPayCount          = 0.0;	    --当前充值数额
	self.m_currentPokerCount        = 0;		--当前玩牌次数
	self.m_dollCurrentPokerCount    = 0;        --玩偶收集玩牌次数
	self.m_currentWinCount          = 0;		--当前获胜次数
	self.m_twoWinningStreak         = 0;		--当前2连胜次数
	self.m_threeWinningStreak       = 0;	    --当前3连胜次数
	self.m_seniorWinCount           = 0;		--高级场胜利次数
	self.m_middleWinCount           = 0;		--中级场胜利次数
	self.m_roundWinChips            = 0;		--某局赢取筹码 
	self.m_usePropCount             = 0;		--使用互动道具次数 
	self.m_sendTableGifts           = 0;		--赠送牌桌礼物次数 
	self.m_enterIntoKnockout        = 0;		--参加单桌淘汰赛次数
	self.m_winKnockout              = 0;		--参加单桌淘汰赛夺冠次数
	self.m_enterIntoTournament      = 0;	    --参加多桌锦标赛次数
	self.m_currentBoxCount          = 0;		--开启宝箱次数
	self.m_useSmallLabasCount       = 0;		--使用小喇叭次数
	self.m_superLottoCount          = 0;		--参加夺金岛次数
	self.m_inviteFriendsCount       = 0;		--邀请好友次数
	self.m_sharesCount              = 0;		--分享次数
	self.m_levelNum                 = 0;        --等级
		
	--春节活动牌局统计
	self.m_newYearPrimaryPokerCount = 0;	    --初级场
	self.m_newYearIntermediatePokerCount = 0;   --中级场
	self.m_newYearSeniorPokerCount  = 0;		--高级场
		
	self.m_allTaskV                 = {};
	self.m_roomTaskV                = {};
	self.m_paysTask                 = {};
	self.m_winsTask                 = {};       --赢牌任务
	self.m_twoWinningStreakTask     = {};       --两连胜任务
	self.m_threeWinningStreakTask   = {};       --三连胜任务
	self.m_pokersTask               = {};       --打牌任务
	self.m_roundWinChipsTask        = {};       --赢钱任务
	self.m_middleWinsTask           = {};       --中级场赢牌任务
	self.m_seniorWinsTask           = {};       --高级场赢牌任务
	self.m_giftsTask                = {};       --牌桌送礼任务
	self.m_usePropsTask             = {};       --使用互动道具任务
	self.m_joinKnockoutsTask        = {};       --参加淘汰赛任务
	self.m_joinTournamentsTask      = {};       --参加锦标赛任务
	self.m_winKnockoutsTask         = {};       --赢取淘汰赛任务
	self.m_boxsTask                 = {};       --开宝箱任务
	self.m_useSmallLabasTask        = {};       --使用小喇叭任务
	self.m_superLottosTask          = {};       --夺金岛任务
	self.m_invitesTask              = {};       --邀请任务
	self.m_sharesTask               = {};       --分享任务
	self.m_upgrateLevelTask         = {};       --升级奖励任务
		
	self.m_winningStreak1           = 0;        -- 用于统计连胜
	self.m_winningStreak2           = 0;        -- 用于统计连胜
	self.m_winningStreak3           = 0;        -- 用于一分钟刷分上报
	self.m_winningStreak4           = 0;        -- 用于十连胜刷分上报
	self.m_winningStreak5           = 0;        -- 用于统计五连胜
	self.m_winningStreak6           = 0;        -- 用于统计七连胜
	self.m_currentTime              = 0;
		
	self.m_reGetTimes               = 0;
	self.m_isLoggedIn               = false;
	self.m_finishTask               = 0;
		
	self.m_taskButton               = nil;
	self.m_taskItem                 = nil;
    
	self.m_currentUid               = "";       --当前用户id
	self.m_usedUids                 = {};
end

TaskReporter.initialize = function(self)
	local oldDateString = CookieService.getString(CookieKeys.REPORTER_RECORD_DATE, "");
	local dateString = tostring( os.time() );

	if oldDateString ~= dateString then
		local usedUidsString = CookieService.getString(CookieKeys.REPORTER_USED_UIDS, nil);
		if usedUidsString ~= nil then
			local usedUidsList = StringKit.split(usedUidsString, ",");
			for i = 1, #usedUidsList do
                local uid = usedUidsList[i];
				CookieService.clearProperty(CookieKeys.REPORTER_CURRENT_PAY_COUNT     .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_CURRENT_POKER_COUNT   .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_CURRENT_WIN_COUNT     .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_TWO_WINNING_STREAK    .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_THREE_WINNING_STREAK  .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_MIDDLE_WIN_COUNT      .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_SENIOR_WIN_COUNT      .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_ROUND_WIN_CHIPS       .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_USE_PROP_COUNT        .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_SEND_TABLE_GIFTS      .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_ENTER_INTO_KNOCKOUT   .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_ENTER_INTO_TOURNAMENT .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_WIN_KNOCKOUT          .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_OPEN_BOX              .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_SMALL_LABA            .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_SUPER_LOTTO           .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_INVITE_FRIEND         .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_SHARES_COUNT          .. uid);
				CookieService.clearProperty(CookieKeys.REPORTER_LEVEL_COUNT           .. uid);
						
				-- OG相关
				CookieService.clearProperty(CookieKeys.SENDED_MASTER_OG               .. uid);
				CookieService.clearProperty(CookieKeys.SENDED_SLOT_OG                 .. uid);
				CookieService.clearProperty(CookieKeys.SENDED_TOURNAMENT_OG           .. uid);
			end
			CookieService.clearProperty(CookieKeys.REPORTER_USED_UIDS);
		end
				
		self.m_usedUids = {};
		CookieService.setString(CookieKeys.REPORTER_RECORD_DATE, dateString);
	else
		local usedUidsStr = CookieService.getString(CookieKeys.REPORTER_USED_UIDS, "");
        self.m_usedUids = {};
        if usedUidsStr ~= nil then
		    self.m_usedUids = StringKit.split(usedUidsStr, ",");
        end
	end
			
	Model.watchData(ModelKeys.CURRENRT_FINISHED_TASK, self, self.onFinishedTask, false);
end

TaskReporter.getFinishedTask = function(self)
	return Model.getData(ModelKeys.CURRENRT_FINISHED_TASK);
end
			
TaskReporter.onFinishedTask = function(self, num)
    if num >= 1 then
		if self.m_taskButton ~= nil then
			self.m_taskButton:startGlow();
        end
		if self.m_taskItem ~= nil then
			self.m_taskItem:setItemTips( tostring(num) );
		end
	else
		if self.m_taskButton ~= nil then
			self.m_taskButton:stopGlow();
        end
		if self.m_taskItem ~= nil then
			self.m_taskItem:setItemTips("");
		end
	end
end
		
TaskReporter.userLoggedIn = function(self)
    local userData = Model.getData(ModelKeys.USER_DATA);
	self.m_currentUid = userData ~= nil and userData.uid or "";
	
    if ArrayKit.indexOf(self.m_usedUids, self.m_currentUid) == -1 then
		table.insert(self.m_usedUids, self.m_currentUid);
		local usedUidsStr = StringKit.join(self.m_usedUids, ",");
		CookieService.setString(CookieKeys.REPORTER_USED_UIDS, usedUidsStr);
	end
			
	self.m_currentPayCount        = CookieService.getNumber(CookieKeys.REPORTER_CURRENT_PAY_COUNT                   .. self.m_currentUid);
	self.m_currentPokerCount      = CookieService.getInteger(CookieKeys.REPORTER_CURRENT_POKER_COUNT                .. self.m_currentUid);
	self.m_dollCurrentPokerCount  = CookieService.getInteger(CookieKeys.DOLL_COLLECT_REPORTER_CURRENT_POKER_COUNT   .. self.m_currentUid);
	self.m_currentWinCount        = CookieService.getInteger(CookieKeys.REPORTER_CURRENT_WIN_COUNT                  .. self.m_currentUid);
	self.m_twoWinningStreak       = CookieService.getInteger(CookieKeys.REPORTER_TWO_WINNING_STREAK                 .. self.m_currentUid);
	self.m_threeWinningStreak     = CookieService.getInteger(CookieKeys.REPORTER_THREE_WINNING_STREAK               .. self.m_currentUid);
	self.m_middleWinCount         = CookieService.getInteger(CookieKeys.REPORTER_MIDDLE_WIN_COUNT                   .. self.m_currentUid);
	self.m_seniorWinCount         = CookieService.getInteger(CookieKeys.REPORTER_SENIOR_WIN_COUNT                   .. self.m_currentUid);
	self.m_roundWinChips          = CookieService.getNumber(CookieKeys.REPORTER_ROUND_WIN_CHIPS                     .. self.m_currentUid);
	self.m_usePropCount           = CookieService.getInteger(CookieKeys.REPORTER_USE_PROP_COUNT                     .. self.m_currentUid);
	self.m_sendTableGifts         = CookieService.getInteger(CookieKeys.REPORTER_SEND_TABLE_GIFTS                   .. self.m_currentUid);
	self.m_enterIntoKnockout      = CookieService.getInteger(CookieKeys.REPORTER_ENTER_INTO_KNOCKOUT                .. self.m_currentUid);
	self.m_enterIntoTournament    = CookieService.getInteger(CookieKeys.REPORTER_ENTER_INTO_TOURNAMENT              .. self.m_currentUid);
	self.m_winKnockout            = CookieService.getInteger(CookieKeys.REPORTER_WIN_KNOCKOUT                       .. self.m_currentUid);
	self.m_currentBoxCount        = CookieService.getInteger(CookieKeys.REPORTER_OPEN_BOX                           .. self.m_currentUid);
	self.m_useSmallLabasCount     = CookieService.getInteger(CookieKeys.REPORTER_SMALL_LABA                         .. self.m_currentUid);
	self.m_superLottoCount        = CookieService.getInteger(CookieKeys.REPORTER_SUPER_LOTTO                        .. self.m_currentUid);
	self.m_inviteFriendsCount     = CookieService.getInteger(CookieKeys.REPORTER_INVITE_FRIEND                      .. self.m_currentUid);
	self.m_sharesCount            = CookieService.getInteger(CookieKeys.REPORTER_SHARES_COUNT                       .. self.m_currentUid);
	self.m_levelNum               = CookieService.getInteger(CookieKeys.REPORTER_LEVEL_COUNT                        .. self.m_currentUid);
			
	self.m_newYearPrimaryPokerCount         = CookieService.getInteger(CookieKeys.NEW_YEAR_PRIMARY_ROOM_COUNTS      .. self.m_currentUid);
	self.m_newYearIntermediatePokerCount    = CookieService.getInteger(CookieKeys.NEW_YEAR_INTERMEDIATE_ROOM_COUNTS .. self.m_currentUid);
	self.m_newYearSeniorPokerCount          = CookieService.getInteger(CookieKeys.NEW_YEAR_SENIOR_ROOM_COUNTS       .. self.m_currentUid);
			
	self.m_finishTask = 0;
	self.m_reGetTimes = 5;
	self:getTaskListAll();
end
		
TaskReporter.getTaskListAll = function(self)
	HttpService.post({
    ["mod"] = "taskNew", ["act"] = "list"}, self, self.getTaskListCallback, self.getTaskListTryAgain, self.getTaskListTryAgain);
end
		
TaskReporter.getTaskListTryAgain = function(self)
	if self.m_reGetTimes > 0 then
		HttpService.post({
        ["mod"] = "taskNew", ["act"] = "list"}, self, self.getTaskListCallback, self.getTaskListTryAgain, self.getTaskListTryAgain);
	end
end
		
TaskReporter.getTaskListCallback = function(self, data)
	local userData = Model.getData(ModelKeys.USER_DATA);
    if data ~= nil then
        local flag, jsonObj = JsonKit.decode(data);
		if flag then
			local list = {};
			if jsonObj.ret == 0 and jsonObj.list ~= nil then
				list = jsonObj.list;
			    self.m_allTaskV = {};
			    self.m_roomTaskV = {};
			    
                if list.pays ~= nil then
				    self.m_paysTask = new(TaskVO);
				    self:parseData(self.m_paysTask, list.pays, self.m_currentPayCount);
			    end
			
                if list.wins ~= nil then
				    self.m_winsTask = new(TaskVO);
				    self:parseData(self.m_winsTask, list.wins, self.m_currentWinCount);
			    end
			
                if list.twoWinningStreak ~= nil then
				    self.m_twoWinningStreakTask = new(TaskVO);
				    self:parseData(self.m_twoWinningStreakTask, list.twoWinningStreak, self.m_twoWinningStreak);
			    end
			    
                if list.threeWinningStreak ~= nil then
				    self.m_threeWinningStreakTask = new(TaskVO);
				    self:parseData(self.m_threeWinningStreakTask, list.threeWinningStreak, self.m_threeWinningStreak);
			    end

			    if list.pokers ~= nil then
				    self.m_pokersTask = new(TaskVO);
				    self:parseData(self.m_pokersTask, list.pokers, self.m_currentPokerCount);
			    end

			    if list.maxWinChips ~= nil then
				    self.m_roundWinChipsTask = new(TaskVO);
				    self:parseData(self.m_roundWinChipsTask, list.maxWinChips, self.m_roundWinChips);
			    end

			    if list.middleWins ~= nil then
				    self.m_middleWinsTask = new(TaskVO);
				    self:parseData(self.m_middleWinsTask, list.middleWins, self.m_middleWinCount);
			    end

			    if list.seniorWins ~= nil then
				    self.m_seniorWinsTask = new(TaskVO);
				    self:parseData(self.m_seniorWinsTask, list.seniorWins, self.m_seniorWinCount);
			    end

			    if list.gifts ~= nil then
				    self.m_giftsTask = new(TaskVO);
				    self:parseData(self.m_giftsTask, list.gifts, self.m_sendTableGifts);
			    end

			    if list.props ~= nil then
				    self.m_usePropsTask = new(TaskVO);
				    self:parseData(self.m_usePropsTask, list.props, self.m_usePropCount);
			    end

			    if list.matches ~= nil then
				    self.m_joinKnockoutsTask = new(TaskVO);
				    self:parseData(self.m_joinKnockoutsTask, list.matches, self.m_enterIntoKnockout);
			    end

			    if list.joinTournaments ~= nil then
				    self.m_joinTournamentsTask = new(TaskVO);
				    self:parseData(self.m_joinTournamentsTask, list.joinTournaments, self.m_enterIntoKnockout);
			    end

			    if list.winKnockouts ~= nil then
				    self.m_winKnockoutsTask = new(TaskVO);
				    self:parseData(self.m_winKnockoutsTask, list.winKnockouts, self.m_winKnockout);
			    end

			    if list.boxs ~= nil then
				    self.m_boxsTask = new(TaskVO);
				    self:parseData(self.m_boxsTask, list.boxs, self.m_currentBoxCount);
			    end

			    if list.speakers ~= nil then
				    self.m_useSmallLabasTask = new(TaskVO);
				    self:parseData(self.m_useSmallLabasTask, list.speakers, self.m_useSmallLabasCount);
			    end

			    if list.lottos ~= nil then
				    self.m_superLottosTask = new(TaskVO);
				    self:parseData(self.m_superLottosTask, list.lottos, self.m_superLottoCount);
			    end

			    if list.invites ~= nil then
				    self.m_invitesTask = new(TaskVO);
				    self:parseData(self.m_invitesTask, list.invites, self.m_inviteFriendsCount);
			    end

			    if list.shares ~= nil then
				    self.m_sharesTask = new(TaskVO);
				    self:parseData(self.m_sharesTask, list.shares, self.m_sharesCount);
			    end

			    if list.levels ~= nil then
				    self.m_upgrateLevelTask = new(TaskVO);
				    self.m_upgrateLevelTask.isLevelTask = true;
				    self:parseData(self.m_upgrateLevelTask, list.levels, userData.level, true);
			    end
					
			    Model.setData(ModelKeys.CURRENRT_FINISHED_TASK, self.m_finishTask);
                self:__sort();
            end
		else
			self:getTaskListTryAgain();
		end
	else
		self:getTaskListTryAgain();
	end
end

TaskReporter.__sort = function(self)
    --排序
	local n = #self.m_allTaskV - 1;
	local i = 0;
	local temp = nil;
	while n > 0 do
		for i = 1, n do
			if TaskVO:compareStatus(self.m_allTaskV[i], self.m_allTaskV[i + 1]) then
				temp = self.m_allTaskV[i];
				self.m_allTaskV[i],self.m_allTaskV[i + 1] = self.m_allTaskV[i + 1], self.m_allTaskV[i];
			end
		end
        n = n - 1;
	end
	Model.setData(ModelKeys.ALL_TASK_LIST, self.m_allTaskV);

	n = #self.m_roomTaskV - 1;
	while n > 0 do
		for i = 1, n do
			if TaskVO:compareStatus(self.m_roomTaskV[i], self.m_roomTaskV[i + 1]) then
				self.m_roomTaskV[i], self.m_roomTaskV[i + 1] = self.m_roomTaskV[i + 1], self.m_roomTaskV[i];
			end
		end
        n = n - 1;
	end
    Model.setData(ModelKeys.ROOM_TASK_LIST, self.m_roomTaskV);
end
		
TaskReporter.parseData = function(self, taskVO, data, progress, isRoom)
    if isRoom == nil then
        isRoom = true;
    end
	taskVO:parse(data);
	taskVO.m_totalProgress = progress;
	if  taskVO.m_status == taskVO.STATUS_UNDER_WAY or taskVO.m_status == taskVO.STATUS_CAN_REWARD then
		if progress >= tonumber(taskVO.m_target) then
			self.m_finishTask   = self.m_finishTask + 1;
			taskVO.m_progress   = taskVO.m_target;
			taskVO.m_status     = taskVO.STATUS_CAN_REWARD;
		
        elseif taskVO.m_isLevelTask and taskVO.m_canGet then
			self.m_finishTask   = self.m_finishTask + 1;
			taskVO.m_status     = taskVO.STATUS_CAN_REWARD;
		else
			taskVO.m_progress   = progress;
		end
	end

	if taskVO.m_special ~= nil then
		Model.setData(ModelKeys.TASK_SPECIAL, taskVO);
	else
		table.insert(self.m_allTaskV, taskVO);
	end

	if isRoom then
		table.insert(self.m_roomTaskV, taskVO);
	end
end
		
TaskReporter.reportData = function(self, taskVO, reportValue)
	if taskVO ~= nil then
	    if taskVO.m_status == taskVO.STATUS_UNDER_WAY then
		    if reportValue >= taskVO.m_target then
			    Model.setData(ModelKeys.CURRENRT_FINISHED_TASK, finishedTask + 1);
			    taskVO.m_progress   = taskVO.m_target;
			    taskVO.m_status     = taskVO.STATUS_CAN_REWARD;
			    self:setTopTip(taskVO);
			    local index = ArrayKit.indexOf(self.m_allTaskV, taskVO);
			    if index ~= -1 then
				    self.m_allTaskV.splice(index, 1);
				    self.m_allTaskV.unshift(taskVO);
			    end
			    index = self.m_roomTaskV.indexOf(taskVO);
			    if index ~= -1 then
				    self.m_roomTaskV.splice(index, 1);
				    self.m_roomTaskV.unshift(taskVO);
			    end
		    else
			    taskVO.m_progress = reportValue;
		    end
	    end
    end
end
		
TaskReporter.dayPassed = function(self)
	local userData = Model.getData(ModelKeys.USER_DATA);
    self:initialize();
	if userData ~= nil then
		self:userLoggedIn();
	end
end
		
TaskReporter.setTopTip = function(self,taskVO)
    local param = {
        TextureConfig.m_orangeUpScale9Textures.texture,
        TextureConfig.m_orangeDownScale9Textures.texture,
        128,60,
        TextureConfig.m_orangeUpScale9Textures.gird9
    };
	local btn = new(DynamicHitAreaButton,unpack(param));
	btn:setLabel(STR_ACTIVITY_ACTIVITY_BTN_GET_REWARD);
    
    btn:setOnClick(nil, function()
	    local postData = {["mod"] = "taskNew", ["act"] = "reward", ["id"] = taskVO.m_id};
	    HttpService.post(postData, nil, function (_, data) 
		    local flag, jsonObj = JsonKit.decode(data);
		    if flag then
			    TopTipKit.badNetworkHandler();
                return;
		    end
			    
            if jsonObj.ret == 1 or jsonObj.ret == 0 then-- 领奖成功
				if tonumber(jsonObj.money) ~= nil then
					EventDispatcher.getInstance():dispatch(
                        UIEvent.s_event,
                        UIEvenet.s_cmd.GET_TASK_REWARD,
                        StringKit.substitute(STR_ACTIVITY_ACT_TASK_CHIP_REWARD, Formatter.formatNumberWithSplit(jsonObj.money)));
				end
				btn:removeFromParent(true);
			else
				TopTipKit.badNetworkHandler();
				return;
			end
						
			if jsonObj.task ~= nil and jsonObj.ret == 0 then-- 还有后续任务了
				taskVO:parse(jsonObj.task);
				if taskVO.m_totalProgress >= taskVO.m_target then
					Model.setData(ModelKeys.CURRENRT_FINISHED_TASK, self:getFinishedTask() + 1);
					taskVO.m_progress   = taskVO.m_target;
					taskVO.m_status     = taskVO.STATUS_CAN_REWARD;
					self:setTopTip(taskVO)
				else
					taskVO.m_progress   = taskVO.m_totalProgress;
					taskVO.m_status     = taskVO.STATUS_UNDER_WAY;
				end
			    
            elseif jsonObj.ret == 1 then  --没有后续任务了，任务链完成
				taskVO.m_status = taskVO.STATUS_FINISHED
				local index = ArrayKit.indexOf(self.m_allTaskV, taskVO);
				if index > -1 then
					self.m_allTaskV.splice(index, 1);
					local temp = self.m_allTaskV.pop();
					self.m_allTaskV.push(taskVO);
					self.m_allTaskV.push(temp);
				end
							
				index = self.m_roomTaskV:indexOf(taskVO);
				if index > -1 then
					self.m_roomTaskV.splice(index, 1);
					self.m_roomTaskV.push(taskVO);
				end
			end
			self:getTaskListAll();
        end);
			
	    local taskIcon = new(Node);
	    taskIcon.setOnClick(nil, function () 
		    taskIcon:setOnClick(nil, nil);
		    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, {
			    ["message"] =  StringKit.substitute(STR_ACTIVITY_ACT_TASK_COMPLETE, taskVO.m_name) .. taskVO.m_reward, 
			    ["image"] = taskIcon, 
			    ["button"] =  button
		    });
         end);
	    TaskIconCache.getInstance():addIcon(taskVO, taskIcon, 56, 56);
    end);
end

TaskReporter.reportGameOverByParam = function(self, param)
    self:reportGameOver(
        param.tableId, 
        param.roomType, 
        param.tableLevel, 
        param.roundCount, 
        param.winChip
    );
end
		
TaskReporter.reportGameOver = function(tableId, roomType, tableLevel, roundCount, winChip)
	if roomType ~= LoginSuccData.ROOM_TYPE_NORMAL and roomType ~= LoginSuccData.ROOM_TYPE_PROFESSIONAL then
		return;
	end
	
    if userData.dollOpen == 1 or userDatal.dollOpen == 2 then
		if self.m_dollCurrentPokerCount ~= 0 and MathKit.mod(self.m_dollCurrentPokerCount, 10) == 0 then
			HttpService.post({["mod"] = "doll",["act"] = "report"});
			self.m_dollCurrentPokerCount = 0;   
		end		
	end
	self.m_dollCurrentPokerCount = self.m_dollCurrentPokerCount + 1;		--更新玩牌局数 
			
	CookieService.setInteger(CookieKeys.DOLL_COLLECT_REPORTER_CURRENT_POKER_COUNT .. self.m_currentUid, self.m_dollCurrentPokerCount)

	self:setCurrentPokerCount(self:getCurrentPokerCount() + 1);
	if winChip > 0 then
        self.m_winningStreak1 = self.m_winningStreak1 + 1;
        self.m_winningStreak2 = self.m_winningStreak2 + 1;
		self:setCurrentWinCount(self:getCurrentWinCount() + 1);
		self:setRoundWinChips(winChip);
				
		if self.m_winningStreak3 == 0 then
			self.m_currentTime = os.time();
			self.m_winningStreak3 = self.m_winningStreak3 + 1;
		else
			if os.time() - self.m_currentTime > 60 * 1000 then
				self.m_winningStreak3 = 0;
			elseif self.m_winningStreak3 == 3 then
				-- 一分钟连赢四局，需上报
				self.m_winningStreak3 = 0;
				HttpService.post({
                    ["mod"]   = "tj", 
                    ["act"]   = "game", 
                    ["tid"]   = tableId, ["table"] = tableLevel, ["pid"]   = roundCount, ["type"]  = 1});
			else
				self.m_winningStreak3 = self.m_winningStreak3 + 1;
			end
		end
				
		self.m_winningStreak4 = self.m_winningStreak4 + 1;
		if self.m_winningStreak4 == 10 then
			-- 连赢十局，需上报
			self.m_winningStreak4 = 0;
			HttpService.post({
                ["mod"] = "tj", 
                ["act"] = "game", 
                ["tid"] = tableId, ["table"] = tableLevel, ["pid"] = roundCount, ["type"] = 2});
		end
        	
		self.m_winningStreak5 = self.m_winningStreak5 + 1;
		if self.m_winningStreak5 == 5 then
			self.m_winningStreak5 = 0;
			EventDipatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_FACEBOOK_SHARE, {
				["title"]       = StringKit.substitute(STR_SOCIAL_WINNING_STREAK_SHARE_TITLE, "5"), 
				["feedId"]      = "winningStreak", 
				["image"]       ="fiveWinningStreak", 
				["callBack"]    = function(data)
					data.message = StringKit.substitute(data.message, "5");
					data.picture = StringKit.substitute(data.picture, "fiveWinningStreak");
				end
			});
		end
				
		self.m_winningStreak6 = self.m_winningStreak6 + 1;
		if self.m_winningStreak6 == 7 then
			self.m_winningStreak6 = 0;
			EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.ROOM_FACEBOOK_SHARE, {
				["title"]   = StringKit.substitute(STR_SOCIAL_WINNING_STREAK_SHARE_TITLE, "7"), 
				["feedId"]  = "winningStreak", 
				["image"]   = "sevenWinningStreak", 
				["callBack"]= function(data)
					data.message = StringKit.substitute(data.message, "7");
					data.picture = StringKit.substitute(data.picture, "sevenWinningStreak");
				end
			});
		end
	else
		self.m_winningStreak1 = 0;
		self.m_winningStreak2 = 0;
		self.m_winningStreak3 = 0;
		self.m_winningStreak4 = 0;
		self.m_winningStreak5 = 0;
		self.m_winningStreak6 = 0;
	end
	self:reportWinningStreak();
			
	if winChip > 0 then
		if tableLevel == LoginSuccData.ROOM_LEVEL_INTERMEDIATE then
			self:setMiddleWinCount(self:getMiddleWinCount() + 1);

		elseif tableLevel == LoginSuccData.ROOM_LEVEL_SENIOR then
            self:setSeniorWinCount(self:getSeniorWinCount() + 1);
        end
	end
			
	-- 钻石大赢家统计钻石
	if userData.diamond == 1 then
		--DiamondManger.updateCurrDiamond();
        --从这里发送事件更新
	end
			
	--春节活动玩牌统计，初级场，中级场，高级场分开统计
	if tableLevel == LoginSuccData.ROOM_LEVEL_NEWER or --新手场
        tableLevel == LoginSuccData.ROOM_LEVEL_PRIMARY then --初级场
        self.m_newYearPrimaryPokerCount = self.m_newYearPrimaryPokerCount + 1;

	elseif tableLevel == LoginSuccData.ROOM_LEVEL_INTERMEDIATE then --中级场
        self.m_newYearIntermediatePokerCount = self.m_newYearIntermediatePokerCount + 1;

    elseif  tableLevel == LoginSuccData.ROOM_LEVEL_SENIOR then  --高级场
        self.m_newYearSeniorPokerCount = self.m_newYearSeniorPokerCount + 1;
	end

	--每打10局牌上报一次
	if self.m_newYearPrimaryPokerCount >= 10 then
		if userData["dollOpen"] == 3 then
			HttpService.post({["mod"] = "spring",["act"] = "report"},self, self.callBackFun, self.callBackFun, self.callBackFun);
		end
		self.m_newYearPrimaryPokerCount = 0;   
    end

	if self.m_newYearIntermediatePokerCount >= 10 then
		if userData["dollOpen"] == 3 then
			HttpService.post({["mod"] = "spring",["act"] = "report"},self, self.callBackFun, self.callBackFun, self.callBackFun);
		end
		self.m_newYearIntermediatePokerCount = 0; 
	end

	if self.m_newYearSeniorPokerCount >= 10 then
		if userData["dollOpen"] == 3 then
			HttpService.post({["mod"] = "spring",["act"] = "report"},self, self.callBackFun, self.callBackFun, self.callBackFun);
		end
		self.m_newYearSeniorPokerCount = 0; 
	end
	CookieService.setInteger(CookieKeys.NEW_YEAR_PRIMARY_ROOM_COUNTS .. self.m_currentUid,          self.m_newYearPrimaryPokerCount);
	CookieService.setInteger(CookieKeys.NEW_YEAR_INTERMEDIATE_ROOM_COUNTS .. self.m_currentUid,     self.m_newYearIntermediatePokerCount);
	CookieService.setInteger(CookieKeys.NEW_YEAR_SENIOR_ROOM_COUNTS .. self.m_currentUid,           self.m_newYearSeniorPokerCount);
end
		
TaskReporter.callBackFun = function(self, value)
	Log.d(self.TAG, "spring_report callback value:", value);
end
		
TaskReporter.reportUserPay = function(self, value)
	self:setCurrentPayCount(self:getCurrentPayCount() + value);
end
		
TaskReporter.reportUseProp = function(self)
	self:setUsePropCount(self:getUsePropCount() + 1);
end
		
TaskReporter.reportSendTableGifts = function(self)
	self:setSendTableGifts(self:getSendTableGifts() + 1);
end
		
TaskReporter.reportEnterIntoMatch = function(self, roomType)
	if roomType == LoginSuccData.ROOM_TYPE_KNOCKOUT then
	    self:setEnterIntoKnockout(self:getEnterIntoKnockout() + 1);
    elseif roomType == LoginSuccData.ROOM_TYPE_TOURNAMENT then
        self:setEnterIntoTournament(self:getEnterIntoTournament() + 1);
	end
end
		
TaskReporter.reportWinningStreak = function(self)
	if self.m_winningStreak1 >= 2 then
        self:setTwoWinningStreak(self:getTwoWinningStreak() + 1);
		self.m_winningStreak1 = 0;
	end

	if self.m_winningStreak2 >= 3 then
		self:setThreeWinningStreak(self:getThreeWinningStreak() + 1);
		self.m_winningStreak2 = 0;
	end
end
		
TaskReporter.reportWinKnockout = function(self)
    self:setWinKnockout(self:getWinKnockout() + 1);
end
		
TaskReporter.reportOpenBox = function(self)
    self:setReportOpenBox(self:getReportOpenBox() + 1);
end
		
TaskReporter.reportSmallLaba = function(self)
    self:setUseSmallLabasCount(self:getUseSmallLabasCount() + 1);
end
		
TaskReporter.reportSuperLotto = function(self)
    self:setReportSuperLotto(self:getReportSuperLotto() + 1);
end
		
TaskReporter.reportInviteFriend = function(inviteNum)
    self:setInviteFriendsCount(self:getInviteFriendsCount() + inviteNum);
end
		
		
TaskReporter.reportShare = function(self)
    self:setSharesCount(self:getShareCount() + 1);
end
		
		
--[Comment]
-- 当前玩牌局数 		
TaskReporter.getCurrentPayCount = function(self)
	return self.m_currentPayCount;
end
		
TaskReporter.setCurrentPayCount = function(self, value)
	if self.m_paysTask ~= nil then
        self.m_currentPayCount = value;
		self.m_paysTask.m_totalProgress = value;
		if self.m_paysTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.writeNumber(CookieKeys.REPORTER_CURRENT_PAY_COUNT .. self.m_currentUid, self.m_currentPayCount);
		end
		self:reportData(self.m_paysTask, selfl.m_currentPayCount);
	end
end
		
--[Comment]
--当前玩牌局数 		
TaskReporter.getCurrentPokerCount = function(self)
	return self.m_currentPokerCount;
end
		
TaskReporter.setCurrentPokerCount = function(self, value)
	if self.m_pokersTask then
        self.m_currentPokerCount = value;
		self.m_pokersTask.m_totalProgress = value;
		if self.m_pokersTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_CURRENT_POKER_COUNT .. self.m_currentUid, self.m_currentPokerCount);
		end
		self:reportData(self.m_pokersTask, self.m_currentPokerCount);
	end
end
		
--[Comment]
--当前获胜局数 
TaskReporter.getCurrentWinCount = function(self)
	return self.m_currentWinCount;
end
		
TaskReporter.setCurrentWinCount = function(self, value)
	if self.m_winsTask ~= nil then
        self.m_currentWinCount = value;
		self.m_winsTask.m_totalProgress = value;
		if self.m_winsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_CURRENT_WIN_COUNT .. self.m_currentUid, self.m_currentWinCount);
		end
		self:reportData(self.m_winsTask, self.m_currentWinCount);
	end
end
		
--[Comment]
--高级场胜利次数
TaskReporter.getSeniorWinCount = function(self)
	return self.m_seniorWinCount;
end

TaskReporter.setSeniorWinCount = function(self, value)
	if self.m_seniorWinsTask ~= nil then
        self.m_seniorWinCount = value;
		self.m_seniorWinsTask.m_totalProgress = value;
		if self.m_seniorWinsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_SENIOR_WIN_COUNT .. self.m_currentUid, self.m_seniorWinCount);
		end
		self:reportData(self.m_seniorWinsTask, self.m_seniorWinCount);
	end
end

--[Comment]
--高级场玩牌次数
TaskReporter.getMiddleWinCount = function(self)
	return self.m_middleWinCount;
end

TaskReporter.setMiddleWinCount = function(self, value)
	if self.m_middleWinsTask ~= nil then
        self.m_middleWinCount = value;
		self.m_middleWinsTask.totalProgress = value;
		if self.m_middleWinsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_MIDDLE_WIN_COUNT .. self.m_currentUid, self.m_middleWinCount);
		end
		self:reportData(self.m_middleWinsTask, self.m_middleWinCount);
	end
end

--[Comment]
--最大赢取筹码
TaskReporter.getRoundWinChips = function(self)
	return self.m_roundWinChips;
end

TaskReporter.setRoundWinChips = function(self, value)
	if self.m_roundWinChipsTask ~= nil and value > self.m_roundWinChips then
        self.m_roundWinChips = value;
		self.m_roundWinChipsTask.m_totalProgress = value;
		if self.m_roundWinChipsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.writeNumber(CookieKeys.REPORTER_ROUND_WIN_CHIPS .. self.m_currentUid, self.m_roundWinChips);
		end
		self:reportData(self.m_roundWinChipsTask, self.m_roundWinChips);
	end
end

--[Comment]
--使用互动道具次数 
TaskReporter.getUsePropCount = function(self)
	return self.m_usePropCount;
end

TaskReporter.setUsePropCount = function(self, value)
	if self.m_usePropsTask ~= nil then
        self.m_usePropCount = value;
		self.m_usePropsTask.m_totalProgress = value;
		if self.m_usePropsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_USE_PROP_COUNT .. self.m_currentUid, self.m_usePropCount);
		end
		self:reportData(self.m_usePropsTask, self.m_usePropCount);
	end
end

TaskReporter.getSendTableGifts = function(self)
	return self.m_sendTableGifts;
end
		
TaskReporter.setSendTableGifts = function(self, value)
	if self.m_giftsTask ~= nil then
        self.m_sendTableGifts = value;
		self.m_giftsTask.m_totalProgress = value;
		if self.m_giftsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_SEND_TABLE_GIFTS .. self.m_currentUid, self.m_sendTableGifts);
		end
		self:reportData(self.m_giftsTask, self.m_sendTableGifts);
	end
end
		
TaskReporter.getEnterIntoKnockout = function(self)
	return self.m_enterIntoKnockout;
end
		
TaskReporter.setEnterIntoKnockout = function(self, value)
	if self.m_joinKnockoutsTask ~= nil then
        self.m_enterIntoKnockout = value;
		self.m_joinKnockoutsTask.totalProgress = value;
		if self.m_joinKnockoutsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_ENTER_INTO_KNOCKOUT .. self.m_currentUid, self.m_enterIntoKnockout);
		end
		self:reportData(self.m_joinKnockoutsTask, self.m_enterIntoKnockout);
	end
end
		

TaskReporter.getEnterIntoTournament = function(self)
	return self.m_enterIntoTournament;
end
		
TaskReporter.setEnterIntoTournament = function(self, value)
	if self.m_joinTournamentsTask ~= nil then
        self.m_enterIntoTournament = value;
		self.m_joinTournamentsTask.m_totalProgress = value;
		if self.m_joinTournamentsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_ENTER_INTO_TOURNAMENT .. self.m_currentUid, self.m_enterIntoTournament);
		end
		self:reportData(self.m_joinTournamentsTask, self.m_enterIntoTournament);
	end
end

TaskReporter.getTwoWinningStreak = function(self)
	return self.m_twoWinningStreak;
end
		
TaskReporter.setTwoWinningStreak = function(self, value)
	if self.m_twoWinningStreakTask then
        self.m_twoWinningStreak = value;
		self.m_twoWinningStreakTask.m_totalProgress  = value;
		if self.m_twoWinningStreakTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_TWO_WINNING_STREAK .. self.m_currentUid, self.m_twoWinningStreak);
		end
		self:reportData(self.m_twoWinningStreakTask, self.m_twoWinningStreak);
	end
end

TaskReporter.getThreeWinningStreak = function(self)
	return self.m_threeWinningStreak;
end
		
TaskReporter.setThreeWinningStreak = function(self, value)
	if self.m_threeWinningStreakTask ~= nil then
		self.m_threeWinningStreak = value;
        self.m_threeWinningStreakTask.m_totalProgress = value;
		if self.m_threeWinningStreakTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_THREE_WINNING_STREAK .. self.m_currentUid, self.m_threeWinningStreak);
		end
		self:reportData(self.m_threeWinningStreakTask, self.m_threeWinningStreak);
	end
end
		
TaskReporter.getWinKnockout = function(self)
	return self.m_winKnockout;
end

TaskReporter.setWinKnockout = function(self, value)
	if self.m_winKnockoutsTask ~= nil then
        self.m_winKnockout = value;
		self.m_winKnockoutsTask.m_totalProgress = value;
		if self.m_winKnockoutsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_WIN_KNOCKOUT .. self.m_currentUid, self.m_winKnockout);
		end
		self:reportData(self.m_winKnockoutsTask, self.m_winKnockout);
	end
end

TaskReporter.getCurrentBoxCount = function(self)
	return self.m_currentBoxCount;
end

TaskReporter.setCurrentBoxCount = function(self, value)
	if self.m_boxsTask ~= nil then
        self.m_currentBoxCount = value;
		self.m_boxsTask.m_totalProgress = value;
		if self.m_boxsTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_OPEN_BOX .. self.m_currentUid, self.m_currentBoxCount);
		end
		self:reportData(self.m_boxsTask, self.m_currentBoxCount);
	end
end

TaskReporter.getUseSmallLabasCount = function(self)
	return self.m_useSmallLabasCount;
end

TaskReporter.setUseSmallLabasCount = function(self, value)
	if self.m_useSmallLabasTask ~= nil then
		self.m_useSmallLabasCount = value;
        self.m_useSmallLabasTask.m_totalProgress = value;
		if self.m_useSmallLabasTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_SMALL_LABA .. self.m_currentUid, self.m_useSmallLabasCount);
		end
		self:reportData(self.m_useSmallLabasTask, self.m_useSmallLabasCount);
	end
end

TaskReporter.getSuperLottoCount = function(self)
	return self.m_superLottoCount;
end

TaskReporter.setSuperLottoCount = function(self, value)
	if self.m_superLottosTask ~= nil then
		self.m_superLottoCount = value;
        self.m_superLottosTask.totalProgress = value;
		if self.m_superLottosTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_SUPER_LOTTO .. self.m_currentUid, self.m_superLottoCount);
		end
		self:reportData(self.m_superLottosTask, self.m_superLottoCount);
	end
end

TaskReporter.getInviteFriendsCount = function(self)
	return self.m_inviteFriendsCount;
end

TaskReporter.setInviteFriendsCount = function(self, value)
	if self.m_invitesTask ~= nil then
        self.m_inviteFriendsCount = value;
		self.m_invitesTask.m_totalProgress  = value;
		if self.m_invitesTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_INVITE_FRIEND .. self.m_currentUid, self.m_inviteFriendsCount);
		end
		self:reportData(self.m_invitesTask, self.m_inviteFriendsCount);
	end
end
		
TaskReporter.getSharesCount = function(self)
	return self.m_sharesCount;
end
		
TaskReporter.setSharesCount = function(self, value)
	if self.m_sharesTask ~= nil then
        self.m_sharesCount = value;
		self.m_sharesTask.m_totalProgress = value;
		if self.m_sharesTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setInteger(CookieKeys.REPORTER_SHARES_COUNT .. self.m_currentUid, self.m_sharesCount);
		end
		self:reportData(self.m_sharesTask, self.m_sharesCount);
	end
end

TaskReporter.setTaskButton = function(self, value)
	self.m_taskButton = value
	self:onFinishedTask(Model.getData(ModelKeys.CURRENRT_FINISHED_TASK));
end

TaskReporter.setTaskItem = function(self, value)
	self.m_taskItem = value;
end

--[Comment]
--升级任务
TaskReporter.getLevelNum = function(self)
	return self.m_levelNum;
end
		
TaskReporter.setLevelNum = function(self, value)
	if self.m_upgrateLevelTask ~= nil then
        self.m_levelNum = value;
		self.m_upgrateLevelTask.m_totalProgress = value;
		if self.m_paysTask.status ~= taskVO.STATUS_FINISHED then
			CookieService.setNumber(CookieKeys.REPORTER_LEVEL_COUNT .. self.m_currentUid, self.m_levelNum);
		end
		self.m_upgrateLevelTask.m_canGet = true;
		self:reportData(self.m_upgrateLevelTask, self.m_levelNum);
	end
end
		
TaskReporter.reportUserLevel = function(self, value)
	self.m_levelNum = value;
end