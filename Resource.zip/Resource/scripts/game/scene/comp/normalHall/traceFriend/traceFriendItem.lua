require("view/hall/layout_normal_hall_trace_friend_item");
--[Comment]
--跟踪好友项
TraceFriendItem = class(Node, false);

TraceFriendItem.ctor = function(self, data)
    super(self);
    self.m_root                 = SceneLoader.load(layout_normal_hall_trace_friend_item);
    self.m_photoContainer       = self.m_root:getNodeByName("bg.photo_container");
    self.m_imgSex               = self.m_root:getNodeByName("bg.img_sex");
    self.m_txtNick              = self.m_root:getNodeByName("bg.txt_nick");
    self.m_txtLvl               = self.m_root:getNodeByName("bg.txt_lvl");
    self.m_txtPlayerNum         = self.m_root:getNodeByName("bg.txt_player_num");
    self.m_txtTableFlag         = self.m_root:getNodeByName("bg.txt_table_flag");
    self.m_txtTableId           = self.m_root:getNodeByName("bg.txt_table_id");
    
    self.m_defaultMalePhoto     = "userinfo/imgface_default_male.jpg";
    self.m_defautlFemalePhoto   = "userinfo/imgface_default_female.jpg";
    self.m_maleIcon             = "hall/normal/traceFriend/maleIcon.png";
    self.m_femaleIcon           = "hall/normal/traceFriend/femaleIcon.png";
    
    self.m_headImage            = new(CircleImage,self.m_defaultMalePhoto, self.m_defaultMalePhoto);
    self.m_headContainer        = self.m_root:getNodeByName("bg.photo_container");
    
    self.m_txtTableFlag:setText(STR_NEW_HALL_TRACE_FRIENDS_ROOMID);
    self.m_txtLvl:setAlpha(0.4);
    self.m_headImage:hideSide();
    self.m_headContainer:addChild(self.m_headImage);

    self:setSize(self.m_root:getSize());
    self:addChild(self.m_root);
    self:addControlEventList();
    self:setData(data);
end

TraceFriendItem.dtor = function(self)
    self:removeControlEventList();
end

TraceFriendItem.addControlEventList = function(self)
    if self.m_controlEventList == nil then
        self.m_controlEventList = {
            {self, "setEventTouch", self.onTouch};
        }
    end
    EventListKit.addEventList(self, self.m_controlEventList);
end

TraceFriendItem.removeControlEventList = function(self)
    if self.m_controlEventList ~= nil then
        EventListKit.removeEventList(self, self.m_controlEventList);
    end
    self.m_controlEventList = nil;
end


TraceFriendItem.onTouch = function(self, finger_action, x, y)
   if self.m_data ~= nil then
       TouchHelper.catch(self, finger_action, x, y);
       if TouchHelper.isClick(self) then
            if not (self.m_data.field ~= nil and 
                    not TableLimit.checkAccess(self.m_data.field, LoginSuccData.ROOM_TYPE_NORMAL, true)) then		
	            local param = {
                    ["tid"]     = self.m_data.tid, 
                    ["ip"]      = self.m_data.ip, 
                    ["port"]    = self.m_data.port
                 };
                EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_TRACE_FRIEND_POPUP);
    	        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.QUICK_ENTER_ROOM, param);
            end
       end
    end
end


TraceFriendItem.setData = function(self, value)	
    self.m_data = value;
    
    --更新玩家数量文本
    self:__updatePlayerNumText(self.m_data)
    
    --更新玩家昵称文本
    local nick = (self.m_data ~= nil) and (self.m_data.nick or "") or "";
    self.m_txtNick:setText(nick);
	
    --更新玩家等级文本
    local lvl = "Lv."..( (value ~= nil) and (value.lv or "") or "");
    self.m_txtLvl:setText(lvl);

     --更新桌子tid文本
    local tid = ""..( (value ~= nil) and (value.tid or "") or "");
    self.m_txtTableId:setText(tid);

    --更新玩家性别图片
	self:__updateSexImg(self.m_data);
	
    --更新朋友图像
    self:__updatePhoto(self.m_data);
end

TraceFriendItem.__updatePlayerNumText = function(self, value)
     if value ~= nil then
        value.pc = value.pc or 0;
        value.all = value.all or 9;
        self.m_txtPlayerNum:setText(value.pc.."/"..value.all);
	    self.m_txtPlayerNum:setColor(RGBKit.getRGB((value.pc < value.all) and 0xa2aac2 or 0xff0000));
     else
        self.m_txtPlayerNum:setText("");
     end
end

TraceFriendItem.__updateSexImg = function(self, value)
     if value ~= nil then
         self.m_imgSex:setFile((value.sex == 1) and self.m_femaleIcon or self.m_maleIcon);
    else
        self.m_imgSex:setFile(self.m_maleIcon);
    end
end

TraceFriendItem.__updatePhoto = function(self, value)
    if value ~= nil then
        self.m_headImage:setFile(PhotoKit.getPhotoURL(value.img))
    else
        self.m_headImage:setFile(self.m_defaultMalePhoto);
    end
end