require("view/hall/layout_normal_hall_trace_friend");
require("game/scene/comp/normalHall/traceFriend/traceFriendItem");
--[Comment]
TraceFriendPopup = class(PopupDialog, false)

TraceFriendPopup.ctor = function(self)
    super(self, layout_normal_hall_trace_friend, true);
    self.m_txtTitle         = self.m_root:getNodeByName("bg.txt_title");
    self.m_listContainer    = self.m_root:getNodeByName("bg.list_container");
    self.m_bgPlayMySelf     = self.m_root:getNodeByName("bg.bg_play_myself");
    self.m_txtPlayMySelf    = self.m_root:getNodeByName("bg.bg_play_myself.txt_play_myself");
    self.m_btnClose         = self.m_root:getNodeByName("bg.btn_close");

    --创建列表
    local width, height     = self.m_listContainer:getSize();
    self.m_list             = new(ListView2, 0, 0, width, height);
    self.m_list:setScrollBarWidth(0);
    self.m_listContainer:addChild(self.m_list);
    
    --设置文本
    self.m_txtTitle:setText(STR_NEW_HALL_TRACE_FRIENDS_TITLE);
    self.m_txtPlayMySelf:setText(STR_NEW_HALL_TRACE_FRIENDS_IGNORE);
    
    --初始化弹框时延迟时间
    self:setDelay(50);
end

TraceFriendPopup.dtor = function(self)
    PopupDialog.dtor(self);
end

TraceFriendPopup.addControlEventList = function(self)
    if self.m_controlEventList == nil then
        self.m_controlEventList = {
            {self.m_bgPlayMySelf, "setEventTouch",  self.onTouch};
            {self.m_btnClose,     "setOnClick",     self.close};
        }
    end
    EventListKit.addEventList(self, self.m_controlEventList);
end

TraceFriendPopup.removeControlEventList = function(self)
    if self.m_controlEventList ~= nil then
       EventListKit.removeEventList(self, self.m_controlEventList);
    end
    self.m_controlEventList = nil;
end

TraceFriendPopup.update = function(self, data)
    if self.m_list ~= nil then
        self.m_list:removeAllChildren();
        if data ~= nil then
            self.m_adapter = new(CacheAdapter,TraceFriendItem,data);
            self.m_list:setAdapter(self.m_adapter);
        end
    end
end

TraceFriendPopup.onTouch = function(self, finger_action, x, y)
    TouchHelper.catch(self.m_bgPlayMySelf, finger_action, x, y)
    if TouchHelper.isClick(self.m_bgPlayMySelf) then
        self:close();
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.QUICK_ENTER_ROOM);
    end
end

TraceFriendPopup.show = function(self, popupStyle, customStyleFunc)
    PopupDialog.show(self, popupStyle, customStyleFunc);
    self:addControlEventList();
end

TraceFriendPopup.close = function(self)
    self:removeControlEventList();
    PopupDialog.close(self);
end