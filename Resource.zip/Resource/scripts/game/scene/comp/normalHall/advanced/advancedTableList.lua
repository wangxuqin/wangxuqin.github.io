require("game/scene/comp/normalHall/advanced/advancedTableListAnim");
require("game/scene/comp/normalHall/advanced/advancedTableItem");
require("game/scene/comp/normalHall/common/safeScrollListView");

AdvancedTableList = class(Node);

AdvancedTableList.ctor = function(self, width, height)
    self.m_list = new(SafeScrollListView);
    self.m_list:setAlign(kAlignTopLeft)
    self.m_list:setSize(width, height);
    self.m_listAnim = new(AdvancedTableListAnim);
    self.m_list:setTopBanner(self.m_listAnim);
    _,self.m_max_offset = self.m_listAnim:getSize();
    self.m_max_offset  = self.m_max_offset / 2;
    self.m_min_offset = 5;
    self:addChild(self.m_list);
    self.m_callBack = {};
    self:addEventList();
end

AdvancedTableList.dtor = function(self)
    self:removeEventList();
    self.m_callBack = nil;
end

AdvancedTableList.addEventList = function(self)
    self.m_list:setOnScroll(function (_, offset)
        if offset >= self.m_max_offset then 
            if self.m_listAnim.isPlaying ~= true then
                self:playListAnim();
                self.m_needUpdata = true;
            end
        end

        if self.m_list:isBouncing() then
            if offset <= self.m_min_offset then
                self:stopListAnim();
            end
        end

        self.m_itemPosition = self.m_list:getItemPositionArr();
        if self.m_itemPosition ~= nil and self.m_itemPosition ~= nil and #self.m_itemPosition > 0 then
            local index = self.m_list:getItemByPosition(self.m_itemPosition[1] + self.m_titleHeight);
            if index ~= nil then
                local position = self.m_list:getItemPosition(index);
                local nextPosition = self.m_list:getItemPosition(index + 1);
                if position < 0 and (nextPosition + self.m_titleHeight) > 0 then
                    self.m_items[index]:setTitleVisible(false);
                    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_ADVANCED_FLOAT_BRING_TITLE, self.m_items[index]:getTitle());
                else
                    self.m_items[index]:setTitleVisible(true);
                    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_ADVANCED_FLOAT_BRING_TITLE);
                end

                if index ~= nil and index ~= -1 then
                    if self.m_index ~= index then
                        self.m_index = index;
                        self:onChangeItem(self.m_index);
                    end
                end
            end
        end
    end);

    self.m_list:setOnBeginBouncing(function() end)

    self.m_list:setOnStop(function()
        if self.m_needUpdata == true then
           EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.REQUEST_BRING_GROUPS_INFO, 4)
        end
        self:stopListAnim();
        self.m_needUpdata = false;
    end)
end

AdvancedTableList.playListAnim = function(self)
    self.m_listAnim.isPlaying = true;
    self.m_listAnim:play();
end

AdvancedTableList.stopListAnim = function(self)
    self.m_listAnim.isPlaying = false;
    self.m_listAnim:stop();
end

AdvancedTableList.removeEventList = function(self)
    self.m_list:setOnScroll(nil);
    self.m_list:setOnBeginBouncing(nil);
    self.m_list:setOnStop(nil);
end

AdvancedTableList.setData = function(self, data, index)
    index = index or 1;
    if self.m_list ~= nil then
        self.m_list:removeAllItem(function()
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_MINI_LOAD);
            self.m_items = {};
            self.m_index = index;
            if data ~= nil then
                for i = 1, #data + 1 do
                    local item = new(AdvancedTableItem);
                    table.insert(self.m_items, item);
                    item:setData(data[i]); --�� i=#data+1 ����ֵ��ȥ
                    item:setAlign(kAlignTopLeft);
                    self.m_titleHeight = self.m_titleHeight or item:getTitleHeight();
                    self.m_list:addItem(item, (function()
                        if i ==  #data + 1 then
                            self:showItem(index);
                            self:setVisible(true);
                            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_MINI_LOAD);
                        end
                    end));
                end
            end
        end);
    end
end


AdvancedTableList.showItem = function(self, index)
    self.m_list:showItem(index);
end

AdvancedTableList.setOnChangeItem = function(self, obj, func)
    self.m_callBack.changeItem = self.m_callBack.changeItem or {}
    self.m_callBack.changeItem.obj = obj;
    self.m_callBack.changeItem.func = func;
end

AdvancedTableList.onChangeItem = function(self, index)
    if self.m_callBack ~= nil and self.m_callBack.changeItem ~= nil then
        local obj = self.m_callBack.changeItem.obj;
        local func = self.m_callBack.changeItem.func;
        if func ~= nil then
            if obj ~= nil then
                func(obj, index);
            else
                func(index);
            end
        end
    end
end