require("view/hall/layout_normal_hall_advanced_head");
AdvancedPlayersHead = class(Node);
AdvancedPlayersHead.ctor = function(self)
	self.m_root = SceneLoader.load(layout_normal_hall_advanced_head);
    self:addChild(self.m_root);
    self.m_txtNick = self.m_root:getNodeByName("bg.txt_nick");
    self.m_txtNick:setAlpha(0.5);
    self.m_headContainer = self.m_root:getNodeByName("bg.head_container");
end

AdvancedPlayersHead.dtor = function(self)
    --�ͷŲ���
    if self.m_anim ~= nil then
        self.m_anim:release();
        self.m_anim = nil;
    end
end
		
		
AdvancedPlayersHead.setData = function(self, value)
	if value ~= nil then
		
	    if value.friendsFlag == 1 then
		    self.m_anim = AtomAnimManager.getInstance():playAnim("atomAnimTable/hall/anim_advanced_item_friend", self.m_root:getNodeByName("bg.anim_container"), nil, nil, false);
        end

        if self.m_headImage ~= nil then
            local parent = self.m_headImage:getParent();
            if parent ~= nil then
                parent:removeChild(self.m_headImage, true);
            end
        end

        self.m_headImage = new(CircleImage,"userinfo/imgface_default_male.jpg", PhotoKit.getDefaultPhotoUrl(value.img));
        self.m_headImage:hideSide();
        self.m_headImage:setRadius(25, 2);
        self.m_headContainer:addChild(self.m_headImage);
	    self.m_txtNick:setText(value.nick);
    end
end