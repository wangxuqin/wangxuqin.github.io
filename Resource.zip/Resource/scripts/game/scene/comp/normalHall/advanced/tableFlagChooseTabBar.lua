require("view/hall/layout_normal_hall_advanced_choose_tab")
--[Comment]
--高级场（好友，全部，满）筛选按钮
TableFlagChooseTabBar = class(Node);
TableFlagChooseTabBar.ctor = function(self)
    self.m_root       = SceneLoader.load(layout_normal_hall_advanced_choose_tab)
    self.m_txtAll     = self.m_root:getNodeByName("bg.txt_all");
    self.m_txtNotFull = self.m_root:getNodeByName("bg.txt_not_full");
    self.m_txtFriends = self.m_root:getNodeByName("bg.txt_friends");
    
    self.m_txtAll     :setText(STR_NEW_HALL_ALL);
    self.m_txtNotFull :setText(STR_NEW_HALL_NOT_FULL);
    self.m_txtFriends  :setText(STR_NEW_HALL_FRIENDS);
    
    self.m_txtList    = {self.m_txtAll, self.m_txtNotFull, self.m_txtFriends};
    self.m_index      = 1;
    self.m_callBack   = {};
    
    self.m_defaultFont         = {18, 0xffffff, 0.6};
    self.m_defaultSelectedFont = {24, 0xffffff, 1.0};
    self:addControlEventList();
    self:setAlign(kAlignTopLeft);
    self:addChild(self.m_root);
    self:changeTab(1);
end

TableFlagChooseTabBar.dtor = function(self)
    Node.dtor(self);
    self:removeControlEventList();
    self.m_callBack = nil;
end

--[Comment]
--添加控件监听事件
TableFlagChooseTabBar.addControlEventList = function(self)
    if self.m_eventList == nil then
        self.m_eventList = {
            {self.m_txtAll,     "setOnClick",   self.onClick};
            {self.m_txtNotFull, "setOnClick",   self.onClick};
            {self.m_txtFriends, "setOnClick",   self.onClick};
        }
        EventListKit.addEventList(self, self.m_eventList);
    end
end

TableFlagChooseTabBar.removeControlEventList = function(self)
    if self.m_eventList ~= nil then
        EventListKit.removeEventList(self, self.m_eventList);
    end
    self.m_eventList = nil;
end

--[Comment]
--设置字体样式
TableFlagChooseTabBar.setFont = function(self, index)
    if self.m_txtList ~= nil and index > 0 and index <= #self.m_txtList then
        for i = 1, #self.m_txtList do
            local text = self.m_txtList[i];
            if i ~= index then
                text:setEnable(true);
                self:__setFont(text, self.m_defaultFont);
            else
                text:setEnable(false);
                self:__setFont(text, self.m_defaultSelectedFont);
            end
        end
    end
end

TableFlagChooseTabBar.__setFont = function(self, text, font)
    text:setFontSize(font[1]);
    text:setColor(RGBKit.getRGB(font[2]));
    text:setAlpha(font[3]);
end

TableFlagChooseTabBar.onClick = function(self,finger_action,x,y,drawing_id_first,drawing_id_current)
    SoundManager.playSound("ButtonClick");
    local index = -1;
    for i = 1, #self.m_txtList do
        local text = self.m_txtList[i];
        if text.m_drawingID == drawing_id_current then
            index = i;
            break;
        end
    end
    if index ~= - 1 then
        self:changeTab(index);
    end
end

TableFlagChooseTabBar.changeTab = function(self, index)
    self.m_index = index;
    self:setFont(index);
    self:onChange();
end

TableFlagChooseTabBar.setOnChange = function(self, obj, func)
    self.m_callBack.obj = obj;
    self.m_callBack.func = func;
end

TableFlagChooseTabBar.onChange = function(self)
    if self.m_callBack ~= nil then
        local obj   = self.m_callBack.obj;
        local func  = self.m_callBack.func;
        if func ~= nil then
           if obj ~= nil then
                func(obj, self.m_index);
           else
                func(self.m_index);
           end
        end
    end
end

TableFlagChooseTabBar.getIndex = function(self)
    return self.m_index;
end