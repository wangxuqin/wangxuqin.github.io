require("view/hall/layout_normal_hall_advanced_item");
require("game/scene/comp/normalHall/advanced/advancedBringTitle");
require("game/scene/comp/normalHall/advanced/tableLayoutContainer");
require("game/scene/comp/normalHall/advanced/advancedTableContainer");

--[Comment]
--高级场某种携带量下的桌子list集合 
AdvancedTableItem = class(Node);

AdvancedTableItem.MIN_WIDTH = 320;

AdvancedTableItem.MIN_HEIGHT = 244;

AdvancedTableItem.ctor = function(self)
    self.m_root = SceneLoader.load(layout_normal_hall_advanced_item);
	self.m_title = new(AdvancedBringTitle);
    self.m_title:setLevel(10);
	self.m_titleContainer = self.m_root:getNodeByName("bg.title_container");
    self.m_titleContainer:addChild(self.m_title);
	self.m_list = self.m_root:getNodeByName("bg.list");
    local width,height = self.m_list:getSize();
    self.m_root:getNodeByName("bg"):removeChild(self.m_list, true);
    self.m_container = new(TableLayoutContainer, 3, width, height, 320, 244, AdvancedTableContainer);
    self.m_container:setAlign(kAlignTopLeft);
    self.m_root:addChild(self.m_container);
    self:addChild(self.m_root);
end

AdvancedTableItem.dtor = function(self)
end	
		
AdvancedTableItem.setData = function(self, value)
	if value ~= nil then
	    self.m_title:setVisible(true);
        self.m_title:setData(value);
--        local num = math.random(0, 3);
--        for i = 1, num do
--            table.insert(value.tables, value.tables[i]);
--        end
	    if value.tables ~= nil then
		    self.m_container:setData(value.tables);
	   end
    else
        self.m_title:setVisible(false);
        self.m_container:setData(nil);
    end
    self:setSize(self.m_container:getSize());
end

AdvancedTableItem.getTitleHeight = function(self)
    local _,height = self.m_titleContainer:getSize();
    return height;
end

AdvancedTableItem.setTitleVisible = function(self, value)
    if self.m_titleContainer ~= nil then
        self.m_titleContainer:setVisible(value);
    end
end

AdvancedTableItem.getTitle = function(self)
    local ret = nil;
    if self.m_title ~= nil then
        ret = self.m_title:getTitle();
    end
    return ret;
end