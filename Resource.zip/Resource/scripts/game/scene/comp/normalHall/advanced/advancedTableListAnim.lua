require("view/hall/layout_normal_hall_advanced_list_anim")
--[Comment]
--高级场桌子列表下拉动画
AdvancedTableListAnim = class(Node)

AdvancedTableListAnim.ctor = function(self)
    self.m_root = SceneLoader.load(layout_normal_hall_advanced_list_anim);
    self.m_imgPullDown = self.m_root:getNodeByName("bg.img_pull_down");
    self.m_txtPullDown = self.m_root:getNodeByName("bg.txt_pull_down");
    self.m_txtPullDown:setText(STR_COMMON_PULL_TO_REFRESH);
    local width, height = self.m_root:getNodeByName("bg"):getSize();
    self:setSize(width, height);
    self:addChild(self.m_root);
end

AdvancedTableListAnim.dtor = function(self)
end

AdvancedTableListAnim.play = function(self)
    self:stop();
    KTween.to(self.m_imgPullDown, 300, {angle=180});
    self.m_txtPullDown:setText(STR_COMMON_RELEASE_TO_REFRESH);
    self.m_txtPullDown:setBold(true);
end

AdvancedTableListAnim.stop = function(self)
    KTween.remove(self.m_imgPullDown);
    self.m_txtPullDown:setText(STR_COMMON_PULL_TO_REFRESH);
    self.m_txtPullDown:setBold(false);
end