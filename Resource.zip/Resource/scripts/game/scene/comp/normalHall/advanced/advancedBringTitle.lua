require("view/hall/layout_normal_hall_advanced_title");
--[Comment]
--�߼���Я�������ı�
AdvancedBringTitle = class(Node)

AdvancedBringTitle.ctor = function(self)
    self.m_root = SceneLoader.load(layout_normal_hall_advanced_title);
    self.m_txt1 = self.m_root:getNodeByName("bg.txt1");
    self.m_txt2 = self.m_root:getNodeByName("bg.txt2");
    self.m_txt3 = self.m_root:getNodeByName("bg.txt3");
    self.m_txt4 = self.m_root:getNodeByName("bg.txt4");
    self:addChild(self.m_root);
end
			
AdvancedBringTitle.setData = function(self, value)
    local arr = {};
    arr[1] = STR_NEW_HALL_BRING_SET_RENDER_TITLE_1;
    arr[2] = Formatter.formatBigNumber(value.minb).."-"..Formatter.formatBigNumber(value.maxb);
	arr[3] = STR_NEW_HALL_BRING_TXT;
	arr[4] = Formatter.formatBigNumber(value.sb).."/"..Formatter.formatBigNumber(value.bb);
	self:setTitle(arr);
end

AdvancedBringTitle.getTitle = function(self)
   return {self.m_str1, self.m_str2, self.m_str3, self.m_str4}; 
end

AdvancedBringTitle.setTitle = function(self,arr)
    if arr ~= nil and #arr >= 4 then
        self.m_str1 = arr[1];
        self.m_str2 = arr[2];
	    self.m_str3 = arr[3];
	    self.m_str4 = arr[4];
	    self.m_txt1:setText(self.m_str1);
	    self.m_txt2:setText(self.m_str2);
	    self.m_txt3:setText(self.m_str3);
	    self.m_txt4:setText(self.m_str4);
    end
end
