require("view/hall/layout_normal_hall_advanced_table");
require("game/scene/comp/normalHall/advanced/advancedPlayersHead");

--[Comment]
--高级场单个桌子render 
AdvancedTableContainer = class(Node);

AdvancedTableContainer.ctor = function(self)	
    self.m_root             = SceneLoader.load(layout_normal_hall_advanced_table);
	self.m_playerNum        = self.m_root:getNodeByName("bg.txt_player_num");
	self.m_imgQuick         = self.m_root:getNodeByName("bg.img_quick");
	self.m_playerContainer  = self.m_root:getNodeByName("bg.player_container");
    self.m_root:setAlign(kAlignTopLeft);
    self:setSize(self.m_root:getSize());
    self:addChild(self.m_root);
    self.m_root:setEventTouch(self, self.onTouch);
end

AdvancedTableContainer.dtor = function(self)
end

AdvancedTableContainer.setData = function(self, value)
	self.m_data = value;
	if value ~= nil then
	    self.m_playerNum.setText(value.pc.."/"..value.all);
	    if value.flag == 2 then
		    self.m_imgQuick:setVisible(true);
	    else
		    self.m_imgQuick:setVisible(false);
        end
	    self:updatePlayerContainer(value);
    end
end

AdvancedTableContainer.clearPlayerContainer = function(self)
    if self.m_playerContainer ~= nil then
        self.m_playerContainer:getNodeByName("item1"):removeAllChildren(true);
        self.m_playerContainer:getNodeByName("item2"):removeAllChildren(true);
    end
end

AdvancedTableContainer.updatePlayerContainer = function(self, value)
   self:clearPlayerContainer();
	if value ~= nil and value.players ~= nil then
		local players = value.players;
		for i = 1, #players do
			local player = new(AdvancedPlayersHead);
			player:setData(players[i]);
			self.m_playerContainer:getNodeByName("item"..i):addChild(player)
		end
	end
end

AdvancedTableContainer.onTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
    if finger_action == kFingerDown then
        self.__bMoveFar = false;
        self.__xDown = x;
        self.__yDown = y;
        self.m_root:setScale(0.95);
    elseif finger_action == kFingerMove then
        if(math.abs(x - self.__xDown) > 4 or math.abs(y - self.__yDown) > 4) then
            self.__bMoveFar = true;
        end
    elseif finger_action == kFingerUp then
        self.m_root:setScale(1.0);
        if(not self.__bMoveFar) then
            local roomInfo = {["tid"]= self.m_data.tid, ["ip"]=self.m_data.ip, ["port"]= self.m_data.port};
		    EventDispatcher.getInstance():dispatch(UIEvent.s_event,UIEvent.s_cmd.QUICK_ENTER_ROOM,roomInfo);
        end
    end
end
