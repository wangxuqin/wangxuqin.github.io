TableLayoutContainer = class(Node);
TableLayoutContainer.ctor = function(self, col, width, height, itemWidth, itemHeight, itemType)
    self.m_col = col;
    
    self.m_cur_width        = width;
    self.m_cur_height       = height;

    self.m_delta_width      = width;
    self.m_delta_height     = height;
    
    self.m_horizontal_gap   = (width - itemWidth * col) / (col - 1);
    self.m_vertical_gap     = height - itemHeight;
    
    self.m_item_width       = itemWidth;
    self.m_item_height      = itemHeight;
    self.m_num = 0;
    self:setSize(width, height);
    self.m_arr = {};
    self:setAlign(kAlignTopLeft);
    self.m_itemType = itemType;
end

TableLayoutContainer.dtor = function(self)
    self:clear();
end

TableLayoutContainer.add = function(self, node)
    if node ~= nil then
        if ArrayKit.indexOf(self.m_arr, node) ~= -1 then
            self:remove(node);
        end
        
        self.m_num = self.m_num + 1;
        local mod = MathKit.mod(self.m_num, self.m_col + 1)
        if mod == 0 then
            self.m_cur_height = self.m_cur_height + self.m_delta_height;
            self:setSize(nil, self.m_cur_height);
        end
        local xNum = MathKit.mod((self.m_num - 1), self.m_col)
        local yNum = math.floor((self.m_num - 1) / self.m_col);
        local x = (self.m_item_width + self.m_horizontal_gap) * xNum;
        local y = (self.m_delta_height * yNum + self.m_vertical_gap);
        node:setPos(x, y);
        self:addChild(node);
        table.insert(self.m_arr, node);
    end
end

TableLayoutContainer.remove = function(self, node)
    if node ~= nil and ArrayKit.indexOf(self.m_arr, node) ~= -1 then
        self.m_num = self.m_num - 1;
        local mod = MathKit.mod(self.m_num, self.m_col)
        if mod == 0 then
            self.m_cur_height = self.m_cur_height - self.m_delta_height;
            self:setSize(nil, self.m_cur_height);
        end
        self:removeChild(node, true);
        local index = ArrayKit.indexOf(self.m_arr, node);
        if index ~= -1 then
            As3Kit.deleteAt(self.m_arr, index);
        end
    end
end

TableLayoutContainer.setData = function(self, data)
    self:clear();
    if data ~= nil then
        self.m_data = data;
        for i = 1, #data do
            local node = new(self.m_itemType);
            node:setData(data[i]);
            self:add(node);
        end
    end
end

TableLayoutContainer.clear = function(self)
    self.m_data = nil;
    for i = #self.m_arr, 1 do
        self:remove(self.m_arr[i]);
    end
    self:setSize(self.m_delta_width, self.m_delta_height);
end