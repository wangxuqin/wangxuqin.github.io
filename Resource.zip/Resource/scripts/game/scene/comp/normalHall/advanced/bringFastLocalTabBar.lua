require("view/hall/layout_normal_hall_advanced_tip");
--[Comment]
--携带快速定位tab 
BringFastLocalTabBar = class(Node)

BringFastLocalTabBar.ctor = function(self)
	self.m_selected     = "hall/normal/newHallRoom_swtichBring_Select.png";
    self.m_unselected   = "hall/normal/newHallRoom_swtichBring_defaut.png"
    self.m_bg = UIFactory.createImageByParam({
        file = "hall/normal/newHallRoom_toggle_Bg.png", 
        left   = 5,
        right  = 5,
        top    = 40,
        bottom = 40
    });

    self.m_callBack = {};

    self.m_tipRoot = SceneLoader.load(layout_normal_hall_advanced_tip);
    self.m_tipBg   = self.m_tipRoot:getNodeByName("bg");

    self.m_tip     = self.m_tipRoot:getNodeByName("bg.txt_tip");
    self.m_tip:setText(STR_NEW_HALL_BRING_SET_RENDER_TITLE_1);		
	
    self.m_tipRoot:setAlign(kAlignTopLeft);
    self.m_tipRoot:setVisible(false);
    self.m_bg:addChild(self.m_tipRoot);
    self.m_bg:setAlign(kAlignTopLeft);
    self:addChild(self.m_bg);
    
    self.m_index = 1;
end

BringFastLocalTabBar.dtor = function(self)
    self.m_callBack = nil;
    self:removeControlEventList();
    Node.dtor(self);
end

BringFastLocalTabBar.addControlEventList = function(self)
    if self.m_controlEventList == nil then
        self.m_controlEventList = {};
        if self.m_tabButtons then
            for i = 1, #self.m_tabButtons do
                local button = self.m_tabButtons[i];
                self.m_controlEventList[i] = {button, "setEventTouch", self.setEventTouch};
            end
        end
    end
    EventListKit.addEventList(self, self.m_controlEventList);
end

BringFastLocalTabBar.removeControlEventList = function(self)
    if self.m_controlEventList ~= nil then
        EventListKit.removeEventList(self, self.m_controlEventList);
    end
    self.m_controlEventList = nil;
end

BringFastLocalTabBar.setBtns = function(self, tableListsData)
	self:removeControlEventList();
    self:removeButtons();
	--Tab按钮组
	self.m_tabButtons   = {};
	self.m_tipsDataArr  = {};
	self.m_btnPosArr    = {};
	self.m_buttonNum =  #tableListsData;
	for i = 1, self.m_buttonNum do
		local tabButton = UIFactory.createButtonByParam({
            normalFile= (self.m_index == i) and self.m_selected or self.m_unselected,
        });
        tabButton:setAlign(kAlignTopLeft);
        local width, height     = tabButton:getSize();
        local bgWidth, bgHeight = self.m_bg:getSize();
        local x = (bgWidth - width) / 2;
		local y = (i - 1) * 55 + 38
		tabButton:setPos(x, y);
        self.m_tabButtons[i]    = tabButton;
		self.m_btnPosArr[i]     = {x=x,y=y};
		self.m_tipsDataArr[i]   = STR_NEW_HALL_BRING_SET_RENDER_TITLE_1..Formatter.formatBigNumber(tableListsData[i].minb).."~"..Formatter.formatBigNumber(tableListsData[i].maxb);
        self.m_bg:addChild(tabButton);
	end
    local height = #tableListsData * 55 + 38;
    self.m_bg:setSize(nil,height);
    self:addControlEventList();
 end
		
BringFastLocalTabBar.showTips = function(self, index)
	self.m_tipRoot:setVisible(true);
	self.m_tip:setText(self.m_tipsDataArr[index]);
    local x, y = self.m_tabButtons[index]:getPos();
	x = - 270;
	y = y - 15;
    self.m_tipRoot:setPos(x,y);
end
		
BringFastLocalTabBar.hideTips = function(self)
	self.m_tipRoot:setVisible(false);
end

BringFastLocalTabBar.setEventTouch = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)
	local index = -1;
    if finger_action == kFingerDown then
        index = self:indexOf(drawing_id_first);
        if index ~= -1 then
            self:showTips(index);
        end
    elseif finger_action == kFingerUp then
        self:hideTips();
        index = self:indexOf(drawing_id_current);
        if index ~= -1 then
            self:onTabButtonTriggered(index);
	    end
    end
end

BringFastLocalTabBar.indexOf = function(self, drawingID)
    local index = -1;
    if self.m_tabButtons ~= nil then
        for i = 1, #self.m_tabButtons do
            local btn = self.m_tabButtons[i];
            if btn.m_drawingID == drawingID then
                index = i;
                break;
            end
        end
    end
    return index;
end

BringFastLocalTabBar.onTabButtonTriggered = function(self, index)
	SoundManager.playSound("ButtonClick");
	self:changeTab(index);
end
		
BringFastLocalTabBar.changeTab = function(self, index, immediately)
    if self.m_index ~= index or immediately == true then
	    self:setIndex(index);
		self:onChange(index);
	end
end

BringFastLocalTabBar.setIndex = function(self, index)
    self.m_index = index; 
    for i = 1, #self.m_tabButtons do
		self.m_tabButtons[i]:setFile((i == index) and self.m_selected or self.m_unselected);
	end
end

BringFastLocalTabBar.setOnChange = function(self, obj, func)
    self.m_callBack.obj = obj;
    self.m_callBack.func = func;
end

BringFastLocalTabBar.onChange = function(self, index)
    if self.m_callBack ~= nil then
        local obj = self.m_callBack.obj;
        local func = self.m_callBack.func;
        if func ~= nil then
            if obj ~= nil then
                func(obj, index);
            else
                func(index);
            end
        end
    end
end

--[Comment]
--移除所有的定位按钮 
BringFastLocalTabBar.removeButtons = function(self)
    if self.m_tabButtons ~= nil then
        for i = 1, #self.m_tabButtons do
            local parent = self.m_tabButtons[i]:getParent();
            if parent ~= nil then
                parent:removeChild(self.m_tabButtons[i], true);
                self.m_tabButtons[i] = nil;
            end
        end
    end
end

BringFastLocalTabBar.getIndex = function(self)
    return self.m_index;
end