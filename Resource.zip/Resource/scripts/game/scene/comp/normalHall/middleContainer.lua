require("game/scene/comp/normalHall/common/normalHallBasicContainer");
MiddleContainer = class(NormalHallBasicContainer, false);

MiddleContainer.ctor = function(self, container)
    super(self, container, true);
end

MiddleContainer.dtor = function(self)
    NormalHallBasicContainer.dtor(self);
end

MiddleContainer.setVisible = function(self, value)
    NormalHallBasicContainer.setVisible(self, value);
    if value == true then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_MINI_LOAD);
    end
end