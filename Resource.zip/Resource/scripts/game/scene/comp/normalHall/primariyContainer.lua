require("game/scene/comp/normalHall/common/normalHallBasicContainer");
PrimariyContainer = class(NormalHallBasicContainer, false);

PrimariyContainer.ctor = function(self, container)
    super(self, container, true);
end

PrimariyContainer.dtor = function(self)
    NormalHallBasicContainer.dtor(self);
end

PrimariyContainer.setVisible = function(self, value)
    NormalHallBasicContainer.setVisible(self, value);
    if value == true then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_MINI_LOAD);
    end
end