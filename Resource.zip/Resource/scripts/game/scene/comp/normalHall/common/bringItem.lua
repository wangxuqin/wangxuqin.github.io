BringItem = class();
BringItem.m_data                     = nil;
BringItem.m_index                    = 1;
BringItem.m_owner                    = {}
BringItem.m_isSelected               = false;

BringItem.ctor = function(self, container)
   self.m_container = container;
   
   self.m_btn       = self.m_container:getNodeByName("btn");
   self.m_imgTitle  = self.m_container:getNodeByName("btn.img_title");
   self.m_txtTitle  = self.m_container:getNodeByName("btn.txt_title");
   self.m_txtBring  = self.m_container:getNodeByName("btn.txt_bring");
   self.m_txtBlind  = self.m_container:getNodeByName("btn.txt_blind");
   self.m_btnFriend = self.m_container:getNodeByName("btn_friend");
   
   self.m_txtBlind:setAlpha(0.6);
   self.m_btnFriend:setVisible(false);
   self:watchData();
   self.m_btn:setOnClick(self, self.onTouch);
   self.m_btnFriend:setOnClick(self, self.onShowTraceFriendPopup)
end

BringItem.dtor = function(self)
    self:unwatchData();
    if self.m_btn ~= nil then
       self.m_btn:setOnClick(nil, nil);
    end
    if self.m_btnFriend ~= nil then
       self.m_btnFriend:setOnClick(nil, nil);
    end
end

BringItem.watchData = function(self)
	Model.watchProperty(ModelKeys.USER_DATA, "money", self, self.updateMoney);
end


BringItem.unwatchData = function(self)
	Model.unwatchProperty(ModelKeys.USER_DATA, "money", self, self.updateMoney);
end

BringItem.updateMoney = function(self, useBring)
    userBring = userBring or 0;
    self:setTitle(userBring);
end

BringItem.setTitle = function(self, useBring)
	if self.m_data ~= nil and useBring < self.m_data.minb then --Я������
		self.m_imgTitle:setVisible(true);
		self.m_txtTitle:setFontSize(20);
        self.m_txtTitle:setColor(RGBKit.getRGB(0xffffff));
        self.m_txtTitle:setText(STR_NEW_HALL_BRING_SET_RENDER_TITLE_2);
	else
	self.m_imgTitle:setVisible(false);
		self:setTitleTxtStyle();
		self.m_txtTitle:setText(STR_NEW_HALL_BRING_SET_RENDER_TITLE_1);
	end
end

BringItem.setTitleTxtStyle = function(self)
	if self.m_data and self.m_data.setId then
		self.m_txtTitle:setFontSize(26);
        setId = self.m_data.setId;
        if setId == 1 then
			self.m_txtTitle:setColor(RGBKit.getRGB(0x2b4aa9));
		elseif setId == 2 then
			self.m_txtTitle:setColor(RGBKit.getRGB(0x096d23));
		elseif setId == 3 then
			self.m_txtTitle:setColor(RGBKit.getRGB(0x1f1f1f));
		elseif setId == 4 then
			self.m_txtTitle:setColor(RGBKit.getRGB(0x272545));
		elseif setId == 5 then
			self.m_txtTitle:setColor(RGBKit.getRGB(0x7d4f00));
		else 
			self.m_txtTitle:setColor(RGBKit.getRGB(0x5b1414));
        end
	end
end

BringItem.setData = function(self, data)
	self.m_data = data
	self:commitData();
end
		
BringItem.getIndex = function(self)
	return self.m_index;
end
	
BringItem.getOwner = function(self)
	return self.m_owner;
end
		
BringItem.setOwner = function(self, value)
	self.m_owner = value;
end
		
BringItem.isSelected = function(self)
	return self.m_isSelected;
end

BringItem.setSelected = function(self, value)
	if self.m_isSelected ~= value then
	    self.m_isSelected = value;
    end
end
		
BringItem.onTouch = function(self)
    self:onTouchHandler();
end

--[Comment]
--�򿪺���׷����� 
BringItem.onShowTraceFriendPopup= function(self)
	local param = {["field"] = self.m_data.field,["minbuyin"] = self.m_data.minb};
	EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.REQUEST_TRACE_FRIENDS_DATA,param);
end
			
BringItem.commitData = function(self)
	if self.m_data ~= nil then
		self.m_container:setVisible(true);
		self.m_txtBring:setText(Formatter.formatBigNumber(self.m_data.minb, false).."/"..Formatter.formatBigNumber(self.m_data.maxb, false));
		self.m_txtBlind:setText(Formatter.formatBigNumber(self.m_data.sb, false).."/"..Formatter.formatBigNumber(self.m_data.bb, false)..STR_NEW_HALL_BRING_SET_RENDER_BLIND);
		self:setTitleTxtStyle();
		local userData = Model.getData(ModelKeys.USER_DATA);
		self:setTitle(userData.money);
    else
		self.m_container:setVisible(false);
	end	
	self:setFriendIcon();
end

BringItem.setFriendIcon = function(self)
	if self.m_data ~= nil and self.m_data.friendsFlag == 1 then
		self.m_btnFriend:setVisible(true);
    else
		self.m_btnFriend:setVisible(false);
	end
end

BringItem.onTouchHandler = function(self)
    SoundManager.playSound("ButtonClick");
	if self.m_data ~= nil then
        local data = {["sb"]=self.m_data.sb,["field"]=self.m_data.field,["flag"] = 1};  --����û�п��ٳ�����ͨ��֮��
	    --�ӳ�1֡���뷿��
	    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.BRING_GROUP_ENTER_ROOM, data);
    end
end