--[Comment]
--这里封装NVerticalScrollView，提供一些安全调用的函数

SafeScrollListView = class(Node);

SafeScrollListView.ctor = function(self)
    local NVerticalListView = require('ui2.NVerticalListView')
    self.m_list = NVerticalListView.create();
    self.m_list:setScrollBarWidth(0);
    self:addChild(self.m_list);
end

SafeScrollListView.dtor = function(self)
    Node.dtor(self);

end

SafeScrollListView.setSize = function(self, width, height)
    Node.setSize(self, width, height);
    if self.m_list ~= nil then
        self.m_list:setSize(width, height);
    end
end

SafeScrollListView.setAlign = function(self, align)
    Node.setAlign(self, align);
    if self.m_list ~= nil then
        self.m_list:setAlign(align);
    end
end

SafeScrollListView.setTopBanner = function(self, banner)
    if self.m_list ~= nil and banner ~= nil then
        self.m_list:setTopBanner(banner);
    end
end


SafeScrollListView.setOnScroll = function(self, func)
    if self.m_list ~= nil then
        self.m_list:setOnScroll(func);
    end
end

SafeScrollListView.setOnBeginBouncing = function(self, func)
    if self.m_list ~= nil then
        self.m_list:setOnBeginBouncing(func);
    end
end

SafeScrollListView.setOnStop = function(self, func)
    if self.m_list ~= nil then
        self.m_list:setOnStop(func);
    end
end

--[Comment]
--callBack为插入item后的操作
SafeScrollListView.addItem = function(self, item, callBack)
    if self.m_list ~= nil and item ~= nil then
        self.m_list:addInvokeOnStop(function()
            if self.m_list:isCurrentlyNoScrolling() then
                self.m_list:addItem(item);
                local position = self.m_list:getItemPosition(self.m_list:getItemCount());
                self.m_itemPosition = self.m_itemPosition or {};
                table.insert(self.m_itemPosition, position);
                if callBack ~= nil and type(callBack) == "function" then
                    callBack();
                end
            else
                self:addItem(self, item, callBack);
            end
        end);
    end
end

--[Comment]
--callBack为执行移除所有Item后的操作
SafeScrollListView.removeAllItem = function(self, callBack)
    if self.m_list ~= nil then
        self.m_list:addInvokeOnStop(function()
            if self.m_list:isCurrentlyNoScrolling() then
                self.m_list:removeAllChildren();
                self.m_itemPosition = {};
                if callBack ~= nil and type(callBack) == "function" then
                    callBack();
                end
            else
                SafeScrollListView.removeAllItem(self);
            end
        end);
    end
end

SafeScrollListView.moveByItem = function(self, index, callBack)
    if self.m_list ~= nil then
        self.m_list:addInvokeOnStop((function ()
            if self.m_list:isCurrentlyNoScrolling() then
                if index ~= nil and index > 0 and index < #self.m_itemPosition then
                    local position = self.m_itemPosition[1];
                    self.m_list:moveByItem(index, position);
                    if callBack ~= nil and type(callBack) ~= nil then
                        callBack();
                    end
                end
            else
                self:moveByItem(index);
            end
        end));
    end
end

SafeScrollListView.showItem = function(self, index)
    if self.m_list ~= nil then
        self.m_list:addInvokeOnStop((function ()
            if self.m_list:isCurrentlyNoScrolling() then
                if index ~= nil and index > 0 and index < #self.m_itemPosition then
                    local position = self.m_itemPosition[1];
                    self.m_list:moveByItem(index, position);
                end
            else
                self:showItem(index);
            end
        end));
    end
end

SafeScrollListView.isBouncing = function(self)
    local ret = false;
    if self.m_list ~= nil then
        ret = self.m_list:isBouncing();
    end
    return ret;
end

SafeScrollListView.getItemByPosition = function(self, position)
    local index = -1;
    if self.m_list ~= nil then
        index = self.m_list:getItemByPosition(position);
    end
    return index;
end

SafeScrollListView.getItemPosition = function(self, index)
    local position = nil;
    if index ~= nil and index ~= -1 and self.m_list ~= nil then
        position = self.m_list:getItemPosition(index);
    end
    return position;
end

SafeScrollListView.getItemPositionArr = function(self)
    return self.m_itemPosition;
end