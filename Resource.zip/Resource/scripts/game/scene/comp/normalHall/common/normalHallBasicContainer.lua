require("game/scene/comp/normalHall/common/bringContainer");
--[Comment]
--普通场大厅容器基类
NormalHallBasicContainer = class();

NormalHallBasicContainer.ctor = function(self, container, hasBringContainer)
    self.m_container = container;
    
    if hasBringContainer then
        self.m_bringContainer = new(BringContainer, container:getNodeByName("bg.bring_container"));
    end
    self.m_isInit = true; --是否初始化
end

NormalHallBasicContainer.dtor = function(self)
    self.m_isInit   = false;
    if self.m_bringContainer ~= nil then
        self.m_bringContainer:dtor();
        self.m_bringContainer = nil;
    end
end

NormalHallBasicContainer.resume = function(self)
end

NormalHallBasicContainer.pause = function(self)
end

--[Comment]
--判断是否初始化
NormalHallBasicContainer.isInit = function(self)
    return self.m_isInit;
end

NormalHallBasicContainer.setVisible = function(self, visible)
    if self.m_container ~= nil then
        self.m_container:setVisible(visible);
    end 
end

NormalHallBasicContainer.getVisible = function(self)
    local ret = false;
    if self.m_container ~= nil then
        ret = self.m_container:getVisible();
    end 
    return ret;
end

NormalHallBasicContainer.updateBringContainer = function(self, data)
    if self.m_bringContainer ~= nil then
        self.m_bringContainer:addItems(data);
    end
end

NormalHallBasicContainer.playBringContainerAnim = function(self)
    if self.m_bringContainer ~= nil then
        self.m_bringContainer:playAnim();
    end
end