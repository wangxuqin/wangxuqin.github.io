require("game/scene/comp/normalHall/common/bringItem");
BringContainer = class();
BringContainer.TAG = "BringContainer";
BringContainer.MAX_COUNT = 6;
BringContainer.ctor = function(self, container)
    self.m_container = container;
	self.m_chipsArr  = {};
	for i = 1, self.MAX_COUNT do --筹码携带只有6种
		local item = new(BringItem, self.m_container:getNodeByName("item"..i));
		table.insert(self.m_chipsArr, item);
	end
end

BringContainer.dtor = function(self)
    if self.m_chipsArr ~= nil then
        for i = 1, #self.m_chipsArr do
            self.m_chipsArr[i]:dtor();
            self.m_chipsArr[i] = nil;
        end
    end
end

BringContainer.playAnim = function(self)
    for i = 1, #self.m_chipsArr do
        local item = self.m_chipsArr[i];
        KTween.remove(item.m_btn);
        local param = {
            startY = 600, 
            y = 0, 
            startAlpha = 0, 
            alpha = 1.0, 
            easeType = EaseType.SinOut, 
            delay=(300 + 125 * i), 
        }
        if i == #self.m_chipsArr then
            param.onComplete = self.onComplete;
            param.obj = self;
        end
        KTween.to(item.m_btn, 300, param);    
    end
end
		
BringContainer.addItems = function(self, arr)
    for i = 1, #self.m_chipsArr do
        local item = self.m_chipsArr[i];
        item.m_container:setVisible(false);
        if arr ~= nil and i <= #arr then
		    item.m_container:setVisible(true);
            item:setData(arr[i]);
        end
	end			
end

BringContainer.onComplete = function(self)
    for i = 1, #self.m_chipsArr do
        local item = self.m_chipsArr[i];
        item:setFriendIcon();
	end	
end		