require("game/scene/comp/normalHall/common/normalHallBasicContainer");
require("game/scene/comp/normalHall/advanced/tableFlagChooseTabBar");
require("game/scene/comp/normalHall/advanced/bringFastLocalTabBar");
require("game/scene/comp/normalHall/advanced/advancedTableList");

--[Comment]
--高级场容器
AdvancedContainer = class(NormalHallBasicContainer, false);
AdvancedContainer.ctor = function(self, container)
    super(self, container, false);
	self.m_chooseTab = new(TableFlagChooseTabBar);
    self.m_chooseTabContainer = container:getNodeByName("bg.choose_tab_container");
    self.m_chooseTabContainer:addChild(self.m_chooseTab);
	
    self.m_switchTab = new(ButtonTag);    
    self.m_switchTab:setButtonTagVerticalSingle({"5"..STR_NEW_HALL_PALYER_NUM,"9"..STR_NEW_HALL_PALYER_NUM},"hall/normal/newHallRoom_toggle_Bg.png",58,141,"hall/normal/newHallRoom_toggle_Btn.png",nil,nil,nil,nil,nil,nil,nil,nil,0,0);
    self.m_switchTab:getButtonSlider():setSize(80,81);
    self.m_switchTab:setAlign(kAlignTopLeft);
    self.m_switchTabContianer = container:getNodeByName("bg.switch_tab_container");
    self.m_switchTabContianer:addChild(self.m_switchTab);
    
    self.m_bringTab = new(BringFastLocalTabBar);
    self.m_bringTab:setVisible(false);
    self.m_bringTab:setAlign(kAlignTopLeft);
    self.m_bringTabContainer = container:getNodeByName("bg.bring_tab_container");
    self.m_bringTabContainer:addChild(self.m_bringTab);

    self.m_listContianer = container:getNodeByName("bg.list_container");
    local width, height  = self.m_listContianer:getSize();
    self.m_list = new(AdvancedTableList, width, height);
    self.m_list:setAlign(kAlignTopLeft);
    self.m_listContianer:addChild(self.m_list);

    self.m_floatBringTitle = new(AdvancedBringTitle);
    self.m_floatBringTitleContainer = container:getNodeByName("bg.float_bring_title_container");
    self.m_floatBringTitle:setAlign(kAlignTopLeft);
    self.m_floatBringTitle:setVisible(false);
    self.m_floatBringTitleContainer:addChild(self.m_floatBringTitle);
    
    self:addEventList();
    self:addControlEventList();
end

AdvancedContainer.dtor = function(self)
    NormalHallBasicContainer.dtor(self);
    self:removeEventList();
    self:removeControlEventList();
end

AdvancedContainer.resume = function(self)
   NormalHallBasicContainer.resume(self);
   self:addEventList();
   self:addControlEventList();
end

AdvancedContainer.pause = function(self)
   NormalHallBasicContainer.pause(self);
   self:removeEventList();
   self:removeControlEventList();
end

AdvancedContainer.addEventList = function(self)
    if self.m_eventList == nil then
        self.m_eventList = {
            {UIEvent, UIEvent.s_cmd.NEW_HALL_NO_TABLES,              "onUpdataChooseTabBar"};
            {UIEvent, UIEvent.s_cmd.SHOW_ADVANCED_FLOAT_BRING_TITLE, "onShowFloatBringTitle"};
            {UIEvent, UIEvent.s_cmd.HIDE_ADVANCED_FLOAT_BRING_TITLE, "onHideFloatBringTitle"};
        }
    end
    EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
end

AdvancedContainer.removeEventList = function(self)
    if self.m_eventList ~= nil then
        EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
    end
    self.m_eventList = nil;
end

AdvancedContainer.addControlEventList = function(self)
    if self.m_controlEventList == nil then
        self.m_controlEventList = {
            {self.m_switchTab, "setOnTagChangedAnimEnd", self.onFilterPlayerNumInfo};
            {self.m_list,      "setOnChangeItem",        self.onListChangeItem};
            {self.m_chooseTab, "setOnChange",            self.onFilterTableInfo};
            {self.m_bringTab,  "setOnChange",            self.onBringTabChange};
        }
    end
    EventListKit.addEventList(self, self.m_controlEventList);
end

AdvancedContainer.removeControlEventList = function(self)
    if self.m_controlEventList ~= nil then
         EventListKit.removeEventList(self, self.m_controlEventList);
    end
    self.m_controlEventList = nil;
end

AdvancedContainer.setGroupList = function(self, arr)
	--self:removeLoading();
	--self:removeTip();
	self.m_availbeTablesData = {};
	local tableListsData = arr;	
			
	if tableListsData ~= nil then
		self.m_bringTab:setVisible(true);
		--添加桌子组
		for i = 1, #tableListsData do
			if tableListsData[i].tables ~= nil and #tableListsData[i].tables > 0 then
				table.insert(self.m_availbeTablesData, tableListsData[i]);
			end
		end

        if #self.m_availbeTablesData > 0 then
            self.m_list:setData(self.m_availbeTablesData, self.m_bringTab:getIndex());
        end
		self.m_bringTab:setBtns(self.m_availbeTablesData);
    else
		self.m_bringTab:setVisible(false);			
	end
end

--[Commnet]
--5/9人桌
AdvancedContainer.onFilterPlayerNumInfo = function(self, index)
	local player = 5;
	local str = "";
	if index == 1 then
		player = 5;
		str = STR_NEW_HALL_FIVE_TIPS;	
	else
		player = 9;
		str = STR_NEW_HALL_NINE_TIPS;	
	end
			
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP,str);
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.NEW_HALL_FILTER_PlAYER_INFO, player);
	
    if self.m_bringTab ~= nil then
        self.m_bringTab:changeTab(1);
	end
end

--[Comment]
--满/未满/好友
AdvancedContainer.onFilterTableInfo = function(self, index)
	EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.NEW_HALL_FILTER_TABLE_INFO, index);		
end

AdvancedContainer.onUpdataChooseTabBar = function(self, index)
	if self.m_chooseTab ~= nil then
		self.m_chooseTab:changeTab(index);
    end
end


AdvancedContainer.onBringTabChange = function(self, index)
    if self.m_list ~= nil then
        self.m_list:showItem(index);
    end
end

AdvancedContainer.onListChangeItem = function(self, index)
    if self.m_bringTab ~= nil then
        self.m_bringTab:setIndex(index);
    end
end

AdvancedContainer.onShowFloatBringTitle = function(self, arr)
    if self.m_floatBringTitle ~= nil then
        self.m_floatBringTitle:setTitle(arr);
        self.m_floatBringTitle:setVisible(true);
    end
end

AdvancedContainer.onHideFloatBringTitle = function(self)
    if self.m_floatBringTitle ~= nil then
        self.m_floatBringTitle:setVisible(false);
    end
end

AdvancedContainer.setVisible = function(self, value)
    NormalHallBasicContainer.setVisible(self, value);
    if value == true then
        if self.m_list ~= nil then
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_MINI_LOAD);
            self.m_list:setVisible(false);
        end
    end
end
