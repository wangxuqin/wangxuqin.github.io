-------------------------------------------------------
--邮件系统对话框

require("ui/ex/buttonTag");
require("view/hall/layout_mail");
local NButton = require 'ui2.NButton'
local Debug = require 'ui2.util.debug'
local UniqId = require 'ui2.util.uniqId'

MsgDialog = class(PopupDialog, false);

MsgDialog.ctor = function(self)
    super(self, layout_mail, true);
    --插入上面的tab
    local tab = new(ButtonTag);
    local textTable = {};
    for i=1,#STR_MESSAGE_MESSAGE_TAB_ITEM do
        textTable[#textTable+1] = STR_MESSAGE_MESSAGE_TAB_ITEM[i];
    end
    tab:setButtonTagHorizontalSingle(textTable,
                               "common/dialog/common_tab_bar_background.png", 530, 63,
                               "common/dialog/common_tab_bar_selector_background.png",
                               9, 9, 8, 11, 9, 13, 8, 10,
                               4, 4);
    tab:setAlign(kAlignTop);
    tab:setPos(0, 10);
    self:getDialog():addChild(tab);

    local scrollRegion = self.m_root:getNodeByName("bg.mask");
    local wScroll,hScroll = scrollRegion:getSize();
    local x1,y1 = scrollRegion:convertPointToSurface(0, 0);

    --系统消息
    local view = tab:getView(1);
    local x2,y2 = view:convertPointToSurface(0, 0);
    scrollRegion:addChild(view);
    local scroll = new(ScrollView2, 0, 0, wScroll, hScroll, true);
    view:addChild(scroll);
    --填充数据
    local allMessages =
    {
        {
            readed = true,
            date = "2015-07-21",
            msg = "您于2015-07-21,15:08:11获得登录奖励2824筹码。",
        },
        {
            readed = false,
            date = "2015-07-20",
            msg = "您于2015-07-20,15:08:11获得登录奖励3250筹码。",
        },
        {
            readed = true,
            date = "2015-07-19",
            msg = "您于2015-07-19,15:08:11获得登录奖励250筹码。",
        },
        {
            readed = true,
            date = "2015-07-21",
            msg = "您于2015-07-21,15:08:11获得登录奖励2824筹码。",
        },
        {
            readed = false,
            date = "2015-07-20",
            msg = "您于2015-07-20,15:08:11获得登录奖励3250筹码。",
        },
        {
            readed = true,
            date = "2015-07-19",
            msg = "您于2015-07-19,15:08:11获得登录奖励250筹码。",
        },
    };
    self:fillMsgList(allMessages, scroll, "message/friend_page_invite_email_icon_down.png");
    --奖励相关
    local view = tab:getView(3);
    local x2,y2 = view:convertPointToSurface(0, 0);
    scrollRegion:addChild(view);
    local scroll = new(ScrollView2, 0, 0, wScroll, hScroll, true);
    view:addChild(scroll);
    --填充数据
    local allMessages =
    {
        {
            readed = true,
            msg = "每日登录，领取3082筹码",
            date = "2015-07-23",
        },
        {
            readed = true,
            msg = "每日登录，领取2824筹码",
            date = "2015-07-22",
        },
        {
            readed = true,
            msg = "每日登录，领取3250筹码",
            date = "2015-07-21",
        },
        {
            readed = false,
            msg = "大转盘，领取500筹码",
            date = "2015-07-20",
        },
        {
            readed = true,
            msg = "大转盘，领取100筹码",
            date = "2015-07-20",
        },
    };
    self:fillMsgList(allMessages, scroll, "message/user_info_send_gift_btn_icon.png");
end

MsgDialog.onPopupEnd = function(self)
    local closeBtn = self.m_root:getNodeByName("bg.btn_close");
    if(closeBtn) then
        closeBtn:setOnClick(self, self.onClickClose);
    end
end

MsgDialog.onClickClose = function(self)
    self:close();
end

MsgDialog.fillMsgList = function(self, allMessages, scroll, iconFile)
    local itemHeight = 84;
    local wScroll,hScroll = scroll:getSize();
    for _,v in pairs(allMessages) do
        local itemLine = new(DrawingEmpty);
        itemLine:setSize(wScroll, itemHeight);
        --删除按钮(对已读消息)
        if(v.readed) then
            local closeBtn = new(Button, "message/new_message_delete_down.png");
            local w,h = closeBtn:getSize();
            closeBtn:setPos(12, (itemHeight-h)/2);
            itemLine:addChild(closeBtn);
        end
        --图标
        local icon = new(Image, iconFile);
        local w,h = icon:getSize();
        icon:setPos(56, (itemHeight-h)/2);
        itemLine:addChild(icon);
        --消息内容
        --str, width, height, align, fontName, fontSize, r, g, b, fontBold,radius,dx,dy,dr,dg,db,fontItalic
        local msg = new(Text, v.msg, nil, nil, nil, nil, 20, 255, 255, 255);
        msg:setPos(116, 15);
        itemLine:addChild(msg);
        --日期
        local date = new(Text, v.date, nil, nil, nil, nil, 20, 255, 255, 255);
        date:setPos(116, 50);
        itemLine:addChild(date);
        --如果消息未读，显示按钮
        if(not v.readed) then
            local btn = NButton.create {
                normalImageFile = {
                    file = 'common/dialog/common_green_btn_up.png',
                    leftWidth = 9, 
                    rightWidth = 10, 
                    topWidth = 9, 
                    bottomWidth = 10
                }
            }

            btn:setSize(123);
            local seq = 110


            if EngineConfig.MsgDialogKnownButtonDisappearAnimation then 
                local animation = {}
                animation.play = function ()
                        local prop = btn:addPropTransparency(seq, kAnimNormal, 250, 0, 1, 0)
                        prop:setEvent(nil, function ()
                            btn:removeProp(seq)
                            btn:resume()
                        end)                
                    end
                animation.interrupt = function ()
                        btn:removeProp(seq)                        
                    end 

                btn:setAnimationOnInvisible(animation)
            end 
                

            local w,h = btn:getSize();
            btn:setPos(wScroll-137, (itemHeight-h)/2);
            itemLine:addChild(btn);
                
            local text = new(Text,  STR_COMMON_KNOW, nil, nil, nil, nil, nil, 255, 255, 255);

            text:setAlign(kAlignCenter);
            btn:addChild(text);

            btn:setOnClicked(function ()
                btn:setVisible(false);
                local closeBtn = new(Button, "message/new_message_delete_down.png");
                local w,h = closeBtn:getSize();
                closeBtn:setPos(12, (itemHeight-h)/2);
                itemLine:addChild(closeBtn);
            end);

        end
        local graphs=require("uiex/vectorGraph")
        local line=new(graphs.Line, wScroll-60)
        line:setPos(30, itemHeight)
        line:setColor(0x66, 0x99, 0xcc)
        itemLine:addChild(line)

        scroll:addChild(itemLine);
    end
end