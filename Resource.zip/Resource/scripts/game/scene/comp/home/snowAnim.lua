require("anim/animBase");
require("particle/particleSnow");

SnowAnim = class(AnimBase);

SnowAnim.load = function(parent)
	if parent ~= nil and not SnowAnim.root then
		
        local width, height = parent:getSize();
		SnowAnim.root = UIFactory.createNode();
		
		SnowAnim.root:setSize(parent:getSize());
        parent:addChild(SnowAnim.root);
		SnowAnim.root:setVisible(false);

		SnowAnim.parSnowNode = ParticleSystem.getInstance():create("animation/snow/snow.png",ParticleSnow,0,0,nil,kParticleTypeBlast,20,{["w"] = width,["h"] = height;["scale"]=1});
		SnowAnim.root:addChild(SnowAnim.parSnowNode);
	end
end

SnowAnim.play = function(parent)
	SnowAnim.stop();
	SnowAnim.load(parent);

	SnowAnim.root:setVisible(true);
	SnowAnim.parSnowNode:resume();
end

SnowAnim.stop = function()
	if SnowAnim.root then
		delete(SnowAnim.root);
		SnowAnim.root=nil;
	end
end

SnowAnim.release = function()
	SnowAnim.stop();
end