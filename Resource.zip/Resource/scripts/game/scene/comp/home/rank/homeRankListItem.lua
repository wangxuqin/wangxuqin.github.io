require("view/home/layout_home_ranking_item");
require("ui/node");
require("ui/text")
require("ui/image")
require("ui/ex/circleImage");

--[Comment]
--主页排行项
HomeRankListItem = class(Node, false)

HomeRankListItem.ctor = function (self, data)
    super(self);
    self.m_root                 = SceneLoader.load(layout_home_ranking_item);
    self.m_container            = self.m_root:getNodeByName("container");
    self.m_photoContainer       = self.m_root:getNodeByName("container.photo_container");
    self.m_imgRank              = self.m_root:getNodeByName("container.img_rank");
    self.m_txtNick              = self.m_root:getNodeByName("container.txt_nick");
    
    self.m_defaultHeadImage     = "userinfo/imgface_default_male.jpg";
    self.m_headImage = new(CircleImage,self.m_defaultHeadImage , self.m_defaultHeadImage);
    self.m_headImage:hideSide();
    self.m_headImage:setAlign(kAlignCenter);
    self.m_photoContainer:addChild(self.m_headImage);

    self.m_imgRank:setVisible(false);

    self:setAlign(kAlignTopLeft);
    self:setSize(self.m_root:getSize());
    self:addChild(self.m_root);
    self:setData(data);
end

HomeRankListItem.dtor = function (self)
    Node.dtor(self);
end

HomeRankListItem.setData = function (self,data)
    if self.m_data ~= data then
        self.m_data = data;

        local img = (self.m_data == nil) and self.m_defaultHeadImage  or self.m_data.m_img
        self.m_headImage:setFile(img);
        
        local nick = (self.m_data == nil) and ""  or self.m_data.m_nick
        self.m_txtNick:setText(nick);
        
        local imgRank = nil;
        if self.m_data ~= nil and self.m_data.m_index ~= nil and self.m_data.m_index < 4 then
            imgRank = StringKit.substitute("home/rank/headCrown_{0}.png", self.m_data.m_index);
        end
        if imgRank ~= nil then
            self.m_imgRank:setFile(imgRank);
            self.m_imgRank:setVisible(true); 
        else
            self.m_imgRank:setVisible(false);
        end

        local isNull = (data == nil) or ((data.m_img == nil) and (data.m_nick == nil) and data.m_index == nil);
        self.m_headImage:setVisible(not isNull);
    end
end