require("view/home/layout_home_ranking");
require("game/scene/comp/home/rank/homeRankListItem");

--[Comment]
--主页排行榜
HomeRankList = class(Node, false);

HomeRankList.m_index = 1; --1为世界榜, 2为好友榜
HomeRankList.m_indexName = {"money", "firends"};
HomeRankList.m_imgTitleArr = {
    "home/rank/main_rank_hand_world.png", 
    "home/rank/main_rank_hand_friends.png"
}

HomeRankList.PLUS   = 1;
HomeRankList.SUB    = 2;

HomeRankList.ctor = function(self)
    super(self);
    self.m_root                 = SceneLoader.load(layout_home_ranking);
    self.m_titleAnimContainer   = self.m_root:getNodeByName("bg.rank_title_anim_container");
    self.m_imgRankTitle         = self.m_root:getNodeByName("bg.img_rank_title");
    self.m_listContainer        = self.m_root:getNodeByName("bg.list_container");
    self.m_btnRankList          = self.m_root:getNodeByName("bg.btn_rank_list");
    self.m_btnArrowRight        = self.m_root:getNodeByName("bg.btn_arrow_right");
    self.m_btnArrowLeft         = self.m_root:getNodeByName("bg.btn_arrow_left");
    
    self.m_adapter = {};
    self:createRankList(self.m_listContainer);
    
    self:setAlign(kAlignTopLeft);
    self:setSize(self.m_root:getSize());
    self:addChild(self.m_root);
    self:addControlEventList(); --添加控件事件
    self:watchData();

    self:playTitleAnim();
end

HomeRankList.dtor = function(self)
    self:unwatchData();
    self:removeControlEventList();--移除控件事件
    Node.dtor(self);
end

HomeRankList.addControlEventList = function(self)
    if self.m_controlEventList == nil then
        self.m_controlEventList = {
            {self.m_list,           "setOnItemClick",   self.onItemClick};       --点击排行榜列表项
            {self.m_imgRankTitle,   "setEventTouch",    self.onRankTitleTouch};    --点击排行榜标题
            {self.m_btnArrowRight,  "setOnClick",       self.onRightBtnClick};   --点击>按钮
            {self.m_btnArrowLeft,   "setOnClick",       self.onLeftBtnClick};    --点击<按钮
        }
    end
    EventListKit.addEventList(self, self.m_controlEventList);
end

HomeRankList.removeControlEventList = function(self)
    if self.m_controlEventList ~= nil then
        EventListKit.removeEventList(self, self.m_controlEventList);
    end
    self.m_controlEventList = nil;
end

--[Commenet]
--绑定数据
HomeRankList.watchData = function(self)
    Model.watchData(ModelKeys.MHOME_RANKING_DATA, self, self.setData, true);
end

--[Commet]
--解除数据绑定
HomeRankList.unwatchData = function(self)
    Model.unwatchData(ModelKeys.MHOME_RANKING_DATA, self, self.setData);
end

--[Comment]
--创建排行榜
HomeRankList.createRankList = function(self, container)   
    if container ~= nil then
        local width, height = container:getSize();
        self.m_list = new(ListView2,0,0,width,height);      --构建ViewPager,后面四个参数分别为:x,y,width,height，				
   	    self.m_list:setAlign(kAlignTopLeft);
        self.m_list:setScrollBarWidth(0);                   --滚动条宽带，小于1不显示滚动条
	    self.m_list:setMaxClickOffset(5);                   --设置点击范围，即当手指按下和松开时的偏移小于offset时响应子条目点击事件,默认为5
        container:addChild(self.m_list);
    end
end

HomeRankList.playTitleAnim = function(self)
    self.m_rankTitleAnim = AtomAnimManager.getInstance():playAnim("atomAnimTable/room/anim_rank_title", self.m_titleAnimContainer, 0, 0, false);
end

--[Comment]
--更新数据
HomeRankList.setData = function(self, data)
	if self.m_data ~= data then 
        self.m_listData = {};
        self.m_listData[self.m_indexName[1]] = {};
        self.m_listData[self.m_indexName[2]] = {};
        data = data or {};
        data["money"]    = data["money"] or {};
        data["friends"]  = data["friends"] or {};
        
        local ml = #data["money"];
	    local fl = #data["friends"];
	    local n  = math.max(ml,fl);	
	    for i = 1, n do
            if i <= ml then
                table.insert(self.m_listData[self.m_indexName[1]], new(RankingVO, data["money"][i], nil, i));
            end
			   
            if i <= fl then
                table.insert(self.m_listData[self.m_indexName[2]], new(RankingVO, data["friends"][i], nil, i));
			end
	    end
        self:changeTab(self.m_index, true);
    end
end

HomeRankList.createAdapter = function(self)
    self.m_adapter = {};
    for i = 1, #self.m_indexName do
        if not(#self.m_listData[self.m_indexName[i]] > 0) then
            table.insert(self.m_listData[self.m_indexName[i]], {});
        end
        self.m_adapter[i] = new(CacheAdapter,HomeRankListItem,self.m_listData[self.m_indexName[i]]); 
    end
end


HomeRankList.changeTab = function(self, index, immediately)
    if 0 < index and index <= #self.m_indexName then
        if self.m_index ~= index or immediately == true then
            self.m_index = index;
            self:createAdapter(self);
            self.m_list:setAdapter(self.m_adapter[self.m_index]);
            self:__changeTitle(index);
        end
    end
end

--[Comment]
--切换标签
HomeRankList.__changeTitle = function(self, index)
    self.m_imgRankTitle:setFile(self.m_imgTitleArr[index]);
    KTween.remove(self.m_imgRankTitle);
    KTween.to(self.m_imgRankTitle, 200, {alpha = 0, onComplete = function() 
        KTween.remove(self.m_imgRankTitle);
        KTween.to(self.m_imgRankTitle, 200, {startAlpha = 0, alpha = 1});
    end});
end

HomeRankList.onRankTitleTouch = function(self, finger_action)
    if finger_action == kFingerUp then
        self:__changeIndex(self.PLUS);
    end
end

HomeRankList.onRightBtnClick = function(self)
    self:__changeIndex(self.PLUS);
end

HomeRankList.onLeftBtnClick = function(self)
    self:__changeIndex(self.SUB);
end

HomeRankList.__changeIndex = function(self, flag)
    flag = flag or HomeRankList.PLUS;
    local index = self.m_index;
    if flag == HomeRankList.PLUS then
        index = index + 1;
        if index > #self.m_indexName then
            index = 1;
        end
    elseif flag == HomeRankList.SUB then
        index = index - 1;
        if index < 1 then
            index = #self.m_indexName;
        end
    end
    
    self:changeTab(index);
end

HomeRankList.onItemClick=function (self,adapter,view,index)
     EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_PER_RANKING_DIALOG);    --打开个人排行榜
end