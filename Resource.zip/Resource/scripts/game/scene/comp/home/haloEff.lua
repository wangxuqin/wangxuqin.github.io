require("view/home/layout_home_halo_eff");
--[Comment]
--光晕特效
HaloEff = class(Node)

HaloEff.ctor = function(self)
    self.m_root = SceneLoader.load(layout_home_halo_eff);
    self.m_imgEllipse = self.m_root:getNodeByName("bg.img_ellipse");
    self.m_imgRatoteRay = self.m_root:getNodeByName("bg.img_rorate_ray");
    self:addChild(self.m_root);
end

HaloEff.dtor = function(self)
    KTween.remove(self.m_imgEllipse);
    KTween.remove(self.m_imgRatoteRay);
    Node.dtor(self);
end

HaloEff.playAnim = function(self)
    KTween.remove(self.m_imgEllipse);
    KTween.remove(self.m_imgRatoteRay);
    KTween.to(self.m_imgEllipse, 1500, {startAlpha = 1, alpha = 0.5, animType=kAnimLoop});
    KTween.to(self.m_imgRatoteRay, 50000, {startAngle= 0, angle = 360, animType=kAnimRepeat});
end