require("view/system/layout_system_about_popup");

--���ڶԻ���
FriendDialog = class(PopupDialog, false);

FriendDialog.ctor = function (self)
    super(self,layout_system_about_popup,true);
end


FriendDialog.dtor = function (self)
    
end

FriendDialog.onPopupEnd = function (self)
    self:getCtrls();    
    self:init();    
end

FriendDialog.getCtrls = function(self)   
    self.m_btnClose     = self.m_root:getNodeByName("bg.btn_close");
    self.m_btnService   = self.m_root:getNodeByName("bg.btn_service");
    self.m_txtTitle     = self.m_root:getNodeByName("bg.txt_title");
    self.m_txtVersion   = self.m_root:getNodeByName("bg.txt_version");
    self.m_txtContact1  = self.m_root:getNodeByName("bg.txt_contact1");
    self.m_txtContact2  = self.m_root:getNodeByName("bg.txt_contact2");
    self.m_txtCompany   = self.m_root:getNodeByName("bg.txt_company");
    self.m_txtService   = self.m_root:getNodeByName("bg.btn_service.txt_service");
    self.m_topLight     = self.m_root:getNodeByName("bg.img_top_light");
    self.m_txtCompany   = self.m_root:getNodeByName("bg.txt_company");
end

FriendDialog.init = function(self)   
    self.m_btnClose:setOnClick(self,self.onCloseBtnClick);
    self.m_btnService:setOnClick(self,self.onServiceBtnClick);
    self.m_txtTitle:setText(STR_SETTING_ABOUT_POPUP_TITLE); 
    self.m_txtVersion:setText(StringKit.substitute(STR_SETTING_ABOUT_CURRENT_VERSION,"2.2.0"));
    self.m_txtContact1:setText(STR_SETTING_ABOUT_CUSTOMER_SERVICE);
    self.m_txtContact2:setText(STR_SETTING_ABOUT_OFFICIAL_WEIXIN);   
    self.m_txtCompany:setText(STR_SETTING_COMPANY_NAME_AND_ICP);
    self.m_txtService:setText(STR_SETTING_THE_TERMS_OF_SERVICE_AND_PRIVACY);
    self.m_topLight:setTransparency(0.6);
end

FriendDialog.onCloseBtnClick = function(self)
    self:close();
end

FriendDialog.onServiceBtnClick = function(self)
    Log.d("FriendDialog", "onServiceBtnClick");
end
