require("ui/node");
require("view/ranking/layout_ranking_per_list_item");
PerRankListItem = class(Node)
PerRankListItem.m_select = false;

PerRankListItem.ctor = function(self,data)  
    self:setSize(600,74); 
    self.m_root = SceneLoader.load(layout_ranking_per_list_item);
    self:addChild(self.m_root);

    self.m_data = data;

    self:getCtrls();
    self:init();
end

PerRankListItem.dtor = function(self)
   
end

PerRankListItem.getCtrls = function(self)
    self.m_imgRankingIcon   = self.m_root:getNodeByName("bg.imgRankingIcon");
    self.m_txtRankingNum    = self.m_root:getNodeByName("bg.imgRankingIcon.txtRankingNum");
    self.m_imgDefualtHead     = self.m_root:getNodeByName("bg.imgDefualtHead");
    self.m_txtName       = self.m_root:getNodeByName("bg.txtName");
    self.m_txtChips      = self.m_root:getNodeByName("bg,txtChips");
    self.m_imgChangeArrow = self.m_root:getNodeByName("bg.imgChangeArrow"); 
end

PerRankListItem.init = function(self)

  --data�����
     self.m_txtRankingNum:setText("10");
     self.m_imgChangeArrow:setVisible(true);
end



