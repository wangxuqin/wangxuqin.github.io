require("view/ranking/layout_ranking_per");
require("game/scene/comp/ranking/perRankTabPage");

RankingDialog = class(PopupDialog, false)

RankingDialog.TAB_ASSET_PAGE      = 1;
RankingDialog.TAB_LEVEL_PAGE      = 2;
RankingDialog.TAB_ACHIEVE_PAGE    = 3;

RankingDialog.ctor = function (self)
    super(self,layout_ranking_per,true);

    self.m_data={1,2,3,4,5,6,7,8,9,10};--待修改：Model.getData()
end


RankingDialog.dtor = function (self)
   self.m_pageArr = nil;
end

RankingDialog.onPopupEnd = function (self)
    self:getCtrls();    
    self:init();    
end

RankingDialog.getCtrls = function(self)   
    self.m_btnClose             = self.m_root:getNodeByName("bg.btn_close");
    self.m_txtTitle             = self.m_root:getNodeByName("bg.img_top.txt_title");
    self.m_tabContainer         = self.m_root:getNodeByName("bg.tab_container");

    self.m_assetContainer       = self.m_root:getNodeByName("bg.asset_container");
    self.m_levelContainer       = self.m_root:getNodeByName("bg.level_container");
    self.m_achieveContainer     = self.m_root:getNodeByName("bg.achieve_container");  

    self.m_pageArr = {
        [self.TAB_ASSET_PAGE]  = self.m_assetContainer;
        [self.TAB_LEVEL_PAGE]   = self.m_levelContainer;
        [self.TAB_ACHIEVE_PAGE]    = self.m_achieveContainer;
    };

end

RankingDialog.init = function(self)
    self.m_initPageFlagArr = {};   
    self.m_btnClose:setOnClick(self,self.onBtnClickClose);
    self.m_txtTitle:setText(STR_SETTING_RANKING_POPUP_TITLE); 

    self.m_tab = new(ButtonTag);
    self.m_tab:setButtonTagVerticalMul(STR_RANKING_RANKING_TAB_ITEM,
                                            "help/page-pop-up-tab-bg.png",
                                            "help/page-pop-up-tab-group-vernier.png",
                                            "help/page-pop-up-tab-group-vernier.png",
                                            230,240,10,10,16,16,12,12,4,29,true,32);  
    self.m_tab.buttonSlide:setPos(-10);
    self.m_tab.buttonSlide:setSize(250);
    self.m_tab:setOnTagChangedAnimEnd(self,self.onTabChanged);
    self.m_tabContainer:addChild(self.m_tab);  
    
    self:onTabChanged(1);
end

RankingDialog.onTabChanged = function(self,index)   
    for i = 1, #self.m_pageArr do
		local page = self.m_pageArr[i];
		page:setVisible(index == i);
	end
    
    if index == self.TAB_ASSET_PAGE then     
      self.m_pageArr[RankingDialog.TAB_ASSET_PAGE]:removeAllChildren();
      self.m_assetPage = new(PerRankTabPage,RankingDialog.TAB_ASSET_PAGE,self.m_data);
      self.m_pageArr[self.TAB_ASSET_PAGE]:addChild(self.m_assetPage);
        
    elseif index ==self.TAB_LEVEL_PAGE then
      self.m_pageArr[RankingDialog.TAB_LEVEL_PAGE]:removeAllChildren();
      self.m_levelPage = new(PerRankTabPage,RankingDialog.TAB_LEVEL_PAGE,self.m_data);
      self.m_pageArr[self.TAB_LEVEL_PAGE]:addChild(self.m_levelPage);
    else 
       -- if Model.getData(ModelKeys.USER_DATA)~=nil then
      self.m_pageArr[RankingDialog.TAB_ACHIEVE_PAGE]:removeAllChildren();
      self.m_achievePage = new(PerRankTabPage,RankingDialog.TAB_ACHIEVE_PAGE,self.m_data);
      self.m_pageArr[self.TAB_ACHIEVE_PAGE]:addChild(self.m_achievePage);
    end
end

RankingDialog.hideAllPage = function(self)
    if self.m_pageArr ~= nil then
        for i = 1, #self.m_pageArr do
            self.m_pageArr[i]:setVisible(false);
        end
    end
end


RankingDialog.onBtnClickClose = function(self)
    self:close();
end