require("ui/node");
require("view/ranking/layout_ranking_per_page");



PerRankListPage = class(Node)

PerRankListPage.ctor = function(self)
    self:setSize(630,490);
    self.m_root = SceneLoader.load(layout_ranking_per_page);   
    self:addChild(self.m_root);
    
    self:getCtrls();
    self:init();
end

PerRankListPage.dtor = function(self)
   
end

PerRankListPage.getCtrls = function(self)
    self.m_tabContainer               = self.m_root:getNodeByName("container.tab_container");  
    
    self.m_txt_info_asset             = self.m_root:getNodeByName("container.asset_container.info_container.txt_info");
    self.m_txt_info_level             = self.m_root:getNodeByName("container.level_container.info_container.txt_info");
    self.m_txt_info_achieve           = self.m_root:getNodeByName("container.achieve_container.info_container.txt_info");

    self.m_level_container            = self.m_root:getNodeByName("container.level_container");
    self.m_asset_container            = self.m_root:getNodeByName("container.asset_container");
    self.m_achieve_container          = self.m_root:getNodeByName("container.achieve_container");

    self.m_pageArr = {
       [1] = self.level_container;
       [2] = self.m_level_container;
       [3] = self.m_achieve_container;
    };     
end

PerRankListPage.init = function(self)
    self.m_tab = new(ButtonTag);
    self.m_tab:setButtonTagHorizontalSingle(STR_RANKING_RANKING_TOP_TAB_ITEM,
                                             "help/common-tab-bar-background.png", 600, 50,
                                             "help/common-tab-bar-selector-background.png",
                                             10,10,10,10,10,10,5,5,3,3,24); 
    self.m_tab.buttonSlide:setPos(nil,-1);  
    self.m_tab:setOnTagChangedAnimEnd(self,self.onTabChanged);                                           
    self.m_tabContainer:addChild(self.m_tab); 

    self:initConfigStr();
    
    self:creatAssetPage();
    self:creatLevelPage();
    self:creatAchievePage();
     
end


PerRankListPage.creatAssetPage = function(self)   
    self.m_assetList = new(ScrollView2,0,0,600,392);					    						
   	self.m_assetList:setScrollBarWidth(0);								
    self.m_asset_container:addChild(self.m_assetList);
    self.m_txt_info_asset:setText(STR_RANKING_RANKING_FORMAT_RESOURCE[1]);
    self:setData(self.m_assetList,nil);
end


PerRankListPage.creatLevelPage = function(self)   
    self.m_levelList = new(ScrollView2,0,0,600,392);					    						
   	self.m_levelList:setScrollBarWidth(0);								
    self.m_level_container:addChild(self.m_levelList);
    self.m_txt_info_level:setText(STR_RANKING_RANKING_FORMAT_RESOURCE[1]);
    self:setData(self.m_levelList,nil);
end

PerRankListPage.creatAchievePage = function(self)   
    self.m_achieveList = new(ScrollView2,0,0,600,392);					    						
   	self.m_achieveList:setScrollBarWidth(0);								
    self.m_achieve_container:addChild(self.m_achieveList);
     self.m_txt_info_achieve:setText(STR_RANKING_RANKING_FORMAT_RESOURCE[1]);
    self:setData(self.m_achieveList,nil);
end

PerRankListPage.setData = function(self,list,data)   
--    local txtItem = {};

--    for i = 1,#data do
--        txtItem[i] = new(StaticTxtItem,data[i]);        
--        if i > 1 then 
--            local _,h = txtItem[i-1].m_bg:getSize();
--            local _,y = txtItem[i-1]:getPos();             
--            txtItem[i]:setPos(0,y+h+10); 
--        end

        for i=1,10 do
        local item=new(PerRankListItem,nil);
        list:addChild(item);   
    end    
end

PerRankListPage.onTabChanged = function(self,index)   
    for i = 1, #self.m_pageArr do
		local page = self.m_pageArr[i];
		page:setVisible(index == i);
	end

    if index == 1 then
        if self.m_initPageFlagArr[self.TAB_NORMAL_PAGE] ~= true then
            self.m_normalPage = new(NormalPage);
            self.m_pageArr[self.TAB_NORMAL_PAGE]:addChild(self.m_normalPage);
            self.m_initPageFlagArr[self.TAB_NORMAL_PAGE] = true;
        end
        self.m_pageArr[self.TAB_NORMAL_PAGE]:setVisible(true);
    
    elseif index ==2 then
        self.m_pageArr[2]:removeAllChildren();
        self.m_basicPage = new(BasicPage);
        self.m_pageArr[2]:addChild(self.m_basicPage);
    elseif index ==3 then


end

--[comment] 多国语言配置
PerRankListPage.initConfigStr = function(self)   
    self.m_txtCardContainerArr = {};
    self.m_txtRuleContainerArr = {};

    for i = 1, 10 do   
         self.m_txtCardContainerArr[i] = self.m_root:getNodeByName(tostring("container.card_container.bg.scrollview.txt"..i));     
         self.m_txtCardContainerArr[i]:setText(STR_SETTING_HELP_CONTENT.page[1].section[i].title);
    end 


    for i = 1, 4 do
        self.m_txtRuleContainerArr[i]           = self.m_txtRuleContainerArr[i] or {};
        self.m_txtRuleContainerArr[i].title     = self.m_root:getNodeByName(tostring("container.rule_container.bg.scrollview.txt_title"..i));
        self.m_txtRuleContainerArr[i].content   = self.m_root:getNodeByName(tostring("container.rule_container.bg.scrollview.txt_content"..i));

        self.m_txtRuleContainerArr[i].title:setText(STR_SETTING_HELP_CONTENT.page[2].section[i].title);
        self.m_txtRuleContainerArr[i].content:setText(STR_SETTING_HELP_CONTENT.page[2].section[i].content);
    end

    self.m_txtCardRule      = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_card_rule");
    self.m_txtPublicCard    = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_public_card");
    self.m_txtPlus1         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_plus1");
    self.m_txtPlus2         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_plus2");
    self.m_txtPlayerA       = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerA");
    self.m_txtPlayerB       = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerB");
    self.m_txtLoser         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.img_loser.txt_loser");
    self.m_txtWinner        = self.m_root:getNodeByName("container.rule_container.bg.scrollview.img_winner.txt_winner");
    self.m_txtPlayerABest   = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerA_best");
    self.m_txtPlayerBBest   = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerB_best");
    self.m_txtTypeA         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_typeA");
    self.m_txtTypeB         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_typeB");


    self.m_txtCardRule:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].title);
    self.m_txtPublicCard:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.pub_poker);
    self.m_txtPlus1:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.plus);
    self.m_txtPlus2:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.plus);
    self.m_txtPlayerA:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.a_poker);
    self.m_txtPlayerB:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.b_poker);
    self.m_txtLoser:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.loser);
    self.m_txtWinner:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.winner);
    self.m_txtPlayerABest:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.a_best_poker);
    self.m_txtPlayerBBest:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.b_best_poker);
    self.m_txtTypeA:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.poker_1);
    self.m_txtTypeB:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.poker_2);
end

