require("game/scene/comp/ranking/perRankListItem");
require("view/ranking/layout_ranking_per_page_tab");

PerRankTabPage = class(Node)

PerRankTabPage.ctor = function(self,typeEnum,data)
    self:setSize(630,490);
    self.m_root = SceneLoader.load(layout_ranking_per_page_tab);
    self:addChild(self.m_root);
    self.m_type=typeEnum;
    self.m_data=data;
    self.m_data1={1,2,3};
    self:getCtrls();
    self:init();
end

PerRankTabPage.dtor = function(self)
   
end

PerRankTabPage.getCtrls = function(self)
    self.m_tabContainer             = self.m_root:getNodeByName("container.tab_container");  
    self.m_allContainer             = self.m_root:getNodeByName("container.all_container");     
    self.m_txtInfoAll            = self.m_root:getNodeByName("container.all_container.txt_allInfo");
    self.m_friendContainer             = self.m_root:getNodeByName("container.friend_container");     
    self.m_txtInfoFriend            = self.m_root:getNodeByName("container.friend_container.txt_friInfo");
    self.m_pageArr = {
       [1] = self.m_allContainer;
       [2] = self.m_friendContainer;     
    };     
end

PerRankTabPage.init = function(self)
    self.m_tab = new(ButtonTag);
    self.m_tab:setButtonTagHorizontalSingle(STR_RANKING_RANKING_TOP_TAB_ITEM,
                                             "help/common-tab-bar-background.png", 600, 50,
                                             "help/common-tab-bar-selector-background.png",
                                             10,10,10,10,10,10,5,5,3,3,24); 
    self.m_tab.buttonSlide:setPos(nil,-1);  
    self.m_tab:setOnTagChangedAnimEnd(self,self.onTabChanged);                                           
    self.m_tabContainer:addChild(self.m_tab); 

    self:creatAllPage();
    self:creatFriendPage();
     
end


PerRankTabPage.creatAllPage = function(self) 
    self.m_allList = new(ListView2, 0, 34, 590, 360);							
    self.m_allContainer:addChild(self.m_assetList);
    self.m_txtInfoAll:setText("全部排行");--STR_RANKING_MY_RANKING
    self.m_adapterAll = new(CacheAdapter, PerRankListItem, self.m_data1);
    self.m_allList:setAdapter(self.m_adapterAll);
end


PerRankTabPage.creatFriendPage = function(self)   
    self.m_friendList =  new(ListView2, 0, 34, 590, 360);							
    self.m_friendContainer:addChild(self.m_friendList);
    self.m_txtInfoFriend:setText("好友排行");

    self.m_adapterFri = new(CacheAdapter, PerRankListItem, self.m_data);
    self.m_friendList:setAdapter(self.m_adapterFri);
   
end

PerRankTabPage.onTabChanged = function(self,index)   
    for i = 1, #self.m_pageArr do
		local page = self.m_pageArr[i];
		page:setVisible(index == i);
	end
end

--[comment] 多国语言配置
--PerRankTabPage.initConfigStr = function(self)   
--    self.m_txtCardContainerArr = {};
--    self.m_txtRuleContainerArr = {};

--    for i = 1, 10 do   
--         self.m_txtCardContainerArr[i] = self.m_root:getNodeByName(tostring("container.card_container.bg.scrollview.txt"..i));     
--         self.m_txtCardContainerArr[i]:setText(STR_SETTING_HELP_CONTENT.page[1].section[i].title);
--    end 


--    for i = 1, 4 do
--        self.m_txtRuleContainerArr[i]           = self.m_txtRuleContainerArr[i] or {};
--        self.m_txtRuleContainerArr[i].title     = self.m_root:getNodeByName(tostring("container.rule_container.bg.scrollview.txt_title"..i));
--        self.m_txtRuleContainerArr[i].content   = self.m_root:getNodeByName(tostring("container.rule_container.bg.scrollview.txt_content"..i));

--        self.m_txtRuleContainerArr[i].title:setText(STR_SETTING_HELP_CONTENT.page[2].section[i].title);
--        self.m_txtRuleContainerArr[i].content:setText(STR_SETTING_HELP_CONTENT.page[2].section[i].content);
--    end

--    self.m_txtCardRule      = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_card_rule");
--    self.m_txtPublicCard    = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_public_card");
--    self.m_txtPlus1         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_plus1");
--    self.m_txtPlus2         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_plus2");
--    self.m_txtPlayerA       = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerA");
--    self.m_txtPlayerB       = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerB");
--    self.m_txtLoser         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.img_loser.txt_loser");
--    self.m_txtWinner        = self.m_root:getNodeByName("container.rule_container.bg.scrollview.img_winner.txt_winner");
--    self.m_txtPlayerABest   = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerA_best");
--    self.m_txtPlayerBBest   = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerB_best");
--    self.m_txtTypeA         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_typeA");
--    self.m_txtTypeB         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_typeB");


--    self.m_txtCardRule:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].title);
--    self.m_txtPublicCard:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.pub_poker);
--    self.m_txtPlus1:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.plus);
--    self.m_txtPlus2:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.plus);
--    self.m_txtPlayerA:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.a_poker);
--    self.m_txtPlayerB:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.b_poker);
--    self.m_txtLoser:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.loser);
--    self.m_txtWinner:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.winner);
--    self.m_txtPlayerABest:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.a_best_poker);
--    self.m_txtPlayerBBest:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.b_best_poker);
--    self.m_txtTypeA:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.poker_1);
--    self.m_txtTypeB:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.poker_2);
--end

