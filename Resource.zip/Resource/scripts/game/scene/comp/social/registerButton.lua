--[Comment]
--报名按钮
RegisterButton = class(DynamicHitAreaButton, false);

--[Comment]
-- 创建一个报名按钮
-- @param bmg 按钮显示文字
-- @param data 报名所需要的具体数据
-- @param w 按钮宽度
-- @param h 按钮高度
RegisterButton.ctor = function(self, str, data, w, h, normalFile, disableFile)
	super(self, normalFile, disableFile, w, h)
    self.m_data = data;
	
    --是推送消息
	self.m_data.push    = "true";
    self:addControlEventList();
end
		
RegisterButton.dtor = function(self)
    self:removeControlEventList();
    RegisterButton.dtor(self);
end

--[Comment]
--加入控件事件
ShareButton.addControlEventList = function(self)
    if self.m_controlEventList == nil then
        self.m_controlEventList = {
            {self, "setOnClick", self.onTriggered};
        }
    end
    EventListKit.addEventList(self, self.m_eventList);
end

--[Comment]
--移除控件事件
ShareButton.removeControlEventList = function(self)
    if self.m_controlEventList ~= nil then
        EventListKit.removeEventList(self, self.m_eventList);
    end
    self.m_controlEventList = nil;
end

--[Comment]
--报名弹框 
ShareButton.onTriggered = function(self)
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOURNAMENT_APPLY, self.m_data);--报名弹框
end