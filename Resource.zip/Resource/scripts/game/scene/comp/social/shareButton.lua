require("ui/ex/dynamicHitAreaButton");
--[Comment]
--分享按钮
ShareButton = class(DynamicHitAreaButton, false)
ShareButton.m_platforms                 = {"FACEBOOK"};
ShareButton.m_feedId                    = nil;
ShareButton.m_shareCallback             = nil;
ShareButton.ShareSDKExtension           = nil;
ShareButton.PlatformID                  = nil;
ShareButton.ShareMenuArrowDirection     = nil;
ShareButton.shareSDk                    = nil;
	
--[Comment]	
--创建一个分享按钮
--@param feedId 语言包中的FeedId，默认取这个构造分享数据
--@param onShareCallback 分享之前的数据处理回调 function(data:Object):void 进行默认构造的分享数据的修改及定制
ShareButton.ctor = function(self, feedId, onShareCallback, w, h, normalFile, disableFile)
    super(self, normalFile, disableFile, w, h)
	self.m_feedId = feedId;
	self.m_shareCallback = onShareCallback;
    self:addControlEventList();
    self:watchData();
end

ShareButton.dtor = function(self)
	self:unwatchData();
    self:removeControlEventList();
    DynamicHitAreaButton.dtor(self);
end

--[Comment]
--加入控件事件
ShareButton.addControlEventList = function(self)
    if self.m_controlEventList == nil then
        self.m_controlEventList = {
            {self, "setOnClick", self.onTriggered};
        }
    end
    EventListKit.addEventList(self, self.m_eventList);
end

--[Comment]
--移除控件事件
ShareButton.removeControlEventList = function(self)
    if self.m_controlEventList ~= nil then
        EventListKit.removeEventList(self, self.m_eventList);
    end
    self.m_controlEventList = nil;
end

--[Comment]
--加入数据监听
ShareButton.watchData = function(self)
    if self.m_watchDataList == nil then
        self.m_watchDataList = {
            {ModelKeys.SOCIAL_SHARE_ENABLED, self,   self.onSocialEnabledChange, true};
	        {ModelKeys.SOCIAL_SHARE_BUSY,    self,   self.onShareBusy,true};		
        };
    end
    Model.watchData(self.m_watchDataList);
end

--[Comment]
--移除数据监听
ShareButton.unwatchData = function(self)
    if self.m_watchDataList ~= nil then
        Model.unwatchData(self, self.m_watchDataList);
    end
    self.m_watchDataList = nil;
end
		
ShareButton.onShareBusy = function(self, val)
    self:setEnabled(not val);
end
	
--[Comment]
--点击事件处理	
ShareButton.onTriggered = function(self)		
	self:doFeed();
end
		
--[Comment]
--分享
ShareButton.doFeed = function(self)
	local data = {["platforms"] = self.m_platforms};
	local feed = STR_SOCIAL_CONFIG[self.m_feedId];
	if feed ~= nil then
		if feed.name ~= nil then
			data["name"] = feed.name;
		end

        if feed.caption ~= nil then
			data["caption"] = feed.caption;
		end

        if feed.message ~= nil then
			data["message"] = feed.message;
		end
		
        if feed.description ~= nil then
			data["description"] = feed.description;
		end
		
		if feed.picture ~= nil then
			data["picture"] = feed.picture;
		end

        if feed.link ~= nil then
			data["link"] = feed.link;
		end
		
		if self.m_shareCallback ~= nil then
			self.m_shareCallback(data);
		end
	end
	data.feedId = self.m_feedId;
	EventDispatch.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.SOCIAL_SHARE, data);
end
		
ShareButton.onSocialEnabledChange = function(self, val)
	self:setAlpha(val and 1 or 0);
end