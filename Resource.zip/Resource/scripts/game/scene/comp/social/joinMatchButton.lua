--[Comment]
--参赛按钮
JoinMatchButton = class(DynamicHitAreaButton, false)
JoinMatchButton.m_enterMatchObj = nil;
		
--[Comment]
-- 创建一个参赛按钮
-- @param bmg 按钮显示文字
-- @param data 参赛所需要的具体数据
-- @param w 按钮宽度
-- @param h 按钮高度
JoinMatchButton.ctor = function(self, text, enterMatchObj, w, h, normalFile, disableFile) 
    super(self, normalFile, disableFile, w, h)
    self.m_enterMatchObj = enterMatchObj;
    self:setOnClick(self, self.onGotoBtnTriggered);
end

JoinMatchButton.dtor = function(self)
	self:setOnClick(nil, nil);
    DynamicHitAreaButton.dtor(self);
end

--[Comment]
--场景切换
JoinMatchButton.onGotoBtnTriggered = function(self)
	local roomData = {["tid"] = 0, ["ip"] = self.m_enterMatchObj.ip, ["port"] = self.m_enterMatchObj.port};
	if StateMachine.getInstance():getCurrentState() == States.Room then
		Model.setData(ModelKeys.ROOM_ENTER_MATCH_DATA, self.m_enterMatchObj);-- 用户在比游戏中
	
    elseif StateMachine.getInstance():getCurrentState() == States.NormalHall then
	    EventDispatcher.getInstance():dispatch(
            ScreenEvent.s_event, 
            ScreenEvent.s_cmd.NORMAL_HALL_2_GAME_ROOM);

		EventDispatcher.getInstance():dispatch(
            CommandEvent.s_event, 
            CommandEvent.s_cmd.PREPARE_LOGIN_ROOM, 
            {["playNow"] = false, ["enterFrom"] = RequestLoginData.NORMAL_HALL, ["roomInfo"] = roomData});
    
    elseif StateMachine.getInstance():getCurrentState() == States.Home then
        EventDispatcher.getInstance():dispatch(
            ScreenEvent.s_event, 
            ScreenEvent.s_cmd.MAIN_PAGE_2_GAME_ROOM);
		
        EventDispatcher.getInstance():dispatch(
            CommandEvent.s_event, 
            CommandEvent.s_cmd.PREPARE_LOGIN_ROOM, 
            {["playNow"] = false, ["enterFrom"] = RequestLoginData.MAIN_PAGE, ["roomInfo"] = roomData});
	end
end