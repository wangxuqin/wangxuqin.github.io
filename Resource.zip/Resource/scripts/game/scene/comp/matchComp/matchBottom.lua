require("ui/node");
require("view/hall/layout_match_bottom");

MatchBottom = class(Node)

MatchBottom.ctor = function(self)
    self:setSize(1280,101);
    self.m_root = SceneLoader.load(layout_match_bottom);
    self.m_root:setVisible(false);
    self:addChild(self.m_root);
   
    self:getCtrls();
end

MatchBottom.dtor = function(self)
   
end

MatchBottom.getCtrls = function(self)
    self.m_bg                           = self.m_root:getNodeByName("bg");
    self.m_txtPoints                    = self.m_root:getNodeByName("bg.txt_points");
    self.m_txtRank                      = self.m_root:getNodeByName("bg.img_ranking_bg.txt_ranking");
    self.m_txtDistance                  = self.m_root:getNodeByName("bg.txt_distance");
    self.m_txtMoney                     = self.m_root:getNodeByName("bg.txt_money");
    self.m_imgUp                        = self.m_root:getNodeByName("bg.img_up");
    self.m_imgDown                      = self.m_root:getNodeByName("bg.img_down");
    self.m_txtTotalCompeteNum           = self.m_root:getNodeByName("bg.txt_total_compete_num");  
    self.m_txtCup1                      = self.m_root:getNodeByName("bg.txt_cup1");
    self.m_txtCup2                      = self.m_root:getNodeByName("bg.txt_cup2");
    self.m_txtCup3                      = self.m_root:getNodeByName("bg.txt_cup3");

    self.m_cupVector = {
        [1] = self.m_txtCup1;
        [2] = self.m_txtCup2;
        [3] = self.m_txtCup3;
    };
end

MatchBottom.playAnim = function(self)
    KTween.to(self.m_bg, 600, {startY = 400, y = 0, startAlpha = 0, alpha = 1, easeType = EaseType.SinOut});
    self.m_root:setVisible(true);            
end


MatchBottom.showInfo = function(self,data)
    self.m_data = data;
    self.m_txtPoints:setText(data.soc); 
     --����Ϊ0��ʱ������ʾ-		
	self.m_txtRank:setText(data.ranking == "0" and "-" or data.ranking);

	--��������999����ʾ-
    self.m_txtRank:setText(tonumber(data.ranking) > 999 and "-" or data.ranking);
    self.m_txtDistance:setText(StringKit.substitute(STR_MATCH_MATCH_DISTANCE_MSG,data.distance));  
    self.m_txtMoney:setText("+"..tostring(data.inCome)); 
    
    if data.chain~=0 then
		data.chain = 1 and self:__showUpOrDown(true) or self:__showUpOrDown(false);
	end

    self:__productContainer(data.prize);
         
end

MatchBottom.__showUpOrDown = function(self,isShowUpOrDown)
    self.m_imgUp:setVisible(isShowUpOrDown);
    self.m_imgDown:setVisible(not isShowUpOrDown);             
end

MatchBottom.__productContainer = function(self,str)
   if str == nil or str=="" then return; end
   self.m_rest=StringKit.split(str,",");
   self.m_txtTotalCompeteNum:setText(StringKit.substitute(STR_MATCH_MATCH_TOTALENTRIES,self.m_rest[1]));

   for i=2,#self.m_rest do
       self.m_cupVector[i-1]:setText(self.m_rest[i]);    
   end              
end

