require("view/gift/layout_gift_dialog");
require("game/scene/comp/gift/giftInfoItem");
--[Comment]
--礼物对话框
GiftDialog = class(PopupDialog, false);
GiftDialog.TAG = "GiftDialog";


GiftDialog.ctor = function(self)
    super(self, layout_gift_dialog, true);
end


GiftDialog.dtor = function(self)
    PopupDialog.dtor(self);
end

GiftDialog.update = function (self, data)
    if not data or type(data) ~= "table" then
        return;
    end
    self:isInRoom(data.isInRoom);
    self:setUserId(data.userId);
    self:setSeatId(data.seatId);
    self:setUserNick(data.uiseNick);
    self:setTab(data.tabId);
end

GiftDialog.onPopupEnd = function(self)
    self:getCtrls();
    self:initialize();
	Model.setData(ModelKeys.HAS_POP_UP, true);
    self:addEventList();
    self:watchData();
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.GIFT_DIALPG_ON_POPUP_END);
end

--关闭弹窗
GiftDialog.close = function(self)
    self:unwatchData();
    self:removeEventList();
    Model.setData(ModelKeys.HAS_POP_UP, false);
    PopupDialog.close(self);
    --关闭有此弹窗打开的弹窗
end

GiftDialog.addEventList = function(self)
    if self.m_eventList == nil then
        self.m_eventList = {
            {UIEvent,       UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM,                      "close"};
            {CommandEvent,  CommandEvent.s_cmd.GIFT_SALE_BUTTON_STATUS_CHANGE_DARK,     "saleGiftButtonDarkHandler"};
            {CommandEvent,  CommandEvent.s_cmd.GIFT_SALE_BUTTON_STATUS_CHANGE_LIGHT,    "saleGiftButtonLightHandler"};
        };
    end
    EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
end

GiftDialog.removeEventList = function(self)
    if self.m_eventList ~= nil then
        EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
    end
    self.m_eventList = nil;
end

GiftDialog.watchData = function(self)
    if self.m_watchDataList == nil then
        self.m_watchDataList = {
            {ModelKeys.GIFT_LIST_DISPLAYING, self, self.giftListDisplaying, false};
        }
    end
    Model.watchDataList(self.m_watchDataList);
end

GiftDialog.unwatchData = function(self)
    if self.m_watchDataList ~= nil then
        Model.unwatchDataList(self.m_watchDataList);
    end
    self.m_watchDataList = nil;
end

GiftDialog.getCtrls = function(self)
    self.m_btnClose                 = self.m_root:getNodeByName("bg.btn_close");
    self.m_imgTopLight              = self.m_root:getNodeByName("bg.img_top_light");
    self.m_leftContainer            = self.m_root:getNodeByName("bg.left_container");
    self.m_txtTitle                 = self.m_root:getNodeByName("bg.left_container.txt_title");
    self.m_topContainer             = self.m_root:getNodeByName("bg.top_container");
    self.m_rightContainer           = self.m_root:getNodeByName("bg.right_container");
    self.m_btnQuicklySalesGift      = self.m_root:getNodeByName("bg.btn_quickly_sales_gift");
    self.m_txtQuicklySalesGift      = self.m_root:getNodeByName("bg.btn_quickly_sales_gift.txt_quickly_sales_gift");
    self.m_loadAnimContainer        = self.m_root:getNodeByName("bg.load_anim_container");
    self.m_imgBottomOverLay         = self.m_root:getNodeByName("bg.img_bottom_over_lay");
end

-- 初始化
GiftDialog.initialize = function(self)
    self.m_btnQuicklySalesGift:setVisible(false);
    self.m_btnQuicklySalesGift:setOnClick(self, self.quicklySaleGiftButtonHandler);
    self.m_btnClose:setOnClick(self, self.onCloseBtnClick);
    self.m_imgTopLight:setTransparency(0.6);
    self.m_txtTitle:setText(STR_GIFT_GIFT_CATEGORY);
    self.m_txtQuicklySalesGift:setText(STR_GIFT_SALE_ALL_DUE_GIFT_HINT);
    self.m_topItems = Model.getData(ModelKeys.STORE_SUPPORT_BY) or STR_GIFT_TOP_CATEGORY_ITEM_3 and STR_GIFT_TOP_CATEGORY_ITEM_2;
    if self.m_topItems == STR_GIFT_TOP_CATEGORY_ITEM_3 then
        self.m_giftIndex = 3;
    elseif self.m_topItems == STR_GIFT_TOP_CATEGORY_ITEM_2 then
        self.m_giftIndex = 2;
    end
    self:initTopContainer(self.m_topItems);
    self:initLeftContainer(STR_GIFT_LEFT_CATEGORY_ITEM);
    --self:initRightContainer();
end

--[Comment]
--topItems -> STR_GIFT_TOP_CATEGORY_ITEM_3 or STR_GIFT_TOP_CATEGORY_ITEM_2
GiftDialog.initTopContainer = function(self, topItems)
    if not self.m_topTab then
        self.m_topTab = new(ButtonTag);
        self.m_topTab:setButtonTagHorizontalSingle(topItems,
                                            "common/common_tab_bar_background.png",#topItems * 250,66,
                                            "common/common_tab_bar_selector_background.png",
                                            10,10,10,10,15,15,15,15,2,2,24); 
        self.m_topTab:setOnTagChangedAnimEnd(self,self.onTopTabChanged);
        for i = 1, #topItems do
            self.m_topTab.bgImg[i].text:setColor(21, 127, 186);
        end
        self.m_topSelectedIndex = 1;
        self.m_topTab.bgImg[self.m_topSelectedIndex].text:setColor(231, 237, 242);
        self.m_topContainer:addChild(self.m_topTab);
    end 
end

GiftDialog.onTopTabChanged = function(self, index) 
    Log.d(self.TAG, "onTopTabChanged", "index:".. index);
    self.m_topTab.bgImg[self.m_topSelectedIndex].text:setColor(21, 127, 186);
    self.m_topSelectedIndex = index;
    self.m_topTab.bgImg[index].text:setColor(231, 237, 242);
    if index == self.m_giftIndex then
        self:initLeftContainer(STR_MYGIFT_LEFT_CATEGORY_ITEM);
    else
        self:initLeftContainer(STR_GIFT_LEFT_CATEGORY_ITEM);
    end
    local data = {selectedCategory = self:getSelectedCategory(), myGiftSelectedTag = self:getMygiftSelectedTag(), selectedTag = self:getSelectedTag()};
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.GIFT_CATEGORY_TAG_CHANGE, data);
end


--[Comment]
--leftItems -> STR_GIFT_LEFT_CATEGORY_ITEM or STR_MYGIFT_LEFT_CATEGORY_ITEM
GiftDialog.initLeftContainer = function(self, leftItems)
    if self.m_leftTab then
        self.m_leftTab:removeAllChildren();
        self.m_leftTab = nil;
    end
    self.m_leftTab = new(ButtonTag);    
    self.m_leftTab:setButtonTagVerticalMul(leftItems,
                                            "main/page-pop-up-tab-bg.png",
                                            "main/page-pop-up-tab-group-vernier.png",
                                            "main/page-pop-up-tab-group-vernier.png",
                                            184,61 * #leftItems,10,10,16,16,12,12,4,4,false,22);
    self.m_leftTab.buttonSlide:setPos(-4);
    self.m_leftTab.buttonSlide:setSize(199);  
    self.m_leftTab:setOnTagChangedAnimEnd(self,self.onLeftTabChanged);
    self.m_leftTab:setPos(0, 48);
    self.m_leftSelectedIndex = 1;
    self.m_mygiftSelectedIndex = 1;
    self.m_leftContainer:addChild(self.m_leftTab); 
end

GiftDialog.onLeftTabChanged = function(self, index) 
    Log.d(self.TAG, "onLeftTabChanged", "index:".. index);
    if self.m_topSelectedIndex == self.m_giftIndex then
        self.m_mygiftSelectedIndex = index;
    else
        self.m_leftSelectedIndex = index;
    end
    local data = {selectedCategory = self:getSelectedCategory(), myGiftSelectedTag = self:getMygiftSelectedTag(), selectedTag = self:getSelectedTag()};
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.GIFT_CATEGORY_TAG_CHANGE, data);
end

GiftDialog.initRightContainer = function(self, data)
    if self.m_scrollView then
        self.m_scrollView:removeAllChildren();
        self.m_scrollView = nil;
    end
    local w, h = self.m_rightContainer:getSize();
    self.m_scrollView = new(ScrollView2, 0, 0, w, h, false);
    self.m_rightContainer:addChild(self.m_scrollView);
    self:setScrollViewData(data);
end


GiftDialog.setScrollViewData = function(self, data)   
    for i = 1,#data do
        local item = new(GiftInfoItem,data[i]);        
        local row, _ = math.modf((i - 1) / 4) + 1; --行
        local col = (i - 1 ) % 4 + 1; --列
        local w, h = 120, 112; --item 宽高
        local x = (col - 1) * GiftInfoItem.PADDING + (col - 1) * w;
        local y = row * GiftInfoItem.PADDING + (row - 1) * h;
        item:setPos(x, y);
        item:setSize(w, h);
        item:setEventTouch({["obj"] = self, ["item"] = item}, self.onItemClick);
        self.m_scrollView:addChild(item);   
    end    
end

GiftDialog.onCloseBtnClick = function(self)
    self:close();
end

GiftDialog.isInRoom = function(self, val)
    self._isInRoom = val;
end

GiftDialog.setUserId = function(self, val)
    self._userId = val;
end

GiftDialog.setSeatId = function(self, val)
    self._seatId = val;
end

GiftDialog.setUserNick = function(self, val)
    self._userNick = val;
end

--[Comment]
--展示指定tab的内容
--支持卡拉币时，0：筹码礼物；1：卡拉币礼物；2：我的礼物
--不支持卡拉币时，0：筹码礼物；1：我的礼物
GiftDialog.setTab = function(self, index)
    if self.m_topSelectedIndex == index then
        return;
    end
	if not Model.getData(ModelKeys.STORE_SUPPORT_BY) and index == 2 then
		self.m_topSelectedIndex = 1;
	else
		self.m_topSelectedIndex = index;
	end
	--tabNav.gotoTab(self.m_topSelectedIndex + 1); 到指定index界面
    if self.m_topTab then
        self.m_topTab:onTouchHorizontalSingle(kFingerUp, _, _, self.m_topTab.bgImg[self.m_topSelectedIndex + 1].text.m_drawingID);
    end
end

GiftDialog.saleGiftButtonDarkHandler = function(self)
    self.m_btnQuicklySalesGift:setVisible(false);
end

GiftDialog.saleGiftButtonLightHandler = function(self)
    self.m_btnQuicklySalesGift:setVisible(true);
end

GiftDialog.quicklySaleGiftButtonHandler = function(self)
	EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.QUICKLY_SALE_ALL_OVERDUE_GIFT);
end


--[Comment]
--获取顶部所选的tabCategory
GiftDialog.getSelectedCategory = function(self)
	if self.m_topSelectedIndex then
		if Model.getData(ModelKeys.STORE_SUPPORT_BY) then
            local tab = {[1] = "bychip", [2] = "bycoalaa", [3] = "mygift"};
			return tab[self.m_topSelectedIndex];
		else
            local tab = {[1] = "bychip", [2] = "mygift"};
			return tab[self.m_topSelectedIndex];
		end
	end
	return nil;
end

--[Comment]
--获取左侧所选tab的 tag
GiftDialog.getSelectedTag = function(self)
	if self.m_leftSelectedIndex then
        local tab = {[1] = "0", [2] = "1", [3] = "2", [4] = "3", [5] = "4"};
		return tab[self.m_leftSelectedIndex];
	end
	return nil;
end

--[Comment]
--获取左侧所选 我的礼物tab的 tag
GiftDialog.getMygiftSelectedTag = function(self)
	if self.m_mygiftSelectedIndex then
        local tab = {[1] = "0", [2] = "1"};
		return tab[self.m_mygiftSelectedIndex];
	end
	return nil;
end

GiftDialog.giftListDisplaying = function(self, data)
    --待实现
    Log.d(self.TAG, "giftListDisplaying");
	if data and type(data) == "string" then
        self.m_miniLoad = AtomAnimManager.getInstance():playAnim("atomAnimTable/common/anim_common_miniLoad", self.m_loadAnimContainer, 0, 0, false);
		--JuhuaAndHintManager.showHint(list, data, false);
		self:initRightContainer({});
	elseif data then
    	if self.m_miniLoad ~= nil then
            self.m_miniLoad:release();
            self.m_miniLoad = nil;
        end 
		if self:getMygiftSelectedTag() == "1" and self:getSelectedCategory() == "mygift" then
			local w, h = self.m_scrollView:getSize();
            local _, height = self.m_btnQuicklySalesGift:getSize();
            h = h - height - 12;
            self.m_scrollView:setSize(w, h); --一键出售按钮
            local x, y = self.m_imgBottomOverLay:getPos();
            self.m_imgBottomOverLay:setPos(x, y - height - 12);
        end
        self:initRightContainer(data);
	else
		self:initRightContainer({});
        self.m_miniLoad = AtomAnimManager.getInstance():playAnim("atomAnimTable/common/anim_common_miniLoad", self.m_loadAnimContainer, 0, 0, false);
	end
end

GiftDialog.onItemClick = function(tab, finger_action,x,y,drawing_id_first,drawing_id_current)
    local dialog = tab.obj;  --self
    local item   = tab.item; --被点击的item
    local data   = item:getData();
    if dialog:getSelectedCategory() == "mygift" then
        if (data.giftType == "0" or data.name ~= 0) and (data.giftType ~= "2") then
			--normalPopup.setButtonLabels(null, Localization.getText("GIFT.USE"));		
		elseif data.giftType == "1" then
			--gloryPopup.setButtonLabels(null, Localization.getText("GIFT.USE"));
		elseif data.giftType == "2" then
			--duePopup.setButtonLabels(null,Localization.getText("GIFT.SALE_OVERDUE_GIFT"));
		else
			--我的礼物
			--operatePopup.setButtonLabels(null, Localization.getText("GIFT.USE"));
		end
    else
        --卡拉币或者筹码礼物分类
		if dialog._isInRoom  then
			--在房间内
			if dialog._userId ~= Model.getData(ModelKeys.USER_DATA)["uid"] then
				--点击房间别人的礼物弹出
				--operatePopup.setButtonLabels(Localization.getText("GIFT.BUY_FOR_TABLE"),Localization.getText("GIFT.PRESENT"));
			else
				--点击房间自己的礼物弹出
				--operatePopup.setButtonLabels(Localization.getText("GIFT.BUY_FOR_TABLE"),Localization.getText("GIFT.BUY_LONG"));
			end
		elseif dialog._userId then
			--不在房间内，赠送礼物给别人
			--operatePopup.setButtonLabels(null, Localization.getText("GIFT.PRESENT"));
		else
			--不在房间内
			--operatePopup.setButtonLabels(null, Localization.getText("GIFT.BUY_LONG"));
		end
    end
end
