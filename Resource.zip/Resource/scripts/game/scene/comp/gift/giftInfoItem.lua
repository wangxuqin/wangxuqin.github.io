require("game/model/data/vo/giftVO");
require("view/gift/layout_gift_item");
require("ui/ex/urlImage");
--[Comment]
--礼物Item
GiftInfoItem = class(Node);
GiftInfoItem.TAG = "GiftInfoItem";
GiftInfoItem.PADDING =  20;
GiftInfoItem.TAG_FILE = 
{
    HOT = "gift/gift_item_tag_hot.png";
    NEW = "gift/gift_item_tag_new.png";
}
GiftInfoItem.ctor = function(self,data) 
    if not data or type(data)~="table" then
        Log.e(self.TAG, "ctor", "data is nil or not table");
        return;
    end 
    self.m_root = SceneLoader.load(layout_gift_item);
    self:addChild(self.m_root);
    self.m_data = data;
    self:getCtrls();
    self:initialize();
end

GiftInfoItem.dtor = function(self)
   Node:dtor(self);
end

GiftInfoItem.getCtrls = function(self)
    self.m_bg                   = self.m_root:getNodeByName("bg");
    self.m_imgSelected          = self.m_root:getNodeByName("bg.img_selected");
    self.m_imgTag               = self.m_root:getNodeByName("bg.img_tag");
    self.m_priceDescContainer   = self.m_root:getNodeByName("bg.price_desc_container"); 
    self.m_txtPriceDesc         = self.m_root:getNodeByName("bg.price_desc_container.txt_price_desc"); 
end

GiftInfoItem.initialize = function(self)
    if self.m_data.isOwn then
        self.m_txtPriceDesc:setText(self:getFromName());
        --Formatter.spliceSingleLineLongString();
        self.m_imgTag:setVisible(false);
        self.m_imgSelected:setVisible(Model.getData(ModelKeys.USER_DATA).user_gift == self.m_data.id);
    else
        self.m_imgSelected:setVisible(false);
        if self.m_data.itemTag == "2" then
            self.m_imgTag:setFile(self.TAG_FILE.HOT);
            self.m_imgTag:setVisible(true);
        elseif self.m_data.itemTag == "1" then
            self.m_imgTag:setFile(self.TAG_FILE.NEW);
            self.m_imgTag:setVisible(true);
        else
            self.m_imgTag:setVisible(false);
        end
        local num = tonumber(STR_COMMON_CURRENCY_MULTIPLE);
        if num and type(num) == "number" and num > 10 then
            self.m_txtPriceDesc:setText(Formatter.formatBigNumber(self.m_data.price));
        else
            self.m_txtPriceDesc:setText(Formatter.formatNumberWithSplit(self.m_data.price));
        end
    end
    local pre = Model.getData(ModelKeys.USER_DATA)["SWFURL"];
    local map = Model.getData(ModelKeys.GIFT_ID_FILE_MAPPING);
    local url = "";
    if map then
        url = pre .. map[self.m_data.id] .. ".swf";
    else
        url = pre .. self.m_data.id .. ".swf";
    end
    self:addGiftImage(url);
    self.m_giftImage:setLevel(1);
    self.m_imgTag:setLevel(2);
    self.m_imgSelected:setLevel(2);
    self.m_priceDescContainer:setLevel(2);
end

GiftInfoItem.addGiftImage = function(self, url)
    self.m_giftImage = new(UrlImage, "gift/gift-default.png", url, nil, 1);
    self.m_giftImage:setSize(100, 100);
    self.m_giftImage:setPos(10, 8);
    self.m_bg:addChild(self.m_giftImage);
end

GiftInfoItem.getFromName = function (self)
    if self.m_data["type"] == "4" then
        return STR_GIFT_GLORY_OBTAIN_GIFT;
    else
        if self.m_data.name ~= "" then
            if self.m_data.exprice == 0 then
                return STR_GIFT_GIFT_PAST_DUE;
            elseif self.m_data.exprice > 0 then
                return STR_GIFT_PRESENT;
            end
        else
            if self.m_data.exprice == 0 then
                return STR_GIFT_GIFT_PAST_DUE;
            elseif self.m_data.exprice > 0 then
                return STR_GIFT_GIFT_BUY_BY_SELF;
            end
        end
    end
end

GiftInfoItem.getData = function(self)
    return self.m_data;
end
