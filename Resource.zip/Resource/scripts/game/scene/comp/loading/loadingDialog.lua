require("view/loading/layout_loading");
require("atomAnim/atomAnimManager");

LoadingDiaLog = class(PopupDialog, false)

kTipIndex = 1;

LoadingDiaLog.ctor = function (self)
    super(self,layout_loading);
    self.m_animDots = AtomAnimManager.getInstance():playAnim("atomAnimTable/loading/anim_loading", self.m_root:getNodeByName("bg.dot_container"), 0, 0, false, true);   --���һ������Ϊ������ʱ���ϲ���
    self:setLevel(10);
    self.m_tipText = self.m_root:getNodeByName("bg.tipsText");
    self.m_tipText:setVisible(false);
    self.m_animDots:setEvent(self,self.animCallBack);
    self.m_root:setAlpha(0.5);
end

LoadingDiaLog.dtor = function (self)
    if self.m_animDots ~= nil then
        self.m_animDots:release();
        self.m_animDots = nil;
    end
end


LoadingDiaLog.close = function(self)
    PopupDialog.close(self);
end

LoadingDiaLog.animCallback = function (self)
    if self.m_animDots ~=nil then
        self.m_animDots:play();
    end
end

LoadingDiaLog.update = function (self,text)   
    if text and type(text) == "string" then       
        self.m_text = self.m_root:getNodeByName("bg.loginTextBg.loggingIn");
        self.m_text:setText(text);
        self.m_textBg = self.m_root:getNodeByName("bg.loginTextBg");
        self.m_tipText:setVisible(true);
        self.m_tipText:setText(STR_COMMON_TIPS_TEXT_ARR[kTipIndex]);
        kTipIndex = kTipIndex  + 1; 
        if kTipIndex > 20 then
            kTipIndex = 1;
        end       
    end
end