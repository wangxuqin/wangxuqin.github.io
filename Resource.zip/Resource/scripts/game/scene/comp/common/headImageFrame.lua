require("ui/node");
require("ui/ex/urlImage");
require("view/common/layout_common_head_image_frame");
HeadImageFrame = class(Node, false)
HeadImageFrame.DEFAULT_MALE_PHOTO    = "userinfo/imgface_default_male.png"
HeadImageFrame.DEFAULT_FEMALE_PHOTO  = "userinfo/imgface_default_female.png";
HeadImageFrame.EDIT_ICON_UP          = "headImageFrame/head_frame_edit_icon_up.png"
HeadImageFrame.EDIT_ICON_DOWN        = "headImageFrame/head_frame_edit_icon_down.png"

HeadImageFrame.ctor = function(showSexIcon)
    super(self)
    self.m_root = SceneLoader.load(layout_common_head_image_frame);
    self.m_photoContainer  = self.m_root:getNodeByName("container.photo_cantainer");
    self.m_imgMaleFrame    = self.m_root:getNodeByName("container.img_male_frame");
    self.m_imgFemaleFrame  = self.m_root:getNodeByName("container.img_female_frame");
	self.m_imgMaleIcon     = self.m_root:getNodeByName("container.img_male_icon");
    self.m_imgFemaleIcon   = self.m_root:getNodeByName("container.img_female_icon");
	self.m_imgEditIcon     = self.m_root:getNodeByName("container.img_edit_icon");
	                       
	self.m_isMale          = true;
    self.m_editable        = false;

    self.m_photoContainer  :setPickable(false);
    self.m_imgMaleFrame    :setPickable(false);
    self.m_imgFemaleFrame  :setPickable(false);
    self.m_imgMaleIcon     :setPickable(false);
    self.m_imgFemaleIcon   :setPickable(false);
    self.m_imgEditIcon     :setPickable(false);

    if showSexIcon == nil then
        showSexIcon = true;
    end
    self.m_isShowSexIcon   = showSexIcon;
    self.m_url             = "";
    self.m_photo           = new(UrlImage, self.DEFAULT_MALE_PHOTO, self.m_url);
    
    self.m_photo           :setSize(100, 100);
    self.m_photoContainer  :addChild(self.m_photo);

    self:update();

    self:addChildBySize(self.m_root);
    self:setEventTouch(self, onTouch);
end

HeadImageFrame.dtor = function(self)
    self:setEventTouch(nil, nil);
    Node.dtor(self);
end

HeadImageFrame.getEditable = function(self)
	return self.m_editable;
end

HeadImageFrame.setEditable = function(self, value)
	if value == nil then
        value = true;
    end
    self.m_editable = value;
    self:updateEditIcon();
end
		
HeadImageFrame.getIsMale = function(self)
	return self.m_isMale;
end
		
HeadImageFrame.setIsMale = function(self, value)
	if value == nil then
        value = true;
    end
    self.m_isMale = value;
    self:updateSexIcon();
end
		
HeadImageFrame.setURL = function(url)
	self.m_url = url;
    self:updatePhoto();
end

HeadImageFrame.update = function(self)
    self:updatePhoto();
    self:updateSexFrame();
    self:updateSexIcon();
    self:updateEditIcon();
end

HeadImageFrame.updatePhoto = function(self)
    if self.m_url == nil or not string.len(self.m_url) > 0 then
        local defaultPhoto = self.m_isMale and self.DEFAULT_MALE_PHOTO or self.DEFAULT_FEMALE_PHOTO;
        self.m_photo:setUrl(self.m_url or "", defaultPhoto);
    end
end

HeadImageFrame.updateSexFrame = function(self)
     self.m_maleFrame:setVisible(self.m_isMale);
     self.m_femaleFrame:setVisible(not self.m_isMale);
end

HeadImageFrame.updateSexIcon = function(self)
    if self.m_isShowSexIcon then
        self.m_maleIcon:setVisible(self.m_isMale);
        self.m_femaleIcon:setVisible(not self.m_isMale);
    else
        self.m_maleIcon:setVisible(false);
        self.m_femaleIcon:setVisible(false);
    end
end

HeadImageFrame.updateEditIcon = function(self)
    self.m_editIcon:setVisible(self.m_editable);
end


HeadImageFrame.onTouch = function(self, finger_action,x,y,drawing_id_first,drawing_id_current, event_time)
    TouchHelper.catch(self, finger_action, x, y);
    if TouchHelper.isDown(self) then
	    self.m_imgEditIcon:setFile(self.EDIT_ICON_DOWN);
    end

    if TouchHelper.isClick(self) then
		self:onEdit();
		SoundManager.playSound("ButtonClick");
	end
        
    if TouchHelper.isUp(self) then
        self.m_imgEditIcon:setFile(self.EDIT_ICON_UP);
    end
 end

HeadImageFrame.setOnEdit = function(self, obj, func)
    self.m_editCallBack.obj = obj;
    self.m_editCallBack.func = func;
end

HeadImageFrame.onEdit = function(self)
    if self.m_editable then
        local obj   = self.m_editCallBack.obj;
        local func  = self.m_editCallBack.func;
        FunctionKit.call(obj, func);
    end
end
