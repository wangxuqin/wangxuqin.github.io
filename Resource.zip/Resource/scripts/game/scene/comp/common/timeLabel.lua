TimeLabel = class();
TimeLabel.ctor = function(self, text)
    self.m_txtTime = text;
    self.m_txtTime:setText(DateKit.getCurrentTime());  
    self.m_timer = new(AnimInt,kAnimRepeat,0,0,1000,-1);
    self.m_timer:setEvent(self,function(self)
        self.m_txtTime:setText(DateKit.getCurrentTime());          
    end);
end

TimeLabel.dtor = function(self)
    if self.m_timer ~= nil then
        self.m_timer:dtor();
        self.m_timer = nil;
    end
end

TimeLabel.setColor = function(self, color)
    if color ~= nil and type(color) == "number" then
        if self.m_txtTime ~= nil then
            self.m_txtTime:setColor(RGBKit.getRGB(color));
        end
    end
end