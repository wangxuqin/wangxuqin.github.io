require("ui/node")
require("ui/image");
require("core/global");
require("core/object");

SignalLabel = class(Node);

SignalLabel.__eventList = {
    {UIEvent, UIEvent.s_cmd.ROOM_NETWORK_SIGNAL, "update"};
};

SignalLabel.ctor = function(self,quadImage)
     self:setSize(30,25);
     self.quad={};
     self.m_quadImage = quadImage;
     self:addSignalImage();    
     EventDispatcher.getInstance():registerEventList(self, self.__eventList);
end

SignalLabel.dtor = function(self)
    EventDispatcher.getInstance():unregisterEventList(self, self.__eventList);
end

SignalLabel.update = function(self, data)
    local delayTime = math.ceil(data * 1000);
	if delayTime < 200 then
		self:signalStrength(5);
	elseif delayTime < 400 then
		self:signalStrength(4);
	elseif delayTime < 700 then
		self:signalStrength(3);
	elseif delayTime < 1200 then
		self:signalStrength(2);
	else
		self:signalStrength(1);
	end
end

SignalLabel.addSignalImage = function(self)
    if self.m_quadImage then
         for i=1,5 do
            self.quad[i] = new(Image,self.m_quadImage);  
            self.quad[i]:setSize(4,4*i); 
            self.quad[i]:setAlign(kAlignBottomLeft);
            self.quad[i]:setPos(6*(i-1),0);
            self:addChild(self.quad[i]);
         end
     end 
end

SignalLabel.signalStrength = function(self,strength)
    for i=1,strength do
        self.quad[i]:setVisible(true);    
    end    

    for i=#self.quad,strength+1,-1 do
        self.quad[i]:setVisible(false);  
    end

end



