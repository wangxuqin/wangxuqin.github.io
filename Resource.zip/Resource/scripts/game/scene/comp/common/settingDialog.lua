require("view/setting/layout_setting")
require("ui/switch");

SettingDialog = class(PopupDialog, false);

SettingDialog.ctor = function(self)
    super(self, layout_setting, true);
end

SettingDialog.onPopupEnd = function(self)
    self:getCtrls();
    self:setTextFromConfig();
    self:addElements();
    self.m_logoutBtn:setOnClick(self, self.onClickLogout);
    self.m_closeBtn:setOnClick(self, self.onClickClose);
end

SettingDialog.close = function(self)
    self.m_logoutBtn:setOnClick(nil, nil);
    self.m_closeBtn:setOnClick(nil, nil);
    PopupDialog.close(self);
end

SettingDialog.getCtrls = function(self)
    self.m_closeBtn          = self.m_root:getNodeByName("bg.btn_close");
    self.m_slider            = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_voice.slider");
    self.m_mainTitle         = self.m_root:getNodeByName("bg.txt_title");
                              
    self.m_accountBg         = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_account");
    self.m_accountTitle      = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_account.txt_account_title");
    self.m_accountName       = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_account.txt_account_name");
    self.m_logoutText        = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_account.btn_logout.txt_logout");
    self.m_logoutBtn         = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_account.btn_logout");
                              
    self.m_voiceBg           = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_voice")
    self.m_voiceTitle        = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_voice.txt_voice_title");
    self.m_voiceText         = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_voice.txt_voice_title.txt_voice");
    self.m_shakeText         = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_voice.txt_voice_title.txt_shake_text");
                              
    self.m_otherBg           = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_other");
    self.m_otherTitle        = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_other.txt_other_title");
    self.m_autoSitText       = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_other.txt_other_title.txt_auto_sit_name");
    self.m_autoBuyText       = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_other.txt_other_title.txt_auto_buy_name");
    self.m_playCountTipsText = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_other.txt_other_title.txt_play_count_tips_name");
    self.m_clearCacheText    = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_other.txt_other_title.txt_clear_cache_name");
    self.m_ratingUsText      = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_other.txt_other_title.txt_rating_us_name");
    self.m_updateNameText    = self.m_root:getNodeByName("bg.img_dark.scroll_view.img_other.txt_other_title.txt_update_name");
end

SettingDialog.setTextFromConfig = function(self)
    self.m_mainTitle:setText(STR_SETTING_TITLE_SETTING);

    self.m_accountTitle:setText(STR_SETTING_SETTING_PAGE_ACCOUNT_TITLE);
    self.m_accountName:setText("accountName");
    self.m_logoutText:setText(STR_COMMON_SINGLE_GAME_RETURN_BTN);

    self.m_voiceTitle:setText(STR_SETTING_SETTING_PAGE_VOICE_CONTENT_TITLE);
    self.m_voiceText:setText(STR_SETTING_SOUND);
    self.m_shakeText:setText(STR_SETTING_SHOCK);

    self.m_otherTitle:setText(STR_SETTING_SET_PAGE_TITLE_OTHER_MEMU);
    self.m_autoSitText:setText(STR_SETTING_AUTO_SIT_DOWN);
    self.m_autoBuyText:setText(STR_SETTING_AUTO_BUY_IN);
    self.m_playCountTipsText:setText(STR_SETTING_SET_PAGE_TITLE_PLAY_GAME_MEMU);
    self.m_clearCacheText:setText(STR_SETTING_CLEAR_CACHE);
    self.m_ratingUsText:setText(STR_SETTING_APPSTORE_GRADE);
    self.m_updateNameText:setText(STR_SETTING_CHECK_UPDATE);
end


SettingDialog.addElements = function(self)
    self.m_slider:setImages("setting/slider_max.png", "setting/slider_min.png", "setting/toggle_thumb_up.png")

    self.m_vibrateBtn = self:createSwitchButton(600, 105);
    self.m_voiceBg:addChild(self.m_vibrateBtn);

    self.m_sitBtn = self:createSwitchButton(600, 18);
    self.m_otherBg:addChild(self.m_sitBtn);

    self.m_buyBtn = self:createSwitchButton(600, 102);
    self.m_otherBg:addChild(self.m_buyBtn);

    self.m_countBtn = self:createSwitchButton(600, 182);
    self.m_otherBg:addChild(self.m_countBtn);
end

SettingDialog.createSwitchButton = function(self, posX, posY)
    local switchButton = new(Switch, 80, 40);
    switchButton:setPos(posX, posY);
    switchButton:setNeedAnimation(true)
    return switchButton;
end

SettingDialog.onClickClose = function(self)
    self:close();
end

SettingDialog.onClickLogout = function(self)
    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.LOGOUT);
    self:close();
end