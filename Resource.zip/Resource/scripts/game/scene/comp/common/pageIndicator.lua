---------------------------------------------------------------------
--頁面指示器

PageIndicator = class(Node, false);

PageIndicator.TAG = "PageIndicator";
PageIndicator.DIRECTION_VERTICAL = "vertical";
PageIndicator.DIRECTION_HORIZONTAL = "horizontal";

--- <summary>
--- 構造函數，參數:
--- pageCount=頁面數
--- gap=指示點與指示點之間的間距(中心點間的間距)
--- direction=方向，nil表示橫向
--- normalImg,selectedImg=未選中和選中的圖片
--- </summary>
PageIndicator.ctor = function(self, pageCount, gap, direction, normalImg, selectedImg)
    super(self);
    pageCount = pageCount or 0;
    gap = gap or 30;
    direction = direction or PageIndicator.DIRECTION_HORIZONTAL;
    local len = 0;
    if(pageCount > 1) then
        len = (pageCount - 1) * gap;
    end
    if(direction == PageIndicator.DIRECTION_HORIZONTAL) then
        local x = -len / 2;
        for i=1,pageCount do
            local symbol = new(Image, normalImg);
            symbol:setPos(x);
            symbol:setAlign(kAlignCenter);
            self:addChild(symbol);
            x = x + gap;
        end
    else
        local y = -len / 2;
        for i=1,pageCount do
            local symbol = new(Image, normalImg);
            symbol:setPos(nil, y);
            symbol:setAlign(kAlignCenter);
            self:addChild(symbol);
            y = y + gap;
        end
    end
    self.m_selectedSymbol = new(Image, selectedImg);
    self.m_selectedSymbol:setAlign(kAlignCenter);
    self.m_selectedSymbol:setVisible(false);
    self:addChild(self.m_selectedSymbol);
end

PageIndicator.dtor = function(self)
end

--- <summary>
--- 設定當前選中的頁面索引(base 1)
--- </summary>
PageIndicator.setSelectedIndex = function(self, index)
    if(index < 1) then
        return;
    end
    local arrChildren = self:getChildren();
    if(index > #arrChildren) then
        return;
    end
    for i=1,#arrChildren do
        if(i ~= index) then
            arrChildren[i]:setVisible(true);
        end
    end
    local child = arrChildren[index];
    child:setVisible(false);
    self.m_selectedSymbol:setVisible(true);
    self.m_selectedSymbol:setPos(child:getPos());
end
