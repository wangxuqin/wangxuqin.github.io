require("view/comingSoon/layout_comingSoon")

ComingSoonDialog = class(PopupDialog, false);

ComingSoonDialog.ctor = function (self)
    super(self,layout_comingSoon,true);
    self:setLevel(10);
end

ComingSoonDialog.onPopupEnd = function(self)
    --�����¼���Ӧ
    self.m_closeButton = self:getChildByName2("closeButton");
    self.m_closeButton:setOnClick(self, self.onClickClose);
    self.m_confirmButton = self:getChildByName2("confirmButton");
    self.m_confirmButton:setOnClick(self, self.onClickClose);
end

ComingSoonDialog.onClickClose = function(self)
    self:close();
end