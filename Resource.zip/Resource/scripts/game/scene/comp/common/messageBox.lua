---------------------------------------------------------
-- MessageBox
-- Author: GerryGuo

require("view/common/layout_messagebox");
require("game/scene/comp/common/dialogCallback");

MessageBox = class(PopupDialog, false);

MessageBox.ctor = function(self)
    super(self, layout_messagebox, true);
    self.m_callback = nil;
    self.m_objCallback = nil;
end

MessageBox.dtor = function(self)
end

--[Comment]
--data中的参数: title=对话框标题
--      message=对话框文本内容
--      confirm=确定按钮文本
--      cancel=取消按钮文本，如果为nil表示只有一个确定按钮
MessageBox.update = function(self, data)
    local title = data.title;
    local message = data.message;
    local confirmText = data.confirm;
    local cancelText = data.cancel;
    self:setLevel(1000);
    if(title == nil) then
        title = STR_COMMON_DIALOG_TITLE;
    end
    local tx = self.m_root:getNodeByName("bg.title");
    tx:setText(title);
    local tx = self.m_root:getNodeByName("bg.message");
    tx:setText(message);
    local tx = self.m_root:getNodeByName("bg.btn_confirm.text_confirm");
    tx:setText(confirmText);
    if(cancelText) then -- 确定和取消
        local btn = self.m_root:getNodeByName("bg.btn_cancel");
        btn:setVisible(true);
        local tx = self.m_root:getNodeByName("bg.btn_cancel.text_cancel");
        tx:setText(cancelText);
    else -- 只有一个确定按钮
        local btn = self.m_root:getNodeByName("bg.btn_cancel");
        btn:setVisible(false);
        btn = self.m_root:getNodeByName("bg.btn_confirm");
        local w,h = btn:getSize();
        local ww,hh = self:getDialog():getSize();
        btn:setPos((ww-w)/2);
    end
    self.m_callback = data.callback;
    self.m_objCallback = data.obj;
end

--[Comment]
--设置回调
MessageBox.setCallback = function(self, obj, func)
    self.m_callback = func;
    self.m_objCallback = obj;
end

MessageBox.onPopupEnd = function(self)
    --添加事件响应
    local btn = self.m_root:getNodeByName("bg.btn_close");
    if(btn) then
        btn:setOnClick(self, self.__onBtnClickClose);
    end
    local btn = self.m_root:getNodeByName("bg.btn_cancel");
    if(btn) then
        btn:setOnClick(self, self.__onBtnClickCancel);
    end
    local btn = self.m_root:getNodeByName("bg.btn_confirm");
    if(btn) then
        btn:setOnClick(self, self.__onBtnClickConfirm);
    end
end

MessageBox.__onBtnClickClose = function(self)
    self:close();
    if(self.m_callback) then
        self.m_callback(self.m_objCallback, DialogCallback.CLOSE);
    end
end

MessageBox.__onBtnClickCancel = function(self)
    self:close();
    if(self.m_callback) then
        self.m_callback(self.m_objCallback, DialogCallback.CANCEL);
    end
end

MessageBox.__onBtnClickConfirm = function(self)
    self:close();
    if(self.m_callback) then
        self.m_callback(self.m_objCallback, DialogCallback.CONFIRM);
    end
end
