require("ui/node");
require("ui2/compat/scrollView2");
require("view/friend/layout_friend_invite_item");


InvitePage = class(Node)
InvitePage.TAG = "InvitePage";

InvitePage.ctor = function(self, x, y, w, h, data)
    self:setSize(w, h);
    self.m_root = new(ScrollView2, x, y, w, h, false);
    self:addChild(self.m_root);
    self:setData(data);
    self.m_root:setScrollBarWidth(0);
end

InvitePage.dtor = function(self)
   Node.dtor(self);
end

InvitePage.setData = function(self, data)   
    local inviteItems = {};

    for i = 1,#data do
        inviteItems[i] = new(InviteItem,data[i]);        
        if i > 1 then 
            local h = inviteItems[i-1]:getHeight();
            local _,y = inviteItems[i-1]:getPos();             
            inviteItems[i]:setPos(0,y+h+InviteItem.PADDING); 
        end
        self.m_root:addChild(inviteItems[i]);   
    end    
end


