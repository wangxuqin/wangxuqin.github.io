
FacebookInviteService = {};
FacebookInviteService.TAG = "FacebookInviteService";

FacebookInviteService.invite = function()
    HttpService.post({mod = "invite", act = "getFBid"}, FacebookInviteService,
    FacebookInviteService.resultHandler, FacebookInviteService.errorHandler);
end

FacebookInviteService.resultHandler = function(self, json_data)
    Log.i(self.TAG, "resultHandler", "getFBid return:"..json_data);
    local flag, json = JsonKit.decode(json_data);
    local userData = Model.getData(ModelKeys.USER_DATA);
    if flag then
        if json.ret == 0 then
            if userData["inviteNeedCode"] == "1" then
                EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FACEBOOK_INVITE_CODE, {["exclude_ids"] = json.fbid});
            else
                EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FACEBOOK_INVITE, 
                {["message"] = STR_SOCIAL_INVITE_MESSAGE_FACEBOOK, ["callback"] = FacebookInviteService.facebookInviteCallback, ["exclude_ids"] = json.fbid});
            end
        else
            if userData["inviteNeedCode"] == "1" then
                EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FACEBOOK_INVITE_CODE);
            else
                EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FACEBOOK_INVITE, 
                {["message"] = STR_SOCIAL_INVITE_MESSAGE_FACEBOOK, ["callback"] = FacebookInviteService.facebookInviteCallback});
            end
        end
    else
        Log.e(FacebookInviteService.TAG, "resultHandler", "json decode error!!");
    end
end

FacebookInviteService.errorHandler = function(self)
    Log.d(FacebookInviteService.TAG, "errorHandler");
    local userData = Model.getData(ModelKeys.USER_DATA);
    if userData["inviteNeedCode"] == "1" then
        EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FACEBOOK_INVITE_CODE);
    else
        EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FACEBOOK_INVITE, 
        {["message"] = STR_SOCIAL_INVITE_MESSAGE_FACEBOOK, ["callback"] = FacebookInviteService.facebookInviteCallback});
    end
end

FacebookInviteService.facebookInviteCallback = function(success, data1, data2)
    Log.i(FacebookInviteService.TAG, "facebookInviteCallback", "success:".. tostring(success));
    if success == true then
        TaskReporter.getInstance():reportInviteFriend(#data1);
        HttpService.post({mod = "invite", act = "reward", fbid = StringKit.join(data1, ","), request = data2}, FacebookInviteService, 
        function (json_data)
            local flag, json = JsonKit.decode(json_data);
            if flag then
                if json.ret == 0 then
                    if json.money > 0 then
                        if tonumber(STR_COMMON_CURRENCY_MULTIPLE) > 10 then
                            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, StringKit.substitute(STR_SOCIAL_INVITE_SUCCESS_WITH_REWARD, #data1, Formatter.formatBigNumber(json.money)));
                        else
                            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, StringKit.substitute(STR_SOCIAL_INVITE_SUCCESS_WITH_REWARD, #data1, Formatter.formatNumberWithSplit(json.money)));
                        end
                    else
                        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, StringKit.substitute(STR_SOCIAL_INVITE_SUCCESS, ""));
                    end
                end
            end
        end, 
        function ()
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, StringKit.substitute(STR_SOCIAL_INVITE_SUCCESS, "1"));
        end);
    elseif data1 == "error" then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, StringKit.substitute(STR_SOCIAL_INVITE_ERROR, data2));
    end
end