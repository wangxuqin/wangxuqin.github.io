require("game/model/data/vo/friendVO");
require("view/friend/layout_friend_invite_item");
require("game/scene/comp/friend/invitePage/facebookInviteService");

InviteItem = class(Node)
InviteItem.PADDING = 12;
InviteItem.TAG = "InviteItem";
InviteItem.NAME =
{
    FACKBOOKNEW = "facebooknew";
    FACKBOOK = "facebook";
    SMS = "sms";
    EMAIL = "email";
}

InviteItem.s_txtMap =
{
    [InviteItem.NAME.FACKBOOK]  = {
        TITLE = STR_FRIEND_INVITE_FACEBOOK_TITLE,
        DESC = STR_FRIEND_INVITE_FACEBOOK_DESC
    },
    [InviteItem.NAME.EMAIL]  = {
        TITLE = STR_FRIEND_INVITE_EMAIL_TITLE,
        DESC = STR_FRIEND_INVITE_EMAIL_DESC
    },
    [InviteItem.NAME.SMS]  = {
        TITLE = STR_FRIEND_INVITE_SMS_TITLE,
        DESC = STR_FRIEND_INVITE_SMS_DESC
    },
    [InviteItem.NAME.FACKBOOKNEW]  = {
        TITLE = STR_FRIEND_INVITE_FACEBOOK_TITLE,
        DESC = STR_FRIEND_INVITE_FACEBOOK_DESC
    },
}


InviteItem.s_iconMap =
{
    UP =
    {
        [InviteItem.NAME.FACKBOOK]      = "social/friend_page_invite_facebook_icon_up.png",
        [InviteItem.NAME.SMS]           = "social/friend_page_invite_sms_icon_up.png",
        [InviteItem.NAME.EMAIL]         = "social/friend_page_invite_email_icon_up.png",
        [InviteItem.NAME.FACKBOOKNEW]   = "social/friend_page_invite_facebook_icon_up.png",
    },

    DOWN =
    {
        [InviteItem.NAME.FACKBOOK]      = "social/friend_page_invite_facebook_icon_down.png",
        [InviteItem.NAME.SMS]           = "social/friend_page_invite_sms_icon_down.png",
        [InviteItem.NAME.EMAIL]         = "social/friend_page_invite_email_icon_down.png",
        [InviteItem.NAME.FACKBOOKNEW]   = "social/friend_page_invite_facebook_icon_down.png",
    }
}

InviteItem.s_btnMap =
{

    [InviteItem.NAME.FACKBOOK]      = { "social/friend_page_invite_facebook_background_up.png", "social/friend_page_invite_facebook_background_down.png" },
    [InviteItem.NAME.SMS]           = { "social/friend_page_invite_sms_background_up.png", "social/friend_page_invite_sms_background_down.png" },
    [InviteItem.NAME.EMAIL]         = { "social/friend_page_invite_email_background_up.png", "social/friend_page_invite_email_background_down.png" },
    [InviteItem.NAME.FACKBOOKNEW]   = { "social/friend_page_invite_facebook_background_up.png", "social/friend_page_invite_facebook_background_down.png" },
}

InviteItem.s_btnOnclickMap =
{
    [InviteItem.NAME.FACKBOOK]      = "onFaceBookBtnClick",
    [InviteItem.NAME.SMS]           = "onSmsBtnClick",
    [InviteItem.NAME.EMAIL]         = "onEmailBtnClick",
    [InviteItem.NAME.FACKBOOKNEW]   = "onFaceBookBtnClick",
}

InviteItem.ctor = function(self, data)
    if not data then
        Log.e("InviteItem", "data is nil or not table");
        return;
    end
    self.m_root = SceneLoader.load(layout_friend_invite_item);
    self:addChild(self.m_root);
    self.m_data = data;
    self:getCtrls();
    self:initialize();
end

InviteItem.dtor = function(self)

end

InviteItem.getCtrls = function(self)
    self.m_btnInvite = self.m_root:getNodeByName("btn_invite");
    self.m_imgIconUp = self.m_root:getNodeByName("btn_invite.img_icon_up");
    self.m_imgIconDown = self.m_root:getNodeByName("btn_invite.img_icon_down");
    self.m_txtTitle = self.m_root:getNodeByName("btn_invite.txt_title");
    self.m_tvContent = self.m_root:getNodeByName("btn_invite.tv_content");
end

InviteItem.initialize = function(self)
    if self.m_data == InviteItem.NAME.FACKBOOKNEW then
        local res = new(ResImage, "hall/room-new-icon.png");
        local resWidth = res:getWidth(); 
        res:dtor();
        local width, _ = self.m_btnInvite:getSize();
        self.m_newImage = new(Image, "hall/room-new-icon.png")
        self.m_newImage:setPos(width - resWidth, 0);
        self.m_btnInvite:addChild(self.m_newImage);
    end
    local title = InviteItem.s_txtMap[self.m_data].TITLE;
    local content = InviteItem.s_txtMap[self.m_data].DESC;
    self.m_txtTitle:setText(title);
    local _, title_h = self.m_txtTitle:getSize();
    local _, title_y = self.m_txtTitle:getPos();
    local tv_y = title_y + title_h + InviteItem.PADDING;
    local tv_w , _ = self.m_tvContent:getSize();
    local resTxt = new(ResText, content, tv_w, 1, kAlignCenter, _, 18, _, _, _, 1);
    local tv_h = resTxt:getHeight();
    resTxt:dtor();
    self.m_tvContent:setText(content, tv_w, tv_h);
    local btn_w, btn_h = self.m_btnInvite:getSize();
    btn_h = tv_y + tv_h + InviteItem.PADDING;
    self.m_btnInvite:setSize(btn_w, btn_h);
    self.m_height = btn_h;
    local icon_x, icon_y = self.m_imgIconUp:getPos();
    local icon_w, icon_h = self.m_imgIconUp:getSize();
    icon_y =  (btn_h - icon_h) / 2;
    self.m_imgIconUp:setPos(icon_x, icon_y);
    self.m_imgIconDown:setPos(icon_x, icon_y);

    self.m_btnInvite:setImages(InviteItem.s_btnMap[self.m_data]);
    self.m_imgIconUp:setFile(InviteItem.s_iconMap.UP[self.m_data]);
    self.m_imgIconDown:setFile(InviteItem.s_iconMap.DOWN[self.m_data]);
    self.m_btnInvite:setEventTouch(self, self.onBtnClick);
end


InviteItem.setSelected = function(self, selected)
    self.m_imgIconUp:setVisible(not selected);
    self.m_imgIconDown:setVisible(selected);
    self.m_btnInvite:setEnable(not selected);
end

InviteItem.getHeight = function(self)
    return self.m_height;
end

InviteItem.onBtnClick = function(self, finger_action)
    if finger_action == kFingerDown then
        self:setSelected(true);
    elseif finger_action == kFingerUp then
        self:setSelected(false);
        self[InviteItem.s_btnOnclickMap[self.m_data]](self);
    end 
end

InviteItem.onFaceBookBtnClick = function (self)
    Log.d(self.TAG, "onFaceBookBtnClick");
    FacebookInviteService.invite();
end

InviteItem.onSmsBtnClick = function (self)
    Log.d(self.TAG, "onSmsBtnClick");
end

InviteItem.onEmailBtnClick = function (self)
    Log.d(self.TAG, "onEmailBtnClick");
end
