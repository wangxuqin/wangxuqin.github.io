require("view/friend/layout_friend_popup");
require("game/scene/comp/friend/leftTab/friendItem");
require("game/scene/comp/friend/invitePage/inviteItem");
require("game/scene/comp/friend/invitePage/invitePage");
require("game/scene/comp/friend/friendInfoPage/friendInfoPage");
-- ���ѶԻ���
FriendDialog = class(PopupDialog, false);
FriendDialog.TAG = "FriendDialog";


FriendDialog.ctor = function(self)
    super(self, layout_friend_popup, true);
end


FriendDialog.dtor = function(self)
    self.m_friendListView = nil;
    self.m_friendInfoPage = nil;
    PopupDialog.dtor(self);
end

FriendDialog.update = function (self, data)
    self.m_data = data;
end

FriendDialog.onPopupEnd = function(self)
    self:getCtrls();
    self:initialize();
	Model.setData(ModelKeys.HAS_POP_UP, true);
    self:addEventList();
    self:watchData();
    --this.addEventListener(TouchEvent.TOUCH,popUpTouchHandler); item��ɾ����ť
end

--�رյ���
FriendDialog.close = function(self)
    self:unwatchData();
    self:removeEventList();
    Model.setData(ModelKeys.HAS_POP_UP, false);
    PopupDialog.close(self);
end

FriendDialog.getCtrls = function(self)
    self.m_btnClose                 = self.m_root:getNodeByName("bg.btn_close");
    self.m_txtTitle                 = self.m_root:getNodeByName("bg.title_container.txt_title");
    self.m_topLight                 = self.m_root:getNodeByName("bg.img_top_light");
    self.m_mainContainer            = self.m_root:getNodeByName("bg.main_container");
    self.m_titleContainer           = self.m_root:getNodeByName("bg.title_container");
    self.m_leftListContainer        = self.m_root:getNodeByName("bg.left_container.left_list_container");
    self.m_leftInviteBtnContainer   = self.m_root:getNodeByName("bg.left_container.left_invite_btn");
    self.m_leftInviteBtnSelect      = self.m_root:getNodeByName("bg.left_container.left_invite_btn.img_left_invite_btn_select");
    self.m_leftInviteIcon           = self.m_root:getNodeByName("bg.left_container.left_invite_btn.img_left_invite_icon");
    self.m_txtInvite                = self.m_root:getNodeByName("bg.left_container.left_invite_btn.txt_invite");
    self.m_inviteCodeContainer      = self.m_root:getNodeByName("bg.main_container.invite_code_container");
    self.m_tvInviteCodeDesc         = self.m_root:getNodeByName("bg.main_container.invite_code_container.tv_invite_code_desc");
    self.m_txtInviteCodeTitle       = self.m_root:getNodeByName("bg.main_container.invite_code_container.txt_invite_code_title");
    self.m_imgInviteCodeUid         = self.m_root:getNodeByName("bg.main_container.invite_code_container.img_invite_code_uid");
    self.m_txtInviteCodeUid         = self.m_root:getNodeByName("bg.main_container.invite_code_container.txt_invite_code_uid");
    self.m_loadAnimContainer        = self.m_root:getNodeByName("bg.load_anim_container");
end

-- ��ʼ��
FriendDialog.initialize = function(self)
    self.m_inviteCodeContainer:setVisible(false);
    self.m_userData = Model.getData(ModelKeys.USER_DATA);
    self.m_btnClose:setOnClick(self, self.onCloseBtnClick);
    self.m_txtTitle:setText(STR_RANKING_FRIENDRANKING);
    self.m_txtInvite:setText(STR_FRIEND_FRIEND_POPUP_INVITE_TITLE);
    self.m_topLight:setTransparency(0.6);
    self.m_leftInviteBtnContainer:setEventTouch(self, self.onInviteBtnClick);
    self.m_leftInviteBtnContainer:setPickable(true);
    self.m_leftInviteBtnSelected = true;
    -- ��ʼ��ѡ��
    self.m_leftInviteBtnSelect:setVisible(self.m_leftInviteBtnSelected);
    local width, height = self.m_leftListContainer:getSize();
    self.m_friendListView = new(ListView2, 0, 0, 335, height);
    self.m_friendListView:setScrollBarWidth(0);
    self.m_friendListView:setOnItemClick(self, self.onItemClick);
    self.m_leftListContainer:addChild(self.m_friendListView);

    -- mainContainer layout
    self.m_inviteData = {};
    local x = InviteItem.PADDING * 2;
    local y = InviteItem.PADDING * 2;
    local main_w, main_h = self.m_mainContainer:getSize();
    local w = main_w - 2 * x;
    local h = main_h - 2 * y;
    if ArrayKit.indexOf(Model.getData(ModelKeys.SUPPORTED_LOGIN_TYPE), LoginTypes.LOGIN_TYPE_FACEBOOK) ~= -1 
    and LocalService.currentLocaleId() ~= "zh_Hans" then
        if self.m_userData["inviteNeedCode"] == "1" and self.m_userData["inviteCodeReward"] ~= nil then
            self.m_inviteCodeContainer:setVisible(true);
            local tv_w, _ = self.m_inviteCodeContainer:getSize();
            local content = StringKit.substitute(STR_FRIEND_FRIEND_POPUP_INVITE_CODE_PROMPT_LABEL, self.m_userData["inviteCodeReward"].inviteReward, self.m_userData["inviteCodeReward"].inviteLevel);
            local resTxt = new(ResText, content, tv_w, 1, kAlignCenter, _, 22, _, _, _, 1);
            local tv_h = resTxt:getHeight();
            resTxt:dtor();
            self.m_tvInviteCodeDesc:setText(content, tv_w, tv_h);
            self.m_txtInviteCodeTitle:setText(STR_FRIEND_FRIEND_POPUP_MY_INVITE_CODE_LABEL);
            self.m_txtInviteCodeUid:setText(self.m_userData.uid);
            local txt_w, txt_h = self.m_txtInviteCodeUid:getSize();
            local txt_y = tv_h + InviteItem.PADDING;
            self.m_txtInviteCodeTitle:setPos(0, txt_y);
            self.m_txtInviteCodeUid:setPos(180, txt_y);
            self.m_imgInviteCodeUid:setPos(180 - 5, txt_y - 5);
            self.m_imgInviteCodeUid:setSize(txt_w + 10, txt_h + 10);
            self.m_inviteCodeContainer:setSize(tv_w, txt_y + txt_h + 5);
            h = h - (txt_y + txt_h + 5 + InviteItem.PADDING);
            y = y + (txt_y + txt_h + 5 + InviteItem.PADDING);
            InviteItem.s_txtMap[InviteItem.NAME.FACKBOOK].TITLE = STR_FRIEND_INVITE_CODE_FACEBOOK_TITLE;
            InviteItem.s_txtMap[InviteItem.NAME.FACKBOOK].DESC = StringKit.substitute(STR_FRIEND_INVITE_CODE_FACEBOOK_DESC, self.m_userData["inviteCodeReward"].inviteReward, self.m_userData["inviteCodeReward"].inviteLevel);
        end
        if self.m_userData["inviteNeedCodeNew"] == "1" then
            table.insert(self.m_inviteData, InviteItem.NAME.FACKBOOKNEW);
        else
            table.insert(self.m_inviteData, InviteItem.NAME.FACKBOOK);
		end
    end
    if System.isAndroid() and LocalService.currentLocaleId() ~= "zh_Hans" then
        table.insert(self.m_inviteData, InviteItem.NAME.SMS);
        table.insert(self.m_inviteData, InviteItem.NAME.EMAIL);
    end
    self.m_invitePage = new(InvitePage, x, y, w, h, self.m_inviteData);
    self.m_mainContainer:addChild(self.m_invitePage);
    self.m_invitePage:setVisible(true);
end

FriendDialog.addEventList = function(self)
    if self.m_eventList == nil then
        self.m_eventList = {
            {UIEvent,      UIEvent.s_cmd.ROOM_PASSIVE_LEAVE_ROOM,       "close"};
            {CommandEvent, CommandEvent.s_cmd.FRIEND_LIST_ITEM_CHANGE,  "listChangHandler"};
            {CommandEvent, CommandEvent.s_cmd.FRIEND_LIST_IS_NULL,      "friendListIsNullHandler"};
        };
    end
    EventDispatcher.getInstance():registerEventList(self, self.m_eventList);
end

FriendDialog.removeEventList = function(self)
    if self.m_eventList ~= nil then
        EventDispatcher.getInstance():unregisterEventList(self, self.m_eventList);
    end
    self.m_eventList = nil;
end

FriendDialog.watchData = function(self)
    if self.m_watchDataList == nil then
        self.m_watchDataList = {
            {ModelKeys.FRIEND_LIST_IS_LOADING, self, self.watchFriendListIsLoading, true};
            {ModelKeys.FRIEND_LIST_NEW,        self, self.watchFriendListNew,       true};
        }
    end
    Model.watchDataList(self.m_watchDataList);
end

FriendDialog.unwatchData = function(self)
    if self.m_watchDataList ~= nil then
        Model.unwatchDataList(self.m_watchDataList);
    end
    self.m_watchDataList = nil;
end

FriendDialog.watchFriendListIsLoading = function(self, value)
	self.m_isLoading = value;
end

FriendDialog.watchFriendListNew = function(self, value)
    if value == nil then
        self.m_miniLoad = AtomAnimManager.getInstance():playAnim("atomAnimTable/common/anim_common_miniLoad", self.m_loadAnimContainer, 0, 0, false);
		self.m_loadAnimContainer:setVisible(true);
        self.m_mainContainer:setVisible(false);
	else
		if self.m_miniLoad ~= nil then
            self.m_miniLoad:release();
            self.m_miniLoad = nil;
        end
        self.m_loadAnimContainer:setVisible(false);
		self.m_mainContainer:setVisible(true);
	    local vector = value or {};
        if #vector == 0 then
            if not(ArrayKit.indexOf(Model.getData(ModelKeys.SUPPORTED_LOGIN_TYPE), LoginTypes.LOGIN_TYPE_FACEBOOK) ~= -1  and LocalService.currentLocaleId() ~= "zh_Hans" or System.isAndroid() and LocalService.currentLocaleId() ~= "zh_Hans") then
				--JuhuaAndHintManager.showHint(bgSprite, Localization.getText("FRIEND.FRIEND_LIST_IS_NULL_TIPS"), false);
                self.m_miniLoad = AtomAnimManager.getInstance():playAnim("atomAnimTable/common/anim_common_miniLoad", self.m_loadAnimContainer, 0, 0, false);
            else
                if self.m_miniLoad ~= nil then
                    self.m_miniLoad:release();
                    self.m_miniLoad = nil;
                end     
            end
            EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.FRIEND_LIST_IS_NULL);
            self.m_data = {};
            if self.m_adapter then
                self.m_adapter:changeData(self.m_data);
            else
                self.m_adapter = new(CacheAdapter, FriendLeftItem, self.m_data);
                self.m_friendListView:setAdapter(self.m_adapter);
            end
        else
            vector = AlgorithmKit.quickSort(vector, self, self.sortFunction);
            self.m_data = vector;
            if self.m_adapter then
                self.m_adapter:changeData(self.m_data);
            else
                self.m_adapter = new(CacheAdapter, FriendLeftItem, self.m_data);
                self.m_friendListView:setAdapter(self.m_adapter);
            end	
        end
    end
end

--[Comment]
--�ض�����
FriendDialog.sortFunction = function(self, data1, data2)
    local ret = 0;
    if data1.status == data2.status then
		if data1.status == FriendVO.STATUS_AT_PLAY then
			if data1:isSupportTable() and not data2:isSupportTable() then
                ret = -1;
			elseif not data1:isSupportTable() and data2:isSupportTable() then
				ret = 1;
			else 	
				ret = 0;
			end
		elseif data1.status == FriendVO.STATUS_OFF_LINE then
			if data1.offLineDays >= 7 and data2.offLineDays >= 7 then
				if data1.isPlatFriend and not data2.isPlatFriend then
					ret = -1;
				elseif not data1.isPlatFriend and data2.isPlatFriend then
					ret = 1;
				else
					if data1.offLineDays > data2.offLineDays then
						ret = 1;
					elseif data1.offLineDays < data2.offLineDays then
                        ret = -1;
					else
						ret = 0;
					end
				end
			elseif data1.offLineDays >= 7 and data2.offLineDays < 7 then
				ret = -1;
			elseif data1.offLineDays < 7 and data2.offLineDays >= 7 then
			    ret = 1;
			else
				if data1.offLineDays > data2.offLineDays then
					ret = 1;
				elseif data1.offLineDays < data2.offLineDays then
				    ret = -1;
				else
					ret = 0;
                end
			end
		else
			ret = 0;
		end
	else
		local arr = {FriendVO.STATUS_AT_PLAY, FriendVO.STATUS_ON_LINE, FriendVO.STATUS_OFF_LINE};
		local index1 = ArrayKit.indexOf(arr, data1.status);
		local index2 = ArrayKit.indexOf(arr, data2.status);
		if index1 < index2 then
			ret = -1;
		elseif index1 > index2 then
			ret = 1;
		else
			ret = 0;
		end
	end
end

FriendDialog.onCloseBtnClick = function(self)
    self:close();
end

FriendDialog.onInviteBtnClick = function(self, finger_action)
    if finger_action == kFingerUp then
        Log.d(self.TAG, "onInviteBtnClick");
        if not self.m_leftInviteBtnSelected then
            self.m_leftInviteBtnSelected = true;
            self.m_leftInviteBtnSelect:setVisible(true);
            if self.m_lastSelectItem then
                self.m_lastSelectItem:setSelected(false);
                self.m_lastSelectItem = nil;
            end
            -- ���½���
            self:showInviteFriendPage();
            return;
        end
    end
end

FriendDialog.onItemClick = function(self, adapter, view, index)
    Log.d(self.TAG, "onItemClick", "index:" .. index);
    if self.m_lastSelectItem and self.m_lastSelectItem == view then
        return;
    end
    self.m_leftInviteBtnSelected = false;
    self.m_leftInviteBtnSelect:setVisible(false);
    if self.m_lastSelectItem then
        self.m_lastSelectItem:setSelected(false);
    end
    view:setSelected(true);
    self.m_lastSelectItem = view;
    local data = self.m_data[index];
    -- ���½���
    if not self.m_friendInfoPage then
        self.m_friendInfoPage = new(FriendInfoPage);
        self.m_mainContainer:addChild(self.m_friendInfoPage); 
    end
    self.m_friendInfoPage:setData(data);
    self:showFriendInfoPage();
end

FriendDialog.listChange = function(self)
    --ʵ�ֵ��listView ���������
end

FriendDialog.listChangHandler = function(self)
    self:showFriendInfoPage();
    self.m_leftInviteBtnSelected = false;
    self.m_leftInviteBtnSelect:setVisible(false);
    if self.m_lastSelectItem then
        self.m_lastSelectItem:setSelected(true);
    else
        self.m_adapter:getView(1):setSelected(true);
    end
end

FriendDialog.friendListIsNullHandler = function(self)
    local index = ArrayKit.indexOf(Model.getData(ModelKeys.SUPPORTED_LOGIN_TYPE), LoginTypes.LOGIN_TYPE_FACEBOOK);
    if( index ~= -1  and LocalService.currentLocaleId() ~= "zh_Hans" or System.isAndroid() and LocalService.currentLocaleId() ~= "zh_Hans") then
        self:showInviteFriendPage();
	else
		if self.m_friendInfoPage then
            self.m_friendInfoPage:setVisible(false);
        end
	end
end

FriendDialog.showInviteFriendPage = function(self)
    local _, y = self.m_invitePage:getPos();
    self.m_invitePage:setVisible(true);
    self.m_inviteCodeContainer:setVisible(y ~= 0);
    if self.m_friendInfoPage then
        self.m_friendInfoPage:setVisible(false);
    end
end

FriendDialog.showFriendInfoPage = function(self)
    self.m_invitePage:setVisible(false);
    self.m_inviteCodeContainer:setVisible(false);
    if self.m_friendInfoPage then
        self.m_friendInfoPage:setVisible(true);
    end
end