require("game/model/data/vo/friendVO");
require("view/friend/layout_friend_left_item");
require("ui/ex/urlImage");

FriendLeftItem = class(Node);
FriendLeftItem.TAG = "FriendLeftItem";
FriendLeftItem.DEFAULT_FILE = 
{
    MALE    = "userinfo/imgface_default_male.jpg";
    FEMALE  = "userinfo/imgface_default_female.jpg";
}
FriendLeftItem.ctor = function(self,data) 
    if not data or type(data)~="table" then
        Log.e(self.TAG, "ctor", "data is nil or not table");
        return;
    end 
    self:setSize(320,61); 
    self.m_root = SceneLoader.load(layout_friend_left_item);
    self:addChild(self.m_root);
    self.m_data = data;
    self:getCtrls();
    self:initialize();
end

FriendLeftItem.dtor = function(self)
   Node:dtor(self);
end

FriendLeftItem.getCtrls = function(self)
    self.m_bg               = self.m_root:getNodeByName("bg");
    self.m_imgSelected      = self.m_root:getNodeByName("bg.img_selected");
    self.m_txtName          = self.m_root:getNodeByName("bg.txt_name"); 
    self.m_imgHeadFtameM    = self.m_root:getNodeByName("bg.img_head_frame_m");
    self.m_imgHeadFtameF    = self.m_root:getNodeByName("bg.img_head_frame_f");    
    self.m_imgStatusOff     = self.m_root:getNodeByName("bg.img_status_off");
    self.m_imgStatusOn      = self.m_root:getNodeByName("bg.img_status_on");    
    self.m_btnDelete        = self.m_root:getNodeByName("bg.btn_delete"); 
    self.m_txtDelete        = self.m_root:getNodeByName("bg.btn_delete.txt_delete");
end

FriendLeftItem.initialize = function(self)
    if self.m_data.sex == "m" then
        self.m_imgHeadFtameM:setVisible(true);
        self.m_imgHeadFtameF:setVisible(false);
        self:addHeadImage(FriendLeftItem.DEFAULT_FILE.MALE, self.m_data.image);
        self.m_imgHeadFtameM:setLevel(3);
    else
        self.m_imgHeadFtameM:setVisible(false);
        self.m_imgHeadFtameF:setVisible(true);
        self:addHeadImage(FriendLeftItem.DEFAULT_FILE.FEMALE, self.m_data.image);
        self.m_imgHeadFtameF:setLevel(3);
    end
    if self.m_data.status == FriendVO.STATUS_OFF_LINE then
        self.m_imgStatusOn:setVisible(false);
        self.m_imgStatusOff:setVisible(true);
        self.m_imgStatusOff:setLevel(2);
    else
        self.m_imgStatusOn:setVisible(true);
        self.m_imgStatusOff:setVisible(false);
        self.m_imgStatusOn:setLevel(2);
    end 
    self.m_txtName:setText(self.m_data.name);
    self.m_imgSelected:setLevel(1);
    self.m_headImage:setLevel(2);
    self.m_txtName:setLevel(2);
    self.m_btnDelete:setLevel(4);
end

FriendLeftItem.setSelected = function(self, selected)
    self.m_imgSelected:setVisible(selected);
end

FriendLeftItem.addHeadImage = function(self, defaultFile, url)
    if string.len(url) <= 5 then
        if FileKit.isFileExist("userinfo/imgface_" .. url .. ".jpg") then
            self.m_headImage = new(Image, "userinfo/imgface_" .. url .. ".jpg");
        else
            self.m_headImage = new(Image, defaultFile);
        end
    else
        self.m_headImage = new(UrlImage, defaultFile, url, nil, 1);
    end
    self.m_headImage:setSize(48, 48);
    self.m_headImage:setPos(15, 6);
    self.m_bg:addChild(self.m_headImage);
end

