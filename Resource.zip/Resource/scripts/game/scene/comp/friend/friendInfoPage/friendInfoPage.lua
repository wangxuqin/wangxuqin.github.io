require("game/model/data/vo/friendVO");
require("view/friend/layout_friend_info_page");

FriendInfoPage = class(Node)
FriendInfoPage.PADDING = 12;
FriendInfoPage.TAG = "FriendInfoPage";
local mFile = "userinfo/user_info_gender_label_male.png";
local fFile = "userinfo/user_info_gender_label_female.png";
local mRes = new(ResImage, mFile);
local fRes = new(ResImage, fFile);
FriendInfoPage.s_sexMap = 
{
    ["m"] = {icon = mFile, width = mRes:getWidth(), height = mRes:getHeight()},
    ["f"] = {icon = fFile, width = fRes:getWidth(), height = fRes:getHeight()},
}

FriendInfoPage.ctor = function(self)
    self.m_root = SceneLoader.load(layout_friend_info_page);
    self:addChild(self.m_root);
    self:setPos(0, 70);
    self:getCtrls();
end

FriendInfoPage.dtor = function(self)
    Node.dtor(self);
end

FriendInfoPage.getCtrls = function(self)
    self.m_imgFriendFrameM      = self.m_root:getNodeByName("img_friend_frame_m");
    self.m_imgFriendFrameF      = self.m_root:getNodeByName("img_friend_frame_f");
    self.m_imgSexIcon           = self.m_root:getNodeByName("img_sex_icon");
    self.m_imgVipIcon           = self.m_root:getNodeByName("img_vip_icon");
    self.m_txtName              = self.m_root:getNodeByName("txt_name");
    self.m_txtLevel             = self.m_root:getNodeByName("txt_level");
    self.m_txtChips             = self.m_root:getNodeByName("txt_chips");
    self.m_txtCounts            = self.m_root:getNodeByName("txt_counts");
    self.m_txtRate              = self.m_root:getNodeByName("txt_rate");
    self.m_btnGiveChips         = self.m_root:getNodeByName("btn_give_chips");
    self.m_txtGiveChips         = self.m_root:getNodeByName("btn_give_chips.txt_give_chips");
    self.m_btnGiveGift          = self.m_root:getNodeByName("btn_give_gift");
    self.m_txtGiveGift          = self.m_root:getNodeByName("btn_give_gift.txt_give_gift");
    self.m_trackFriendContainer = self.m_root:getNodeByName("track_friend_container");
    self.m_btnTrackFriend       = self.m_root:getNodeByName("track_friend_container.btn_track_friend");
    self.m_imgTrackBack         = self.m_root:getNodeByName("track_friend_container.img_track_back");
    self.m_txtStatus            = self.m_root:getNodeByName("track_friend_container.img_track_back.txt_status");
    self.m_txtTrack             = self.m_root:getNodeByName("track_friend_container.txt_track");
end

FriendInfoPage.setData = function(self, data)
    self.m_data = data;
    if not data then
        Log.e("FriendInfoPage", "data is nil or not table");
        return;
    end
    self.m_imgSexIcon:setFile(FriendInfoPage.s_sexMap[data.sex]["icon"]);
    self.m_imgSexIcon:setSize(FriendInfoPage.s_sexMap[data.sex]["width"],FriendInfoPage.s_sexMap[data.sex]["height"]);
    if data.sex == "m" then
        self.m_imgFriendFrameM:setVisible(true);
        self.m_imgFriendFrameF:setVisible(false);
        self:addHeadImage(FriendLeftItem.DEFAULT_FILE.MALE, data.image);  
    else
        self.m_imgFriendFrameM:setVisible(false);
        self.m_imgFriendFrameF:setVisible(true);
        self:addHeadImage(FriendLeftItem.DEFAULT_FILE.FEMALE, data.image);
    end
    
    self.m_txtName:setText(data.name);
    self.m_txtLevel:setText(StringKit.substitute(STR_LOGIN_LEVEL_TEXT, data.level).. " " .. data.title);
    self.m_txtChips:setText(StringKit.substitute(STR_FRIEND_USER_FRIEND_CHIPS, Formatter.formatBigNumber(data.chip)));
    self.m_txtCounts:setText(StringKit.substitute(STR_FRIEND_PLAY_GAME_COUNTS, data.lose + data.win));
    if data.win == 0 and data.lose == 0 then
        self.m_txtRate:setText(StringKit.substitute(STR_ROOM_USERINFO_WINRATE, 0));
    else
        self.m_txtRate:setText(StringKit.substitute(STR_ROOM_USERINFO_WINRATE, FriendInfoPage.getRounding(data.win * 100 /(data.win + data.lose))));
    end
    self.m_txtGiveChips:setText(StringKit.substitute(STR_FRIEND_GIVE_CHIP_BUTTON, Formatter.formatBigNumber(data.sendChipLimit)));
    self.m_txtGiveGift:setText(STR_FRIEND_GIVE_GIFT_BUTTON);
    self.m_txtTrack:setText(STR_FRIEND_TRACK_BUTTON);
    
    self.m_btnTrackFriend:setOnClick(self, self.onTrackBtnClick);
    self.m_btnGiveChips:setOnClick(self, self.onGiveChipsBtnClick);
    self.m_btnGiveGift:setOnClick(self, self.onGiveGiftBtnClick);
    self.m_btnGiveChips:setEnable( data.sendChipTimes > 0);
	self.m_imgVipIcon:setVisible(data.vip > 0);				
	if data.vip > 0 then
        self.m_imgVipIcon:setFile("store/vip_icon_" .. tostring(data.vip) .. ".png");
        self.m_imgVipIcon:setVisible(true);
    end
    self.m_userData = Model.getData(ModelKeys.USER_DATA);
    if self.m_userData["isSendChips"] == 0 then
		self.m_btnGiveChips:setVisible(false);
        local _, gift_h = self.m_btnGiveGift:getSize();
        local _, gift_y = self.m_btnGiveGift:getPos();
        local gift_w, _ = self.m_btnTrackFriend:getSize();
        local gift_x, _ = self.m_trackFriendContainer:getPos();
        self.m_btnGiveGift:setPos(gift_x, gift_y);
        self.m_btnGiveGift:setSize(gift_w, gift_h);
	else
		self.m_btnGiveChips:setVisible(true);
	end
    if data.status == FriendVO.STATUS_AT_PLAY and data:isSupportTable() then
		--追踪好友，进桌游戏
        if data.tableType == LoginSuccData.ROOM_TYPE_NORMAL or data.tableType == LoginSuccData.ROOM_TYPE_PROFESSIONAL then
            local text = "";
            local smallBlind = Formatter.formatBigNumber(data.smallBlind) .. "/" .. Formatter.formatBigNumber(data.smallBlind * 2);
            if data.tableLevel == 1 then
                text = STR_FRIEND_USER_FRIEND_STATUE_PRIMARY_LEVEL;
            elseif data.tableLevel == 2 then
                text = STR_FRIEND_USER_FRIEND_STATUE_PRIMARY_LEVEL;
            elseif data.tableLevel == 3 then
                text = STR_FRIEND_USER_FRIEND_STATUE_MIDDLE_LEVEL;
            elseif data.tableLevel == 4 then
                text = STR_FRIEND_USER_FRIEND_STATUE_HIGH_LEVEL;
            end
            self.m_txtStatus:setText(StringKit.substitute(text, smallBlind));
		else
			self.m_txtStatus:setText(StringKit.substitute(STR_FRIEND_USER_FRIEND_STATUE, data.tableName)); 
        end
        self.m_btnTrackFriend:setEnable(true);
    else
        self.m_btnTrackFriend:setEnable(false);
        if data.status == FriendVO.STATUS_AT_PLAY or data.status == FriendVO.STATUS_ON_LINE then
			self.m_txtStatus:setText(STR_FRIEND_USER_FRIEND_STATUE_IN_HALL);
		else
            local statusText = "";
			if(data.offLineDays == 0) then
				statusText = STR_FRIEND_OFF_LINE_TODAY;
			elseif data.offLineDays < 7 then
			    statusText = StringKit.substitute(STR_FRIEND_OFF_LINE_DAYS, data.offLineDays);
			elseif data.offLineDays >= 7 and data.offLineDays < 30 then
				statusText = StringKit.substitute(STR_FRIEND_OFF_LINE_WEEKS, math.ceil(data.offLineDays/7));
				if data.isMobile then
                    self.m_btnTrackFriend:setEnable(true);
                    statusText = StringKit.substitute(STR_FRIEND_FRIEND_POPUP_CALLBACK_BTN_TEXT, Formatter.formatBigNumber(self.m_userData.CALLBACK_REWARD));
                    self.m_txtTrack:setText(STR_FRIEND_FRIEND_POPUP_CALLBACK);
				end
			elseif data.offLineDays >= 30 and data.offLineDays < 360 then
                statusText = StringKit.substitute(STR_FRIEND_OFF_LINE_MONTH, math.ceil(data.offLineDays/30));
				if data.isMobile then
					self.m_btnTrackFriend:setEnable(true);
					statusText = StringKit.substitute(STR_FRIEND_FRIEND_POPUP_CALLBACK_BTN_TEXT, Formatter.formatBigNumber(self.m_userData.CALLBACK_REWARD));
					self.m_txtTrack:setText(STR_FRIEND_FRIEND_POPUP_CALLBACK);
				end
			else
                statusText = StringKit.substitute(STR_FRIEND_OFF_LINE_YEARS, math.ceil(data.offLineDays/360));
			end
			self.m_txtStatus:setText(statusText);			
        end
        self.m_txtTrack:setColor(180, 180, 180);
        self.m_txtStatus:setColor(180, 180, 180);
	end
end

FriendInfoPage.onTrackBtnClick = function (self)
    Log.d(self.TAG, "onTrackBtnClick");
    if self.m_data.status == FriendVO.STATUS_AT_PLAY and self.m_data:isSupportTable() and TableLimit.checkAccess(self.m_data.tableLevel, LoginSuccData.ROOM_TYPE_NORMAL, true) then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_FRIEND_DIALOG);
        local roomInfo = {tid = self.m_data.tid, ip = self.m_data.ip, port = self.m_data.port};
        if StateMachine.getInstance():getCurrentState() == States.Room then
            if LoginSuccData.isMatch(Model.getData(ModelKeys.ROOM_LOGIN_SUCC_DATA).roomType) then
                EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, {message = STR_ROOM_MATCH_ROOM_NOT_TRACK_FRIENDS_TIP});
		    else
			    if SeatManager.selfInGame then
				    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG,{
					    message     = STR_ROOM_ROOM_TRACK_FRIEND_TIPS, 
					    confirm     = STR_COMMON_CONFIRM,
					    cancel      = STR_COMMON.CANCEL,
					    callback    = 
                        function(types)
						    if types == DialogCallback.CONFIRM then
							    --用户确定参加活动，本局游戏结束后站起
							    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.USER_STAND_UP_AND_LEAVE_ROOM, { ["type"] = RoomScene.ROOM_TO_ROOM_OF_TRACK_FRINED_NEXT_HAND, ["roomInfo"] = roomInfo});
                            end
					    end
				    });
			    else
                    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.USER_STAND_UP_AND_LEAVE_ROOM, { ["type"] = RoomScene.ROOM_TO_ROOM_OF_TRACK_FRINED_NOW, ["roomInfo"] = roomInfo});
			    end
		    end
        else    
            CommonFunction.gotoScene(States.Room, 1000);
			EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.PREPARE_LOGIN_ROOM, { playNow = false, enterFrom = RequestLoginData.MAIN_PAGE, roomInfo = roomInfo});
        end
    elseif self.m_data.offLineDays >= 7 then
        --facebook好友发送消息,未做好。。。
		--if(selectedFriend.isPlatFriend && selectedFriend.pid) //如果是fb好友，发送推送并且发送fb邀请
	    --FrameworkGlobal.context.dispatchEventWith(CommandEventNames.FACEBOOK_SEND_MESS_TO_FRIEND, false, {"message":"my friends come on!","callback" : facebookInviteCallback, "sendToFid" : [100003164752173]});//selectedFriend.pid});
		--发送推送
        local data = Model.getData(ModelKeys.USER_DATA);
		if data.CALLBACK_CGI_ROOT ~= nil then 
            HttpService.postUrl(data.CALLBACK_CGI_ROOT, { mod = "friend", act = "callback", fbid = self.m_data.uid}, self.friendCallBack, TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
		else
            HttpService.post({ mod = "friend", act = "callback", fbid = self.m_data.uid}, self.friendCallBack, TopTipKit.badNetworkHandler, TopTipKit.badNetworkHandler);
		end
    end
end

FriendInfoPage.friendCallBack = function (value)
	if value ~= nil then
		local flag, data = JsonKit.decode(value);
		if flag then
			if data.ret == 0 and data.count >= 1 then --发送成功
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, { message = STR_FRIEND_FRIEND_POPUP_CALLBACKE_SUCC_WITH_CHIP});
			elseif data.ret == 0 and data.count == 0 then --当天已经发送过
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, { message = STR_FRIEND_FRIEND_POPUP_CALLBACK_REPEAT});
			else --发送失败
				EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, { message = STR_FRIEND_FRIEND_POPUP_CALLBACK_FAILE});
            end
		end
	end
end

FriendInfoPage.onGiveChipsBtnClick = function (self)
    Log.d(self.TAG, "onGiveChipsBtnClick");
	if self.m_data and not self._giveChipFriend then
		self._giveChipFriend = self.m_data;
        local params = { mod = "friend", act = "giveChipsNew", touid = self.m_data.uid};
		HttpService.post(params, self, self.giveChipCallback, self.giveChipCallback, self.giveChipCallback);
	end
end

FriendInfoPage.giveChipCallback = function (self, json)
    local flag, result = JsonKit.decode(json);
    if flag and result then
        if result.ret == 0 then
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {
            message     = STR_FRIEND_GIVE_CHIP_TOO_POOR,
            confirm     = STR_HALL_GO_TO_STORE,
            cancel      = STR_COMMON_CANCEL,
            callback    = 
            function(types)
                if types == DialogCallback.CONFIRM then
                    EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.OPEN_STORE_POPUP, StoreDialog.STORE_POP_UP_CHIPS_PAGE);
                end
            end
            });
        elseif result.ret == 1 then
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_FRIEND_GIVE_CHIP_COUNT_OUT );
        elseif result.ret == 2 then
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, StringKit.substitute(STR_FRIEND_GIVE_CHIP_SUCCESS, Formatter.formatNumberWithSplit(self._giveChipFriend.sendChipLimit)));
			self._giveChipFriend.sendChipTimes = self._giveChipFriend.sendChipTimes - 1;
			if self.m_data == self._giveChipFriend then
                self.m_btnGiveChips:setEnable(self._giveChipFriend.sendChipTimes > 0);
            end
        else
            TopTipKit.badNetworkHandler();
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_COMMON_BAD_NETWORK);
        end
    else
        TopTipKit.badNetworkHandler();
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_COMMON_BAD_NETWORK);
    end
    self._giveChipFriend = nil;
end

FriendInfoPage.onGiveGiftBtnClick = function (self)
    Log.d(self.TAG, "onGiveGiftBtnClick");
	if self.m_data then
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.HIDE_FRIEND_DIALOG);
        EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.OPEN_GIFT_POPUP, {isInRoom = false, uid = self.m_data.uid, userNick = self.m_data.name, tabId = 0});
	end
end

FriendInfoPage.addHeadImage = function(self, defaultFile, url)
    if not self.m_headImage then
        if string.len(url) <= 5 then
            if FileKit.isFileExist("userinfo/imgface_" .. url .. ".jpg") then
                self.m_headImage = new(Image, "userinfo/imgface_" .. url .. ".jpg");
            else
                self.m_headImage = new(Image, defaultFile);
            end
        else 
            self.m_headImage = new(UrlImage, defaultFile, url, nil, 1);
        end
    else
        if string.len(url) <= 5 then
            if FileKit.isFileExist("userinfo/imgface_" .. url .. ".jpg") then
                self.m_headImage:setFile("userinfo/imgface_" .. url .. ".jpg");
            else
                self.m_headImage:setFile(defaultFile);
            end
        else
            if self.m_headImage.setDefault then
                self.m_headImage:setDefault(defaultFile);
                self.m_headImage:setUrl(url);
            else
                self.m_headImage = nil;
                self.m_headImage = new(UrlImage, defaultFile, url, nil, 1);
            end
        end
    end
    local x, y = self.m_imgFriendFrameM:getPos();
    self.m_headImage:setSize(150, 150);
    self.m_headImage:setPos(x + 3, y + 3);
    self.m_root:addChild(self.m_headImage);
    self.m_headImage:setLevel(1);
    self.m_imgFriendFrameM:setLevel(2);
    self.m_imgFriendFrameF:setLevel(2);
    self.m_imgSexIcon:setLevel(3);
    self.m_imgVipIcon:setLevel(3);
end

--四舍五入
FriendInfoPage.getRounding = function(a)
	local r1, r2 = math.modf(a, 1)
	r2 = r2 >= 0.5 and 1 or 0
	return r1 + r2
end
