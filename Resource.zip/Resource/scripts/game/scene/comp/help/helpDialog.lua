require("view/help/layout_help");
require("game/scene/comp/help/basicPage/basicPage");
require("game/scene/comp/help/normalPage/normalPage");
require("game/scene/comp/help/levelPage/levelPage");
require("game/scene/comp/help/feedPage/feedPage");
require("game/scene/comp/help/feedPage/loginFeedPage");

HelpDialog = class(PopupDialog, false)

HelpDialog.TAB_NORMAL_PAGE  = 1;
HelpDialog.TAB_BASIC_PAGE   = 2;
HelpDialog.TAB_LEVEL_PAGE   = 3;
HelpDialog.TAB_FEED_PAGE    = 4;
--�����ټ��Ϸ����������ͣ������ڵ�¼ҳ���ȥ��һ�����ͣ�����ҳҳ�����������һ������

HelpDialog.ctor = function (self)
    super(self,layout_help,true);
end


HelpDialog.dtor = function (self)
    self.m_initPageFlagArr = nil;
end

HelpDialog.onPopupEnd = function (self)
    self:getCtrls();    
    self:init();    
end

HelpDialog.getCtrls = function(self)   
    self.m_btnClose              = self.m_root:getNodeByName("bg.btn_close");
    self.m_txtTitle              = self.m_root:getNodeByName("bg.img_top.txt_title");
    self.m_tabContainer          = self.m_root:getNodeByName("bg.tab_container");

    self.m_normalContainer       = self.m_root:getNodeByName("bg.normal_container");
    self.m_basicContainer        = self.m_root:getNodeByName("bg.basic_container");
    self.m_levelContainer        = self.m_root:getNodeByName("bg.level_container");
    self.m_feedContainer         = self.m_root:getNodeByName("bg.feed_container");  

    self.m_pageArr = {
        [self.TAB_NORMAL_PAGE]  = self.m_normalContainer;
        [self.TAB_BASIC_PAGE]   = self.m_basicContainer;
        [self.TAB_LEVEL_PAGE]   = self.m_levelContainer;
        [self.TAB_FEED_PAGE]    = self.m_feedContainer;
    };

end

HelpDialog.init = function(self)
    self.m_initPageFlagArr = {};   
    self.m_btnClose:setOnClick(self,self.onBtnClickClose);
    self.m_txtTitle:setText(STR_SETTING_HELP_POPUP_TITLE); 

    self.m_tab = new(ButtonTag);
    self.m_tab:setButtonTagVerticalMul(STR_SETTING_HELP_CATEGORY_ITEM,
                                            "help/page-pop-up-tab-bg.png",
                                            "help/page-pop-up-tab-group-vernier.png",
                                            "help/page-pop-up-tab-group-vernier.png",
                                            230,240,10,10,16,16,12,12,4,29,true,28);  
    self.m_tab.buttonSlide:setPos(-5);
    self.m_tab.buttonSlide:setSize(245);
    self.m_tab:setPopView(4);
    self.m_tab:setOnTagChangedAnimEnd(self,self.onTabChanged);
    self.m_tabContainer:addChild(self.m_tab);      
    self:onTabChanged(4);
end



HelpDialog.onTabChanged = function(self,index)   
    self:hideAllPage(); --����������ҳ��
    if index == self.TAB_NORMAL_PAGE then
        if self.m_initPageFlagArr[self.TAB_NORMAL_PAGE] ~= true then
            self.m_normalPage = new(NormalPage);
            self.m_pageArr[self.TAB_NORMAL_PAGE]:addChild(self.m_normalPage);
            self.m_initPageFlagArr[self.TAB_NORMAL_PAGE] = true;
        end
        self.m_pageArr[self.TAB_NORMAL_PAGE]:setVisible(true);   
   
    elseif index == self.TAB_BASIC_PAGE then
        if self.m_initPageFlagArr[self.TAB_BASIC_PAGE] ~= true then
            self.m_basicPage = new(BasicPage);
            self.m_pageArr[self.TAB_BASIC_PAGE]:addChild(self.m_basicPage);
            self.m_initPageFlagArr[self.TAB_BASIC_PAGE] = true;
        end
        self.m_pageArr[self.TAB_BASIC_PAGE]:setVisible(true);
    
    elseif index == self.TAB_LEVEL_PAGE then
        if self.m_initPageFlagArr[self.TAB_LEVEL_PAGE] ~= true then
            self.m_levelPage = new(LevelPage);
            self.m_pageArr[self.TAB_LEVEL_PAGE]:addChild(self.m_levelPage);
            self.m_initPageFlagArr[self.TAB_LEVEL_PAGE] = true;
        end
        self.m_pageArr[self.TAB_LEVEL_PAGE]:setVisible(true);
    
    elseif index == self.TAB_FEED_PAGE then
    
        if Model.getData(ModelKeys.USER_DATA)~=nil then
            if self.m_initPageFlagArr[self.TAB_FEED_PAGE] ~= true then
                self.m_feedPage = new(FeedPage);
                self.m_pageArr[self.TAB_FEED_PAGE]:addChild(self.m_feedPage);
                self.m_initPageFlagArr[self.TAB_FEED_PAGE] = true;
            end
            self.m_pageArr[self.TAB_FEED_PAGE]:setVisible(true);
        else
            if self.m_initPageFlagArr[self.TAB_FEED_PAGE] ~= true then
                self.m_loginFeedPage = new(LoginFeedPage);
                self.m_pageArr[self.TAB_FEED_PAGE]:addChild(self.m_loginFeedPage);
                self.m_initPageFlagArr[self.TAB_FEED_PAGE] = true;
            end
            self.m_pageArr[self.TAB_FEED_PAGE]:setVisible(true);  
        end
    end
end

HelpDialog.hideAllPage = function(self)
    if self.m_pageArr ~= nil then
        for i = 1, #self.m_pageArr do
            self.m_pageArr[i]:setVisible(false);
        end
    end
end

HelpDialog.onBtnClickClose = function(self)
    self:close();
end

HelpDialog.update = function(self, data)
   PopupDialog.update(self, data);
   if data ~= nil and data.tab ~= nil then
        self:onTabChanged(data.tab);
   end
end