require("view/help/bet/layout_bet");

helpBetPage = {}

helpBetPage.getView = function ()
   
    helpBetPage.m_root = SceneLoader.load(layout_bet); 

    helpBetPage.getCtrls();

    helpBetPage.setText();

    return helpBetPage.m_root;
end

helpBetPage.getCtrls = function ()    
    helpBetPage.roundTitle1 = helpBetPage.m_root:getNodeByName("view.scrollView.bg1.roundTitle1"); 
    helpBetPage.text1       = helpBetPage.m_root:getNodeByName("view.scrollView.bg1.text1"); 
    helpBetPage.roundTitle2 = helpBetPage.m_root:getNodeByName("view.scrollView.bg2.roundTitle2");  
    helpBetPage.text2       = helpBetPage.m_root:getNodeByName("view.scrollView.bg2.text2");  
    helpBetPage.roundTitle3 = helpBetPage.m_root:getNodeByName("view.scrollView.bg3.roundTitle3");  
    helpBetPage.text3       = helpBetPage.m_root:getNodeByName("view.scrollView.bg3.text3");  
    helpBetPage.roundTitle4 = helpBetPage.m_root:getNodeByName("view.scrollView.bg4.roundTitle4");  
    helpBetPage.text4       = helpBetPage.m_root:getNodeByName("view.scrollView.bg4.text4");  
    helpBetPage.roundTitle5 = helpBetPage.m_root:getNodeByName("view.scrollView.bg5.roundTitle5");  
    helpBetPage.text5       = helpBetPage.m_root:getNodeByName("view.scrollView.bg5.text5");        
end

helpBetPage.setText = function ()    
    helpBetPage.roundTitle1:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[1].TITLE); 
    helpBetPage.text1:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[1].CONTENT); 
    helpBetPage.roundTitle2:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[2].TITLE); 
    helpBetPage.text2:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[2].CONTENT); 
    helpBetPage.roundTitle3:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[3].TITLE); 
    helpBetPage.text3:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[3].CONTENT); 
    helpBetPage.roundTitle4:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[4].TITLE); 
    helpBetPage.text4:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[4].CONTENT);  
    helpBetPage.roundTitle5:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[5].TITLE); 
    helpBetPage.text5:setText(STR_SETTING_HELP_CONTENT.PAGE3.SECTION[5].CONTENT);   
end
