require("view/help/rules/layout_rules");
require("game/scene/comp/room/pokerCard");

helpGameRulesPage = {}

helpGameRulesPage.getView = function ()
   
    helpGameRulesPage.m_root = SceneLoader.load(layout_rules); 

    helpGameRulesPage.m_publicCard  = {};

    helpGameRulesPage.m_handCardLeft  = {};
    helpGameRulesPage.m_handCardRight  = {};
    
    helpGameRulesPage.m_bestCardleft = {};
    helpGameRulesPage.m_bestCardRight = {};

    helpGameRulesPage.getCtrls();

    helpGameRulesPage.setText();

    helpGameRulesPage.creatPublicCard();
    helpGameRulesPage.creatHandCard();
    helpGameRulesPage.creatBestCard();

    return helpGameRulesPage.m_root;
end

helpGameRulesPage.getCtrls = function ()
    helpGameRulesPage.m_cardTypeRule      = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.cardTypeRule"); 
    helpGameRulesPage.m_publicCardText    = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.publicCardText");
    helpGameRulesPage.m_plusLeft          = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.plusLeft");
    helpGameRulesPage.m_plusRight         = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.plusRight");
    helpGameRulesPage.m_playerAText       = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.playerAText");
    helpGameRulesPage.m_playerBText       = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.playerBText");
    helpGameRulesPage.m_lostText          = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.lost.lostText");
    helpGameRulesPage.m_winText           = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.win.winText");
    helpGameRulesPage.m_bestCardTextLeft  = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.bestCardTextLeft");
    helpGameRulesPage.m_bestCardTextRight = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.bestCardTextRight");
    helpGameRulesPage.m_typeLeft          = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.typeLeft");
    helpGameRulesPage.m_typeRight         = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.typeRight");

    helpGameRulesPage.m_useCard           = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.useCard");
    helpGameRulesPage.m_useCardText       = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.useCardText");
    helpGameRulesPage.m_playerNumber      = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.playerNumber");
    helpGameRulesPage.m_playerNumberText  = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.playerNumberText");
    helpGameRulesPage.m_gameMode          = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.gameMode");
    helpGameRulesPage.m_gameModeText      = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.gameModeText");
    helpGameRulesPage.m_compareRule       = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.compareRule");
    helpGameRulesPage.m_compateRuleText   = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.compateRuleText");

    helpGameRulesPage.m_publicCardNode   = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.publicCardNode");
    helpGameRulesPage.m_handCardNodeLeft   = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.handCardNodeLeft");
    helpGameRulesPage.m_handCardNodeRight = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.handCardNodeRight");
    helpGameRulesPage.m_bestCardNodeleft   = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.bestCardleft");
    helpGameRulesPage.m_bestCardNodeRight   = helpGameRulesPage.m_root:getNodeByName("bg.scrollView.bestCardRight");
    
end

helpGameRulesPage.setText = function ()
    helpGameRulesPage.m_cardTypeRule:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].TITLE);    
    helpGameRulesPage.m_publicCardText:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.PUB_POKER);       
    helpGameRulesPage.m_plusLeft:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.PLUS);            
    helpGameRulesPage.m_plusRight:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.PLUS);            
    helpGameRulesPage.m_playerAText:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.A_POKER);          
    helpGameRulesPage.m_playerBText:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.B_POKER);         
    helpGameRulesPage.m_lostText:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.LOSER);             
    helpGameRulesPage.m_winText:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.WINNER);              
    helpGameRulesPage.m_bestCardTextLeft:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.A_BEST_POKER);     
    helpGameRulesPage.m_bestCardTextRight:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.B_BEST_POKER);    
    helpGameRulesPage.m_typeLeft:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.POKER_1);             
    helpGameRulesPage.m_typeRight:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[5].CONTENT.POKER_2);            
    
    helpGameRulesPage.m_useCard:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[1].TITLE);              
    helpGameRulesPage.m_useCardText:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[1].CONTENT);          
    helpGameRulesPage.m_playerNumber:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[2].TITLE);        
    helpGameRulesPage.m_playerNumberText:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[2].CONTENT);     
    helpGameRulesPage.m_gameMode:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[3].TITLE);             
    helpGameRulesPage.m_gameModeText:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[3].CONTENT);         
    helpGameRulesPage.m_compareRule:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[4].TITLE);          
    helpGameRulesPage.m_compateRuleText:setText(STR_SETTING_HELP_CONTENT.PAGE2.SECTION[4].CONTENT);       
end

helpGameRulesPage.creatPublicCard = function ()
    for i = 1, 5 do
        helpGameRulesPage.m_publicCard[i] = new(PokerCard); 
        helpGameRulesPage.m_publicCard[i]:addPropScaleSolid(i,0.466,0.483);
        helpGameRulesPage.m_publicCard[i]:setAlign(kAlignLeft);
        helpGameRulesPage.m_publicCard[i]:setPos((i-1)*43,28);
        helpGameRulesPage.m_publicCardNode:addChild(helpGameRulesPage.m_publicCard[i]);

    end

    helpGameRulesPage.m_publicCard[1]:createCard(0x303);
    helpGameRulesPage.m_publicCard[2]:createCard(0x206);
    helpGameRulesPage.m_publicCard[3]:createCard(0x10E);
    helpGameRulesPage.m_publicCard[4]:createCard(0x405);
    helpGameRulesPage.m_publicCard[5]:createCard(0x40E);
end

helpGameRulesPage.creatHandCard = function ()
    for i = 1, 2 do
        helpGameRulesPage.m_handCardLeft[i] = new(PokerCard); 
        helpGameRulesPage.m_handCardLeft[i]:addPropScaleSolid(i,0.466,0.483);
        helpGameRulesPage.m_handCardLeft[i]:setAlign(kAlignLeft);
        helpGameRulesPage.m_handCardLeft[i]:setPos((i-1)*36,28);
        helpGameRulesPage.m_handCardNodeLeft:addChild(helpGameRulesPage.m_handCardLeft[i]);

        helpGameRulesPage.m_handCardRight[i] = new(PokerCard); 
        helpGameRulesPage.m_handCardRight[i]:addPropScaleSolid(i,0.466,0.483);
        helpGameRulesPage.m_handCardRight[i]:setAlign(kAlignLeft);
        helpGameRulesPage.m_handCardRight[i]:setPos((i-1)*36,28);
        helpGameRulesPage.m_handCardNodeRight:addChild(helpGameRulesPage.m_handCardRight[i]);
    end

    helpGameRulesPage.m_handCardLeft[1]:createCard(0x30E);
    helpGameRulesPage.m_handCardLeft[2]:createCard(0x404);
    helpGameRulesPage.m_handCardRight[1]:createCard(0x204);
    helpGameRulesPage.m_handCardRight[2]:createCard(0x102);
end

helpGameRulesPage.creatBestCard = function ()
    for i = 1, 5 do
        helpGameRulesPage.m_bestCardleft[i] = new(PokerCard); 
        helpGameRulesPage.m_bestCardleft[i]:addPropScaleSolid(i,0.466,0.483);
        helpGameRulesPage.m_bestCardleft[i]:setAlign(kAlignLeft);
        helpGameRulesPage.m_bestCardleft[i]:setPos((i-1)*36,28);
        helpGameRulesPage.m_bestCardNodeleft:addChild(helpGameRulesPage.m_bestCardleft[i]);

        helpGameRulesPage.m_bestCardRight[i] = new(PokerCard); 
        helpGameRulesPage.m_bestCardRight[i]:addPropScaleSolid(i,0.466,0.483);
        helpGameRulesPage.m_bestCardRight[i]:setAlign(kAlignLeft);
        helpGameRulesPage.m_bestCardRight[i]:setPos((i-1)*36,28);
        helpGameRulesPage.m_bestCardNodeRight:addChild(helpGameRulesPage.m_bestCardRight[i]);

    end

    helpGameRulesPage.m_bestCardleft[1]:createCard(0x30E);
    helpGameRulesPage.m_bestCardleft[2]:createCard(0x10E);
    helpGameRulesPage.m_bestCardleft[3]:createCard(0x30E);
    helpGameRulesPage.m_bestCardleft[4]:createCard(0x206);
    helpGameRulesPage.m_bestCardleft[5]:createCard(0x405);

    helpGameRulesPage.m_bestCardRight[1]:createCard(0x206);
    helpGameRulesPage.m_bestCardRight[2]:createCard(0x405);
    helpGameRulesPage.m_bestCardRight[3]:createCard(0x204);
    helpGameRulesPage.m_bestCardRight[4]:createCard(0x303);
    helpGameRulesPage.m_bestCardRight[5]:createCard(0x102);


end