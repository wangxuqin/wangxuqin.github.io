require("ui/node");
require("view/help/layout_help_feed");
require("game/scene/comp/help/feedPage/feedBackListItem");
FeedPage = class(Node)

FeedPage.ctor = function(self)
    self:setSize(630,490);
    self.m_root = SceneLoader.load(layout_help_feed);
    self:addChild(self.m_root);
    
    self:getCtrls();
    self:init();
    self:watchData();
end

FeedPage.dtor = function(self)
    self:unwatchData();   
end

FeedPage.getCtrls = function(self)
    self.m_tabContainer                = self.m_root:getNodeByName("container.tab_container");  
    
    self.m_contentContainer            = self.m_root:getNodeByName("container.content_container");
    self.m_txtContent                  = self.m_root:getNodeByName("container.content_container.img_bg.txt_content");
    self.m_txtSend                     = self.m_root:getNodeByName("container.content_container.btn_send.txt_send");
    self.m_btnSend                     = self.m_root:getNodeByName("container.content_container.btn_send");
    self.m_bottomListContainer         = self.m_root:getNodeByName("container.bottom_list_container");
    self.m_btnUploadImg                = self.m_root:getNodeByName("container.content_container.btn_upload_img");
end


FeedPage.init = function(self)
    self.m_txtSend:setText(STR_SETTING_SEND);
    self.m_txtContent:setText(STR_SETTING_FEEDBACK_PAY_QUESTION);
    self.m_txtContent:setScrollBarWidth(0);
    self.m_type = 1001;
    self.m_txtContent:setOnTextChange(self,self.onContentChange);
    self.m_btnSend:setEnable(false);
    self.m_btnSend:setOnClick(self,self.onSendBtnClick);
    self.m_btnUploadImg:setOnClick(self,self.OnUploadImgBtnClick);

    self.m_tab = new(ButtonTag);
    self.m_tab:setButtonTagHorizontalSingle(STR_SETTING_HELP_PAGE_FEED_BACK_ITEM,
                                             "help/common-tab-bar-background.png", 600, 50,
                                             "help/common-tab-bar-selector-background.png",
                                             10,10,10,10,10,10,5,5,3,3,24); 
    self.m_tab.buttonSlide:setPos(nil,-1); 
    self.m_tab:setOnTagChangedAnimEnd(self,self.onTabChanged);                                              
    self.m_tabContainer:addChild(self.m_tab);  

    self:createBottomList(self.m_bottomListContainer);

end


FeedPage.watchData = function(self)
     Model.watchData(ModelKeys.USER_FEEDBACK_LIST, self, self.setData, true);
end


--[Commet]
--������ݰ�
FeedPage.unwatchData = function(self)
    Model.unwatchData(ModelKeys.USER_FEEDBACK_LIST, self, self.setData);
end

FeedPage.setData = function(self,data) 
    if data ~= nil then
        local items = {}; 
        for i = 1,#data do
            items[i] = new(FeedBackListItem,data[i]);
            if i > 1 then 
                local w,h = items[i-1]:getSize();
                local x,y = items[i-1]:getPos();             
                items[i]:setPos(x,y+h+10); 

            end                  
            self.m_list:addChild(items[i]);    
        end   
    end       
end

FeedPage.createBottomList = function(self,container) 
    if container ~= nil then
        local width, height = container:getSize();
        self.m_list = new(ScrollView2,0,0,width,height);      		   	    
        self.m_list:setScrollBarWidth(0);                 
        container:addChild(self.m_list);
    end   
end
   
FeedPage.onContentChange = function(self) 
    local txt = StringKit.trim(self.m_txtContent:getText());
	if txt~= "" and txt ~= STR_SETTING_FEEDBACK_PAY_QUESTION and txt ~= STR_SETTING_FEEDBACK_ACCOUNT_NUMBER_QUESTION and txt ~= STR_SETTING_FEEDBACK_GAME_QUESTION and txt ~= STR_SETTING_FEEDBACK_ADVICE then
		 self.m_btnSend:setEnable(true);
	end
   
end


FeedPage.OnUploadImgBtnClick = function(self)  
    NativeService.getInstance():openGallery();
end

FeedPage.onSendBtnClick = function(self)   
	EventDispatcher.getInstance():dispatch(CommandEvent.s_event, CommandEvent.s_cmd.SEND_USER_FEEDBACK,{
				["type"] = self.m_type,
				["content"] = self.m_txtContent:getText(),
				["bitmapData"] = self.m_upImage,
				["jpegData"] = self.m_upData
			});

    if self.m_type == 1001 then
         self.m_txtContent:setText(STR_SETTING_FEEDBACK_PAY_QUESTION);         
    elseif self.m_type == 1002 then
         self.m_txtContent:setText(STR_SETTING_FEEDBACK_ACCOUNT_NUMBER_QUESTION);        
    elseif self.m_type == 1000 then
         self.m_txtContent:setText(STR_SETTING_FEEDBACK_GAME_QUESTION);         
    elseif self.m_type == 1003 then
         self.m_txtContent:setText(STR_SETTING_FEEDBACK_ADVICE);        
    end

    self.m_btnSend:setEnable(false);
    SoundManager.playButtonClickSound();
end



FeedPage.onTabChanged = function(self,index)   
    if index == 1 then
         self.m_txtContent:setText(STR_SETTING_FEEDBACK_PAY_QUESTION);
         self.m_type = 1001;
    elseif index == 2 then
         self.m_txtContent:setText(STR_SETTING_FEEDBACK_ACCOUNT_NUMBER_QUESTION);
         self.m_type = 1002;
    elseif index == 3 then
         self.m_txtContent:setText(STR_SETTING_FEEDBACK_GAME_QUESTION);
         self.m_type = 1000;
    elseif index ==4 then
         self.m_txtContent:setText(STR_SETTING_FEEDBACK_ADVICE);
         self.m_type = 1003;
    end

    self.m_btnSend:setEnable(false);
end
