require("ui/node");
require("view/help/layout_help_login_feed");
LoginFeedPage = class(Node)

LoginFeedPage.ctor = function(self)
    self:setSize(630,490);
    self.m_root = SceneLoader.load(layout_help_login_feed);
    self:addChild(self.m_root);
    
    self:getCtrls();
    self:init();
   
end

LoginFeedPage.dtor = function(self)
     
end

LoginFeedPage.getCtrls = function(self)
    self.m_txtContent     = self.m_root:getNodeByName("container.bg.txt_content");
    self.m_txtSend        = self.m_root:getNodeByName("container.btn_send.txt_send");
    self.m_btnSend        = self.m_root:getNodeByName("container.btn_send");
end

LoginFeedPage.init = function(self)
    self.m_txtSend:setText(STR_SETTING_SEND);
    self.m_txtContent:setText(STR_SETTING_LOGIN_FEED_BACK_QUESTION);
    self.m_txtContent:setOnTextChange(self,self.onContentChange);
    self.m_txtContent:setScrollBarWidth(0);
    self.m_btnSend:setEnable(false);
    self.m_btnSend:setOnClick(self,self.onSendBtnClick);
end

LoginFeedPage.onContentChange = function(self) 
    local txt = StringKit.trim(self.m_txtContent:getText());
	if txt~= "" and txt ~= STR_SETTING_LOGIN_FEED_BACK_QUESTION then
		 self.m_btnSend:setEnable(true);
	end   
end

LoginFeedPage.onSendBtnClick = function(self)   
    --local nativeService:ICommonNativeService = ServiceLocator.findService(ICommonNativeService)[0] as ICommonNativeService;
	local mac = NativeService.getInstance().getMacAddress();
	local openUDID = NativeService.getInstance().getOpenUDID();
	--var httpService:IHttpService = ServiceLocator.httpService;
	self.m_type = mac or openUDID;

--  [lucy] url?
	HttpService.postUrl("https://ipk-demo-1.boyaa.com/mobilespecial.php", {
	["secret"] = ToolKit.base64_encode("t7z^d~d!Dliji!4o|"..self.m_type),
	["mod"] = "feedback",
	["act"] = "setBeforeLogin",
	["type"] = 8000,
	["content"] = self.m_txtContent:getText();
	}, self,self.onLoginResult, self.onLoginError, self.onLoginError);

	self.m_txtContent:setText(STR_SETTING_LOGIN_FEED_BACK_QUESTION);

	self.m_btnSend:setEnable(false);
	SoundManager.playButtonClickSound();
end

LoginFeedPage.onLoginResult = function(self,data) 
    Log.d("login return: ",data);
    if data~= nil then
        local userObj = json.decode(data);
        if userObj.ret == 0 then
             EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_SETTING_FEEDBACK_SUCCEED);
        elseif userObj.ret == 1 then
             EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_SETTING_FEEDBACK_TIMES_LIMIT);
        else
             EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_SETTING_FEEDBACK_FAIL);    
        end            
    end

end

LoginFeedPage.onLoginError = function(self) 
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_COMMON_BAD_NETWORK);  
end




