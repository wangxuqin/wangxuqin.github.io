require("ui/node");
require("view/help/layout_help_feed_bottom_item");

FeedBackListItem = class(Node)

FeedBackListItem.ctor = function(self,data)  
    self.m_width = 600;
    self:setSize(self.m_width,200); 
    self.m_root = SceneLoader.load(layout_help_feed_bottom_item);
    self:addChild(self.m_root);

    self.m_data = data;

    self:getCtrls();
    self:init();
end

FeedBackListItem.dtor = function(self)
   
end

FeedBackListItem.getCtrls = function(self)
    self.m_bg               = self.m_root:getNodeByName("bg");
    self.m_imgUserIcon      = self.m_root:getNodeByName("bg.img_user_icon");
    self.m_txtUserFeedBack  = self.m_root:getNodeByName("bg.txt_user_feed_back");
    self.m_status           = self.m_root:getNodeByName("bg.txt_status");
    self.m_txtFeedBackDate  = self.m_root:getNodeByName("bg.txt_feed_back_date");
  
    self.m_imgPartLine      = self.m_root:getNodeByName("bg.img_part_line");

    self.m_imgAdminIcon     = self.m_root:getNodeByName("bg.img_admin_icon");
    self.m_txtReply         = self.m_root:getNodeByName("bg.txt_reply");
    self.m_txtReplyDate     = self.m_root:getNodeByName("bg.txt_reply_date");
end

FeedBackListItem.init = function(self)
    self.m_txtUserFeedBack:setText(self.m_data.userFeedback);
    local feedBackX,feedBackY = self.m_txtUserFeedBack:getPos();
    local feedBackW,feedBackH = self.m_txtUserFeedBack:getSize();
    local feedBackRes =  new(ResText,self.m_data.userFeedback,feedBackW,1,kAlignTopLeft,_,20,_,_,_,1); 
    local feedBackResH = feedBackRes:getHeight();
    self.m_txtUserFeedBack:setSize(feedBackW,feedBackResH);
     
    self.m_txtFeedBackDate:setText(Formatter.formatDate(self.m_data.sendDate, "%Y-%m-%d"));
    local feedBackDateX,feedBackDateY = self.m_txtFeedBackDate:getPos();
    self.m_txtFeedBackDate:setPos(feedBackDateX,feedBackY + feedBackResH + 10);

    self.m_status:setText(self.m_data.getStatus());
    local statusX,statusY = self.m_status:getPos();
    local statusW,statusH =self.m_status:getSize();
    self.m_status:setPos(statusX,feedBackY + feedBackResH + 10);
    statusX,statusY = self.m_status:getPos();

    if self.m_data.getHasReply == true then
        self.m_imgPartLine:setVisible(true);
        self.m_imgAdminIcon:setVisible(true);
        self.m_txtReply:setVisible(true);
        self.m_txtReplyDate:setVisible(true);

        local partLineX,partLineY = self.m_imgPartLine:getPos(); 
        local adminIconX,adminY = self.m_imgAdminIcon:getPos();      
        self.m_imgPartLine:setPos(partLineX,statusY + statusH + 5);
        self.m_imgAdminIcon:setPos(adminIconX,statusY + statusH + 15);

        self.m_txtReply:setText(self.m_data.adminReply);
        local replyRes =  new(ResText,self.m_data.adminReply,feedBackW,1,kAlignTopLeft,_,20,_,_,_,1); 
        local replyResH = replyRes:getHeight();
        self.m_txtReply:setPos(feedBackX,statusY + statusH + 18);
        self.m_txtReply:setSize(feedBackW,replyResH);

        local replyX,replyY = self.m_txtReply:getPos();
        self.m_txtReplyDate:setText(Formatter.formatDate(self.m_data.replyDate, "%Y-%m-%d"));
        self.m_txtReplyDate:setPos(feedBackDateX,replyY + replyResH + 10);

        self.m_bg:setSize(self.m_width,feedBackY + feedBackResH + statusH *2 + replyResH + 10*5);
        self:setSize(self.m_width,feedBackY + feedBackResH + statusH *2 + replyResH +10*5);

    else
        self.m_imgPartLine:setVisible(false);
        self.m_imgAdminIcon:setVisible(false);
        self.m_txtReply:setVisible(false);
        self.m_txtReplyDate:setVisible(false);

        self.m_bg:setSize(self.m_width,feedBackY + feedBackResH + statusH + 10*3);
        self:setSize(self.m_width,feedBackY + feedBackResH + statusH + 10*3);
    end

end



