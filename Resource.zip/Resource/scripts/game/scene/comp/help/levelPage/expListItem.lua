require("ui/node");
require("view/help/layout_help_exp_list_item");

ExpListItem = class(Node)
ExpListItem.m_select = false;

ExpListItem.ctor = function(self,data)  
    self.m_width = 594;
    self:setSize(self.m_width,330); 
    self.m_root = SceneLoader.load(layout_help_exp_list_item);
    self:addChild(self.m_root);

    self.m_data = data;
    self:getCtrls();
    self:init();
end

ExpListItem.dtor = function(self)
   
end

ExpListItem.getCtrls = function(self)
    self.m_txtTitle = self.m_root:getNodeByName("container.txt_title");
    self.m_body     = self.m_root:getNodeByName("container.body");
    self.m_tips     = self.m_root:getNodeByName("container.tips");
end

ExpListItem.init = function(self)
    self.m_txtTitle:setText(self.m_data.title);
    local titleW,titleH = self.m_txtTitle:getSize();
    if self.m_data.body.content ~= nil then   
        local contentTextView = new(TextView,self.m_data.body.content,self.m_width,300,kAlignTopLeft,nil,20,197,225,246);
        contentTextView:setScrollBarWidth(0);
        local txtContentRealText = new(ResText,self.m_data.body.content,self.m_width,1,kAlignTopLeft,_,20,_,_,_,1);
        local contentH = txtContentRealText:getHeight();
        contentTextView:setSize(self.m_width,contentH+200);
        contentTextView:setPos(0,5);
        self.m_body:setSize(self.m_width,contentH);
        self.m_body:addChild(contentTextView);
    end

    if self.m_data.body.item ~= nil then   
        for i= 1,#self.m_data.body.item do
            local itemH = 30;
            local time = new(Text,self.m_data.body.item[i].time,297,itemH,kAlignLeft,nil,20,197,225,246);
            time:setPos(5,(i-1)*itemH);
            self.m_body:addChild(time);

            local partLine = new(Image,"help/part_line.png");
            partLine:setSize(585,4);
            partLine:setPos(5,itemH*i);
            self.m_body:addChild(partLine);

            local exp = new(Text,self.m_data.body.item[i].time,297,itemH,kAlignRight,nil,20,197,225,246);
            exp:setAlign(kAlignTopRight);
            exp:setPos(0,(i-1)*itemH);
            self.m_body:addChild(exp);
            self.m_body:setSize(self.m_width,itemH*i);


            if self.m_data.body.item[i].fontStyle~=nil and self.m_data.body.item[i].fontStyle.color~=nil then
                local color = self.m_data.body.item[i].fontStyle.color;
                time:setColor(color.r,color.g,color.b);
                exp:setColor(color.r,color.g,color.b);
            end
        end
       
    end

    local bodyX,bodyY = self.m_body:getPos();
    local bodyW,bodyH = self.m_body:getSize();
     self.m_tips:setPos(bodyX,bodyY+bodyH+10);
    if #self.m_data.tip==1 then
        local tip = new(TextView,self.m_data.tip[1],self.m_width,30,kAlignLeft,nil,20,197,225,246); 
        tip:setScrollBarWidth(0);
        local tipW,tipH = tip:getSize();
        self.m_tips:setSize(self.m_width,tipH);      
        self.m_tips:addChild(tip);
    elseif  #self.m_data.tip>1 then
        local bg = new(Image,"help/help-page-problem-item-background_back.png",nil,nil,4,4,4,4);      
        self.m_tips:addChild(bg);
        local bgH =0;
        for i=1,#self.m_data.tip do
            local tip = new(TextView,self.m_data.tip[i],self.m_width,30,kAlignTopLeft,nil,20,197,225,246);
            tip:setScrollBarWidth(0);
            local tipRealText = new(ResText,self.m_data.tip[i],self.m_width,1,kAlignTopLeft,_,20,_,_,_,1);
            local contentH = tipRealText:getHeight();
            tip:setPos(5,bgH+10);
            tip:setSize(self.m_width,contentH+200);
            bgH = bgH + contentH;
            bg:addChild(tip);    
        end
        self.m_tips:setSize(self.m_width,bgH+10*2);
        bg:setSize(600,bgH+10*2);
    end

    local tipsW,tipsH = self.m_tips:getSize();

    self:setSize(self.m_width,titleH + bodyH + tipsH);
        
end


