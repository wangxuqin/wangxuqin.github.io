require("ui/node");
require("view/help/layout_help_level_rank_item");

RankPageListItem = class(Node)
RankPageListItem.m_select = false;

RankPageListItem.ctor = function(self,data)  
    self:setSize(600,30); 
    self.m_root = SceneLoader.load(layout_help_level_rank_item);
    self:addChild(self.m_root);

    self.m_data = data;
    self:getCtrls();
    self:init();
end

RankPageListItem.dtor = function(self)
   
end

RankPageListItem.getCtrls = function(self)
    self.m_style1 = self.m_root:getNodeByName("style1");    
    self.m_style2 = self.m_root:getNodeByName("style2"); 

    self.m_txtLevelStyle1       = self.m_root:getNodeByName("style1.txt_level");
    self.m_txtNameStyle1        = self.m_root:getNodeByName("style1.txt_name");
    self.m_txtNeedExpStyle1     = self.m_root:getNodeByName("style1.txt_needExp");
    self.m_txtTargetExpStyle1   = self.m_root:getNodeByName("style1.txt_targetExp");
    self.m_txtChipsStyle1       = self.m_root:getNodeByName("style1.txt_chips");  

    self.m_txtLevelStyle2       = self.m_root:getNodeByName("style2.bg.txt_level");
    self.m_txtNameStyle2        = self.m_root:getNodeByName("style2.bg.txt_name");
    self.m_txtNeedExpStyle2     = self.m_root:getNodeByName("style2.bg.txt_needExp");
    self.m_txtTargetStyle2      = self.m_root:getNodeByName("style2.bg.txt_targetExp");
    self.m_txtChipsStyle2       = self.m_root:getNodeByName("style2.bg.txt_chips"); 
    self.m_bg                   = self.m_root:getNodeByName("style2.bg");
end

RankPageListItem.init = function(self)
    if  self.m_data.fontStyle~= nil then
        local color = self.m_data.fontStyle.color;   
        if color~=nil then
            self.m_txtLevelStyle1:setColor(color.r,color.g,color.b);
            self.m_txtNameStyle1:setColor(color.r,color.g,color.b);
            self.m_txtNeedExpStyle1:setColor(color.r,color.g,color.b);
            self.m_txtTargetExpStyle1:setColor(color.r,color.g,color.b);
            self.m_txtChipsStyle1:setColor(color.r,color.g,color.b); 
        end
    end
  

    if #self.m_data.other<1 then
        self.m_style1:setVisible(true);
        self.m_style2:setVisible(false);
        
        self.m_txtLevelStyle1:setText(self.m_data.level);      
        self.m_txtNameStyle1:setText(self.m_data.name);       
        self.m_txtNeedExpStyle1:setText(self.m_data.needExp);    
        self.m_txtTargetExpStyle1:setText(self.m_data.targetExp);  
        self.m_txtChipsStyle1:setText(self.m_data.chips);  
    else
        self.m_style1:setVisible(false);
        self.m_style2:setVisible(true);
        self.m_txtLevelStyle2:setText(self.m_data.level);
        self.m_txtNameStyle2:setText(self.m_data.name); 
        self.m_txtNeedExpStyle2:setText(self.m_data.needExp);    
        self.m_txtTargetStyle2:setText(self.m_data.targetExp);
        self.m_txtChipsStyle2:setText(self.m_data.chips);
      
        self.m_rewards = {};
        local x,y = self.m_txtChipsStyle2:getPos();
        local w,h = self.m_txtChipsStyle2:getSize();
        local bgW,bgH = self.m_bg:getSize();
        for i=1,#self.m_data.other do
            self.m_rewards[i] = new(Text,self.m_data.other[i],w,h,kAlignLeft,nil,20,251,213,133);      
            self.m_rewards[i]:setPos(x,y+(h+2)*i);
            self:addChild(self.m_rewards[i]);
            
        end
       
       bgChangeH = 8*2 + (#self.m_data.other+1)*(h+2);

       self.m_bg:setSize(bgW,bgChangeH);
       self:setSize(bgW,bgChangeH);
    end     
end



