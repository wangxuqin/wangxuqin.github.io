require("ui/node");
require("view/help/layout_help_level");
require("game/scene/comp/help/levelPage/rankPageListItem");
require("game/scene/comp/help/levelPage/expListItem");
LevelPage = class(Node)

LevelPage.ctor = function(self)
    self:setSize(630,490);
    self.m_root = SceneLoader.load(layout_help_level);
    self:addChild(self.m_root);
    
    self:getCtrls();
    self:init();
end

LevelPage.dtor = function(self)
   
end

LevelPage.getCtrls = function(self)
    self.m_tabContainer = self.m_root:getNodeByName("container.tab_container"); 
    self.m_expContainer = self.m_root:getNodeByName("container.exp_container");
    self.m_levelContainer = self.m_root:getNodeByName("container.level_container"); 

    self.m_pageArr = {
       [1] = self.m_expContainer;
       [2] = self.m_levelContainer;          
    };  
     
end


LevelPage.init = function(self)
    self.m_tab = new(ButtonTag);
    self.m_tab:setButtonTagHorizontalSingle(STR_SETTING_RATING_SYSTEM_PAGE_ITEM,
                                             "help/common-tab-bar-background.png", 600, 50,
                                             "help/common-tab-bar-selector-background.png",
                                             10,10,10,10,10,10,5,5,3,3,24); 
    self.m_tab.buttonSlide:setPos(nil,-1); 
    self.m_tab:setOnTagChangedAnimEnd(self,self.onTabChanged);                                             
    self.m_tabContainer:addChild(self.m_tab); 
    
    self:creatExpPage();
    self:creatLevelPage();
     
end

LevelPage.creatExpPage = function(self)  
    self.m_expList = new(ScrollView2,0,0,600,392);					    						
   	self.m_expList:setScrollBarWidth(0);    								
    self.m_expContainer:addChild(self.m_expList);
    
    local sections = STR_SETTING_HELP_PAGE_RATING_SYSTEM.page[1].section;
    local expItems = {};
    for i = 1,#sections do
        expItems[i] = new(ExpListItem,sections[i]);
        if i > 1 then 
            local w,h = expItems[i-1]:getSize();
            local x,y = expItems[i-1]:getPos();             
            expItems[i]:setPos(x,y+h+10); 
           
        end                  
        self.m_expList:addChild(expItems[i]);    
    end

   
end

LevelPage.creatLevelPage = function(self)   
    self.m_levelList = new(ScrollView2,0,0,600,392);					    						
   	self.m_levelList:setScrollBarWidth(0);								
    self.m_levelContainer:addChild(self.m_levelList);  
    
    local levelItems = {};
    local sections = STR_SETTING_HELP_PAGE_RATING_SYSTEM.page[2].section;
    for i=1,#sections do        
        levelItems[i] = new(RankPageListItem,sections[i]);
        if i > 1 then 
            local w,h = levelItems[i-1]:getSize();
            local x,y = levelItems[i-1]:getPos();             
            levelItems[i]:setPos(x,y+h+10); 
            if  #sections[i].other == 0 and #sections[i + 1].other == 0 then
                local partLine = new(Image,"help/part_line.png");
                partLine:setSize(w-4,4);
                partLine:setAlign(kAlignBottom);
                levelItems[i]:addChild(partLine);
            end
        end           
       
        self.m_levelList:addChild(levelItems[i]);        
    end    

end


LevelPage.onTabChanged = function(self,index)   
    for i = 1, #self.m_pageArr do
		local page = self.m_pageArr[i];
		page:setVisible(index == i);
	end
end


