require("ui/node");
require("view/help/layout_help_static_txt_item");

StaticTxtItem = class(Node)

StaticTxtItem.ctor = function(self,data)  
    self:setSize(600,250); 
    self.m_root = SceneLoader.load(layout_help_static_txt_item);
    self:addChild(self.m_root);

    self.m_data = data;

    self:getCtrls();
    self:init();
end

StaticTxtItem.dtor = function(self)
   
end

StaticTxtItem.getCtrls = function(self)
    self.m_bg           = self.m_root:getNodeByName("bg");
    self.m_txtTitle     = self.m_root:getNodeByName("bg.txt_title"); 
    self.m_txtContent   = self.m_root:getNodeByName("bg.txt_content");    
    
end

StaticTxtItem.init = function(self)
    self.m_txtTitle:setText(self.m_data.title);  
    self.m_txtContent:setText(self.m_data.content);
    self.m_txtContent:setScrollBarWidth(0);
  
    local bgW = self.m_bg:getSize(); 
    local _,titleH = self.m_txtTitle:getSize();   
    local contentW = self.m_txtContent:getSize();

    local txtContentRealText = new(ResText,self.m_data.content,contentW,1,kAlignTopLeft,_,20,_,_,_,1);
    local contentH = txtContentRealText:getHeight();

    self.m_txtContent:setSize(contentW,contentH + 200);
    self.m_bg:setSize(bgW,titleH + contentH + 16 * 3);
    self:setSize(bgW,titleH + contentH + 16 * 3);    
end



