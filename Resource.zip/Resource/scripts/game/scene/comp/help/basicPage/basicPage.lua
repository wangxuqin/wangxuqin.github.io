require("ui/node");
require("view/help/layout_help_basic");
require("game/scene/comp/help/basicPage/staticTxtItem");


BasicPage = class(Node)

BasicPage.ctor = function(self)
    self:setSize(630,490);
    self.m_root = SceneLoader.load(layout_help_basic);
    self:addChild(self.m_root);
    
    self:getCtrls();
    self:init();
end

BasicPage.dtor = function(self)
   
end

BasicPage.getCtrls = function(self)
    self.m_tabContainer             = self.m_root:getNodeByName("container.tab_container");  
    
    self.m_cardContainer            = self.m_root:getNodeByName("container.card_container");
    self.m_ruleContainer            = self.m_root:getNodeByName("container.rule_container");
    self.m_betContainer             = self.m_root:getNodeByName("container.bet_container");
    self.m_proContainer             = self.m_root:getNodeByName("container.pro_container");


    self.m_ruleScrollView           = self.m_root:getNodeByName("container.rule_container.bg.scrollview");

    self.m_pageArr = {
       [1] = self.m_cardContainer;
       [2] = self.m_ruleContainer;
       [3] = self.m_betContainer;
       [4] = self.m_proContainer;    
    };     
end

BasicPage.init = function(self)
    self.m_tab = new(ButtonTag);
    self.m_tab:setButtonTagHorizontalSingle(STR_SETTING_HELP_PAGE_GAME_INTRODUCE_ITEM,
                                             "help/common-tab-bar-background.png", 600, 50,
                                             "help/common-tab-bar-selector-background.png",
                                             10,10,10,10,10,10,5,5,3,3,24); 
    self.m_tab.buttonSlide:setPos(nil,-1);  
    self.m_tab:setOnTagChangedAnimEnd(self,self.onTabChanged);                                           
    self.m_tabContainer:addChild(self.m_tab); 

    self.m_ruleScrollView:setScrollBarWidth(0);

    self:initConfigStr();

    self:creatPetPage();
    self:creatProfessionalTermsPage();
     
end


BasicPage.creatPetPage = function(self)   
    self.m_betList = new(ScrollView2,0,0,600,392);					    						
   	self.m_betList:setScrollBarWidth(0);								
    self.m_betContainer:addChild(self.m_betList);

    self:setData(self.m_betList,STR_SETTING_HELP_CONTENT.page[3].section);
end


BasicPage.creatProfessionalTermsPage = function(self)   
    self.m_professionalTermsList = new(ScrollView2,0,0,600,392);					    						
   	self.m_professionalTermsList:setScrollBarWidth(0);								
    self.m_proContainer:addChild(self.m_professionalTermsList);


    self:setData(self.m_professionalTermsList,STR_SETTING_HELP_CONTENT.page[4].section); 
end

BasicPage.setData = function(self,list,data)   
    local txtItem = {};

    for i = 1,#data do
        txtItem[i] = new(StaticTxtItem,data[i]);        
        if i > 1 then 
            local _,h = txtItem[i-1].m_bg:getSize();
            local _,y = txtItem[i-1]:getPos();             
            txtItem[i]:setPos(0,y+h+10); 
        end
        list:addChild(txtItem[i]);   
    end    
end

BasicPage.onTabChanged = function(self,index)   
    for i = 1, #self.m_pageArr do
		local page = self.m_pageArr[i];
		page:setVisible(index == i);
	end
end

--[comment] �����������
BasicPage.initConfigStr = function(self)   
    self.m_txtCardContainerArr = {};
    self.m_txtRuleContainerArr = {};

    for i = 1, 10 do   
         self.m_txtCardContainerArr[i] = self.m_root:getNodeByName(tostring("container.card_container.bg.scrollview.txt"..i));     
         self.m_txtCardContainerArr[i]:setText(STR_SETTING_HELP_CONTENT.page[1].section[i].title);
    end 


    for i = 1, 4 do
        self.m_txtRuleContainerArr[i]           = self.m_txtRuleContainerArr[i] or {};
        self.m_txtRuleContainerArr[i].title     = self.m_root:getNodeByName(tostring("container.rule_container.bg.scrollview.txt_title"..i));
        self.m_txtRuleContainerArr[i].content   = self.m_root:getNodeByName(tostring("container.rule_container.bg.scrollview.txt_content"..i));

        self.m_txtRuleContainerArr[i].title:setText(STR_SETTING_HELP_CONTENT.page[2].section[i].title);
        self.m_txtRuleContainerArr[i].content:setText(STR_SETTING_HELP_CONTENT.page[2].section[i].content);
    end

    self.m_txtCardRule      = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_card_rule");
    self.m_txtPublicCard    = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_public_card");
    self.m_txtPlus1         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_plus1");
    self.m_txtPlus2         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_plus2");
    self.m_txtPlayerA       = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerA");
    self.m_txtPlayerB       = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerB");
    self.m_txtLoser         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.img_loser.txt_loser");
    self.m_txtWinner        = self.m_root:getNodeByName("container.rule_container.bg.scrollview.img_winner.txt_winner");
    self.m_txtPlayerABest   = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerA_best");
    self.m_txtPlayerBBest   = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_playerB_best");
    self.m_txtTypeA         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_typeA");
    self.m_txtTypeB         = self.m_root:getNodeByName("container.rule_container.bg.scrollview.txt_typeB");


    self.m_txtCardRule:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].title);
    self.m_txtPublicCard:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.pub_poker);
    self.m_txtPlus1:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.plus);
    self.m_txtPlus2:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.plus);
    self.m_txtPlayerA:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.a_poker);
    self.m_txtPlayerB:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.b_poker);
    self.m_txtLoser:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.loser);
    self.m_txtWinner:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.winner);
    self.m_txtPlayerABest:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.a_best_poker);
    self.m_txtPlayerBBest:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.b_best_poker);
    self.m_txtTypeA:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.poker_1);
    self.m_txtTypeB:setText(STR_SETTING_HELP_CONTENT.page[2].section[5].content.poker_2);
end

