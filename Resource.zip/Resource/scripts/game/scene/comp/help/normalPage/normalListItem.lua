require("ui/node");
require("view/help/layout_help_normal_list_item");

NormalListItem = class(Node)
NormalListItem.m_select = false;

NormalListItem.ctor = function(self,data)  
    self:setSize(600,74); 
    self.m_root = SceneLoader.load(layout_help_normal_list_item);
    self:addChild(self.m_root);

    self.m_data = data;

    self:getCtrls();
    self:init();
end

NormalListItem.dtor = function(self)
   
end

NormalListItem.getCtrls = function(self)
    self.m_btnItemDark   = self.m_root:getNodeByName("btn_item_dark");
    self.m_txtProblem    = self.m_root:getNodeByName("btn_item.txt_problem");
    self.m_txtAnswer     = self.m_root:getNodeByName("txt_answer");
    self.m_btnItem       = self.m_root:getNodeByName("btn_item");
    self.m_imgArrow      = self.m_root:getNodeByName("btn_item.img_arrow");
    self.m_btnNormalItem = self.m_root:getNodeByName("btn_normalItem"); 
end

NormalListItem.init = function(self)
    self.m_txtProblem:setText(self.m_data.title);
    self.m_txtAnswer:setText(self.m_data.content);   

    local contentW = self.m_txtAnswer:getSize();

    local txtAnswerRealText = new(ResText,self.m_data.content,contentW,1,kAlignTopLeft,_,20,_,_,_,1);
    local contentH = txtAnswerRealText:getHeight();

    self.m_txtAnswer:setSize(contentW,contentH);
end



