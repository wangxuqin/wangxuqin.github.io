require("ui/node");
require("view/help/layout_help_normal");
require("game/scene/comp/help/normalPage/normalListItem");
NormalPage = class(Node)

NormalPage.ctor = function(self)
    self:setSize(630,490);
    self.m_root = SceneLoader.load(layout_help_normal);
    self:addChild(self.m_root);
    
    self:getCtrls();
    self:init();
end

NormalPage.dtor = function(self)
   
end

NormalPage.getCtrls = function(self)
    self.m_tabContainer             = self.m_root:getNodeByName("container.tab_container");   
    
    self.m_commonContainer          = self.m_root:getNodeByName("container.common_container");
    self.m_payContainer             = self.m_root:getNodeByName("container.pay_container");
    self.m_accountContainer         = self.m_root:getNodeByName("container.account_container");
    self.m_loginContainer           = self.m_root:getNodeByName("container.login_container");

    self.m_pageArr = {
       [1] = self.m_commonContainer;
       [2] = self.m_payContainer;
       [3] = self.m_accountContainer;
       [4] = self.m_loginContainer;    
    };  
end


NormalPage.init = function(self)
    self.m_tab = new(ButtonTag);
    self.m_tab:setButtonTagHorizontalSingle(STR_SETTING_HELP_PAGE_COMMON_PROBLEM_ITEM,
                                             "help/common-tab-bar-background.png", 600, 50,
                                             "help/common-tab-bar-selector-background.png",
                                             10,10,10,10,10,10,5,5,3,3,24);  
    self.m_tab.buttonSlide:setPos(nil,-1);  
    self.m_tab:setOnTagChangedAnimEnd(self,self.onTabChanged);                                           
    self.m_tabContainer:addChild(self.m_tab);
    
    self.m_list = {};

    self:creatCommonPage();
    self:creatPayPage();
    self:createAccountPage();
    self:createLoginPage();

    self.m_txtItems = {};
    self:setData();      
end


NormalPage.creatCommonPage = function(self)  
    self.m_commonList = new(ScrollView2,0,0,600,392);					    						
   	self.m_commonList:setScrollBarWidth(0);    								
    self.m_commonContainer:addChild(self.m_commonList);
    self.m_list[1] = self.m_commonList;    
end

NormalPage.creatPayPage = function(self)   
    self.m_payList = new(ScrollView2,0,0,600,392);					    						
   	self.m_payList:setScrollBarWidth(0);								
    self.m_payContainer:addChild(self.m_payList);  
    self.m_list[2] = self.m_payList;
end

NormalPage.createAccountPage = function(self)   
    self.m_accountList = new(ScrollView2,0,0,600,392);					    						
   	self.m_accountList:setScrollBarWidth(0);								
    self.m_accountContainer:addChild(self.m_accountList);  
    self.m_list[3] = self.m_accountList;
end

NormalPage.createLoginPage = function(self)   
    self.m_loginList = new(ScrollView2,0,0,600,392);					    						
   	self.m_loginList:setScrollBarWidth(0);								
    self.m_loginContainer:addChild(self.m_loginList);
    self.m_list[4] = self.m_loginList;   
end

NormalPage.setData = function(self,list,data)  
    for i = 1 ,#STR_SETTING_HELP_PAGE_PROBLEM_CONTENT.page do
        self.m_txtItems[i] =  {};
        for j = 1, #STR_SETTING_HELP_PAGE_PROBLEM_CONTENT.page[i].section do
            self.m_txtItems[i][j] = new(NormalListItem,STR_SETTING_HELP_PAGE_PROBLEM_CONTENT.page[i].section[j]); 
            if j > 1 then 
                local _,h = self.m_txtItems[i][j-1]:getSize();
                local x,y = self.m_txtItems[i][j-1]:getPos();             
                self.m_txtItems[i][j]:setPos(x,y+h+10); 
            end           
            self.m_txtItems[i][j].m_btnNormalItem:setOnClick(self,self.onItemClick);
            self.m_list[i]:addChild(self.m_txtItems[i][j]);  
        end
            
    end      
end

NormalPage.onItemClick = function(self, finger_action, x, y, drawing_id_first, drawing_id_current)   
    for i=1,#self.m_txtItems do
        for j = 1 , #self.m_txtItems[i] do
            if drawing_id_current == self.m_txtItems[i][j].m_btnNormalItem.m_drawingID then            
                if not self.m_txtItems[i][j].m_select then 
                    self:reAdaptiveItems(self.m_txtItems[i][j],"down");               
                else
                    self:reAdaptiveItems(self.m_txtItems[i][j],"up");
                end               
            else
                if self.m_txtItems[i][j].m_select then
                    self:reAdaptiveItems(self.m_txtItems[i][j],"up");
                end                                 
            end
            self:reAdaptivePos(self.m_txtItems[i]);
        end       
    end        
end

NormalPage.reAdaptiveItems = function(self,item,downOrUp)
    local _,answerH     = item.m_txtAnswer:getSize(); 
    local itemW,itemH   =item.m_btnItem:getSize();
    KTween.remove(item.m_btnItemDark);
    KTween.remove(item.m_imgArrow);
    if downOrUp == "down" then
        item.m_select = true;
        KTween.to(item.m_btnItemDark, 400,   {startScaleY = 1, scaleY =(answerH+itemH+14*2)/itemH, center = kCenterXY,easeType=EaseType.BackOut,  delay = 20,obj=self, onCompleteParams = item,onComplete = self.onPlayAnimComplete});                                
        KTween.to(item.m_imgArrow,    300,   {startAngle = 0, angle = 90,  delay = 20});
        item:setSize(itemW,answerH+itemH+14*2); 
        item.m_btnNormalItem:setSize(itemW,answerH+itemH+14*2);                          
    elseif downOrUp == "up" then
        item.m_select = false;
        item.m_txtAnswer:setVisible(false);
        KTween.to(item.m_btnItemDark, 300,   {startScaleY  =(answerH+itemH+14*2)/itemH, scaleY =1, center = kCenterXY,easeType=EaseType.BackInOut,  delay = 20});       
        KTween.to(item.m_imgArrow,    300,   {startAngle = 90, angle = 0,  delay = 20});
        item:setSize(itemW,itemH);
        item.m_btnNormalItem:setSize(itemW,itemH);          
    end                   
end

NormalPage.onPlayAnimComplete = function(self,item)   
    item.m_txtAnswer:setVisible(item.m_select);           
end

NormalPage.reAdaptivePos = function(self,items)   
    for i=1,#items do
         if i > 1 then 
            local _,h = items[i-1]:getSize();
            local x,y = items[i-1]:getPos();             
            items[i]:setPos(x,y+h+10); 
        end    
    end        
end

NormalPage.onTabChanged = function(self,index)   
    for i = 1, #self.m_pageArr do
		local page = self.m_pageArr[i];
		page:setVisible(index == i);
	end
end

