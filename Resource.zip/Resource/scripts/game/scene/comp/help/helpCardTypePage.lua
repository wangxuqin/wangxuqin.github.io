require("view/help/cardType/layout_cardType");

helpCardTypePage = {}

helpCardTypePage.getView = function ()
   
    helpCardTypePage.m_root = SceneLoader.load(layout_cardType); 

    helpCardTypePage.m_cardText = {};

    helpCardTypePage.getCtrls();

    helpCardTypePage.setText();

    return helpCardTypePage.m_root;
end

helpCardTypePage.getCtrls = function ()
    if helpCardTypePage.m_root ~= nil then
        for i = 1, 10 do
            helpCardTypePage.m_cardText[i] = helpCardTypePage.m_root:getNodeByName(tostring("bg.scrollView.typeText"..i)); 
        end
    end       
end

helpCardTypePage.setText = function ()
     for i = 1, 10 do 
         helpCardTypePage.m_cardText[i]:setText(STR_SETTING_HELP_CONTENT.PAGE1.SECTION[i].TITLE);
     end
end


