require("view/help/proWords/layout_proWords");

helpProWordsPage = {}

helpProWordsPage.getView = function ()
   
    helpProWordsPage.m_root = SceneLoader.load(layout_proWords); 

    helpProWordsPage.getCtrls();

    helpProWordsPage.setText();

    return helpProWordsPage.m_root;
end

helpProWordsPage.getCtrls = function ()    
    helpProWordsPage.roundTitle1  = helpProWordsPage.m_root:getNodeByName("view.scrollView.marker.roundTitle1"); 
    helpProWordsPage.text1        = helpProWordsPage.m_root:getNodeByName("view.scrollView.marker.text1"); 
    helpProWordsPage.roundTitle2  = helpProWordsPage.m_root:getNodeByName("view.scrollView.smallBind.roundTitle2");  
    helpProWordsPage.text2        = helpProWordsPage.m_root:getNodeByName("view.scrollView.smallBind.text2");  
    helpProWordsPage.roundTitle3  = helpProWordsPage.m_root:getNodeByName("view.scrollView.bigBind.roundTitle3");  
    helpProWordsPage.text3        = helpProWordsPage.m_root:getNodeByName("view.scrollView.bigBind.text3");  
    helpProWordsPage.roundTitle4  = helpProWordsPage.m_root:getNodeByName("view.scrollView.dealCard.roundTitle4");  
    helpProWordsPage.text4        = helpProWordsPage.m_root:getNodeByName("view.scrollView.dealCard.text4");  
    helpProWordsPage.roundTitle5  = helpProWordsPage.m_root:getNodeByName("view.scrollView.meltCard.roundTitle5");  
    helpProWordsPage.text5        = helpProWordsPage.m_root:getNodeByName("view.scrollView.meltCard.text5"); 
    helpProWordsPage.roundTitle6  = helpProWordsPage.m_root:getNodeByName("view.scrollView.handCard.roundTitle6"); 
    helpProWordsPage.text6        = helpProWordsPage.m_root:getNodeByName("view.scrollView.handCard.text6"); 
    helpProWordsPage.roundTitle7  = helpProWordsPage.m_root:getNodeByName("view.scrollView.publicCard.roundTitle7");  
    helpProWordsPage.text7        = helpProWordsPage.m_root:getNodeByName("view.scrollView.publicCard.text7");  
    helpProWordsPage.roundTitle8  = helpProWordsPage.m_root:getNodeByName("view.scrollView.bet.roundTitle8");  
    helpProWordsPage.text8        = helpProWordsPage.m_root:getNodeByName("view.scrollView.bet.text8");  
    helpProWordsPage.roundTitle9  = helpProWordsPage.m_root:getNodeByName("view.scrollView.follow.roundTitle9");  
    helpProWordsPage.text9        = helpProWordsPage.m_root:getNodeByName("view.scrollView.follow.text9");  
    helpProWordsPage.roundTitle10 = helpProWordsPage.m_root:getNodeByName("view.scrollView.pass.roundTitle10");  
    helpProWordsPage.text10       = helpProWordsPage.m_root:getNodeByName("view.scrollView.pass.text10");
    helpProWordsPage.roundTitle11 = helpProWordsPage.m_root:getNodeByName("view.scrollView.check.roundTitle11"); 
    helpProWordsPage.text11       = helpProWordsPage.m_root:getNodeByName("view.scrollView.check.text11"); 
    helpProWordsPage.roundTitle12 = helpProWordsPage.m_root:getNodeByName("view.scrollView.raise.roundTitle12");  
    helpProWordsPage.text12       = helpProWordsPage.m_root:getNodeByName("view.scrollView.raise.text12");  
    helpProWordsPage.roundTitle13 = helpProWordsPage.m_root:getNodeByName("view.scrollView.allIn.roundTitle13");  
    helpProWordsPage.text13       = helpProWordsPage.m_root:getNodeByName("view.scrollView.allIn.text13");  
    helpProWordsPage.roundTitle14 = helpProWordsPage.m_root:getNodeByName("view.scrollView.finalHand.roundTitle14");  
    helpProWordsPage.text14       = helpProWordsPage.m_root:getNodeByName("view.scrollView.finalHand.text14");  
          
end

helpProWordsPage.setText = function ()    

    helpProWordsPage.roundTitle1:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[1].TITLE); 
    helpProWordsPage.text1:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[1].CONTENT);       
    helpProWordsPage.roundTitle2:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[2].TITLE);
    helpProWordsPage.text2:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[2].CONTENT);      
    helpProWordsPage.roundTitle3:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[3].TITLE);
    helpProWordsPage.text3:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[3].CONTENT);     
    helpProWordsPage.roundTitle4:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[4].TITLE);
    helpProWordsPage.text4:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[4].CONTENT);      
    helpProWordsPage.roundTitle5:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[5].TITLE);
    helpProWordsPage.text5:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[5].CONTENT);      
    helpProWordsPage.roundTitle6:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[6].TITLE);
    helpProWordsPage.text6:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[6].CONTENT);      
    helpProWordsPage.roundTitle7:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[7].TITLE);
    helpProWordsPage.text7:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[7].CONTENT);      
    helpProWordsPage.roundTitle8:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[8].TITLE);
    helpProWordsPage.text8:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[8].CONTENT);      
    helpProWordsPage.roundTitle9:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[9].TITLE);
    helpProWordsPage.text9:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[9].CONTENT);      
    helpProWordsPage.roundTitle10:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[10].TITLE);
    helpProWordsPage.text10:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[10].CONTENT);     
    helpProWordsPage.roundTitle11:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[11].TITLE);
    helpProWordsPage.text11:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[11].CONTENT);     
    helpProWordsPage.roundTitle12:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[12].TITLE);
    helpProWordsPage.text12:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[12].CONTENT);     
    helpProWordsPage.roundTitle13:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[13].TITLE);
    helpProWordsPage.text13:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[13].CONTENT);     
    helpProWordsPage.roundTitle14:setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[14].TITLE);
    helpProWordsPage.text14 :setText(STR_SETTING_HELP_CONTENT.PAGE4.SECTION[14].CONTENT);      
end