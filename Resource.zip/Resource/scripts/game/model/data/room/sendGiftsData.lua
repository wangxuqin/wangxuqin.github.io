--[Comment]
--送礼物数据
SendGiftsData = class();

SendGiftsData.ctor = function(self)
end

SendGiftsData.dtor = function(self)
end
SendGiftsData.sendSeatId = 0;	--送礼物的座位id
SendGiftsData.giftId     = 0;	--礼物id
SendGiftsData.userArr    = nil;	--接受礼物座位id数组