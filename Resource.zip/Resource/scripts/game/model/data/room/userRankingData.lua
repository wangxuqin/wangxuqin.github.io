--[Comment]
--用户排名数据
UserRankingData = class();

UserRankingData.ctor = function(self)
end

UserRankingData.dtor = function(self)
end

UserRankingData.count      = 0;--当前人数
UserRankingData.ranking    = 0;--当前排名
UserRankingData.selfChip   = 0;--当前剩余筹码
UserRankingData.differChip = 0;--与前一名的差距