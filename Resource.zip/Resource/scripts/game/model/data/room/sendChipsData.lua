--[Comment]
--赠送筹码数据
SendChipsData = class();

SendChipsData.ctor = function(self)
end

SendChipsData.dtor = function(self)
end

SendChipsData.LESS_THAN_SMALLBLIND    = 0X9401; --钱数不够，不能赠送
SendChipsData.SEND_TOO_MANY_TIMES     = 0X9402; --赠送太频繁
SendChipsData.LARGE_THAN_ONE_THOUSAND = 0X9403; --最多赠送1000

SendChipsData.sendChips      = 0; --赠送的筹码
SendChipsData.senderSeatId   = 0; --赠送者座位id
SendChipsData.recieverSeatId = 0; --接受者座位id


