--[Comment]
--聊天信息数据
ChatData = class();

ChatData.ctor = function(self)
end

ChatData.dtor = function(self)
end

ChatData.seatId                  = 0; --用户没有坐下则为-1
ChatData.senderName              = "";--用户名
ChatData.message                 = "";--消息内容