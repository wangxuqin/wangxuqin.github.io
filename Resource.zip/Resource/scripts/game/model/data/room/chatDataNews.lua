--[Comment]
--聊天信息数据
ChatDataNew = class();

ChatDataNew.ctor = function(self)
end

ChatDataNew.dtor = function(self)
end

ChatDataNew.USER_TO_TABLE = 0;
ChatDataNew.messageType   = 0;
ChatDataNew.senderTid     = 0;
ChatDataNew.receiverTid   = 0;
ChatDataNew.senderUid     = 0;  --sender's uid
ChatDataNew.senderName    = ""; --sender's name
ChatDataNew.receiverUid   = 0;  --receiver's uid
ChatDataNew.receiverName  = ""; --receiver's name
ChatDataNew.message       = ""; --message content
		
