--[Comment]
--用户坐下数据
UserSitDownData = class();

UserSitDownData.ctor = function(self)
end

UserSitDownData.dtor = function(self)
end

UserSitDownData.ERROR_SIT_IP_EQUAL        = 0x9103; --同一IP不能坐下
UserSitDownData.ERROR_SIT_SELF_IS_SITTING = 0x9104;	--自己已经坐下了
UserSitDownData.ERROR_SIT_BUYING          = 0x9105;	--买入不够
UserSitDownData.ERROR_SIT_SEATID          = 0x9106;	--座位id出错
UserSitDownData.ERROR_SIT_IS_HAVE_USER    = 0x9107;	--座位上已经有人了
UserSitDownData.ERROR_SIT_IS_SEATING      = 0x9108;	--用户已经坐下了
UserSitDownData.ERROR_SIT_MONEY_TOO_BIG   = 0x9109;	--钱过大，不能进入新手场
UserSitDownData.ERROR_SIT_MONEY_TOO_POOR  = 0x9110;	--钱不够，不能进入非新手场

UserSitDownData.seatId          = -1;	--用户座位ID
UserSitDownData.uid             = -1;	--用户ID
UserSitDownData.name            = "";	--用户名
UserSitDownData.gender          = "";	--性别
UserSitDownData.totalChips      = 0;	--总资产
UserSitDownData.exp             = 0;	--总经验
UserSitDownData.vip             = 0;	--是否VIP
UserSitDownData.photoUrl        = "";	--头像url
UserSitDownData.winRound        = 0;	--用户赢盘数
UserSitDownData.loseRound       = 0;	--用户输盘数
UserSitDownData.currentPlace    = "";	--用户所在地
UserSitDownData.homeTown        = "";	--用户家乡
UserSitDownData.giftId          = 0;	--用户默认礼物
UserSitDownData.seatChips       = 0;	--买入坐下筹码数
