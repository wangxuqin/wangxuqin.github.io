--[Comment]
--房间公共牌数据
TablePublicCard = class();
TablePublicCard.ctor = function(self)
end

TablePublicCard.dtor = function(self)
end

TablePublicCard.card1 = 0;
TablePublicCard.card2 = 0;
TablePublicCard.card3 = 0;
TablePublicCard.card4 = 0;
TablePublicCard.card5 = 0;