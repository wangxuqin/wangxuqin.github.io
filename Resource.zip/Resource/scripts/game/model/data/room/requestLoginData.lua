--[Comment]
--请求登陆数据
RequestLoginData = {};
RequestLoginData.MAIN_PAGE      = 1;
RequestLoginData.NORMAL_HALL    = 2;
RequestLoginData.MATCH_HALL     = 3;
RequestLoginData.LOGIN_PAGE     = 4;	
RequestLoginData.SNG_HALL       = 5;
RequestLoginData.MTT_HALL       = 6;
		
RequestLoginData.tid            = 0;--桌子ID
RequestLoginData.uid            = 0;--用户ID
RequestLoginData.mtkey          = "";--mtkey
RequestLoginData.imgUrl         = "";--用户头像URL
RequestLoginData.ip             = "";--SVR的IP
RequestLoginData.port           = 0;--SVR的端口号
RequestLoginData.giftId         = 0;--用户礼物ID
RequestLoginData.roomType       = 0;--用户所在房间类型
RequestLoginData.playNow        = false;--是否立即开始进入
RequestLoginData.enterFrom      = 0;--从主页或者大厅进入房间
RequestLoginData.password       = nil;--请输入房间密码

--[Comment]
-- 1:new房
-- 2:hot房
-- 3:top9
-- 4:双倍经验房
-- 11:top房
RequestLoginData.roomStyle      = 0;