--[Comment]
--用户玩牌数据
UserPlayGameData = {};
UserPlayGameData.userPlayGameCounts    = 0;  --用户玩牌局数
UserPlayGameData.userPlayGameWinCounts = 0;  --用户赢牌局数
UserPlayGameData.userBeforeOwnMoney    = 0;  --用户之前资产
UserPlayGameData.userOwnMoneyChange    = 0;  --用户总资变化数
UserPlayGameData.userCurrentOwnMoney   = 0;  --用户现在资产
