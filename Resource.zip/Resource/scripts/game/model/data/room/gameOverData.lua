--[Comment]
--游戏结束数据
GameOverData = class();

GameOverData.ctor = function(self)
end

GameOverData.dtor = function(self)
end

GameOverData.TYPE_PIE_CARD       = 1;	-- 杂牌			Pie Card
GameOverData.TYPE_HIGH_CARD      = 2;	-- 高牌			High Card
GameOverData.TYPE_PAIR           = 3;	-- 一对			Pair
GameOverData.TYPE_TWO_PAIRS      = 4;	-- 二对			Two Pairs
GameOverData.TYPE_THREE_KIND     = 5;	-- 三条			Three of a kind
GameOverData.TYPE_STRAIGHT       = 6;	-- 顺子			Straight
GameOverData.TYPE_FLUSH          = 7;	-- 同花			Flush
GameOverData.TYPE_FULL_HOUSE     = 8;	-- 葫芦			Full House
GameOverData.TYPE_FOUR_KIND      = 9;	-- 四条			Four of a Kind
GameOverData.TYPE_STRAIGHT_FLUSH = 10;	-- 同花顺		Straight Flush
GameOverData.TYPE_ROYAL_FLUSH    = 11;	-- 皇家同花顺	Royal Flush
GameOverData.expChange           = {};	--加减的经验值
GameOverData.chips               = {};	--座位钱数
GameOverData.playerCount         = 0;	--在玩人数
GameOverData.playerList          = nil;	--在玩用户的信息	
GameOverData.chipsPotsCount      = 0;	--台面上奖池个数
GameOverData.chipsPotsInfo       = nil;	--详细的分钱奖池信息	



