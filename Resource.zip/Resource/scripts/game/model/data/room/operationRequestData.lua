--[Comment]
--用户操作数据
OperationRequestData = class();

OperationRequestData.ctor = function()
end

OperationRequestData.dtor = function()
end

OperationRequestData.OP_TYPE_FOLD  = 1;--弃牌
OperationRequestData.OP_TYPE_CHECK = 2;--看牌
OperationRequestData.OP_TYPE_CALL  = 3;--下注
OperationRequestData.operationType = 0;--操作类型
OperationRequestData.betMoney      = 0;--下注金额
