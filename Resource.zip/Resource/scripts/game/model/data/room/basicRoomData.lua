--[Comment]
--基本房间数据
BasicRoomData = {};
BasicRoomData.NINE_SEAT_LIST               = {1, 2, 3, 4, 5, 6, 7, 8, 9};	--九人场坐位ID
BasicRoomData.FIVE_SEAT_LIST               = {1, 3, 5, 7, 9};				--五人场坐位ID
BasicRoomData.TWO_SEAT_LIST                = {3, 7};						--两人场座位ID		