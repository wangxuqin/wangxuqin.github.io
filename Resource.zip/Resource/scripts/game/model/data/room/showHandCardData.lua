--[Comment]
--显示手牌数据
ShowHandCardData = {};

ShowHandCardData.ctor = function(self)
end

ShowHandCardData.dtor = function(self)
end
ShowHandCardData.seatId = 0;
ShowHandCardData.card1  = 0;
ShowHandCardData.card2  = 0;
