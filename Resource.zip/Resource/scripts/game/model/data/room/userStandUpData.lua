--[Comment]
--用户站起数据
UserStandUpData = class();

UserStandUpData.ctor = function(self)
end

UserStandUpData.dtor = function(self)
end

UserStandUpData.seatId    = -1;
UserStandUpData.userChips = 0;