--[Comment]
--登陆成功数据
LoginSuccData = class();
LoginSuccData.ROOM_TYPE_FAST         = -1;--快速场
LoginSuccData.ROOM_TYPE_NONE         = 0; --不在房间
LoginSuccData.ROOM_TYPE_NORMAL       = 1; --普通场
LoginSuccData.ROOM_TYPE_PROFESSIONAL = 2; --专业场
LoginSuccData.ROOM_TYPE_TOURNAMENT   = 3; --锦标赛
LoginSuccData.ROOM_TYPE_KNOCKOUT     = 4; --淘汰赛
LoginSuccData.ROOM_TYPE_PROMOTION    = 5; --晋级赛
LoginSuccData.ROOM_TYPE_TUTORIA  	 = 98;--新手教程
LoginSuccData.ROOM_TYPE_SINGLE_GAME  = 99;--单机游戏

--[Comment]
--新手场	
LoginSuccData.ROOM_LEVEL_NEWER  = 1;
--[Comment]
--初级场	
LoginSuccData.ROOM_LEVEL_PRIMARY = 2;
--[Comment]
--中级场
LoginSuccData.ROOM_LEVEL_INTERMEDIATE = 3;
--[Comment]
--高级场	
LoginSuccData.ROOM_LEVEL_SENIOR = 4;

LoginSuccData.GAME_STATE_READY         = 0;
LoginSuccData.GAME_STATE_PREFLOP_ROUND = 1;
LoginSuccData.GAME_STATE_FLOP_ROUND    = 2;
LoginSuccData.GAME_STATE_TURN_ROUND    = 3;
LoginSuccData.GAME_STATE_RIVER_ROUND   = 4;
LoginSuccData.GAME_STATE_ROUND_OVER    = 6;

LoginSuccData.ERROR_LOGIN_MTKEY               = 0x9001;--参数非法
LoginSuccData.ERROR_LOGIN_USER_DISABLE        = 0x9002;--用户被禁
LoginSuccData.ERROR_LOGIN_TABLE_ERR           = 0x9003;--登录桌子错误
LoginSuccData.ERROR_LOGIN_ROOM_FULL           = 0x9004;--用户达到最大值
LoginSuccData.ERROR_LOGIN_RECONN_ROOM         = 0x9005;--重连进入不同的桌子
LoginSuccData.ERROR_LOGIN_OTHER_RELOGIN       = 0x9006;--账号被其他人登陆了
LoginSuccData.ERROR_LOGIN_EXP_DISABLE         = 0x9007;--等级不够
LoginSuccData.ERROR_LOGIN_SERVER_STOP         = 0x9008;--停服标志
LoginSuccData.ERROR_LOGIN_KICKOUT             = 0x9009;--被踢出
LoginSuccData.ERROR_LOGIN_PASSWORD_ERROR      = 0x810A;--密码错误
LoginSuccData.ERROR_LOGIN_TABLE_NOTEXIST      = 0x810B;--房间不存在

LoginSuccData.smallBlind      = 0;	    --小盲注
LoginSuccData.minBuyIn        = 0;		--最小携带
LoginSuccData.maxBuyIn        = 0;		--最大携带
LoginSuccData.tableId         = 0;	    --桌子ID
LoginSuccData.tableName       = "";	--桌子名字
LoginSuccData.roomType        = 0;		--房间场别
LoginSuccData.tableLevel      = 0;		--房间级别
LoginSuccData.userChips       = 0;	    --用户钱数
LoginSuccData.betInExpire     = 0;		--下注最大时间
LoginSuccData.gameStatus      = 0;		--游戏状态
LoginSuccData.maxSeatCount    = 0;	    --最大玩家数量
LoginSuccData.roundCount      = 0;		--游戏局数
LoginSuccData.dealerSeatId    = -1;	--庄家座位ID
LoginSuccData.chipsPotsCount  = 0;	    --奖池数量
LoginSuccData.chipsPots       = nil;	--奖池数组
LoginSuccData.publicCards     = {0x0, 0x0, 0x0, 0x0, 0x0};--桌子上的牌，数组内存PublicCard对象
LoginSuccData.betInSeatId     = -1;	--桌子目前的下注位置

LoginSuccData.callNeedChips   = 0;     --跟注需要钱数（重连数据）
LoginSuccData.minRaiseChips   = 0;     --加注最小钱数（重连数据）
LoginSuccData.maxRaiseChips   = 0;     --加注最大钱数（重连数据）

LoginSuccData.playerCount     = 0;		--玩家数量（坐下）
LoginSuccData.playerList      = nil;	--玩家用户的信息，数组内存RoomLoginPlayer对象		
LoginSuccData.handCardFlag    = 0;	    --是否有手牌，1有，0无
LoginSuccData.handCard        = nil;	--手牌
LoginSuccData.tableFlag       = 0;		--房间标识

LoginSuccData.isMatch = function(rt)		
    return rt == ROOM_TYPE_KNOCKOUT or rt == ROOM_TYPE_TOURNAMENT or rt == ROOM_TYPE_PROMOTION;		
end	

