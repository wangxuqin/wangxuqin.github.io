--[Comment]
--牌桌数据
TableIdData = class();

TableIdData.ctor = function(self)
end

TableIdData.dtor = function(self)
end

TableIdData.tableId    = 0;--桌子id
TableIdData.startTime  = 0;--开始时间
TableIdData.duration   = 0;--已持续时间
TableIdData.smallBlind = 0;--单桌实时小盲