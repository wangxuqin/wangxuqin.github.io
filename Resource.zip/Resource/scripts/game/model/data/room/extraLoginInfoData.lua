--[Comment]
--特殊登陆数据
ExtraLoginInfoData = {};
ExtraLoginInfoData.currentDealer             = 0;		--本桌荷官
ExtraLoginInfoData.userDealer                = 0;		--个人荷官
ExtraLoginInfoData.setDealer                 = 0;       --是否设置荷官
ExtraLoginInfoData.dealerName                = "";		--荷官的名字
ExtraLoginInfoData.dealerCharge              = 0;		--荷官竞价
ExtraLoginInfoData.autoBuyLotto              = 0;		--是否自动购买乐透
ExtraLoginInfoData.buyNextLotto              = 0;		--是否购买下一局乐透
ExtraLoginInfoData.lottoPrice                = 0;		--乐透买入价格
ExtraLoginInfoData.royalFlushScale           = 0;		--乐透皇家同花顺比例
ExtraLoginInfoData.straightFlushScale        = 0;	    --乐透同花顺比例
ExtraLoginInfoData.fourKindScale             = 0;		--乐透四条比例


