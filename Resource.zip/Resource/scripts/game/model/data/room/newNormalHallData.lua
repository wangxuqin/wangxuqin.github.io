NewNormalHallData = class();
NewNormalHallData.m_currentMatchData = nil;
		
NewNormalHallData.getCurrentMatchData = function(self)
    return self.m_currentMatchData;
end
		
NewNormalHallData.setCurrentMatchData = function(self, value)
    self.m_currentMatchData = value;
    Model.setData(ModelKeys.NEW_HALL_ROOM_DATA, self.m_currentMatchData);
end