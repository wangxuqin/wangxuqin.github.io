--[Comment]
--用户退出数据
UserOutData = {};
UserOutData.ranking = 0;--排名
UserOutData.chip    = 0;--奖励筹码
UserOutData.coalaa  = 0;--奖励卡拉币
UserOutData.score   = 0;--奖励积分
UserOutData.exp     = 0;--预留
