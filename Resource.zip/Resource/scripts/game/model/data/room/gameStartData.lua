--[Comment]
--游戏开始数据
GameStartData = class();

GameStartData.ctor = function(self)
end

GameStartData.dtor = function(self)
end

GameStartData.roundCount   = 0;	    --当前局数
GameStartData.dealerSeatId = -1;	--庄家座位
GameStartData.playerCount  = 0;	    --在玩人数 
GameStartData.seatArray    = nil;	--在玩人数座位列表,数组存放用户信息
GameStartData.handCard1    = 0;     --手牌1
GameStartData.handCard2    = 0;	    --手牌2
GameStartData.userChips    = 0;	    --用户筹码
