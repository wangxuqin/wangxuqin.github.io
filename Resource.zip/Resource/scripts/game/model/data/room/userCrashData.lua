--[Comment]
--用户破产数据
UserCrashData = class();

UserCrashData.ctor = function(self)
end

UserCrashData.dtor = function(self)
end

UserCrashData.times          = 0;--times为1表示第一次或者第二次破产，times为2表示最后一次破产，times为3表示完全破产
UserCrashData.subsidizeChips = 0;--救济金