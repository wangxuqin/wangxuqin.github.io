--[Comment]
--互动道具数据
HddjData = class();

HddjData.ctor = function(self)
end

HddjData.dtor = function(self)
end

HddjData.sendSeatId    = 0;--使用者座位id
HddjData.hddjId        = 0;--道具id
HddjData.receiveSeatId = 0;--被砸玩家的座位id
HddjData.uid           = 0;--被砸玩家的uid