--[Comment]
--轮到谁下注
OperationTurnToData = class();

OperationTurnToData.ctor = function(self)
end

OperationTurnToData.dtor = function(self)
end

OperationTurnToData.seatId        = -1;--座位id
OperationTurnToData.callChips     = 0; --需要跟注钱数
OperationTurnToData.minRaiseChips = 0; --需要加注最小钱数
OperationTurnToData.maxRaiseChips = 0; --需要加注最大钱数