--[Comment]
--已登陆房间并且坐下的用户信息
TableUserData = class();
TableUserData.SEAT_WAIT       = 0;  --等待下一轮
TableUserData.SEAT_READY      = 1;  --等待下注
TableUserData.SEAT_FLOD       = 2;  --弃牌
TableUserData.SEAT_ALLIN      = 3;  --ALL IN
TableUserData.SEAT_CHINPIN    = 4;  --下注
TableUserData.SEAT_SMALLBIND  = 5;  --小盲
TableUserData.SEAT_BIGBIND    = 6;  --大盲
TableUserData.SEAT_CHECK      = 7;  --看牌
TableUserData.SEAT_RAISE      = 8;  --加注


TableUserData.ctor = function(self)
    self.seatId          = -1;	--座位id;
    self.uid             = -1;	--用户id;
    self.totalChips      = 0;	--用户钱数	
    self.exp             = 0;	--用户经验值
    self.vip             = 0;	--VIP标识
    self.name            = "";	--用户名
    self.gender          = "";	--性别
    self.photoUrl        = "";	--用户图片url
    self.winRound        = 0;	--用户赢盘数
    self.loseRound       = 0;	--用户输盘数
    self.currentPlace    = "";	--用户所在地
    self.homeTown        = "";	--用户家乡
    self.giftId          = 0;	--用户默认道具
    self.seatChips       = 0;	--座位的钱数
    self.betInChips      = 0;	--座位的总下注数
    self.operationStatus = 0;	--当前操作类型
    self.platFlag        = 0;  --平台标识
end

TableUserData.dtor = function(self)
end





TableUserData.isSelf = function(self)
    local ret = false;
    if Model.getData(ModelKeys.USER_DATA) then  
        if self.uid == Model.getData(ModelKeys.USER_DATA).uid then
            ret = true;
		else
            ret = false;
        end
	else
		if self.seatId == 5  then
            ret = true
        else
            ret = false
        end
    end
    return ret;
end