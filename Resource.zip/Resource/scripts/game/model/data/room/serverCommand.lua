--[Comment]
--客户端与主SVR通信命令字
ServerCommand = {};

--[Comment]
--客户端请求命令字
ServerCommand.CLI_CMD_LOGIN                     = 0x1001; --CLI请求登陆
ServerCommand.CLI_CMD_LOGIN_VER                 = 1;      --CLI请求登陆协议版本
ServerCommand.CLI_CMD_RETURN                    = 0x1002; --CLI请求返回大厅或登录界面
ServerCommand.CLI_CMD_RETURN_VER                = 1;      --CLI请求返回大厅或登录界面协议版本
ServerCommand.CLI_CMD_SITDOWN                   = 0x1003; --CLI请求坐下
ServerCommand.CLI_CMD_SITDOWN_VER               = 1;      --CLI请求坐下协议版本
ServerCommand.CLI_CMD_STAND                     = 0x1005; --CLI请求站起
ServerCommand.CLI_CMD_STAND_VER                 = 1;      --CLI请求站起协议版本
ServerCommand.CLI_CMD_REQ_BET                   = 0x1004; --CLI请求下注
ServerCommand.CLI_CMD_REQ_BET_VER               = 1;      --CLI请求下注协议版本
ServerCommand.CLI_CMD_REQ_AUTOSIT               = 0x1006; --CLI请求自动买入
ServerCommand.CLI_CMD_REQ_AUTOSIT_VER           = 1;      --CLI请求自动买入协议版本
ServerCommand.CLI_CMD_REQ_CANCEL_AUTOSIT        = 0x1007; --CLI请求取消自动买入
ServerCommand.CLI_CMD_REQ_CANCEL_AUTOSIT_VER    = 1;      --CLI请求取消自动买入协议版本
ServerCommand.CLI_CMD_REQ_SEND_MSG              = 0x1008; --CLI请求发送消息
ServerCommand.CLI_CMD_REQ_SEND_MSG_VER          = 1;      --CLI请求发送消息协议版本
ServerCommand.CLI_CMD_REQ_SEND_EMOTION          = 0x1009; --CLI请求发送表情
ServerCommand.CLI_CMD_REQ_SEND_EMOTION_VER      = 1;      --CLI请求发送表情协议版本
ServerCommand.CLI_CMD_REQ_SHOW_HAND_CARD        = 0x100A; --CLI请求亮出手牌
ServerCommand.CLI_CMD_REQ_SHOW_HAND_CARD_VER    = 1;      --CLI请求亮出手牌协议版本
ServerCommand.CLI_CMD_REQ_SEND_CHIPS            = 0x100C; --CLI请求赠送筹码
ServerCommand.CLI_CMD_REQ_SEND_CHIPS_VER        = 1;      --CLI请求赠送筹码协议版本
ServerCommand.CLI_CMD_SEND_GIFT                 = 0x100B; --CLI请求赠送礼物
ServerCommand.CLI_CMD_SEND_GIFT_VER             = 1;      --CLI请求赠送礼物协议版本
ServerCommand.CLI_CMD_SEND_HD                   = 0x100D; --CLI请求使用互动道具
ServerCommand.CLI_CMD_SEND_HD_VER               = 1;      --CLI请求使用互动道具协议版本
ServerCommand.CLI_CMD_CHANGE_GIFT               = 0x100E; --CLI请求更换礼物
ServerCommand.CLI_CMD_CHANGE_GIFT_VER           = 1;      --CLI请求更换礼物协议版本
ServerCommand.CLI_CMD_ADD_FRIEND                = 0x100F; --CLI请求广播加为牌友
ServerCommand.CLI_CMD_ADD_FRIEND_VER            = 1;      --CLI请求广播加为牌友协议版本
ServerCommand.CLI_CMD_HEART_BEAT                = 0x1010; --主svr心跳包命令字
ServerCommand.CLI_CMD_HEART_BEAT_VER            = 1;      --主svr心跳包命令字版本
ServerCommand.CLI_CMD_NEXT_STAND                = 0x1011; --CLI请求本局结束后站起
ServerCommand.CLI_CMD_BACK_SEAT                 = 0x1012; --CLI请求回到座位
ServerCommand.CLI_CMD_BACK_SEAT_VER             = 1;      --CLI请求回到座位版本
ServerCommand.CLI_CMD_NEXT_STAND_VER            = 1;      --CLI请求本局结束后站起协议版本
ServerCommand.CLI_CMD_SEND_DEALER_MONEY         = 0x1014; --CLI请求给荷官送筹码
ServerCommand.CLI_CMD_SEND_DEALER_MONEY_VER     = 1;      --CLI请求给荷官送筹码协议版本
ServerCommand.CLI_CMD_BUY_NEXT_LOTTO		    = 0x1020;	--CLI请求购买下一局大乐透
ServerCommand.CLI_CMD_BUY_NEXT_LOTTO_VER	    = 1;		--CLI请求购买下一局大乐透版本
ServerCommand.CLI_CMD_AUTO_BUY_LOTTO		    = 0x1021;	--CLI请求自动购买大乐透
ServerCommand.CLI_CMD_AUTO_BUY_LOTTO_VER        = 1;		--CLI请求自动购买大乐透版本
ServerCommand.CLI_CMD_CANCEL_AUTO_BUY_LOTTO     = 0x1022;	--CLI请求取消自动购买大乐透
ServerCommand.CLI_CMD_CANCEL_AUTO_BUY_LOTTO_VER = 1;		--CLI请求取消自动购买大乐透版本
ServerCommand.CLI_CMD_DELAY_AUTO_BUY_LOTTO      = 0x1023; --CLI请求通知延迟自动购买大乐透
ServerCommand.CLI_CMD_DELAY_AUTO_BUY_LOTTO_VER  = 1;		--CLI请求通知延迟自动购买大乐透版本
ServerCommand.CLI_CMD_REQ_SEND_MSG_NEW          = 0x1024; --CLI请求发送消息(new)
ServerCommand.CLI_CMD_REQ_SEND_MSG_NEW_VER      = 1;		--CLI请求发送消息版本(new)

--[Comment]
--SVR返回命令字段
ServerCommand.SVR_CMD_LOGIN_SUCC             = 0x2001; --SVR返回登陆成功包
ServerCommand.SVR_CMD_LOGIN_FAIL             = 0x2002; --SVR返回登陆失败包
ServerCommand.SVR_CMD_RELOGIN_SUCC           = 0x200F; --SVR返回重连登陆成功包
ServerCommand.SVR_CMD_SITEDOWN_FAIL          = 0x2004; --SVR返回坐下失败包
ServerCommand.SVR_CMD_USER_CRASH             = 0x2013; --SVR返回破产包
ServerCommand.SVR_CMD_SEND_CHIPS_FAIL        = 0x2018; --SVR返回赠送筹码失败包
ServerCommand.SVR_CMD_EXTRA_LOGIN_INFO       = 0x2022; --SVR返回登录成功额外信息包
ServerCommand.SVR_CMD_SEND_DEALER_CHIP_SUCC  = 0x2027; --SVR通知赠送荷官筹码成功
ServerCommand.SVR_CMD_SEND_DEALER_CHIP_FAIL  = 0x2028; --SVR通知赠送荷官筹码失败

--[Comment]
--SVR广播命令字段
ServerCommand.SVR_BCCMD_SEND_GIFT            = 0X2015; --SVR广播赠送礼物
ServerCommand.SVR_BCCMD_SEND_CHIPS           = 0x2016; --SVR广播赠送筹码
ServerCommand.SVR_BCCMD_BET_SUCC             = 0x2008; --SVR广播下注成功信息	
ServerCommand.SVR_BCCMD_BET_TURN_TO          = 0x200C; --SVR广播轮到谁下注
ServerCommand.SVR_BCCMD_STAND                = 0x2006; --SVR广播用户站起成功
ServerCommand.SVR_BCCMD_GAME_START           = 0x2007; --SVR广播游戏开始
ServerCommand.SVR_BCCMD_SITDOWN              = 0x2005; --SVR广播坐下信息
ServerCommand.SVR_BCCMD_CARD_FLOP            = 0x2009; --SVR广播翻三张
ServerCommand.SVR_BCCMD_CARD_TRUN            = 0x200A; --SVR广播翻第四张
ServerCommand.SVR_BCCMD_CARD_RIVER           = 0x200B; --SVR广播翻第五张
ServerCommand.SVR_BCCMD_CHIPSPOTS            = 0x200D; --SVR广播奖池信息
ServerCommand.SVR_BCCMD_GAME_OVER            = 0x200E; --SVR广播游戏结束
ServerCommand.SVR_BCCMD_CHATMSG              = 0x2011; --SVR广播发送消息
ServerCommand.SVR_BCCMD_EMOTION              = 0x2012; --SVR广播发送表情
ServerCommand.SVR_BCCMD_SHOW_HAND_CARD       = 0x2014; --SVR广播亮出手牌
ServerCommand.SVR_BCCMD_ALLIN                = 0x3001; --SVR广播All-In结束
ServerCommand.SVR_BCCMD_SEND_HD              = 0x2017; --SVR广播互动道具
ServerCommand.SVR_BCCMD_KITOUT               = 0x2019; --SVR广播踢人
ServerCommand.SVR_BCCMD_ADD_FRIEND           = 0x201A; --SVR广播用户加牌友
ServerCommand.SVR_BCCMD_LEAVE_SEAT           = 0x201B; --SVR广播用户暂离
ServerCommand.SVR_BCCMD_SVR_SWITCH           = 0x2100; --SVR广播SVR升级成功
ServerCommand.SVR_BCCMD_SVR_STOP             = 0x2101; --SVR广播停服通知
ServerCommand.SVR_BCCMD_BUY_LOTTO_SUCCEED    = 0x2041; --SVR通知购买大乐透成功
ServerCommand.SVR_BCCMD_BUY_LOTTO_FAIL	     = 0x2042; --SVR通知购买大乐透失败
ServerCommand.SVR_BCCMD_CHATMSG_NEW          = 0x2051; --SVR广播发送消息(new)

--[Comment]
--私人房
ServerCommand.SVR_BCCMD_TABLE_OWNER				= 0x2023; --广播私人房间房主
ServerCommand.SERVER_CMD_BROADCAST_OWNER_LEAVE	= 0x2024;	--广播房主离开
ServerCommand.SERVER_CMD_LOGOUT					= 0x2026;--用户登出

--[Comment]
--多人锦标赛 
ServerCommand.SVR_BCCMD_BLIND_CHANGE_T		= 0x7001; --SVR广播盲注改变
ServerCommand.SVR_BCCMD_MATCH_END_T			= 0x7003; --SVR广播比赛结束
ServerCommand.SVR_BCCMD_ALL_RANKING_T		= 0x7004; --弃用,保留
ServerCommand.SVR_BCCMD_TABLE_ID_T			= 0x7006; --SVR返回桌子ID
ServerCommand.SVR_BCCMD_COUNT_DOWN_TIME_T	= 0x7009; --SVR返回比赛时间
ServerCommand.SVR_BCCMD_SWITCH_TABLE_T		= 0x700A; --SVR广播开始换桌
ServerCommand.SVR_BCCMD_SWITCH_TABLE_SUCC_T	= 0x700B; --SVR广播换桌成功
ServerCommand.SVR_BCCMD_MATCH_START_T		= 0x700C; --SVR广播比赛开始
ServerCommand.SVR_BCCMD_MATCH_CLOSE_T		= 0x700D; --SVR广播比赛即将关闭
ServerCommand.SVR_BCCMD_MATCH_TIME_T		= 0x700E; --SVR通知比赛开始时间
ServerCommand.SVR_CMD_USER_RANKING_T		= 0x7007; --SVR返回用户排名
ServerCommand.SVR_CMD_USER_OUT_T			= 0x7005; --SVR返回用户出局

--[Comment]
--单桌淘汰赛
ServerCommand.SVR_BCCMD_TABLE_ID_K           = 0x7103; --SVR广播tableID
ServerCommand.SVR_BCCMD_MATCH_START_K        = 0x7101; --SVR广播比赛开始
ServerCommand.SVR_BCCMD_MATCH_END_K          = 0x7102; --SVR广播比赛结束
ServerCommand.SVR_BCCMD_BLIND_CHANGE_K       = 0x7106; --SVR广播盲注改变
ServerCommand.SVR_BCCMD_ALL_RANKING_K        = 0x7107; --SVR返回所有用户排名
ServerCommand.SVR_BCCMD_MATCH_CLOSE_K        = 0x7108; --SVR广播比赛即将关闭
ServerCommand.SVR_CMD_USER_RANKING_K         = 0x7104; --SVR返回用户排名
ServerCommand.SVR_CMD_USER_OUT_K             = 0x7105; --SVR返回用户出局
ServerCommand.SVR_CMD_MATCH_INFO_K           = 0x7109; --SVR广播比赛信息

--[Comment]
--喇叭server
ServerCommand.LB_SVR_CMD_SYSTEM              = 0x1002; --喇叭SVR系统广播
ServerCommand.LB_SVR_CMD_SINGLE              = 0x1003; --喇叭SVR个人广播
ServerCommand.LB_SVR_CMD_HEARTBEAT           = 0x2001; --喇叭SVR心跳包
ServerCommand.LB_SVR_TYPE_LEVEL_UP           = 0x1001; --个人升级广播
ServerCommand.LB_SVR_TYPE_GLORY_FINISH       = 0x1002; --个人完成成就广播
ServerCommand.LB_SVR_TYPE_TASK_FINISH        = 0x1003; --个人完成任务广播
ServerCommand.LB_SVR_TYPE_EXP                = 0x1004; --坐下加经验广播
ServerCommand.LB_SVR_TYPE_LOTTERY            = 0x1005; --个人中奖广播
ServerCommand.LB_SVR_TYPE_MESSAGE            = 0x1006; --个人有新消息
ServerCommand.LB_SVR_TYPE_EDIT_CHIP	         = 0x1007; --维护金币
ServerCommand.LB_SVR_TYPE_MATCH_PROMPT       = 0x1008; --比赛通知进场
ServerCommand.LB_SVR_TYPE_INVITE_PLAY        = 0x1009; --邀请打牌
ServerCommand.LB_SVR_TYPE_GET_VIP            = 0x100A; --vip点亮
ServerCommand.LB_SVR_TYPE_EDIT_SCORE         = 0x100B; --维护积分
ServerCommand.LB_SVR_TYPE_DELAY_PAY          = 0x100C; --延迟发货
ServerCommand.LB_SVR_TYPE_SUCCESS_PAY        = 0x100D; --支付成功
ServerCommand.LB_SVR_TYPE_SUCCESS_ACT        = 0x1015; --活动完成
ServerCommand.LB_SVR_TYPE_ALL_TIP            = 0x2001; --所有展示位提示
ServerCommand.LB_SVR_TYPE_HEAD_TIP           = 0x2002; --顶头提示
ServerCommand.LB_SVR_TYPE_SLOT               = 0x2003; --老虎机大奖
ServerCommand.LB_SVR_TYPE_ROOM_TIP           = 0x2004; --房间提示
ServerCommand.LB_SVR_TYPE_SMALL_LABA         = 0x2005; --小喇叭消息
ServerCommand.LB_SVR_TYPE_BIG_LABA           = 0x2006; --大喇叭消息
ServerCommand.LB_SVR_TYPE_LOTTO_REWARD       = 0x2007; --大乐透中奖通知
ServerCommand.LB_SVR_TYPE_LOTTO_POOL         = 0x2008; --大乐透奖池通知
ServerCommand.LB_SVR_TYPE_SLOT_REWARD        = 0x200A; --老虎机牌型活动中奖通知 0x200C 卡拉币场

--[Comment]
--David新增命令
ServerCommand.LB_SVR_TYPE_PUSH_MESSAGE	           =0x200B;--系统推送信息
ServerCommand.LB_SVR_TYPE_DOUBLE_LOGIN             = 0x9001; --重复登录
ServerCommand.LB_SVR_TYPE_PLAYER_NUM               = 0x3001; --当前玩家人数
ServerCommand.LB_SVR_TYPE_DOSH_BOARD_MESSAGE       = 0x1013; --doshboard消息

--[Comment]
--移动(MB)专属Type
ServerCommand.LB_SVR_TYPE_MB_DISCOUNT		       = 0x10001; --打折信息
ServerCommand.LB_SVR_TYPE_MB_SYS_MSG 		       = 0x10002; --移动设备活动消息 
ServerCommand.LB_SVR_TYPE_MB_ITEM_DISCOUNT         = 0x10003; --详细打折信息
ServerCommand.LB_SVR_TYPE_MB_USER_PAY              = 0x10004; --用户充值
ServerCommand.LB_SVR_TYPE_MB_DOLL_ACQUIRE_PROMPT   = 0x50001; --用户获得玩偶提示
ServerCommand.LB_SVR_TYPE_MB_SINGLE_MESSAGE  	   = 0x50002; --后台通知消息，前端展示消息，不做其他用
ServerCommand.LB_SVR_TYPE_MB_ACCEPT_RED_PACKS      = 0x50003; --用户获得红包提示
ServerCommand.LB_SVR_TYPE_MB_COMMON_MESSAGE_PROMPT = 0x50004; --公共弹框消息提示

ServerCommand.LB_SVR_TYPE_PUSH_MATCH_MESSAGE	   =0x300A;--系统推送进入比赛信息

--[Comment]
--老虎机server
ServerCommand.SLOT_SVR_SEND_CMD_LOGIN        = 0x1001; --登陆
ServerCommand.SLOT_SVR_SEND_CMD_CALCULATOR   = 0x1002; --算牌器请求包
ServerCommand.SLOT_SVR_SEND_CMD_SLOT         = 0x1003; --老虎机请求包
ServerCommand.SLOT_SVR_RECV_CMD_CALCULATOR   = 0x2001; --算牌器返回包
ServerCommand.SLOT_SVR_RECV_CMD_SLOT_SUCC    = 0x2002; --老虎机成功
ServerCommand.SLOT_SVR_RECV_CMD_SLOT_FAIL    = 0x3001; --老虎机失败

ServerCommand.CLI_CMD_PROXY_LOGIN            = 0x6001; --CLI请求通过Proxy服务器连接GameServer
ServerCommand.CLI_CMD_PROXY_LOGIN_VER        = 1;      --CLI请求登陆协议版本


--[Comment]
--服务器发送命令表
ServerCommandCLIMap = {
    [0x1001] = "ServerCommand.CLI_CMD_LOGIN                      --CLI请求登陆";
    [0x1002] = "ServerCommand.CLI_CMD_RETURN                     --CLI请求返回大厅或登录界面";
    [0x1003] = "ServerCommand.CLI_CMD_SITDOWN                    --CLI请求坐下";
    [0x1005] = "ServerCommand.CLI_CMD_STAND                      --CLI请求站起";
    [0x1004] = "ServerCommand.CLI_CMD_REQ_BET                    --CLI请求下注";
    [0x1006] = "ServerCommand.CLI_CMD_REQ_AUTOSIT                --CLI请求自动买入";
    [0x1007] = "ServerCommand.CLI_CMD_REQ_CANCEL_AUTOSIT         --CLI请求取消自动买入";
    [0x1008] = "ServerCommand.CLI_CMD_REQ_SEND_MSG               --CLI请求发送消息";
    [0x1009] = "ServerCommand.CLI_CMD_REQ_SEND_EMOTION           --CLI请求发送表情";
    [0x100A] = "ServerCommand.CLI_CMD_REQ_SHOW_HAND_CARD         --CLI请求亮出手牌";
    [0x100C] = "ServerCommand.CLI_CMD_REQ_SEND_CHIPS             --CLI请求赠送筹码";
    [0x100B] = "ServerCommand.CLI_CMD_SEND_GIFT                  --CLI请求赠送礼物";
    [0x100D] = "ServerCommand.CLI_CMD_SEND_HD                    --CLI请求使用互动道具";
    [0x100E] = "ServerCommand.CLI_CMD_CHANGE_GIFT                --CLI请求更换礼物";
    [0x100F] = "ServerCommand.CLI_CMD_ADD_FRIEND                 --CLI请求广播加为牌友";
    [0x1010] = "ServerCommand.CLI_CMD_HEART_BEAT                 --主svr心跳包命令字";
    [0x1011] = "ServerCommand.CLI_CMD_NEXT_STAND                 --CLI请求本局结束后站起";
    [0x1012] = "ServerCommand.CLI_CMD_BACK_SEAT                  --CLI请求回到座位";
    [0x1014] = "ServerCommand.CLI_CMD_SEND_DEALER_MONEY          --CLI请求给荷官送筹码";
    [0x1020] = "ServerCommand.CLI_CMD_BUY_NEXT_LOTTO		     --CLI请求购买下一局大乐透";
    [0x1021] = "ServerCommand.CLI_CMD_AUTO_BUY_LOTTO		     --CLI请求自动购买大乐透";
    [0x1022] = "ServerCommand.CLI_CMD_CANCEL_AUTO_BUY_LOTTO      --CLI请求取消自动购买大乐透";
    [0x1023] = "ServerCommand.CLI_CMD_DELAY_AUTO_BUY_LOTTO       --CLI请求通知延迟自动购买大乐透";
    [0x1024] = "ServerCommand.CLI_CMD_REQ_SEND_MSG_NEW           --CLI请求发送消息(new)";
    [0x6001] = "ServerCommand.CLI_CMD_PROXY_LOGIN                --CLI请求通过Proxy服务器连接GameServer";
}

ServerCommandSVRMap = {
--[Comment]
--心跳包
[0x1010] = "ServerCommand.CLI_CMD_HEART_BEAT                 --主svr心跳包命令字";

--[Comment]
--SVR返回命令字段
[0x2001] = "ServerCommand.SVR_CMD_LOGIN_SUCC                  --SVR返回登陆成功包";
[0x2002] = "ServerCommand.SVR_CMD_LOGIN_FAIL                  --SVR返回登陆失败包";
[0x200F] = "ServerCommand.SVR_CMD_RELOGIN_SUCC                --SVR返回重连登陆成功包";
[0x2004] = "ServerCommand.SVR_CMD_SITEDOWN_FAIL               --SVR返回坐下失败包";
[0x2013] = "ServerCommand.SVR_CMD_USER_CRASH                  --SVR返回破产包";
[0x2018] = "ServerCommand.SVR_CMD_SEND_CHIPS_FAIL             --SVR返回赠送筹码失败包";
[0x2022] = "ServerCommand.SVR_CMD_EXTRA_LOGIN_INFO            --SVR返回登录成功额外信息包";
[0x2027] = "ServerCommand.SVR_CMD_SEND_DEALER_CHIP_SUCC       --SVR通知赠送荷官筹码成功";
[0x2028] = "ServerCommand.SVR_CMD_SEND_DEALER_CHIP_FAIL       --SVR通知赠送荷官筹码失败";

--[Comment]
--SVR广播命令字段
[0x2015] = "ServerCommand.SVR_BCCMD_SEND_GIFT                 --SVR广播赠送礼物";
[0x2016] = "ServerCommand.SVR_BCCMD_SEND_CHIPS                --SVR广播赠送筹码";
[0x2008] = "ServerCommand.SVR_BCCMD_BET_SUCC                  --SVR广播下注成功信息";	
[0x200C] = "ServerCommand.SVR_BCCMD_BET_TURN_TO               --SVR广播轮到谁下注";
[0x2006] = "ServerCommand.SVR_BCCMD_STAND                     --SVR广播用户站起成功";
[0x2007] = "ServerCommand.SVR_BCCMD_GAME_START                --SVR广播游戏开始";
[0x2005] = "ServerCommand.SVR_BCCMD_SITDOWN                   --SVR广播坐下信息";
[0x2009] = "ServerCommand.SVR_BCCMD_CARD_FLOP                 --SVR广播翻三张";
[0x200A] = "ServerCommand.SVR_BCCMD_CARD_TRUN                 --SVR广播翻第四张";
[0x200B] = "ServerCommand.SVR_BCCMD_CARD_RIVER                --SVR广播翻第五张";
[0x200D] = "ServerCommand.SVR_BCCMD_CHIPSPOTS                 --SVR广播奖池信息";
[0x200E] = "ServerCommand.SVR_BCCMD_GAME_OVER                 --SVR广播游戏结束";
[0x2011] = "ServerCommand.SVR_BCCMD_CHATMSG                   --SVR广播发送消息";
[0x2012] = "ServerCommand.SVR_BCCMD_EMOTION                   --SVR广播发送表情";
[0x2014] = "ServerCommand.SVR_BCCMD_SHOW_HAND_CARD            --SVR广播亮出手牌";
[0x3001] = "ServerCommand.SVR_BCCMD_ALLIN                     --SVR广播All-In结束";
[0x2017] = "ServerCommand.SVR_BCCMD_SEND_HD                   --SVR广播互动道具";
[0x2019] = "ServerCommand.SVR_BCCMD_KITOUT                    --SVR广播踢人";
[0x201A] = "ServerCommand.SVR_BCCMD_ADD_FRIEND                --SVR广播用户加牌友";
[0x201B] = "ServerCommand.SVR_BCCMD_LEAVE_SEAT                --SVR广播用户暂离";
[0x2100] = "ServerCommand.SVR_BCCMD_SVR_SWITCH                --SVR广播SVR升级成功";
[0x2101] = "ServerCommand.SVR_BCCMD_SVR_STOP                  --SVR广播停服通知";
[0x2041] = "ServerCommand.SVR_BCCMD_BUY_LOTTO_SUCCEED         --SVR通知购买大乐透成功";
[0x2042] = "ServerCommand.SVR_BCCMD_BUY_LOTTO_FAIL	          --SVR通知购买大乐透失败";
[0x2051] = "ServerCommand.SVR_BCCMD_CHATMSG_NEW               --SVR广播发送消息(new)";

--[Comment]
--私人房
[0x2023] = "ServerCommand.SVR_BCCMD_TABLE_OWNER				     --广播私人房间房主";
[0x2024] = "ServerCommand.SERVER_CMD_BROADCAST_OWNER_LEAVE	    	--广播房主离开";
[0x2026] = "ServerCommand.SERVER_CMD_LOGOUT					    --用户登出";

--[Comment]
--多人锦标赛 
[0x7001] = "ServerCommand.SVR_BCCMD_BLIND_CHANGE_T		     --SVR广播盲注改变";
[0x7003] = "ServerCommand.SVR_BCCMD_MATCH_END_T			     --SVR广播比赛结束";
[0x7004] = "ServerCommand.SVR_BCCMD_ALL_RANKING_T		     --弃用,保留";
[0x7006] = "ServerCommand.SVR_BCCMD_TABLE_ID_T			     --SVR返回桌子ID";
[0x7009] = "ServerCommand.SVR_BCCMD_COUNT_DOWN_TIME_T	     --SVR返回比赛时间";
[0x700A] = "ServerCommand.SVR_BCCMD_SWITCH_TABLE_T		     --SVR广播开始换桌";
[0x700B] = "ServerCommand.SVR_BCCMD_SWITCH_TABLE_SUCC_T	     --SVR广播换桌成功";
[0x700C] = "ServerCommand.SVR_BCCMD_MATCH_START_T		     --SVR广播比赛开始";
[0x700D] = "ServerCommand.SVR_BCCMD_MATCH_CLOSE_T		     --SVR广播比赛即将关闭";
[0x700E] = "ServerCommand.SVR_BCCMD_MATCH_TIME_T		     --SVR通知比赛开始时间";
[0x7007] = "ServerCommand.SVR_CMD_USER_RANKING_T		     --SVR返回用户排名";
[0x7005] = "ServerCommand.SVR_CMD_USER_OUT_T			     --SVR返回用户出局";

--[Comment]
--单桌淘汰赛
[0x7103] = "ServerCommand.SVR_BCCMD_TABLE_ID_K                --SVR广播tableID";
[0x7101] = "ServerCommand.SVR_BCCMD_MATCH_START_K             --SVR广播比赛开始";
[0x7102] = "ServerCommand.SVR_BCCMD_MATCH_END_K               --SVR广播比赛结束";
[0x7106] = "ServerCommand.SVR_BCCMD_BLIND_CHANGE_K            --SVR广播盲注改变";
[0x7107] = "ServerCommand.SVR_BCCMD_ALL_RANKING_K             --SVR返回所有用户排名";
[0x7108] = "ServerCommand.SVR_BCCMD_MATCH_CLOSE_K             --SVR广播比赛即将关闭";
[0x7104] = "ServerCommand.SVR_CMD_USER_RANKING_K              --SVR返回用户排名";
[0x7105] = "ServerCommand.SVR_CMD_USER_OUT_K                  --SVR返回用户出局";
[0x7109] = "ServerCommand.SVR_CMD_MATCH_INFO_K                --SVR广播比赛信息";

--[Comment]
--喇叭server
[0x1002] = "ServerCommand.LB_SVR_CMD_SYSTEM                   --喇叭SVR系统广播";
[0x1003] = "ServerCommand.LB_SVR_CMD_SINGLE                   --喇叭SVR个人广播";
[0x2001] = "ServerCommand.LB_SVR_CMD_HEARTBEAT                --喇叭SVR心跳包";
[0x1001] = "ServerCommand.LB_SVR_TYPE_LEVEL_UP                --个人升级广播";
[0x1002] = "ServerCommand.LB_SVR_TYPE_GLORY_FINISH            --个人完成成就广播";
[0x1003] = "ServerCommand.LB_SVR_TYPE_TASK_FINISH             --个人完成任务广播";
[0x1004] = "ServerCommand.LB_SVR_TYPE_EXP                     --坐下加经验广播";
[0x1005] = "ServerCommand.LB_SVR_TYPE_LOTTERY                 --个人中奖广播";
[0x1006] = "ServerCommand.LB_SVR_TYPE_MESSAGE                 --个人有新消息";
[0x1007] = "ServerCommand.LB_SVR_TYPE_EDIT_CHIP	              --维护金币";
[0x1008] = "ServerCommand.LB_SVR_TYPE_MATCH_PROMPT            --比赛通知进场";
[0x1009] = "ServerCommand.LB_SVR_TYPE_INVITE_PLAY             --邀请打牌";
[0x100A] = "ServerCommand.LB_SVR_TYPE_GET_VIP                 --vip点亮";
[0x100B] = "ServerCommand.LB_SVR_TYPE_EDIT_SCORE              --维护积分";
[0x100C] = "ServerCommand.LB_SVR_TYPE_DELAY_PAY               --延迟发货";
[0x100D] = "ServerCommand.LB_SVR_TYPE_SUCCESS_PAY             --支付成功";
[0x1015] = "ServerCommand.LB_SVR_TYPE_SUCCESS_ACT             --活动完成";
[0x2001] = "ServerCommand.LB_SVR_TYPE_ALL_TIP                 --所有展示位提示";
[0x2002] = "ServerCommand.LB_SVR_TYPE_HEAD_TIP                --顶头提示";
[0x2003] = "ServerCommand.LB_SVR_TYPE_SLOT                    --老虎机大奖";
[0x2004] = "ServerCommand.LB_SVR_TYPE_ROOM_TIP                --房间提示";
[0x2005] = "ServerCommand.LB_SVR_TYPE_SMALL_LABA              --小喇叭消息";
[0x2006] = "ServerCommand.LB_SVR_TYPE_BIG_LABA                --大喇叭消息";
[0x2007] = "ServerCommand.LB_SVR_TYPE_LOTTO_REWARD            --大乐透中奖通知";
[0x2008] = "ServerCommand.LB_SVR_TYPE_LOTTO_POOL              --大乐透奖池通知";
[0x200A] = "ServerCommand.LB_SVR_TYPE_SLOT_REWARD             --老虎机牌型活动中奖通知 0x200C 卡拉币场";

--[Comment]
--David新增命令
[0x200B] = "ServerCommand.LB_SVR_TYPE_PUSH_MESSAGE	           -系统推送信息";
[0x9001] = "ServerCommand.LB_SVR_TYPE_DOUBLE_LOGIN             --重复登录";
[0x3001] = "ServerCommand.LB_SVR_TYPE_PLAYER_NUM               --当前玩家人数";
[0x1013] = "ServerCommand.LB_SVR_TYPE_DOSH_BOARD_MESSAGE       --doshboard消息";

--[Comment]
--移动(MB)专属Type
[0x10001] = "ServerCommand.LB_SVR_TYPE_MB_DISCOUNT		         --打折信息";
[0x10002] = "ServerCommand.LB_SVR_TYPE_MB_SYS_MSG 		         --移动设备活动消息 ";
[0x10003] = "ServerCommand.LB_SVR_TYPE_MB_ITEM_DISCOUNT          --详细打折信息";
[0x10004] = "ServerCommand.LB_SVR_TYPE_MB_USER_PAY               --用户充值";
[0x50001] = "ServerCommand.LB_SVR_TYPE_MB_DOLL_ACQUIRE_PROMPT    --用户获得玩偶提示";
[0x50002] = "ServerCommand.LB_SVR_TYPE_MB_SINGLE_MESSAGE  	     --后台通知消息，前端展示消息，不做其他用";
[0x50003] = "ServerCommand.LB_SVR_TYPE_MB_ACCEPT_RED_PACKS       --用户获得红包提示";
[0x50004] = "ServerCommand.LB_SVR_TYPE_MB_COMMON_MESSAGE_PROMPT  --公共弹框消息提示";

[0x300A]  = "ServerCommand.LB_SVR_TYPE_PUSH_MATCH_MESSAGE	     --系统推送进入比赛信息";

}