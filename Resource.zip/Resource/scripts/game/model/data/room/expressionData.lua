--[Comment]
--表情数据
ExpressionData = {};

ExpressionData.ctor = function(self)
end

ExpressionData.dtor = function(self)
end

ExpressionData.seatId         = 0;
ExpressionData.expressionType = 0;
ExpressionData.expressionId   = 0;
ExpressionData.minusMoney     = 0;
ExpressionData.totalMoney     = 0;