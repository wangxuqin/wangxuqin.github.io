--[Comment]
--请求坐下数据
RequestBuyInData = class();

RequestBuyInData.ctor = function(self)
end

RequestBuyInData.dtor = function(self)
end

RequestBuyInData.seatId     = 0;--座位ID
RequestBuyInData.buyinChips = 0;--买入筹码
