ActivityRankingVO = class();
ActivityRankingVO.ctor = function(self)
    self.m_rank   = 0; 
    self.m_uid    = 0; 
    self.m_name   = "";
    self.m_picUrl = "";
    self.m_number = "";
end

ActivityRankingVO.dtor = function(self)
end
