SngMttVO = class();

SngMttVO.ctor = function (self)

end
SngMttVO.dtor = function (self)

end


SngMttVO.ranking  = "0";
SngMttVO.distance = "0";
SngMttVO.inCome   = "0";
SngMttVO.chain    = 0;	--这个月的收益环比上涨还是下降  1:上涨 2：下降
SngMttVO.prize    = "";
SngMttVO.soc      = "";

SngMttVO.parseXML = function(self, obj)
    local sngMttVOData = new(SngMttVO);
	sngMttVOData.ranking=obj.rank;
	sngMttVOData.distance=obj.dits;
	sngMttVOData.inCome=obj.inCome;
	sngMttVOData.chain=uint(obj.chain);
	sngMttVOData.prize=obj.prize;
	sngMttVOData.soc=obj.soc;
	return sngMttVOData;
end

