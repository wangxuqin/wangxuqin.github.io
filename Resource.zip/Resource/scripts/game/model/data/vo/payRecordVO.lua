PayRecordVO = {};

PayRecordVO.appOrderId = ""; --facebook订单ID
PayRecordVO.buyMoney   = 0;	 --购买的筹码数
PayRecordVO.buyCoalaa  = 0;	 --购买的卡拉币数
PayRecordVO.detail     = ""; --支付的其他东西
PayRecordVO.money      = 0;	 --支付的facebook credit金额
PayRecordVO.buyTime    = nil;--下单时间
PayRecordVO.settleTime = nil;--发货时间
PayRecordVO.refundTime = nil;--退款时间
PayRecordVO.status     = ""; --订单状态，1表示下单，2表示已经发货，3表示退款


--original version-----------------------------------------------------------
--[[public function PayRecordVO(data:Object)
		{
			if(data)
			{
				if(data["appOrderId"])
				{
					this.appOrderId = data["appOrderId"];
				}
				if(data["buyMoney"] && !isNaN(data["buyMoney"] as Number))
				{
					this.buyMoney = Number(data["buyMoney"]);
				}
				if(data["buyCoalaa"] && !isNaN(data["buyCoalaa"] as Number))
				{
					this.buyCoalaa = Number(data["buyCoalaa"]);
				}
				if(data["money"] && !isNaN(data["money"] as Number))
				{
					this.money = Number(data["money"]);
				}
				if(data["buyTime"] && !isNaN(data["buyTime"] as Number))
				{
					this.buyTime = new Date();
					this.buyTime.time = Number(data["buyTime"]) * 1000;
				}
				if(data["settleTime"] && !isNaN(data["settleTime"] as Number))
				{
					this.settleTime = new Date();
					this.settleTime.time = Number(data["settleTime"]) * 1000;
				}
				if(data["refundTime"] && !isNaN(data["refundTime"] as Number))
				{
					this.refundTime = new Date();
					this.refundTime.time = Number(data["refundTime"]) * 1000;
				}
				if(data["status"])
				{
					this.status = data["status"];
				}
				if(data["detail"])
				{
					this.detail = data["detail"];
				}
			}
		}]]--
--original version-----------------------------------------------------------

function PayRecordVO(data)

	if data then
	
		if data["appOrderId"] ~= nil then
			PayRecordVO.appOrderId = data["appOrderId"];
		end

		if data["buyMoney"] ~= nil and type(data["settleTime"]) ~= "number" then		
			PayRecordVO.buyMoney = tonumber(data["buyMoney"]);
		end

		if data["buyCoalaa"] ~= nil and type(data["settleTime"]) ~= "number" then		
			PayRecordVO.buyCoalaa = tonumber(data["buyCoalaa"]);
		end

		if data["money"] ~= nil and type(data["money"]) ~= "number"	then
			PayRecordVO.money = tonumber(data["money"]);
		end
		if data["buyTime"] ~= nil and type(data["buyTime"]) ~= "number"	then	
			PayRecordVO.buyTime = new(Date);
			PayRecordVO.buyTime.time = tonumber(data["buyTime"]) * 1000;
		end

		if data["settleTime"] ~= nil and type(data["settleTime"]) ~= "number" then		
			PayRecordVO.settleTime = new(Date);
			PayRecordVO.settleTime.time = tonumber(data["settleTime"]) * 1000;
		end

		if data["refundTime"] ~= nil and type(data["settleTime"]) ~= "number" then		
			PayRecordVO.refundTime = new(Date);
			PayRecordVO.refundTime.time = tonumber(data["refundTime"]) * 1000;
		end

		if data["status"] ~= nil then 		
			PayRecordVO.status = data["status"];
		end

		if data["detail"] ~= nil then		
			PayRecordVO.detail = data["detail"];
		end
	end
end

