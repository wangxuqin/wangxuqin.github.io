ProductVO = class();
ProductVO.ctor = function(self)
end
ProductVO.dtor = function(self)
end

ProductVO.id                  = ""; -- TH_LOCAL:表示泰语本地支付，ID_LOCAL:代表印尼本地支付
ProductVO.localPay            = "";  --本地支付商品类型，chip:筹码，coalaa:卡拉币
ProductVO.localPayData        = nil; --本地支付方式，1：卡片支付，2：账号支付，-1：google支付
ProductVO.isSpecialLocalPay   = false;
ProductVO.isSmslocalPay       = false; --是否短信支付
ProductVO.smsLocalPayPhoneNum = "";  --短信支付手机号
ProductVO.localPayDis         = -1;   --本地支付打折
ProductVO.localPayPrice       = "";
ProductVO.localPayUnit        = "";
ProductVO.hasHotIcon          = false;--是否显示hot标志
ProductVO.hasNewIcon          = false;--是否显示new标志
ProductVO.pid                 = "";
ProductVO.displayName         = "";
ProductVO.name                = "";
ProductVO.price               = "";
ProductVO.hasOff              = false;
ProductVO.num                 = 0;
ProductVO.img                 = ""; --商品图片
ProductVO.desc                = "";
ProductVO.isExpire            = false;--本地支付是否支持破产优化
ProductVO.orderid             = "";--支付中心商品id

ProductVO.priceFormatter      = nil;
ProductVO.offFormatter        = nil;


--original version-----------------------------------------------------------
--[[public function fromXML(xml:XML):void
{
	id = xml.id[0];
	pid = xml.pid[0];
	displayName = xml.dname.length() == 0 ? xml.name[0] : xml.dname[0];
	name = xml.name[0];
	num = xml.num[0];
	desc = xml.desc[0];
	hasOff = (xml.st[0] == 1);
	price = xml.price[0];
	if(xml.hasOwnProperty("img"))
	{
		img = xml.img[0];
	}
	else
	{
		img = "";
	}
	//支付中心订单id nerochen 20150506
	if(xml.hasOwnProperty("oid"))
	{
		orderid = xml.oid[0];
	}
}

public function get formattedPrice():String
{
	if(priceFormatter)
	{
		return priceFormatter.apply(null, [this]);
	}
	return price;
}]]--
--original version-----------------------------------------------------------



ProductVO.fromXML = function(self, xml)
	ProductVO.id = xml.id[1];
	ProductVO.pid = xml.pid[1];

    if xml.dname.length() == 0 then
	    ProductVO.displayName = xml.name[1];
    else
        ProductVO.displayName = xml.dname[1];
    end

	ProductVO.name = xml.name[1];
	ProductVO.num = xml.num[1];
	ProductVO.desc = xml.desc[1];

    if xml.st[0] == 1 then
	    ProductVO.hasOff = true;
    else
        ProductVO.hasOff = false;
    end

	ProductVO.price = xml.price[1];

	if xml.hasOwnProperty("img") then	
		ProductVO.img = xml.img[1];	
	else	
		ProductVO.img = "";
	end

	--支付中心订单id nerochen 20150506
	if xml.hasOwnProperty("oid") then
		ProductVO.orderid = xml.oid[1];
	end
end

--[[public function get formattedPrice() = ""
{
	if (priceFormatter)
	{
		return priceFormatter.apply(null, [this]);
	}
	return price;
}]]--






