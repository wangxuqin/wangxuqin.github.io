MessageVO = class();
MessageVO.ctor = function()
end

MessageVO.dtor = function()
end

MessageVO.id          = "";
MessageVO.message     = "";
MessageVO.date        = nil;
MessageVO.img         = "";
MessageVO.hasReaded   = false;
MessageVO.types        = "";
MessageVO.dollId      = 0;
MessageVO.UserId      = 0;
MessageVO.flag        = false;
MessageVO.messageType = "";


