TaskVO = class();

TaskVO.STATUS_UNDER_WAY             = 0;
TaskVO.STATUS_CAN_REWARD            = 1;
TaskVO.STATUS_FINISHED              = 2;
TaskVO.ID_UPGRATE_AWARDS_ITEM       = 10000;

TaskVO.ctor = function (self)
    self.m_id            = 0;
    self.m_name          = "";
    self.m_describe      = "";      --任务内容描述
    self.m_reward        = "";      --任务奖励描述
    self.m_progress      = 0;       --当前进度
    self.m_target        = 0;       --总需求
    self.m_status        = 0;       --任务状态
    self.m_special       = 0;       --置顶任务的倍数
    self.m_iconUrl       = "";
    self.m_totalProgress = 0;       --任务总进度（用于任务链）
    self.m_canGet        = false;   --等级讲咯是否可以领奖
    self.m_post          = "";      --等级奖励领奖接口
    self.m_isLevelTask   = false;   --是不是等级奖励
end

TaskVO.dtor = function (self)
end

TaskVO.parse = function(self, value)
	self.m_id       = value["id"];
	self.m_name     = value["name"];
	self.m_describe = value["desc"];
	self.m_reward   = value["rewardDesc"];
	self.m_target   = value["target"];
	self.m_status   = value["status"];
    self.m_special  = value["special"];
	self.m_iconUrl  = value["url"];
    self.m_canGet   = (value["canGet"] == 1) and true or false;
    self.m_status   = self.m_canGet and self.STATUS_CAN_REWARD or self.STATUS_UNDER_WAY
	self.m_post     = value["post"];
end

TaskVO.compareStatus = function(self, taskVO1, taskVO2)
	local temp1 = self:translateStatus(taskVO1.status);
	local temp2 = self:translateStatus(taskVO2.status);
	return temp1 > temp2;	
end

TaskVO.translateStatus = function(self, status)
    local ret = 0;
    local statusTemp = status;
    if statusTemp == self.STATUS_CAN_REWARD then
        ret = -1;
    elseif statusTemp == self.STATUS_FINISHED then
        ret = 1;
    elseif statusTemp == self.STATUS_UNDER_WAY then
        ret = 0;
    end
    return ret;
end