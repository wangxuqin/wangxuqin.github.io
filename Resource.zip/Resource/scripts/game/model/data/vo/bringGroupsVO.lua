BringGroupsVO = class();

BringGroupsVO.ctor = function(self)
end

BringGroupsVO.dtor = function(self)
end

BringGroupsVO.setId       = 0;
--[Comment]
--最小携带 
BringGroupsVO.minb        = 0;
--[Comment]
--最大携带 
BringGroupsVO.maxb        = 0;
--[Comment]
--小盲注 
BringGroupsVO.sb          = 0;
--[Comment]
--大盲注 
BringGroupsVO.bb          = 0;
--[Comment]
--是否有朋友在玩 
BringGroupsVO.friendsFlag = 0;
BringGroupsVO.friends     = {};
--[Comment]
--是否是快速场 
BringGroupsVO.quickFlag   = 1;
--[Comment]
--是中级场还是初级场 
BringGroupsVO.field       = 0;
--[Comment]
--几人桌 
BringGroupsVO.maxPlayer   = 0;



