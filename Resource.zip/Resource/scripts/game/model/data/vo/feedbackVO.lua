FeedbackVO = class();
FeedbackVO.ctor = function(self, data)
    if data then	
	    if data["content"] then
	    	FeedbackVO.userFeedback = data["content"];
	    end

	    if data["mtime"] and type(data["mtime"]) ~= "number" then    
		    FeedbackVO.sendDate = new(Date);
		    FeedbackVO.sendDate.time = tonumber(data["mtime"]) * 1000;
	    end

	    if data["answer"] then
		    FeedbackVO.adminReply = data["answer"];
	    end

	    if data["atime"] and type(data["atime"]) ~= "number" and data["atime"] ~= "0" then
		    FeedbackVO.replyDate = new(Date);
		    FeedbackVO.replyDate.time = tonumber(data["atime"]) * 1000;
	    end
	end
end

FeedbackVO.dtor = function(self)
end

FeedbackVO.userFeedback = "";	--用户反馈
FeedbackVO.sendDate     = nil;	--反馈时间
FeedbackVO.adminReply   = "";	--管理员回复
FeedbackVO.replyDate    = nil;	--回复时间


FeedbackVO.getHasReply = function(self)
	return FeedbackVO.replyDate ~= nil;
end


FeedbackVO.getStatus = function(self)
	return FeedbackVO.replyDate == nil and STR_SETTING_FEEDBACK_MSG_STATUS[1] or STR_SETTING_FEEDBACK_MSG_STATUS[2];
end

--original version-----------------------------------------------------------
--[[public function FeedbackVO(data:Object = null)
{
	if(data)
	{
		if(data["content"])
		{
			userFeedback = data["content"];
		end
		if(data["mtime"] && !isNaN(data["mtime"]))
		{
			sendDate = new Date();
			sendDate.time = Number(data["mtime"]) * 1000;
		end
		if(data["answer"])
		{
			adminReply = data["answer"];
		end
		if(data["atime"] && !isNaN(data["atime"]) && data["atime"] != "0")
		{
			replyDate = new Date();
			replyDate.time = Number(data["atime"]) * 1000;
		end
	end
end

public function get hasReply():Boolean
{
	return replyDate != null;
end

public function get status():String
{
	return replyDate ? Localization.getArray("SETTING.FEEDBACK_MSG_STATUS")[1].getText() : Localization.getArray("SETTING.FEEDBACK_MSG_STATUS")[0].getText();
end]]--

--original version-----------------------------------------------------------