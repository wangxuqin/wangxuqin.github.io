TournamentUserVO = class();

TournamentUserVO.ctor = function (self)

end

TournamentUserVO.dtor = function (self)

end

TournamentUserVO.rank   = 0;
TournamentUserVO.chip   = 0;
TournamentUserVO.uid    = 0;
TournamentUserVO.tid    = 0;
TournamentUserVO.name   = "";
TournamentUserVO.picUrl = "";

TournamentUserVO.parseXML = function(self, xml, index)
	local  tournamentUserVO = new(TournamentUserVO);
	tournamentUserVO.rank = index + 1;
    if xml["cp"] ~= nil then
	    tournamentUserVO.chip = tonumber(xml["cp"]);--当前排名数据
    end
	tournamentUserVO.uid    = tonumber(xml["uid"]);
	tournamentUserVO.tid    = tonumber(xml["tid"]);
	tournamentUserVO.name   = tostring(xml["un"]);
	tournamentUserVO.picUrl = tostring(xml["pic"]);
	
	return tournamentUserVO;
end