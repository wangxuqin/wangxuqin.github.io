MTTListVO = class();

MTTListVO.ctor = function (self)

end

MTTListVO.dtor = function (self)

end

--[Comment]
--状态 -1-已结束 0-未报名 1-进行中 2已报名
MTTListVO.status          = 0;
--赛事名称
MTTListVO.tittle          = "";
--开赛时间
MTTListVO.starTime        = 0;
--参赛人数
MTTListVO.joinNum         = 0;
--参赛费用
MTTListVO.joinFee         = 0;
--赛事奖励
MTTListVO.reward          = "";
--赛事类型 0-日赛 1-周赛 2-月赛
MTTListVO.type            = 0;
--是否支持rebuy
MTTListVO.isSupportRebuy  = false;
--是否支持addon
MTTListVO.isSupportAddon  = false;
--报名方式 0-免费 1-筹码 2-积分 3-门票 
MTTListVO.signType        = 0;
--玩家集合
MTTListVO.playerArr       = {};
--是否是推荐场
MTTListVO.isSuggest       = false;
--ip
MTTListVO.ip              = "";
--port
MTTListVO.port            = "";
--剩余可进场时间	
MTTListVO.remainTime      = 0;
--剩余进场时间 
MTTListVO.remainStartTime = 0;
--详细比赛奖励 	
MTTListVO.drew            = "";


--original version-----------------------------------------------------------
--[[public static function parseData(value:Object):MTTListVO
		{
			var vo:MTTListVO = new MTTListVO();
			for(var keyValue:String in value)
			{
				if(vo.hasOwnProperty(keyValue))
				{
					vo[keyValue] = value[keyValue];
				}
			}
			return vo;
		}]]--
--original version-----------------------------------------------------------

function parseData(value)
	local vo = new (MTTListVO);
    local keyValue = "";

	for i,v in ipairs(value) do	
		if vo.hasOwnProperty(keyValue) then	
			vo[keyValue] = value[keyValue];
		end
	end

	return vo;
end

