ActivityVO = class();
ActivityVO.ctor = function(self)
    self.m_id           = 0;	--活动ID
    self.m_img          = "";	--图片地址
    self.m_bimg         = "";	--大图片地址
    self.m_title        = "";	--活动标题
    self.m_desc         = "";	--活动描述
    self.m_time         = "";	--活动时间
    self.m_plan         = "";	--是否有进度信息
    self.m_status       = "";	--活动状态  0表示用户未参加活动，1表示用户正在参与活动，2表示用户已经完成了活动但是没有领取奖励，3表示已经领取了奖励
    self.m_count        = 0;	--用户已经完成的进度(要活动xml的plan为1有意义)
    self.m_target       = 0;	--目标进度(要活动xml的plan为1有意义)
    self.m_win          = "";	--win为1时表示需要弹出页面，页面的url就是下面的url地址(记得要把uid、mtkey、skey这些POST传过来),
								--win为0时表示直接领取奖励，领取的接口就是url的地址(记得要把uid、mtkey、skey这些POST传过来)。接口会把文字返回给客户端，客户端需要做统一展示
    self.m_url          = "";
    self.m_show         = "";	--1表示显示在首页 0表示不显示在首页
    self.m_width        = 0;
    self.m_height       = 0;

    self.m_isSpecial    = false;--是否为特殊活动
    self.m_specialProc  = nil;  --特殊活动回调,签名为 function(isInMain = false):void，在首页或活动页面点击时调用
    self.m_iconFactory  = nil;  --特殊活动的图标工厂
end

ActivityVO.dtor = function(self)
end


ActivityVO.getPercent = function(self)
    local ret = 0;
	if self.m_plan == "1" and tonumber(self.m_target) ~= nil and tonumber(self.m_target) > 0 then
		ret = math.floor((count * 100 / target) + 0.5);
	else
		ret = 0;
	end
    return ret;
end
		
ActivityVO.isShowInManPagem = function(self)
	return self.m_show == "1";
end
		
ActivityVO.setShowInManPage = function(self, val)
	if val then
		self.m_show = "1";
	else
		self.m_show = "0";
	end
end