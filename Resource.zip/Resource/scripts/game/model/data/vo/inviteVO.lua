InviteVO = class()
InviteVO.ctor = function(self)
end

InviteVO.dtor = function(self)
end

InviteVO.id            = "";
InviteVO.title         = "";
InviteVO.desc          = "";
InviteVO.inviteService = nil;
InviteVO.imageTexture  = nil;

