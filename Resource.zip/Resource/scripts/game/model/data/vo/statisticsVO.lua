StatisticsVO = class();
StatisticsVO.ctor = function(self)
    self.m_title    = "";
    self.m_times    = "0";
    self.m_progress = "0.0";
end

StatisticsVO.dtor = function(self)
end