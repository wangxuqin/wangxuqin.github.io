LoginRewardVO = {};
LoginRewardVO.date              = 0;
LoginRewardVO.month             = 0;
LoginRewardVO.year              = 0;
LoginRewardVO.monthDays         = 0;
LoginRewardVO.loginDays         = 0;
LoginRewardVO.todayIndex        = 0;
LoginRewardVO.isExtraRewardDay  = false;
LoginRewardVO.isTodayFirstLogin = false;
LoginRewardVO.hasActPush        = false;
LoginRewardVO.actPushMessage    = "";
LoginRewardVO.buttonText        = "";
LoginRewardVO.buttonCode        = 0;

function parse(value)
	LoginRewardVO.date = value["date"];
	LoginRewardVO.month = value["month"];
	LoginRewardVO.year = value["year"];
	LoginRewardVO.monthDays = value["long"];

	local desc = {};
    desc = value["desc"];

    if desc then
	    LoginRewardVO.loginDays = desc.length;
    else
        LoginRewardVO.loginDays = 0; 
    end

	LoginRewardVO.todayIndex = getLoginRewardIndex(LoginRewardVO.loginDays);

	if LoginRewardVO.loginDays == LoginRewardVO.monthDays or LoginRewardVO.loginDays % 5 == 0 then
        LoginRewardVO.isExtraRewardDay = true;
    end
    
	if value["ret"] == 1 then
        LoginRewardVO.isTodayFirstLogin = true;
    end

    if value["actPushMessage"] and value["actPushMessage"] ~= "" then
        LoginRewardVO.hasActPush = true;
    end

	LoginRewardVO.actPushMessage = value["actPushMessage"];
	LoginRewardVO.buttonText = value["actPushBtnText"];
	LoginRewardVO.buttonCode = value["actPushBtnCode"];	
end

function getLoginRewardIndex(loginDays)
	local index = (loginDays - 1) / 5;
	index = math.max(0, math.min(index, 5));
	return index;
end


--original version-----------------------------------------------------------
--[[public function parse(value:Object):void
{
	date = value["date"];
	month = value["month"];
	year = value["year"];
	monthDays = value["long"];
	var desc:Array = value["desc"] as Array;
	loginDays = desc  ? desc.length : 0;
	todayIndex = getLoginRewardIndex(loginDays);
	isExtraRewardDay = loginDays == monthDays || loginDays % 5 == 0;
	isTodayFirstLogin = value["ret"] == 1;
	hasActPush = value["actPushMessage"] && value["actPushMessage"] != "";
	actPushMessage = value["actPushMessage"];
	buttonText = value["actPushBtnText"];
	buttonCode = value["actPushBtnCode"];
	
	CONFIG::DEBUG {
		loginDays = 21;
		todayIndex = getLoginRewardIndex(loginDays);
		isExtraRewardDay = loginDays == monthDays || loginDays % 5 == 0;
		isTodayFirstLogin = true;
		
		hasActPush = false;
		actPushMessage = "买一送你";
		buttonText = "马上参加";
		buttonCode = 2;
		
	}
}

public static function getLoginRewardIndex(loginDays = 0;) = 0;
{
	var index = 0; = (loginDays - 1) / 5;
	index = Math.max(0, Math.min(index, 5));
	return index;
}]]--
--original version-----------------------------------------------------------