GloryVO = class();

GloryVO.GLORY_TYPE_GOLD     = 0;
GloryVO.GLORY_TYPE_SILVER   = 1;
GloryVO.GLORY_TYPE_COPPE    = 2;

GloryVO.ctor = function(self)
    self.m_id                = "";
    self.m_title             = "";
    self.m_types             = 0;    --金制，银质还是铜质
    self.m_reward            = "";
    self.m_isLocked          = true; --是否已解锁
    self.m_description       = "";   --描述
    self.m_hasProgress       = false;--是否有进度条
    self.m_progress          = 0;    --进度
    self.m_hasClaimed        = false;--是否有奖励
    self.m_progressNum       = ""    --进度条数值
end

GloryVO.dtor = function(self)
end