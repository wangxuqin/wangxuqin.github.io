--[Comment]
--排行榜值对象
RankingVO = class();
RankingVO.ctor = function(self, data, types, index)
	self.m_index            = 0;    --排名
	self.m_uid              = "";   --用户ID
	self.m_chipTotal        = 0;	--筹码数
	self.m_siteid           = "";	--facebook id
	self.m_nick             = "";   --名字
	self.m_img              = "";	--头像图片
	self.m_levelName        = "";   --等级称号
	self.m_level            = 1;	--等级
	self.m_winPercent       = "";   --胜率
	self.m_upOrDown         = "";	--上升还是下降
	self.m_friendRanking    = 0;    --好友中的排名
	self.m_ach              = 0;    --玩家成就
	self.m_ip               = "";   -- ip,port用于玩家追踪
	self.m_port             = "";
	self.m_tid              = "";

    if data ~= nil then
        self.m_index        = index;
		self.m_uid          = data.uid;
        self.m_chipTotal    = self:__chipTotal();
        self.m_siteid       = data.siteid;
		self.m_nick         = data.nick;
		self.m_img          = data.img;
        self.m_levelName    = data.title or "";
		self.m_level        = data.level or 1;
		self.m_winPercent   = self:__winPercent(data, types);
	    self.m_upOrDown     = self:__upOrDown(data);
        self.m_ach          = data.ach or 0;
	    self.m_ip           = data.ip or "";
        self.m_port         = data.port or "";
		self.m_tid          = data.tid or "";
	end
end

RankingVO.__chipTotal = function(self, data, types)
    local chipTotal = 0;
    if types == 0 then
		chipTotal = (data.score ~= nil and data.score > 0) and data.score or data.money;
	elseif type == 1 then
		chipTotal = data.level;
	elseif type == 2 then
		chipTotal = data.ach;
	end
    return chipTotal;
end

RankingVO.__upOrDown = function(self, data)
    local upOrDown = 0;
    if data.stat == 1 then
		upOrDown = "up";
	else
        upOrDown = (data.stat == -1) and "down" or ""; 
    end
    return upOrDown;
end


RankingVO.__winPercent = function(self, data)
    local winPercent = "0";
    if data.win ~= nil and data.lose ~= nil then
        local total = (data.win + data.lose);
        if total ~= 0 then
		    winPercent = string.format("%d", data.win * 100 / (data.win + data.lose));
        else
            winPercent = "0";
        end
	end
	return winPercent;
 end