--[Comment]
--高级场的桌子数据定义 
AdvancedTableVO = class();
AdvancedTableVO.ctor = function(self)
end

AdvancedTableVO.dtor = function(self)
end

--[Comment]	
--table id 
AdvancedTableVO.tid   = 0;
AdvancedTableVO.ip    = 0;
AdvancedTableVO.port  = 0;
--[Comment]
--最大人数 
AdvancedTableVO.all   = 0;
--[Comment]
--在玩人数 
AdvancedTableVO.pc    = 0;
--[Comment]
--是否是快速场 
AdvancedTableVO.flag  = 0; 
--[Comment]
--坐下的人 
AdvancedTableVO.users = {};
--[Comment]
--最小携带 
AdvancedTableVO.minb  = 0;
--[Comment]
--最大携带 
AdvancedTableVO.maxb  = 0;
--[Comment]
--小盲注 
AdvancedTableVO.sb    = 0;
--[Comment]
--大盲注 
AdvancedTableVO.bb    = 0;

