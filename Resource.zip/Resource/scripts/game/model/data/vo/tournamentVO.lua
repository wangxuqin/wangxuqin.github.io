TournamentVO = class();

TournamentVO.ctor = function (self)
    
end

TournamentVO.dtor = function (self)
    
end

--[Comment]
--买入类型
TournamentVO.CHIP       = 1;
TournamentVO.BY         = 2;
TournamentVO.SCORE      = 3;
TournamentVO.CHIP_SCORE = 4;
TournamentVO.BY_SCORE   = 5;
TournamentVO.BY_CHIP    = 6;
TournamentVO.SCORE_CHIP = 7;
TournamentVO.SCORE_BY   = 8;
TournamentVO.CHIP_BY    = 9;
TournamentVO.INVITATION = 10;

--[Comment]
--是否为推送消息的报名
TournamentVO.push            = "false";
--[Comment]
--field id 		
TournamentVO.mid             = 0;
--[Comment]
-- 比赛开始时间戳， 与field id 标示比赛		
TournamentVO.time            = 0;
--[Comment]
--比赛奖励(比赛名称) 		
TournamentVO.reward          = "";
--[Comment]
--报名人数 		
TournamentVO.allNumber       = 0;
--[Comment]
--打折前买入 	
TournamentVO.oldBuyIn        = "";
--[Comment]
--打折后买入 		
TournamentVO.nowBuyIn        = "";
--[Comment]
--比赛是否也结束 		
TournamentVO.isEnd           = false;
--[Comment]
--是否已报名 		
TournamentVO.isApply         = false;
--[Comment]
-- 比赛开始		
TournamentVO.startTime       = "";
--[Comment]
--SVR IP 		
TournamentVO.ip              = "";
--[Comment]
--SVR port		
TournamentVO.port            = 0;
--[Comment]
--剩余可进场时间 		
TournamentVO.remainTime      = 0;
--[Comment]
--剩余进场时间 		
TournamentVO.remainStartTime = 0;
--[Comment]
--详细比赛奖励 		
TournamentVO.detailedReward  = "";
--[Comment]
--周赛月赛描述		
TournamentVO.describe    = "";
--[Comment]
--false: 普通竞标赛和可报名状态的周赛月赛,  true:不可报名状态的周赛月赛 		
TournamentVO.isWM        = false;
--[Comment]
--0:普通比赛, 1:周赛, 2:月赛 , 10:高级比赛		
TournamentVO.matchType   = 0;
--[Comment]
--比赛是否有结果 		
TournamentVO.hasResult   = true;
--[Comment]
--buyIn类型 0:免费,1:筹码,2:卡拉币,3:积分,4:筹码+积分,5:卡拉币+积分,6:卡拉币+筹码,7:积分+筹码,8:积分+卡拉币,9:筹码+卡拉币 10参赛券 	
TournamentVO.buyInType   = TournamentVO.CHIP;
--[Comment]
--筹码buyIn 		
TournamentVO.chipBuyIn   = 0;
--[Comment]
--卡拉比BuyIn 		
TournamentVO.coalaaBuyIn = 0;
--[Comment]
--积分BuyIn 		
TournamentVO.scoreBuyIn  = 0;
--[Comment]
--奖励图标ID
TournamentVO.iConId      = 1;
--[Comment]
--奖励图标
TournamentVO.img         = "";
--[Comment]
--置顶高亮<br>
--AS只处理高亮，置顶由PHP处理<br>
TournamentVO.isLight     = 0;
--[Comment]
--加一个数据索引，用于隔行换色
TournamentVO.index       = 0;

--[Comment]
--赛事状态 0-可报名 1-已报名 2-已结束 3-可观战 4-进场 
TournamentVO.status      = 0;

--[Comment]*********************************新增字段*******************************/

--[Comment]
--是否支持rebuy 
TournamentVO.isSupportRebuy  = false;
--[Comment]
--是否支持addon
TournamentVO.isSupportAddon  = false;
--[Comment]
--参赛券买入		
TournamentVO.ticketBuyIn     = 0;
--[Comment]
--已结束状态下的前三名信息
		
TournamentVO.playerArr = {};

TournamentVO.parseXML = function(self, xml)
	local tournamentData = new(TournamentVO);
	tournamentData.mid       = xml["mid"];
	tournamentData.time      = xml["time"];
	tournamentData.reward    = tostring(xml["pic"]);
	tournamentData.allNumber = xml["num"];
	tournamentData.oldBuyIn  = tostring(xml["obi"]);
	tournamentData.nowBuyIn  = tostring(xml["nbi"]);

    if xml["bm"] ~= 0 then
        tournamentData.isApply = true;
    else
        tournamentData.isApply = false;    
    end

    if xml["isend"] ~= 0 then
        tournamentData.isEnd = true;
    else
        tournamentData.isEnd = false;
    end

	tournamentData.startTime       = tostring(xml["st"]);
	tournamentData.ip              = tostring(xml["ip"]);
	tournamentData.port            = xml["port"];
	tournamentData.remainTime      = xml["rt"];--1000;
	tournamentData.remainStartTime = xml["rit"];--1000;
	tournamentData.detailedReward  = tostring(xml["drew"]);
	tournamentData.buyInType       = tonumber(xml["am"]);
	tournamentData.chipBuyIn       = tonumber(xml["chips"]);
	tournamentData.coalaaBuyIn     = tonumber(xml["coalaa"]);
	tournamentData.scoreBuyIn      = tonumber(xml["point"]);
	tournamentData.img             = tostring(xml["img"]);
    tournamentData.matchType = tonumber(xml["mtype"]);
    tournamentData.describe = tostring(xml["wmdec"]);

    if xml.hasOwnProperty("lig") and tonumber(xml["lig"]) == 1 then
        tournamentData.isLight  = true;
    else
        tournamentData.isLight  = false;
    end

    if xml.hasOwnProperty("iswm") and tonumber(xml["iswm"]) ~= 0 then
        tournamentData.isWM  = true;
    else
        tournamentData.isWM = false;
    end	

    if xml.hasOwnProperty("hasReuslt") and tonumber(xml["hasReuslt"]) == 1 then
        tournamentData.hasResult  = true;
    else
        tournamentData.hasResult = false;
    end
	
	setStatus(tournamentData);
	return tournamentData;
end

TournamentVO.parseObject = function(self, value)
	local tournamentData = new (TournamentVO);
	tournamentData.mid = value["mid"];
	tournamentData.time = value["time"];
	tournamentData.reward = tostring(value["pic"]);
	tournamentData.allNumber = value["num"];
	tournamentData.oldBuyIn = tostring(value["obi"]);
	tournamentData.nowBuyIn = tostring(value["nbi"]);
	tournamentData.isApply = value["bm"] ~= 0;
	tournamentData.isEnd = value["isend"] ~= 0;
	tournamentData.startTime = tostring(value["st"]);
	tournamentData.ip = tostring(value["ip"]);
	tournamentData.port = value["port"];
	tournamentData.remainTime = value["rt"]--1000;
	tournamentData.remainStartTime = value["rit"]--1000;
	tournamentData.detailedReward = tostring(value["drew"]);
	tournamentData.buyInType = tonumber(value["am"]);
	tournamentData.chipBuyIn = tonumber(value["chips"]);
	tournamentData.coalaaBuyIn = tonumber(value["coalaa"]);
	tournamentData.scoreBuyIn = tonumber(value["point"]);
	tournamentData.img = tostring(value["img"]);
    tournamentData.matchType = tonumber(value["mtype"]);
    tournamentData.describe = tostring(value["wmdec"]);
	tournamentData.isSupportRebuy = value["isSupportRebuy"];
	tournamentData.isSupportAddon = value["isSupportRebuy"];
	tournamentData.playerArr = value["playerArr"];

    if value.hasOwnProperty("lig") and tonumber(value["lig"]) == 1 then
        tournamentData.isLight  = true;
    else
        tournamentData.isLight = false;
    end

    if value.hasOwnProperty("iswm") and tonumber(value["iswm"]) ~= 0 then
        tournamentData.isWM  = true;
    else
        tournamentData.isWM = false;
    end

    if value.hasOwnProperty("hasReuslt") and tonumber(value["hasReuslt"]) == 1 then
        tournamentData.hasResult  = true;
    else
        tournamentData.hasResult = false;
    end
	
	setStatus(tournamentData);
	return tournamentData;
end

TournamentVO.setStatus = function(self, _data)
	--0-可报名 1-已报名 2-已结束 3-可观战 4-进场
	if not _data.isEnd and _data.remainStartTime > 0 and not _data.isApply then --比赛没开始没报名，显示报名按钮
		_data.status = 0;
	elseif not _data.isEnd and _data.remainTime > 0 and _data.isApply then --比赛没开始已报名，显示已报名按钮
		_data.status = 1;
	elseif _data.isEnd and _data.hasResult then --比赛结束有结果，显示结果按钮
		_data.status = 2;
	elseif _data.remainStartTime <= 0 then --比赛进行中，显示观战按钮
		_data.status = 3;
	elseif _data.remainTime <= 0 and _data.isApply then --可进场已报名，显示进场按钮
		_data.status = 4;
	elseif _data.remainTime <= 0 and not _data.isApply then --可进场没报名，显示报名按钮
		_data.status = 0;
	end
	
end

