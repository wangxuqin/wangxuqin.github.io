KnockoutVO = class();

KnockoutVO.ctor = function (self)

end

KnockoutVO.dtor = function (self)

end

--[Comment]
--作为比赛的唯一标识 
KnockoutVO.mid = -1;
--[Comment]
--比赛名称 
KnockoutVO.matchName = "";
--[Comment]
--服务费 
KnockoutVO.serviceCharge = 0;
--[Comment]
--买入费
KnockoutVO.applyCharge = 0;
--[Comment]
--开赛所需人数
KnockoutVO.needPlayer = 0;
--[Comment]
--当前类型淘汰赛总在玩人数(暂未使用)
KnockoutVO.playerCount = 0;
--[Comment]
--就近一桌已坐下人数 
KnockoutVO.sitNumber = 0;
--[Comment]
--比赛详细奖励 
KnockoutVO.detailedReward = {};
KnockoutVO.ip = "";
KnockoutVO.port = 0;


--original version-----------------------------------------------------------
--[[public static function parseXML(xml:XML):KnockoutVO
{
	var knockoutData:KnockoutVO = new KnockoutVO();
	knockoutData = new KnockoutVO();
	knockoutData.mid = int(xml["field"]);
	knockoutData.matchName = String(xml["name"]);
	knockoutData.serviceCharge = Number(xml["service_charge"]);
	knockoutData.applyCharge = Number(xml["min_buyin"]);
	knockoutData.needPlayer = Number(xml["max_num"]);
	knockoutData.playerCount = Number(xml["num"]);
	knockoutData.sitNumber = Number(xml["sit_num"]);
	knockoutData.ip = String(xml["ip"]);
	knockoutData.port = int(xml["port"]);
	
	--[Comment]
	--各名次奖励
	--买入*9 是总奖池
	--前三名按 50% ，30% 20%的奖池分配
	 */
	var totalPool = xml["min_buyin"] * xml["max_num"];
	knockoutData.detailedReward = new Array(3);
	knockoutData.detailedReward[0] = totalPool * 0.5;
	knockoutData.detailedReward[1] = totalPool * 0.3;
	knockoutData.detailedReward[2] = totalPool * 0.2;
	return knockoutData;
}]]--
--original version-----------------------------------------------------------


KnockoutVO.parseXML = function(self, xml)
	local knockoutData = new(KnockoutVO);
	knockoutData.mid = tonumber(xml["field"]);
	knockoutData.matchName = tostring(xml["name"]);
	knockoutData.serviceCharge = tonumber(xml["service_charge"]);
	knockoutData.applyCharge = tonumber(xml["min_buyin"]);
	knockoutData.needPlayer = tonumber(xml["max_num"]);
	knockoutData.playerCount = tonumber(xml["num"]);
	knockoutData.sitNumber = tonumber(xml["sit_num"]);
	knockoutData.ip = tostring(xml["ip"]);
	knockoutData.port = tonumber(xml["port"]);
	
	--[Comment]
	--各名次奖励
	--买入*9 是总奖池
	--前三名按 50% ，30% 20%的奖池分配
	local totalPool = xml["min_buyin"] * xml["max_num"];
	knockoutData.detailedReward = {};
	knockoutData.detailedReward[0] = totalPool * 0.5;
	knockoutData.detailedReward[1] = totalPool * 0.3;
	knockoutData.detailedReward[2] = totalPool * 0.2;
	return knockoutData;
end

