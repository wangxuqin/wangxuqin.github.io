NewKnockoutVO = class();
NewKnockoutVO.ctor = function (self)

end

NewKnockoutVO.dtor = function (self)

end
--[Comment]
--作为比赛的唯一标识 		
NewKnockoutVO.mid = -1;
--[Comment]
--比赛类型		
NewKnockoutVO.types =0;
--[Comment]
--买入费	
NewKnockoutVO.applyCharge = 0;
--[Comment]
--服务费
NewKnockoutVO.serviceCharge = 0;
--[Comment]
--买入积分
NewKnockoutVO.applyPoints = 0;
--[Comment]
--是否免费
NewKnockoutVO.isFree =false;
--[Comment]
--当前类型淘汰赛总在玩人数		
NewKnockoutVO.playerCount = 0;
--[Comment]
--比赛详细奖励 		
NewKnockoutVO.detailedReward = {};
NewKnockoutVO.ip = "";
NewKnockoutVO.port = 0;


--original version-----------------------------------------------------------
--[[public static function parseOBJ(obj:Object):NewKnockoutVO
		{
			var knockoutData:NewKnockoutVO = new NewKnockoutVO();
			knockoutData = new NewKnockoutVO();
			knockoutData.type = int(obj.ty);
			knockoutData.applyCharge = Number(obj.applyCharge);
			knockoutData.serviceCharge = Number(obj.serviceCharge);
			knockoutData.applyPoints = Number(obj.points);
			knockoutData.playerCount = Number(obj.num);
			knockoutData.ip = String(obj.ip);
			knockoutData.port = int(obj.port);
			
			var str:String=String(obj.prize);
			knockoutData.detailedReward=str.split("/");
			return knockoutData;
		}]]--
--original version-----------------------------------------------------------


function parseOBJ(obj)
	local knockoutData = new(NewKnockoutVO);
	knockoutData.types = tonumber(obj.ty);
	knockoutData.applyCharge = tonumber(obj.applyCharge);
	knockoutData.serviceCharge = tonumber(obj.serviceCharge);
	knockoutData.applyPoints = tonumber(obj.points);
	knockoutData.playerCount = tonumber(obj.num);
	knockoutData.ip = tostring(obj.ip);
	knockoutData.port = tonumber(obj.port);
	
	local str = tostring(obj.prize);
    for v in string.gfind(str,"(%a+)") do 
        table.insert(knockoutData.detailedReward,tostring(v))
    end
	return knockoutData;
end


