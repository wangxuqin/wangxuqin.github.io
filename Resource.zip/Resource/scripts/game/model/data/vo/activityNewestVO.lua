ActivityNewestVO = class();

ActivityNewestVO.ctor = function(self)
end

ActivityNewestVO.dtor = function(self)
end

ActivityNewestVO.actId            = 0;

ActivityNewestVO.imageUrl         = "";

ActivityNewestVO.buttonImageUrl   = "";

ActivityNewestVO.roomActImageUrl  = "";

ActivityNewestVO.arrowsUrl        = "";

ActivityNewestVO.dateText         = "";

ActivityNewestVO.ruleText         = "";

--[Comment]
--0: 根据 button_url 获取的文字展示
--1: playNow
--2: 进入主界面商城 		
ActivityNewestVO.buttonCode       = 0;

ActivityNewestVO.rewardUrl        = "";

ActivityNewestVO.rewardButtonText = "";

ActivityNewestVO.showRewardButton = true;

ActivityNewestVO.isAttended       = true;

ActivityNewestVO.title            = "";

ActivityNewestVO.rankFlag         = 0;

ActivityNewestVO.rankTitle        = "";

--[Comment]
--pb : 活动是否有进度条
--count : 活动当前进度
--target : 活动目标进度
	
ActivityNewestVO.pb                      = -1;

ActivityNewestVO.count                   = 0;

ActivityNewestVO.target                  = 0;
 
ActivityNewestVO.localPayTypeData        = nil;



--original version-----------------------------------------------------------
--[[public function parseObeject(value:Object):void
{
	actId = value["actid"];
	imageUrl = value["img1"];
	buttonImageUrl = value["img2"];
	if(value.hasOwnProperty("img4"))
	{
		roomActImageUrl = value["img4"];
	}
	arrowsUrl = value["img3"];
	dateText = value["time"];
	ruleText = value["cont"];
	rewardUrl = value["button_url"];
	rewardButtonText = value["button_cont"];
	showRewardButton = value["button"] == 1 || value["button"] == "1";
	buttonCode = value["button_code"];
	isAttended = value["attend"];
	title = value["title"];
	if (value.hasOwnProperty("rankFlag"))
	{
		rankFlag = value["rankFlag"];
	}
	if (value.hasOwnProperty("rankTitle"))
	{
		rankTitle = value["rankTitle"];
	}
	if(value.hasOwnProperty("pb"))
	{
		pb = value["pb"];
	}
	if(value.hasOwnProperty("count"))
	{
		count = value["count"];
	}
	if(value.hasOwnProperty("target"))
	{
		target = value["target"];
	}
	if(value.hasOwnProperty("local"))
	{
		localPayTypeData = value.local;
	}
}]]--
--original version-----------------------------------------------------------

ActivityNewestVO.parseObeject = function(self, value)

	self.actId          = value["actid"];
	self.imageUrl       = value["img1"];
	self.buttonImageUrl = value["img2"];

	if value.hasOwnProperty("img4") then	
		self.roomActImageUrl = value["img4"];
	end

	self.arrowsUrl      = value["img3"];
	self.dateText       = value["time"];
	self.ruleText       = value["cont"];
	self.rewardUrl      = value["button_url"];
	self.rewardButtonText = value["button_cont"];

    if value["button"] == 1 or value["button"] == "1" then
        self.showRewardButton = true;
    else
        self.showRewardButton = false;
    end

	self.buttonCode     = value["button_code"];
	self.isAttended     = value["attend"];
	self.title          = value["title"];

	if value.hasOwnProperty("rankFlag") then
		self.rankFlag   = value["rankFlag"];
	end

	if value.hasOwnProperty("rankTitle") then
		self.rankTitle  = value["rankTitle"];
	end

	if value.hasOwnProperty("pb") then	
		self.pb         = value["pb"];
	end

	if value.hasOwnProperty("count") then	
		self.count      = value["count"];
	end

	if value.hasOwnProperty("target") then	
		self.target     = value["target"];
	end

	if value.hasOwnProperty("local") then	
		self.localPayTypeData = value["local"]; --关键字冲突----------------------------------------------
	end
end
