ChipsProductVO = class(ProductVO)
ChipsProductVO.ctor = function(self)
end

ChipsProductVO.dtor = function(self)
end

ChipsProductVO.fromXML = function(self, xml)
    ProductVO.fromXML(self, xml);
end
