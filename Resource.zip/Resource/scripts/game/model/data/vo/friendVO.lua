FriendVO = class();
FriendVO.ctor = function(self)
end

FriendVO.dtor = function(self)
end

--[Comment]
--在玩玩家 	
FriendVO.STATUS_AT_PLAY  = 1;
--[Comment]
--在线玩家		
FriendVO.STATUS_ON_LINE  = 2;
--[Comment]
--离线玩家 		
FriendVO.STATUS_OFF_LINE = 3;
FriendVO.uid             = "";
FriendVO.name            = "";
--[Comment]
--是否是自己 		
FriendVO.isSelf = false;
--[Comment]
--平台id(如:facebook id ) 		
FriendVO.pid             = "";
--[Comment]
--筹码数 		
FriendVO.chip            = 0;
--[Comment]
--经验值 		
FriendVO.experience      = 0;
--[Comment]
--成就值 		
FriendVO.achievement     = 0;
--[Comment]
--当前状态: 在玩,在线,离线 		
FriendVO.status          = 0;
--[Comment]
--vip等级  0为非vip 		
FriendVO.vip             = 0;
--[Comment]
--是否为平台好友 		
FriendVO.isPlatFriend    = false;
--[Comment]
--等级	
FriendVO.level           = 0;
--[Comment]
--胜利场数 		
FriendVO.win             = 0;
--[Comment]
--失败场数 		
FriendVO.lose            = 0;
--[Comment]
--家乡 		
FriendVO.hometown        = "";
--[Comment]
--性别 		
FriendVO.sex             = "";
--[Comment]
--头像地址		
FriendVO.image           = "";
--[Comment]
--离线天数 		
FriendVO.offLineDays     = 0;
--[Comment]
--房间名称 		
FriendVO.tableName       = "";
--[Comment]
--所在房间tid 		
FriendVO.tid             = 0;
--[Comment]
--所在房间ip 		
FriendVO.ip              = "";
--[Comment]
--所在房间端口 		
FriendVO.port            = 0;
--[Comment]
--所在房间类型		
FriendVO.tableType       = 0;
--[Comment]
--所在房间级别		
FriendVO.tableLevel      = 0;
--[Comment]
--所在房间标志 		
FriendVO.roomFlag        = 0;
--[Comment]
--所在房间小盲 		
FriendVO.smallBlind      = 0;
--[Comment]
--等级称号 		
FriendVO.title           = "";
--[Comment]
--好友是否被选中	
FriendVO.flag            =false;
--[Comment]
--胜率		
FriendVO.winPercent      = 0;
--[Comment]
--是否已被邀请或召回	
FriendVO.isOperate       = false;
--[Comment]
--是否在移动设备上登陆
FriendVO.isMobile        = false;
--[Comment]
--可赠送筹码额度	
FriendVO.sendChipLimit   = 0;
--[Comment]
--可赠送筹码次数	
FriendVO.sendChipTimes   = 0;

FriendVO.parse = function(self, item)
	self.uid = item.uid;
	self.name = item.nick;
	self.pid = item.siteid;
	self.chip = item.money;
	self.experience = item.exp;
	self.achievement = item.ach;
	self.status = item.type;---关键字冲突
	self.vip = item.vip;
	if item.fri ~= 2 then
        self.isPlatFriend = true;
    else
        self.isPlatFriend =  false;
    end             
	self.level = item.level;
	self.title = item.title;
	self.win = item.win;
	self.lose = item.lose;
	self.hometown = item.ht;
	self.sex = item.sex;
	self.image = item.img;
	self.offLineDays = 0;
	if self.status == self.STATUS_AT_PLAY then
		self.tid = item.tid;
		self.tableName = item.tn;
		self.ip = item.ip;
		self.port = item.port;
		self.tableType = item.tab;
		self.tableLevel = item.fld;
		self.roomFlag = item.flag;
		self.smallBlind = item.sb;
	elseif self.status == self.STATUS_OFF_LINE then
		self.offLineDays = item.od;
	end
	self.isSelf = false;
	if item.mobile == 1 then
        self.isMobile = true;
    else
        self.isMobile =  false;
    end
	self.sendChipLimit = item.sdchip;
	self.sendChipTimes = item.send;
end

FriendVO.isSupportTable = function (self)
	if self.status ~= self.STATUS_AT_PLAY  then
		return false;
	end
    local isSupport = false;
	if self.tableType == LoginSuccData.ROOM_TYPE_PROFESSIONAL and STR_COMMON_IS_SUPPORT_PROFESSIONAL == "0" then
		isSupport = false;
	elseif self.tableType == LoginSuccData.ROOM_TYPE_TOURNAMENT and STR_COMMON_IS_SUPPORT_PROFESSIONAL == "0" then
		isSupport = false;
	elseif self.tableType == LoginSuccData.ROOM_TYPE_KNOCKOUT and STR_COMMON_IS_SUPPORT_PROFESSIONAL == "0" then
		isSupport = false;
	elseif self.tableType == LoginSuccData.ROOM_TYPE_PROMOTION and STR_COMMON_IS_SUPPORT_PROFESSIONAL == "0" then
		isSupport = false;
	--elseif self.tableType == LoginSuccData.ROOM_TYPE_NORMAL and RoomFlagVO.isSupportFlag(self.roomFlag) then
		--isSupport = true;
    end
	return isSupport;
end



--original version-----------------------------------------------------------
--[[public function parse(item:Object):void
		{
			uid = item.uid;
			name = item.nick;
			pid = item.siteid;
			chip = item.money;
			experience = item.exp;
			achievement = item.ach;
			status = item.type;
			vip = item.vip;
			isPlatFriend = item.fri != 2;
			level = item.level;
			title = item.title;
			win = item.win;
			lose = item.lose;
			hometown = item.ht;
			sex = item.sex;
			image = item.img;
			offLineDays = 0;
			if(status == STATUS_AT_PLAY)
			{
				tid = item.tid;
				tableName = item.tn;
				ip = item.ip;
				port = item.port;
				tableType = item.tab;
				tableLevel = item.fld;
				roomFlag = item.flag;
				smallBlind = item.sb;
			}
			else if(status == STATUS_OFF_LINE)
			{
				offLineDays = item.od;
			}
			
			isSelf = false;
			isMobile = item.mobile == 1;
			sendChipLimit = item.sdchip;
			sendChipTimes = item.send;
		}
		


public function toRankingVO(rankingVO = null):RankingVO
{
	if(!rankingVO)
	{
		var rankingVO:RankingVO = new RankingVO(null);
	}
	
	rankingVO.uid = this.uid;
	rankingVO.chipTotal = this.chip;
	rankingVO.siteid = this.pid;
	rankingVO.nick = this.name;
	rankingVO.img = this.image;
	rankingVO.level = this.level;
	rankingVO.levelName = this.title;
	rankingVO.winPercent = (this.win + this.lose) != 0 ? int(this.win * 100 /(this.win + this.lose)) + "" : "0";
	return rankingVO;
}]]--

--original version-----------------------------------------------------------




--[[public function get isSupportTable() = false
{
	var isSupport = false = false;
	if(status != STATUS_AT_PLAY)
	{
		return false;
	}
	if(tableType == LoginSuccData.ROOM_TYPE_PROFESSIONAL && Localization.getText("COMMON.IS_SUPPORT_PROFESSIONAL") == "0")
	{
		isSupport = false;
	}
	else if(tableType == LoginSuccData.ROOM_TYPE_TOURNAMENT && Localization.getText("COMMON.IS_SUPPORT_TOURNAMENT") == "0")
	{
		isSupport = false;
	}
	else if(tableType == LoginSuccData.ROOM_TYPE_KNOCKOUT && Localization.getText("COMMON.IS_SUPPORT_KNOCKOUT") == "0")
	{
		isSupport = false;
	}
	else if(tableType == LoginSuccData.ROOM_TYPE_PROMOTION && Localization.getText("COMMON.IS_SUPPORT_PROMOTION") == "0")
	{
		isSupport = false;
	}
	else if(tableType == LoginSuccData.ROOM_TYPE_NORMAL && RoomFlag.isSupportFlag(roomFlag))
	{
		isSupport = true;
	}
	
	return isSupport;
}]]--

--[[FriendVO.toRankingVO = function(self, rankingVO)
	if rankingVO ~= nil then 
		rankingVO = new(RankingVO);
	end
	
	rankingVO.uid = self.uid;
	rankingVO.chipTotal = self.chip;
	rankingVO.siteid = self.pid;
	rankingVO.nick = self.name;
	rankingVO.img = self.image;
	rankingVO.level = self.level;
	rankingVO.levelName = self.title;

    if (self.win + self.lose) ~= 0 then
        rankingVO.winPercent = tonumber(this.win);--100 /(this.win + this.lose)) + ""
    else
        rankingVO.winPercent = 0;
    end
	return rankingVO;
end]]--