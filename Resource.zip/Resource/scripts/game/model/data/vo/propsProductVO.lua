PropsProductVO = class(ProductVO);

PropsProductVO.ctor = function()
end

PropsProductVO.dtor = function()
end

PropsProductVO.description = nil;
PropsProductVO.ownInfo = nil;

PropsProductVO.fromXML = function(self, xml)
    ProductVO.fromXML(self, xml);
	--[[local descArr = String(xml.desc[0]).split("◆");
	if(descArr.length > 0)
	{
		description = "";
		for(var i:int = 0; i < descArr.length; i++)
		{
			if(StringKit.trim(descArr[i]))
			{
				if(description != "")
				{
					description += "\r";
				}
				description += "◆ " + StringKit.trim(descArr[i]);
			}
		}
	} 
    else 
    {
		description = "";
	}]]--
end
