SuperLottoVO            = class();

SuperLottoVO.ctor       = function(self)
	self.uid        = 0;
	self.photoUrl   = "";
	self.userName   = "";
	self.money      = 0;
	self.time       = "";
	self.cardType   = 0;
	self.percentage = 0;
	self.cards      = {};
end

SuperLottoVO.dtor       = function(self)
end

--[Comment]
--领奖-额外字段
SuperLottoVO.rewardId = 0;

SuperLottoVO.parse = function(self, value)
	self.uid      = value["uid"];
	self.photoUrl = value["url"];
	self.userName = value["name"];
	self.money    = value["lotteryMoney"];
    self.time     = string.gsub(tostring(value["time"])," ","\r");
	self.cardType = value["type"];

    if cardType == GameOverData.TYPE_FOUR_KIND then
        self.percentage = 10;
    elseif cardType == GameOverData.TYPE_STRAIGHT_FLUSH then
        self.percentage = 30;
    elseif cardType == GameOverData.TYPE_ROYAL_FLUSH then
        self.percentage = 80;
    end

    for i =1,5 do
        self.cards[i] = value["card"..tostring(i)];
    end

	--中奖名单列表没有以下字段
	self.rewardId = tonumber(value["id"]);
end


