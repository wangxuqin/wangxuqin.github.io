TraceFriendsVO = class();
TraceFriendsVO.ctor = function(self)
end

TraceFriendsVO.dtor = function(self)
end

--[Comment]
--好友头像
TraceFriendsVO.friendUrl  = "";
--[Comment]
--好友名字 
TraceFriendsVO.friendName = "";
--[Comment]
--好友等级 
TraceFriendsVO.friendLv   = 0;
--[Comment]
--房间id 
TraceFriendsVO.roomId     = 0;
--[Comment]
--几人桌 
TraceFriendsVO.maxNum     = 0;
--[Comment]
--当前在玩人数 

TraceFriendsVO.playingNum = 0;



