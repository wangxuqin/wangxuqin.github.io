CoalaaProductVO = class(ProductVO)

CoalaaProductVO.ctor = function(self)
end

CoalaaProductVO.dtor = function(self)
end

CoalaaProductVO.fromXML = function(self, xml)
    ProductVO.fromXML(self, xml);
end