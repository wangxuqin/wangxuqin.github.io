MainMenuIds = {};
MainMenuIds.HOME_PAGE      = 0;--主页
MainMenuIds.STORE_PAGE     = 1;--商城
MainMenuIds.RANKING_PAGE   = 2;--排行
MainMenuIds.SYSTEM_PAGE    = 3;--系统
MainMenuIds.FRIEND_PAGE    = 4;--任务
MainMenuIds.MESSAGE_PAGE   = 5;--消息
MainMenuIds.USER_INFO_PAGE = 6;--详情


