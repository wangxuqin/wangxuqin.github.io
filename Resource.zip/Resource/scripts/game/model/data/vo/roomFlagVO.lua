RoomFlagVO = class();

RoomFlagVO.ctor = function(self)
end

RoomFlagVO.dtor = function(self)
end


RoomFlagVO.flag = 0;
RoomFlagVO.text = "";
RoomFlagVO.describe = "";