GiftVO = class();
GiftVO.ctor = function(self, tab)
    if tab ~= nil then 
		self.id = tostring(tab.b);
		self.name = tostring(tab.c);
		self.expire = tonumber(tab.h);
		self.price = tonumber(tab.e);
		self.tag = tostring(tab.f);
		self["type"] = tostring(tab.d);
		self.itemTag = tostring(tab.g);
    end
end

GiftVO.dtor = function(self)
end

GiftVO.id       = "";--id
GiftVO.name     = "";--名称  如果字符不为空就表示赠送   如果为空表示自己购买
GiftVO.expire   = 0; --有效期
GiftVO.price    = 0; --价格
GiftVO.tag      = "";--类型：1 精品 2 礼物 3 节日 4 其他 5娱乐
GiftVO["type"]    = "";--购买方式： 1 游戏币购买 2卡拉币购买
GiftVO.itemTag  = "";--礼物特殊标记  0 空  1 new 2 hot
GiftVO.time     = 0; --获得时间
GiftVO.giftType = "" --礼物

GiftVO.isOwn = false;--是否拥有



--[[public function get fromName() = ""
{
	CONFIG::DEBUG
	{
		trace("name",name,"expire",expire,"type",type)
	}
	
	if(type=="4")
	{
		return Localization.getText("GIFT.GLORY_OBTAIN_GIFT");
	}else
	{
			if(name!="")
			{
				if(expire==0)
				{
					return Localization.getText("GIFT.GIFT_PAST_DUE");
				}else if(expire>0)
				{
					return Localization.getText("GIFT.PRESENT");
				}
				
			}else if(name=="")
			{
				if(expire>0)
				{
					return Localization.getText("GIFT.GIFT_BUY_BY_SELF");
				}else if(expire==0)
				{
					return Localization.getText("GIFT.GIFT_PAST_DUE");
				}
			}
	}
	return "";
	
}]]--


--original version-----------------------------------------------------------
--[[public function GiftVO(xml:XML = null)
		{
			if(xml)
			{
				id = xml.b;
				name = xml.c;
				expire = xml.h;
				price = xml.e;
				tag = xml.f;
				type = xml.d;
				itemTag = xml.g;
			}
		}
		
public function get fromName():String
{
	CONFIG::DEBUG
	{
		trace("name",name,"expire",expire,"type",type)
	}
	
	if(type=="4")
	{
		return Localization.getText("GIFT.GLORY_OBTAIN_GIFT");
	}else
	{
			if(name!="")
			{
				if(expire==0)
				{
					return Localization.getText("GIFT.GIFT_PAST_DUE");
				}else if(expire>0)
				{
					return Localization.getText("GIFT.PRESENT");
				}
				
			}else if(name=="")
			{
				if(expire>0)
				{
					return Localization.getText("GIFT.GIFT_BUY_BY_SELF");
				}else if(expire==0)
				{
					return Localization.getText("GIFT.GIFT_PAST_DUE");
				}
			}
	}
	return "";
	
}]]--
--original version-----------------------------------------------------------