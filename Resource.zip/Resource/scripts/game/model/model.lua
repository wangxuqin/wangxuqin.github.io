require("game/model/modelKeys");
require("game/model/data/room/basicRoomData");
require("game/model/data/room/chatData");
require("game/model/data/room/chatDataNews");
require("game/model/data/room/expressionData");
require("game/model/data/room/extraLoginInfoData");
require("game/model/data/room/gameOverData");
require("game/model/data/room/gameStartData");
require("game/model/data/room/hddjData");
require("game/model/data/room/loginSuccData");
require("game/model/data/room/matchUserOutData");
require("game/model/data/room/operationRequestData");
require("game/model/data/room/operationResultData");
require("game/model/data/room/operationTurnToData");
require("game/model/data/room/requestBuyInData");
require("game/model/data/room/requestLoginData");
require("game/model/data/room/sendChipsData");
require("game/model/data/room/sendGiftsData");
require("game/model/data/room/serverCommand");
require("game/model/data/room/showHandCardData");
require("game/model/data/room/tableIdData");
require("game/model/data/room/tablePublicCard");
require("game/model/data/room/tableUserData");
require("game/model/data/room/userCrashData");
require("game/model/data/room/userOutData");
require("game/model/data/room/userPlayGameData");
require("game/model/data/room/userRankingData");
require("game/model/data/room/userSitDownData");
require("game/model/data/room/userStandUpData");
require("game/model/data/room/newNormalHallData");

require("game/model/data/vo/productVO");
require("game/model/data/vo/activityNewestVO");
require("game/model/data/vo/activityRankingVO");
require("game/model/data/vo/activityVO");
require("game/model/data/vo/advancedTableVO");
require("game/model/data/vo/bringGroupsVO");
require("game/model/data/vo/chipsProductVO");
require("game/model/data/vo/coalaaProductVO");
require("game/model/data/vo/feedbackVO");
require("game/model/data/vo/friendVO");
require("game/model/data/vo/giftVO");
require("game/model/data/vo/gloryVO");
require("game/model/data/vo/inviteVO");
require("game/model/data/vo/knockoutVO");
require("game/model/data/vo/loginRewardVO");
require("game/model/data/vo/mainMenuIds");
require("game/model/data/vo/messageVO");
require("game/model/data/vo/mTTListVO");
require("game/model/data/vo/newKnockoutVO");
require("game/model/data/vo/payRecordVO");
require("game/model/data/vo/promotionVO");
require("game/model/data/vo/propsProductVO");
require("game/model/data/vo/rankingVO");
require("game/model/data/vo/roomFlagVO");
require("game/model/data/vo/sngMttVO");
require("game/model/data/vo/statisticsVO");
require("game/model/data/vo/superLottoVO");
require("game/model/data/vo/taskVO");
require("game/model/data/vo/tournamentUserVO");
require("game/model/data/vo/tournamentVO");
require("game/model/data/vo/traceFriendsVO");
--[Comment]
--统一数据模型[单例]
Model = {};
Model.TAG = "Model";
Model._dataPool = {};
Model._watcherPool = {};
Model._propertyWatcherPool = {};

--是否存在指定key的数据
Model.hasData = function(key)
    local ret = false;
    if key ~= nil then
        ret = (Model._dataPool[key] ~= nil);
    end
    return ret;
end

--[Commnet]
--获取数据
Model.getData = function(key)
    local ret = nil;
    if Model.hasData(key) then
        ret = Model._dataPool[key];
    end
    return ret;
end

--[Commnet]
--获取属性
Model.getProperty = function(key, property)
    local ret = nil;
    if Model.hasData(key) then
	    ret = Model._dataPool[key][property];
    end
    return ret;
end

--[Comment]
--设置数据
Model.setData = function(key, value)
	if key ~= nil then
		Model._dataPool[key] = value;
		Model.notifyDataChange(key);
	end
end

--[Comment]
--设置属性
Model.setProperty = function(key, property, value)
	if key ~= nil and property ~= nil then
		local obj = Model.getData(key) or {};
		obj[property] = value;
		Model.setData(key, obj);
		Model.notifyPropertyChange(key, property);
	end
end


--清除数据	
Model.clearData = function(key)
	if Model.hasData(key) then
		Model.setData(key, {});
	end
end

--[Comment]
--绑定数据观察
--triggeredImmediately 立即进行回调
Model.watchData = function(key, obj, onChange, triggeredImmediately)
    triggeredImmediately = (triggeredImmediately == nil) and true or triggeredImmediately;
    if key ~= nil and onChange ~= nil then
         Model._watcherPool[key] = Model._watcherPool[key] or {};
         Model._watcherPool[key][onChange] = {onChange, obj};
         if triggeredImmediately then
			local data = Model.getData(key);
            Model.__callBack(onChange, obj, data);
         end
    end
end

--[Comment]
--移除数据观察
Model.unwatchData = function(key, obj, onChange)
    if key ~= nil and onChange ~= nil then
         Model._watcherPool[key] = Model._watcherPool[key] or {};
         Model._watcherPool[key][onChange] = nil;
    end
end

--[Comment]
--绑定一组数据
Model.watchDataList = function(arr)
    if arr ~= nil then
        for i = 1, #arr do
            local key      = arr[i][1];
            local obj      = arr[i][2];
            local onChange = arr[i][3];
            local triggeredImmediately = arr[i][4]
            if type(onChange) ~= "function" then
                Log.e(Model.TAG, "onChange must be function!");
            else
                if key and obj and onChange then
                    Model.watchData(key, obj, onChange, triggeredImmediately);
                end
            end
        end
    end
end

--[Comment]
--移除一组数据绑定
Model.unwatchDataList = function(arr)
    if arr ~= nil then
        for i = 1, #arr do
            local key      = arr[i][1];
            local obj      = arr[i][2];
            local onChange = arr[i][3];
            if key and obj and onChange then
                Model.unwatchData(key, obj, onChange);
            end
        end
    end
end

--[Comment]
--移除数据观察
Model.unwatchData = function(key, obj, onChange)
    if key ~= nil and onChange ~= nil then
         Model._watcherPool[key] = Model._watcherPool[key] or {};
         Model._watcherPool[key][onChange] = nil;
    end
end




--[Comment]
--绑定属性观察
--triggeredImmediately 立即进行回调
Model.watchProperty = function(key, property, obj, onChange, triggeredImmediately)
    triggeredImmediately = (triggeredImmediately == nil) and true or triggeredImmediately;
    if key ~= nil and onChange ~= nil then
		 local id = Model.__propertyId(key, property);
         Model._propertyWatcherPool[id] = Model._propertyWatcherPool[id] or {};
         Model._propertyWatcherPool[id][onChange] = {onChange, obj};
         if triggeredImmediately then
			local data = Model.getData(key);
            local prop = (data ~= nil) and data[property] or nil;
            Model.__callBack(onChange, obj, prop);
         end
    end
end

--[Comment]
--移除属性观察
--triggeredImmediately 立即进行回调
Model.unwatchProperty = function(key, property, obj, onChange)
    if key ~= nil and onChange ~= nil then
         local id = Model.__propertyId(key, property);
         Model._propertyWatcherPool[id] = Model._propertyWatcherPool[id] or {};
         Model._propertyWatcherPool[id][onChange] = nil;
    end
end

--[Comment]
--绑定一组属性
Model.watchPropertyList = function(arr)
    if arr ~= nil then
        for i = 1, #arr do
            local key      = arr[i][1];
            local property = arr[i][2];
            local obj      = arr[i][3];
            local onChange = arr[i][4];
            local triggeredImmediately = arr[i][5]
            if type(onChange) ~= "function" then
                Log.e(Model.TAG, "onChange must be function!");
            else
                if key and property and obj and onChange then
                    Model.watchProperty(key, property, obj, onChange, triggeredImmediately);
                end
            end
        end
    end
end

--[Comment]
--移除一组属性绑定
Model.unwatchPropertyList = function(arr)
    if arr ~= nil then
        for i = 1, #arr do
            local key      = arr[i][1];
            local property = arr[i][2];
            local obj      = arr[i][3];
            local onChange = arr[i][4];
            if key and property and obj and onChange then
                Model.unwatchProperty(key, property, obj, onChange);
            end
        end
    end
end

Model.notifyDataChange = function(key)
	if Model.hasData(key) then
		local watchers = Model._watcherPool[key] or {};
		local data = Model.getData(key);
		for _,value in pairs(watchers) do
			local func = value[1];
			local obj  = value[2];
			Model.__callBack(func, obj, data);
		end
	end
end

Model.notifyPropertyChange = function(key, Property)
	if Model.hasData(key) and Property ~= nil then
		local id = Model.__propertyId(key, Property);	--创建属性Id;
		local watchers = Model._propertyWatcherPool[id] or {};
		local data = Model.getData(key)[Property];
		for _,value in pairs(watchers) do
			local func = value[1];
			local obj  = value[2];
			Model.__callBack(func, obj, data);
		end
	end
end

Model.__callBack = function(func, obj, data)
	if func ~= nil then
		if obj ~= nil then
			func(obj, data);
		else
			func(data);
		end
	end
end

Model.__propertyId = function(key, property)
	return key.."__"..property;
end