--[Comment]
--这里是存放事件的地方，事件需要与控制器，模块解耦。对于模块外的事件

--[Comment]
--控制相关事件
CommandEvent = {};
local index = ToolKit.getIndex();
CommandEvent.s_event = EventDispatcher.getInstance():getUserEvent();
CommandEvent.s_cmd = {
        DO_LOGIN                                = index();--点击登录按钮
		LOGIN_RESULT                            = index();--登录结果
		USER_LOGGED_IN                          = index();--用户登录成功，用户切换也会触发该事件
		USER_LOGGED_OUT                         = index();--用户登出成功
		LOGOUT                                  = index();--登出事件
		USER_LOGIN_RETRY                        = index();--用户重新登录
		
		--设置房间列表tab index
		PREPARE_SET_NORMAL_HALL_TAB_INDEX       = index();
		PREPARE_SET_MATCH_HALL_TAB_INDEX        = index();
		
		MODIFY_USER_INFO                        = index();--修改用户信息
		USER_STAT_TIME_SCOPE_CHANGE             = index();--统计时间范围选择改变
		SYSTEM_VOLUMN_CHANGE                    = index();--系统音量改变
		SYSTEM_SHOCK_SWITCH_CHANGE              = index();--振动开关改变
		SYSTEM_SLOT_MACHINES_SWITCH_CHANGE      = index();--老虎机开关改变
		SYSTEM_CLEAR_CACHE                      = index();--清除缓存
		SEND_USER_FEEDBACK                      = index();--发送用户反馈
		SYSTEM_MATCK_COUNT_SWITCH_CHANGE        = index();--牌型统计开关
		OPEN_CREATE_BY_ACCOUNT                  = index();--command to open create coalaa account page
		OPEN_ACCOUNT_BIND_POP_UP                = index();--打开账号绑定页面
		OPEN_MODIFY_PASSWORD                    = index();--edit password of a coalaa account
		OPEN_CREATE_ACCOUNT_TIP                 = index();--open create account tip
		CREATE_BY_ACCOUNT                       = index();--command to create a coalaa account
		MODIFY_ACCOUNT_PASSWORD                 = index();--command to reset account password
		FORGET_ACCOUNT_PASSWORD                 = index();--forget account password
		OPEN_SET_DEFAULT_ACCOUNT                = index();--open set default account popup
		SET_DEFAULT_ACCOUNT                     = index();--set default account
		
		--新手引导
		FIRST_LODE_POP_UP_TUTORIA_DIALOG        = index();--用户第一次登录弹出新手引导对话框
		USER_START_TUTORIA                      = index();--玩家开始新手教程
		USER_COMLETE_TUTORIA                    = index();--用户完成新手教程
		USER_QUIT_TUTORIA                       = index();--玩家退出新手教程
		USER_QUIT_TUTORIA_AND_CLEAN_ROOM        = index();--玩家退出新手教程清理房间
		TUTORIA_USER_NEXT_STRP                  = index();--玩家进入下一步
		TUTORIA_USER_CLICKED_DEALER             = index();--用户点击过荷官
		
		--大厅
		GET_ROOM_INFO_LIST                      = index();
		SORT_ROOM_INFO_LIST                     = index();
		FILTER_ROOM_INFO_LIST                   = index();
		SEARCH_ROOM_BY_ID                       = index();
		PREPARE_LOGIN_ROOM                      = index();--准备登录房间
		INVALID_ROOM_LIST_DATA                  = index();
		USER_CHIPS_CHANGE                       = index();--筹码变化
		
		--new 
		OPEN_USER_INFO_PAGE                     = index();--打开个人主页
		HIDE_USER_INFO_PAGE                     = index();--关闭个人主页
		
		--比赛大厅
		MATCH_HALL_REFRESH                      = index();	
		MATCH_HALL_TAB_CHANGE                   = index();
		MATCH_HALL_SHOW_TAB                     = index();
		MATCH_HALL_ENTER_ROOM                   = index();
		MATCH_HALL_TOURNAMENT_RESULT            = index();
		MATCH_HALL_WATCH_TOURNAMENT             = index();
		MATCH_HALL_TRACK_USER                   = index();
		MATCH_HALL_APPLY_TOURNAMENT             = index();
		
		--房间
		LEAVE_GAME_ROOM                         = index();--离开房间
		PLAY_CARD_OPERATION                     = index();--用户自己打牌操作
		USER_STAND_UP                           = index();--用户自己站起
		USER_BUY_IN                             = index();--用户买入
		USER_PLAY_SLOT                          = index();
		USER_CALCULATE_POKER                    = index();
		ROOM_CHAT_SEND_MESSAGE                  = index();--聊天信息
		ROOM_CHAT_SMALL_LABA                    = index();--小喇叭信息
		ROOM_CHAT_BIG_LABA                      = index();--大喇叭信息
		ROOM_CHAT_SEND_EXPRESSION               = index();
		ROOM_DOUBLE_LOGIN_ERROR                 = index();--重复登录
		ROOM_DETERMINE_ROOM_SOCKET              = index();--确定房间socket是否连接
		ROOM_SOCKET_CONNECTED_DETERMINED        = index();--确定房间socket已经连接
		ROOM_SOCKET_ERROR                       = index();--房间server错误
		ROOM_GET_USER_RANKING                   = index();--获取用户排名
		GET_USER_HDDJ_NUMBER                    = index();--获取互动道具次数
		ROOM_BROADCAST_SEND_HDDJ                = index();--广播发送互动道具
		ROOM_BROADCAST_ADD_FRIEND               = index();--广播添加好友
		ROOM_REQUEST_ADD_FRIEND                 = index();--php添加好友
		ROOM_REQUEST_BACK_SEAT                  = index();--请求回到座位
		ROOM_BROADCAST_SEND_CHIP                = index();--广播赠送筹码
		ROOM_BROADCAST_SEND_DEALER_CHIP         = index();--广播给荷官赠送筹码
		ROOM_GET_USER_PROPS                     = index();--请求用户道具信息
		ROOM_USE_EXP_CARD                       = index();--使用双倍经验卡
		ROOM_SET_MAX_AWARD                      = index();--上报赢得最大奖池
		ROOM_SET_BEST_POKER                     = index();--上报最佳手牌
		ROOM_SHOW_HAND_CARD                     = index();--亮出手牌
		ROOM_DEALER_CHANGE_CONFIRM              = index();--设置我的荷官
		SEND_DEALER_CHIP_FAIL                   = index();--赠送荷官筹码失败
		TOURNAMENT_SEND_EMAIL_DATA              = index();--锦标赛上报email、电话
		PRIVATE_ROOM_BLIND_DATA                 = index();--私人房筹码数据
		ROOM_LEFT_BOTTOM_MESSAGE_NOTICE         = index();--房间左下角消息通知
		ROOM_QUICK_CHAT                         = index();--切换到快捷聊天
		ROOM_QUICK_EXPRESSION                   = index();--切换到表情
--		OPEN_GAME_REVIEW_POP_UP                 = index();--牌局回顾
        BACK_TO_HALL                            = index();--快速设置中返回大厅
		
		--大乐透
		SUPER_LOTTO_AUTO_BUY                    = index(); --夺金岛请求自动买入
		SUPER_LOTTO_DELAY_AUTO_BUY              = index(); --夺金岛请求自动买入
		SUPER_LOTTO_BUY_NEXT                    = index(); --夺金岛请求买入下一局
		SUPER_LOTTO_CANCEL_AUTO_BUY             = index(); --夺金岛请求取消自动买入
		
		--邀请好友
		SEND_INVITE_FRIENDS_MESSAGE             = index();--邀请在线好友
		SEND_INVITE_OFFLINE_FRIENDS_MESSAGE     = index();--邀请不在线好友
		
		--用户破产
		GAME_USER_CRASH_FLAGE                   = index(); 
		USER_CASH_AND_BUY_CHIPS_SUCC            = index();--用户购买筹码成功
		
		--socket
		CLOSE_ROOM_SOCKET                       = index();
		
		--活动
		OPEN_ACTIVITY_RANKING                   = index();--弹出活动排行榜
		ENTER_SERIAL_NUM_EXCHANGE               = index();	
		
		--消息
		MESSAGE_DELETE                          = index();--删除消息
		MESSAGE_I_KNOW                          = index();--消息已读
		MESSAGE_POP_UP_OPENED                   = index();--打开消息页面
		MESSAGE_POP_UP_TOGGLE_CHANGE            = index();
		MESSAGE_SEND_DOLL                       = index();--消息已读
		DELETE_MESSAGE_BUTTON                   = index();--按钮删除
		MESSAGE_RED_POINT_ICON                  = index();--点击消息的红点
		NEW_DOSH_BOARD_MESSAGE_NOTICE           = index();--新的DOSH BOARD消息通知
		NEW_MESSAGE_NOTICE                      = index();--新的消息通知
		
		
		--系统
		CHECK_VERSION                           = index();--检查版本更新
		SYSTEM_SET_NEXT_ENTER_SUB_PAGE          = index();--设置下次进入页面时显示的子页面
		
		--商城
		STORE_MAKE_PURCHASE                     = index();--支付
		MONITOR_MONEY_BY_CHANGE                 = index();--监视筹码或者卡拉币变化
--		OPEN_STORE_POPUP                        = index();
		STORE_SELF_PROP_PAGE_JUMP_PROP_PAGE     = index();--商城页面跳转
		STORE_LOCAL_PAY_BUTTON_TRIGGERED        = index();--本地支付按钮点击
		STORE_LOCAL_PAY_PAGE_HIDE               = index();--关闭本地支付页面
		STORE_PAGE_LOAD_LOCALPAY                = index();--商城拉本地支付
		STORE_PAGE_ADD_STAGE_CHECK_LOAD         = index();--查看是否拉到商城
		STORE_MIMOPAY_PURCHASE_SUCCESSED        = index();--mimopay支付成功
		STORE_MIMOPAY_PURCHASE_ERROR            = index();--mimopay支付失败
		STORE_MIMOPAY_PURCHASE_FETAL_ERROR      = index();--mimopay支付失败
		STORE_MIMOPAY_PURCHASE_CANCELED         = index();--mimopay支付取消
		
		--礼物
		STORE_POPUP_TAB_CHANGE                  = index();
		OPEN_GIFT_POPUP                         = index();
		GIFT_BUY_FOR_SELF                       = index();
		GIFT_BUY_FOR_PERSON                     = index();
		GIFT_BUY_FOR_TABLE                      = index();
		GIFT_USE                                = index();
		QUICKLY_SALE_ALL_OVERDUE_GIFT           = index();--一键出售所有过期礼物
		SALE_OVERDUE_GIFT                       = index();--卖出过期礼物
		ROLL_COLLECT_REQUEST                    = index();--请求上报
		ROLL_COLLECT_UPDATAE_STATUS             = index();--跟新玩偶数据
		
		--礼物通知
		GIFT_NOTIFY_GIFT_FOR_TABLE              = index();
		GIFT_NOTIFY_GIFT_USED                   = index();
		
		-- feed 和 og
		SOCIAL_SHARE                            = index();
		SOCIAL_OG                               = index();
		
		--好友
		FRIEND_REQUEST_REFRESH                  = index();
		REQUEST_NEXT_STAND_UP                   = index();
		UPDATA_FRIENDS_OPERATE_LIST             = index();
		
		FACEBOOK_FEED                           = index();
		FACEBOOK_INVITE                         = index();
		FACEBOOK_INVITE_CODE                    = index();
		SHOW_USER_INFO_EDIT_POPUP               = index();
		FACEBOOK_OPEN_GRAPH                     = index();
		FACEBOOK_SEND_MESS_TO_FRIEND            = index();
		FACEBOOK_ACCOUNT_BINDING                = index();--facebook账户绑定
		FACEBOOK_ACCOUNT_BINDING_POP_UP_HIDE    = index();
		
		OPEN_FRIEND_POP_UP                      = index();--我的好友
		FRIEND_LIST_ITEM_CHANGE                 = index();--好友列表变化时间
		FRIEND_LIST_DELETE_BTN_CHANGE           = index();
		FRIEND_LIST_IS_NULL                     = index();--好友为空
		
		--单机游戏
		SINGLE_GAME_CAN_START_NEXT              = index();--可以开始下一轮游戏
		SINGLE_GAME_LEAVE_ROOM                  = index();--离开单机游戏
		USER_ENTER_SINGLE_GAME                  = index();--用户进入单机游戏
		SINGLE_GAME_USER_OPERATION              = index();--单机游戏用户操作
		SINGLE_GAME_NEXT_PLAYER_OPERATION       = index();--下个玩家操作
		SINGLE_GAME_GAME_OVER                   = index();--一局游戏结束
		SINGLE_GAME_OVER                        = index();--单机游戏结束
		SINGLE_GAME_ALL_ALL_IN                  = index();--所有人都allin
		SINGLE_GAME_USER_SELF_FOLD_CARD         = index();--玩家自己弃牌
		SINGLE_GAME_USER_SELF_OUT               = index();--玩家自己出局
		
		SINGLE_GAME_DIALOG_JOIN_NEXT            = index();
		SINGLE_GAME_DIALOG_RETRY                = index();
		SINGLE_GAME_DIALOG_GO_BACK              = index();
		
		--成就
		OPEN_GLORY_POP_UP                       = index();--打开成就弹框
		GLORY_RECEIVE_REWARD                    = index();--领取成就奖励
		GLORY_COUNT_PAGE_TOPTAB_CHANGE          = index();--统计页顶部tab变化
		
		--设置页
		OPEN_SETTING_POP_UP                     = index();--打开设置弹框
		
		--帮助
		OPEN_HELP_POP_UP                        = index();--打开帮助弹框
		
		--排行
		OPEN_RANKING_POP_UP                     = index();--打开排行榜
		HIDE_RANKING_POP_UP                     = index();--关闭排行榜
		RANKING_PAGE_TAB_CHANGE                 = index();
		RANKING_PAGE_TOP_TAB_CHANGE             = index();
		OPEN_USER_INFO_POP_UP                   = index();--打开玩家信息框
		
		--登陆奖励
		LOGIN_POP_UP_BUBBLE_TRIGGERED           = index();
		
		
		--淘汰赛
		NEWKNOCKOUT_REFRESH                     = index();--刷新数据
		SNG_HALL_ENTER_ROOM                     = index();--进入房间
		
		--SNG&MTT
		GET_SNG_MTT_REFRESH                     = index();--刷新数据
		
		--新大厅
		REQUEST_BRING_GROUPS_INFO               = index();--请求初级场和中级场集合数据
		REQUEST_TRACE_FRIENDS_DATA              = index();--请求当前集合的好友数据
		REQUEST_BRING_GROUPS_ENTER_ROOM         = index();--初级和中级场请求进入房间
		
		--MTTHall
		MTTHALL_GET_MTTLIST                     = index();--获取mtt列表
		MTTHALL_CLEAR_DATA                      = index();--清除缓存数据
		MTTHALL_REFRESH_LIST                    = index();--客户端主动请求刷新mtt列表
		
		--首页
		GET_RANKING_LIST                        = index();--获取排行榜列表
        
        DAY_PASSED                              = index();--一天过去
        GIFT_CATEGORY_TAG_CHANGE                = index();--GiftDialog分类改变通知GiftModule
        GIFT_SALE_BUTTON_STATUS_CHANGE_DARK     = index();
        GIFT_SALE_BUTTON_STATUS_CHANGE_LIGHT    = index();
        GIFT_DIALPG_ON_POPUP_END                = index();--弹出GiftDialog后加载礼物数据
}