require("core/ex/eventDispatcherEx")
require("game/event/commandEvent");
require("game/event/uiEvent");
require("game/event/sceneNavEvent");
require("game/event/testEvent");