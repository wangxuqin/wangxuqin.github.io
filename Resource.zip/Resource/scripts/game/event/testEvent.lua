TestEvent = {};
local index = ToolKit.getIndex();
TestEvent.s_event = EventDispatcher.getInstance():getUserEvent();
TestEvent.s_cmd = {
    TEST_1 = index();
    TEST_2 = index();
    TEST_3 = index();
}