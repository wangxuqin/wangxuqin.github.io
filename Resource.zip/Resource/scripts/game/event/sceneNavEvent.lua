--[Comment]
--这个事件是负责导航作用，从这个场景跳转到另外一个场景，直接派发对应的事件即可。
SceneNavEvent = {};
local index = ToolKit.getIndex();
SceneNavEvent.s_event = EventDispatcher.getInstance():getUserEvent();
SceneNavEvent.s_cmd = {
    LOGIN_2_HOME            = index();  --从登录页面跳转到主页
    LOGIN_2_ROOM            = index();  --从登录页面跳转到房间
		
    HOME_2_NORMAL_HALL      = index();  --从主页跳转到普通场大厅
    HOME_2_KNOCKOUT_HALL    = index();  --从主页跳转到淘汰赛大厅
		
    HOME_2_MATCH_HALL       = index();  --从主页跳转到比赛场大厅
    HOME_2_ROOM             = index();  --从主页跳转到房间
    HOME_2_LOGIN            = index();  --从主页跳转到登录页面
    HOME_2_MTT_HALL         = index();  --从主页跳转到锦标赛页面
		
    NORMAL_HALL_2_HOME      = index();  --从普通场大厅跳转到主页
    NORMAL_HALL_2_ROOM      = index();  --从普通场大厅跳转到房间
		
    MATCH_HALL_2_HOME       = index();  --从比赛场跳转到主页
    MATCH_HALL_2_ROOM       = index();  --从比赛场跳转到房间
		
    ROOM_2_NORMAL_HALL      = index();  --从房间跳转到普通大厅
    ROOM_2_MATCH_HALL       = index();  --从房间跳转到比赛场大厅
    ROOM_2_HOME             = index();  --从房间跳转到主页
    ROOM_2_LOGIN            = index();  --从房间跳转到登录页面
    ROOM_2_MTT_HALL         = index();  --从房间跳转到MTT大厅
		
    KNOCKOUT_HALL_2_HOME    = index();  --从淘汰赛跳转到主页
    KNOCKOUT_HALL_2_ROOM    = index();  --从淘汰赛跳转到房间
		
    MTT_HALL_2_HOME         = index();  --从锦标赛大厅跳转到主页
    MTT_HALL_2_ROOM         = index();  --从锦标赛大厅跳转到房间
		
    ROOM_2_MTT              = index();  --从房间跳转到MTT
    ROOM_2_SNG              = index();  --从房间跳转到SNG
}