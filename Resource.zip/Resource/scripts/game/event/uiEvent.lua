--[Comment]
--UI相关事件
UIEvent = {};
local index = ToolKit.getIndex();
UIEvent.s_event = EventDispatcher.getInstance():getUserEvent();
UIEvent.s_cmd = {
        --登录
		SHOW_LOGIN_LOADING                          = index();--显示登录加载页面
		HIDE_LOGIN_LOADING                          = index();--隐藏登录加载页面
		ENTER_HOME_PAGE                             = index();--进行主页
		ENTER_SUB_PAGE                              = index();--进入子页
		GET_TASK_REWARD                             = index();--获取任务奖励
		HIDE_HOME_ACCOUNT_BUTTON                    = index();
		LOGIN_REWARD_REMOVED                        = index();
		REGISTER_REWARD_REMOVED                     = index();
		HIDE_GUEST_LOGIN_BUTTON                     = index();
		
		--大厅
		OPEN_CREATE_ROOM_POPUP                      = index();
		START_ENTER_ROOM                            = index();
		SHOW_BANK_PASSWORD                          = index();
		SHOW_BANK_POPUP                             = index();
		SHOW_BANK_VIP_POPUP                         = index();
		SHOW_TICKLING_POPUP                         = index();
		
		SHOW_MATCH_COUNTS_DIALOG                    = index();--显示牌型统计对话框
		SHOW_ACT_WHEEL                              = index();--显示大转盘
		SHOW_ACT_LOTTERY                            = index();--显示彩票
		SHOW_ACT_TASK                               = index();--显示每日任务
		SHOW_REWARD_CODE                            = index();--显示粉丝页兑换码
		SHOW_ROOM_TASK                              = index();--显示房间任务
		SHOW_ACT_NEWEST                             = index();--显示最新活动
		HIDE_ACT_NEWEST                             = index();--关闭最新活动
		REFRESH_ROOM_LIST                           = index();
		SHOW_TOURNAMENT_DETAIL                      = index();--显示锦标赛详情
		SHOW_TOURNAMENT_APPLY                       = index();--显示锦标赛详情
		PRIVATE_BANK_SETTING_PASSWORD               = index();--个人银行密码设置弹框
		PRIVATE_BANK_MODIFY_PASSWORD                = index();--个人银行修改密码或者取消密码
		PRIVATE_BANK_MODIFY_PASSWORD_POPUP          = index();--个人银行修改密码弹框
		PRIVATE_BANK_UPDATE_SET_PASSWORD_ICON       = index();--更新设置密码的图标
        
        --普通场大厅
        NORMAL_HALL_ADVANCED_CHOOSE_TAB             = index();--切换“满，未满，朋友”切换按钮
        SHOW_ADVANCED_FLOAT_BRING_TITLE             = index();--显示高级场悬浮提示
        HIDE_ADVANCED_FLOAT_BRING_TITLE             = index();--隐藏高级场悬浮提示
        SHOW_MINI_LOAD                              = index();--显示加载
        HIDE_MINI_LOAD                              = index();--隐藏加载
        SHOW_TRACE_FRIEND_POPUP                     = index();--打开跟踪好友对话框
        HIDE_TRACE_FRIEND_POPUP                     = index();--关闭跟踪好友对话框

		--私人房
		CREATE_PRIVATE_ROOM_POPUP                   = index(); --创建私人房间
		PRIVATE_ROOM_VIP_POPUP                      = index(); --创建私人房间VIP提示
		ENTER_PRIVATE_ROOM_POPUP                    = index(); --进入私人房
		INVITE_FRIENDS_POPUP                        = index();--私人房邀请好友弹框
		CREATE_PRIVATE_ROOM_MIN_BUYIN_POPUP         = index();--创建私人房间筹码不足最小买入
		
		--房间
		ROOM_SOCKET_CONNECTED                       = index();--房间server已连接
		ROOM_SOCKET_CLOSE                           = index();
		ROOM_SERVER_SWITCH                          = index();
		ROOM_SERVER_STOP                            = index();
		ROOM_KNOCKOUT_CLOSE                         = index();
		ROOM_PASSIVE_LEAVE_ROOM                     = index();--强制离开房间
		ROOM_CLEAR_CALCULATOR                       = index();--清理算牌器
		ROOM_NETWORK_SIGNAL                         = index();--房间网络信号
		
		REMOVE_CHAT_POPUP                           = index();
		OPEN_DIALOG                                 = index();
		OPEN_NETWORK_DIALOG                         = index();--显示网络问题对话框
		SHOW_TOP_TIP                                = index();--显示顶部消息框
		SHOW_USER_INFO                              = index();--显示主页中的用户信息对话框
        HIDE_USER_INFO                              = index();--关闭主页中的用户信息对话框
		HIDE_ALL_POPUP                              = index();
		HIDE_TOP_POPUP                              = index();
        SHOW_MESSAGE_DIALOG                         = index();--弹出消息对话框
        HIDE_MESSAGE_DIALOG                         = index();--关闭消息对话框
        SHOW_STORE_DIALOG                           = index();--弹出商城对话框
        HIDE_STORE_DIALOG                           = index();--关闭商城对话框
        SHOW_CHANGEPASSWD_DIALOG                    = index();--打开更改密码对话框
        HIDE_CHANGEPASSWD_DIALOG                    = index();--关闭更改密码对话框
        SHOW_BANK_DIALOG                            = index();--显示保险箱对话框
        HIDE_BANK_DIALOG                            = index();--关闭保险箱对话框
		
		SHOW_NEWER_TIP                              = index();
		HIDE_NEWER_TIP                              = index();
		SHOW_LABEL_LOADING                          = index();
		HIDE_LABEL_LOADING                          = index();
		CONFIRM_DEALER_INFO                         = index();--换荷官
		SHOW_DEALER_ACTION                          = index();--播放荷官动画
--		SHOW_SUPER_LOTTO                            = index();
		SHOW_SUPER_LOTTO_POPUP                      = index();--大乐透弹框
		HIDE_SUPER_LOTTO_POPUP						= index();
		SHOW_SUPER_LOTTO_REWARD                     = index();
		HIDE_SUPER_LOTTO_REWARD                     = index();
		SHOW_FRIENDS_INVITE                         = index();--好友邀请
		ACCEPT_FRIENDS_INVITE                       = index();--在房间中接受好友邀请
		SHOW_INVITE_FRIENDS_DIALOG                  = index();--显示邀请好友对话框
		TOURNAMENT_SEND_EMAIL_SUCC                  = index();--上报email数据成功
		
        SHOW_ROOM_MAX_CARD_TIP                      = index();--显示最大牌型概率
        HIDE_ROOM_MAX_CARD_TIP                      = index();--隐藏最大牌型概率
        TOUCH_ROOM_SCENE_BG                         = index();--触摸房间场景背景

		ROOM_ACTIVITY_PAGE_OPEN                     = index();--打开房间活动界面
		ROOM_ACTIVITY_PAGE_HIDE                     = index();--关闭房间活动界面
		ROOM_ACTIVITY_TREASURE_BOX_FINISHED         = index();--房间倒计时宝箱完成
		ROOM_ACTIVITY_TREASURE_BOX_RECEIVE_REWARD   = index();--房间倒计时宝箱领奖
		ROOM_ACTIVITY_TREASURE_BOX_TIME_CHANGE      = index();--房间倒计时宝箱时间改变
		ROOM_ACTIVITY_TREASURE_BOX_dATA_INVALIDE    = index();--房间倒计时宝箱数据改变
		USER_STAND_UP_AND_LEAVE_ROOM                = index();--用户在本局结束后站起并离开房间
		USER_DIRECT_LEAVE_ROOM                      = index();--用户直接离开房间
		SYSTEM_NOTICE_TASK_FINISHED                 = index();--系统通知任务完成
		ROOM_ACTIVITY_USER_RECEIVED_REWARD          = index();--玩家领取完奖励

		
		--新手引导
		TUTORIA_PAGE_RETURN_BTN_CLICK               = index();
		
		--钻石大赢家
		DIDMOND_WINNER_LOGIN_REWARD_POPUP           = index();
		DIDMOND_WINNER_REWARD_POPUP                 = index();
		DIDMOND_WINNER_REWARD_RANK_POPUP            = index();
		
		--金钥匙
		GOLDEN_KEY_WINNER_REWARD_POPUP              = index();
		
		-- 玩偶收集
		DOLL_COLLECT_BLAG_POPUP                     = index();
		DOLL_COLLECT_PRESENT_POPUP                  = index();
		DOLL_COLLECT_POPUP                          = index();
		
		-- 序列号
		OPEN_SERIAL_NUM_EXCHANGE_POP_UP             = index(); --打开序列号兑换窗口
		
		-- 点球活动
		SHOW_PENALTY_KICK_POPUP                     = index();
		
		WHEEL_REWARD_MESSAGE_INPUT_POPUP            = index();	-- 实物奖励输入弹框
		WHEEL_REWARD_MESSAGE_CONFIRM_POPUP          = index();-- 实物奖励确认弹框
		
		ACTIVITY_OPEN_NEW_YEAR_WHEEL_POP_UP         = index();	--打开新年活动大转盘
		
		--fb登录密码
		FB_LOGIN_OPEN_PASSWORD_PAGE                 = index();--打开登录密码页面
		FB_LOGIN_OPEN_FIND_PASSWORD_PAGE            = index();--打开找回登录密码页面
		FB_LOGIN_OPEN_RESET_PASSWORD_PAGE           = index();--打开重设登录密码页面
		FB_LOGIN_OPEN_FEEDBACK_PAGE                 = index();--打开登录密码反馈页面
		
		--
		SHOW_INVITE_CARD_INFO_PAGE                  = index();--展开邀请函详细信息
		CLOSE_MATCH_RESULT_POP_UP                   = index();--关掉比赛动画
		
		--新大厅
		SHOW_TRACE_FRIENDS_PANEL                    = index();--弹出追踪好友的面板
		QUICK_ENTER_ROOM                            = index();--快速加入
		BRING_GROUP_ENTER_ROOM                      = index();--初级场中级场加入
		NEW_HALL_FILTER_TABLE_INFO                  = index();--过滤高级场数据
		NEW_HALL_FILTER_PlAYER_INFO                 = index(); 
		NEW_HALL_NO_TABLES                          = index();
		NEW_HALL_TOUCH_GOTO_TABLE_ENABLE            = index();
		
		--mtt列表
		SHOW_MTT_LIST                               = index(); 
		
		--退出房间显示回到上一个牌局
		LEAEVE_ROOM_SHOW_BACK_TO_LAST_ROOM          = index();
		
		EFFECT_LOADED                               = index();

        --设置页面
        SHOW_SETTING_PAGE                           = index();--显示设置页面
        HIDE_SETTING_PAGE                           = index();--隐藏设置页面

        --敬请期待页面
        SHOW_COMINGSOON_PAGE                        = index();
        HIDE_COMINGSOON_PAGE                        = index();

        --房间中用户的信息面板
        SHOW_ROOM_USERINFO                     = index();

        --买入坐下的对话框
        SHOW_ROOM_BUYIN_DIALOG                      = index();
        HIDE_ROOM_BUYIN_DIALOG                      = index();

        --帮助页面
        SHOW_HELP_PAGE                              = index();
        HIDE_HELP_PAGE                              = index();
        
        --反馈页面
        SHOW_FEEDBACK_PAGE                          = index();

        --快速设置面板
        SHOW_QUICK_SETTING_PANEL                    = index();
        HIDE_QUICK_SETTING_PANEL                    = index();

        --用户破产对话框
        SHOW_USER_CRASH_DIALOG                      = index();
        HIDE_USER_CRASH_DIALOG                      = index();

        --返回大厅前的相关提示
        BACK_TO_HALL_TIP                            = index();

        --发送互动道具给荷官
        SEND_DEALER_HDDJ                            = index();

        --换荷官相关
        SHOW_DEALER_BUTTONS                         = index();
        HIDE_DEALER_BUTTONS                         = index();
        SHOW_DEALER_CHOICE                          = index();
        HIDE_DEALER_CHOICE                          = index();
        --选荷官中的光效
        DEALER_SPARK_SHRINK                         = index();--光效缩小
        DEALER_SPARK_ENLARGE                        = index();--光效放大
        --聊天
        SHOW_CHAT_POP                               = index();
        HIDE_CHAT_POP                               = index();
        --牌局回顾
        OPEN_GAME_REVIEW_POP_UP                     = index();
        CLOSE_GAME_REVIEW_POP_UP                    = index();
		OPEN_GAME_REVIEW_DETAIL						= index();
		CLOSE_GAME_REVIEW_DETAIL					= index();

        --关于页面
        SHOW_ABOUT_DIALOG                           = index();
        HIDE_ABOUT_DIALOG                           = index();

        --好友页面
        SHOW_FRIEND_DIALOG                          = index();
        HIDE_FRIEND_DIALOG                          = index();
        --邀请好友界面
        SHOW_INVITE_FRIENDS_DIALOG                  = index();
        HIDE_INVITE_FRIENDS_DIALOG                  = index();

        ROOM_FACEBOOK_SHARE                         = index();
		--老虎机帮助页面
		SHOW_SLOTBONUS_POPUP						= index();
		HIDE_SLOTBONUS_POPUP						= index();

        --好友页面
        SHOW_GIFT_DIALOG                            = index();
        HIDE_GIFT_DIALOG                            = index();
         --设置页面
        SHOW_PER_RANKING_DIALOG                     = index();--显示个人排行榜页面
        HIDE_PER_RANKING_DIALOG                     = index();--隐藏个人排行榜页面
        --成就页面
        SHOW_GLORY_DIALOG                           = index();
        HIDE_GLORY_DIALOG                           = index();

}
