require("core/ex/eventDispatcherEx")
--[Comment]
--这里是存放事件的地方，事件需要与控制器，模块解耦。对于模块外的事件

--[Comment]
--登录相关事件
LoginEvent = {};
local index = ToolKit.getIndex();
LoginEvent.s_event = EventDispatcher.getInstance():getUserEvent();
LoginEvent.s_cmd = {
    DO_LOGIN                = index();                  --点击登录按钮
	LOGIN_RESULT            = index();			        --登录结果
    USER_LOGGED_IN          = index();		            --用户登录成功，用户切换也会触发该事件
    USER_LOGGED_OUT         = index();		            --用户登出成功
	LOGOUT                  = index();                  --登出事件
	USER_LOGIN_RETRY        = index();	                --用户重新登录
}