require("core/object");
require("core/constants");
require("core/global");

DownloadFile = class();
local kDownloadFile = "downloadFile";
local kResponse = "downloadFile_response";
local kCommonEvent = "CommonEvent";
local kCode = "code";
local kId = "id";
local kUrl = "url";
local kTimeout = "timeout";
local kName="name"
local kFolder="folder"
local dTimeOut = 5000;

DownloadFile.s_objs = CreateTable("k");
DownloadFile.request_id = 0;


local function request_destroy(iRequestId)
    local key = getKey(iRequestId);
    dict_delete(key);
end

local function allocId()
    DownloadFile.request_id = DownloadFile.request_id + 1;
    return DownloadFile.request_id;
end

local function getKey(iRequestId)
    return string.format("downloadfile_request_%d", iRequestId or 0);
end

--folder 文件路径带"/", name 文件名, imageOrFile  
DownloadFile.ctor = function(self, url, timeout, name, folder)
    self.m_requestID = allocId();
    DownloadFile.s_objs[self.m_requestID] = self;
    self.m_requestUrl = url or "";
    self.m_name = name or "";
    self.m_folder = folder or System.getStorageImagePath() .. "/" ;
    self.m_timeout = timeout or dTimeOut;
    self.m_path = self.m_folder .. self.m_name;
    self.m_eventCallback = { };
end

DownloadFile.execute = function(self)
    if System.getPlatform() ~= kPlatformAndroid then
        return;
    end
    local key = getKey(self.m_requestID);
    dict_set_string(key, kName, self.m_name.."");
    dict_set_string(key, kUrl, self.m_requestUrl.."");
    dict_set_string(key, kFolder, self.m_folder.."");
    dict_set_string(key, kTimeout, self.m_timeout.."");
    dict_set_string(kCommonEvent, kCommonEvent, kDownloadFile);
    dict_set_int(kDownloadFile, kId, self.m_requestID);
    call_native(kCommonEvent);
end

--设置下载回调函数
DownloadFile.setEvent = function(self, obj, func)
    self.m_eventCallback.obj = obj;
    self.m_eventCallback.func = func;
end

DownloadFile.dtor = function(self)
    request_destroy(self.m_requestID);
    self.m_requestID = nil;
end

--java回调此函数
function event_downloadFile_response()
    local requestID = dict_get_int(kResponse, kId, 0);
    local download = DownloadFile.s_objs[requestID];
    --1001：下载成功  1002：下载失败 1003：请求超时 1004：参数错误 1005：响应超时 1006 BadGateWay 1007 SD卡不可写
    download.m_responseCode = dict_get_int(getKey(requestID), kCode, -1);
    if download and download.m_eventCallback.func then
        download.m_eventCallback.func(download.m_eventCallback.obj, download);
    end
end


property(DownloadFile, "m_responseCode", "ResponseCode", true, false);

property(DownloadFile, "m_timeout", "Timeout");

property(DownloadFile, "m_folder", "Folder");

property(DownloadFile, "m_requestUrl", "Url");

property(DownloadFile, "m_name", "Name");

property(DownloadFile, "m_path", "Path");


--[[
        require("util/DownloadFile");
            local download = new(DownloadFile, "http://www.baidu.com", 5000, "baidu.txt");
            download:setEvent(self,function (self, d)
                local id = d.m_requestID;
                dict_set_string("download"..id,"responseCode",d:getResponseCode().."code");
                dict_set_string("download"..id,"Name",d:getName());
                dict_set_string("download"..id,"requestID",id);
                dict_set_string("download"..id,"url",d:getUrl());
                dict_save("download"..id);
            end);
       download:execute();
--]]

-- endregion
