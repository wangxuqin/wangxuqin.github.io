require("core/object");
require("common/log");
require("common/net/downloadFile");
require("service/httpService");
require("version");

-- 更新功能相关的逻辑类
UpdateManager = class();
UpdateManager.s_url = "https://ipk-demo-1.boyaa.com/m.php"
UpdateManager.s_tag = "UpdateManager";
local kCommonEvent = "CommonEvent";

UpdateManager.getInstance = function()
    if not UpdateManager.s_instance then
        UpdateManager.s_instance = new(UpdateManager);
    end
    return UpdateManager.s_instance;
end

UpdateManager.releaseInstance = function(self)
    delete(UpdateManager.s_instance);
    UpdateManager.s_instance = nil;
end

UpdateManager.ctor = function(self)

end

UpdateManager.dtor = function(self)
    self:releaseInstance();
end


-------------------------APK升级相关--------------------------
-- 获取apk更新路径，在Android中即:/mnt/sdcard/.com.boyaa.xxx/update
UpdateManager.createUpdatePath = function(self)
    dict_set_string("createDir", "dirPath", self:getApkUpdatePath() .. "," .. self:getLuaZipPath());
    dict_set_string(kCommonEvent, kCommonEvent, "createDir");
    if System.getPlatform() == kPlatformAndroid then
        call_native(kCommonEvent);
    end
end

UpdateManager.getApkUpdatePath = function(self)
    local path = sys_get_string("storage_temp") .. "/";
    return path;
end


UpdateManager.getLuaZipPath = function(self)
    local path = sys_get_string("storage_update") .. "/";
    return path;
end

-- 获取apk增量更新文件名
UpdateManager.getPatchName = function(self)
    local fileName = string.format("update_apk_%s_%s.patch", self.m_version, self.m_newVersion);
    return fileName;
end

-- 获取apk增量更新文件路径
UpdateManager.getPatchPath = function(self)
    return self:getApkUpdatePath() .. self:getPatchName(self.m_version, self.m_newVersion);
end

-- 获取新apk路径
UpdateManager.getNewApkPath = function(self)
    local rootPath = self:getApkUpdatePath();
    local fileName = string.format("%s%s_%s.apk", rootPath, self.m_version, self.m_newVersion);
    return fileName;
end

-- 下载luazip时，
UpdateManager.getLuaZipNamePath = function(self)
    local luaPath = self:getLuaZipPath();
    local fileName = string.format("%supdate_lua_%s_%s.zip", luaPath, self.m_version, self.m_newVersion);
    return fileName;
end

UpdateManager.getLuaZipName = function(self)
    return string.format("update_lua_%s_%s.zip", self.m_version, self.m_newVersion);
end


-- 判断是否需要更新
UpdateManager.update = function(self)
    if System.getPlatform() ~= kPlatformAndroid then
        return;
    end
    local versionCode = dict_get_int("android_app_info", "version_code", 0);
    self.m_version = tostring((Version.ver_code >= versionCode)and Version.ver_code or versionCode);
    local params = { };
    params.mod = "mobile";
    params.act = "getApkInfo";
    params.apk_appid = "ipk10001";
    params.apk_version = self.m_version;
    HttpService.postUrl("https://ipk-demo-1.boyaa.com/m.php", params, self, self.onUpdateResult, nil, nil);
end

-- 打印table
mprint_table = function(table)
    if not table or type(table) ~= "table" then
        return;
    end
    for k, v in pairs(table) do
        if type(v) == "table" then
            mprint_table(v);
        else
            Log.d(UpdateManager.s_tag, k .. ":" .. tostring(v));
        end
    end
end

--[[
{
info: {
ver: 8,
size: 1663971,
patchMd5: "440c779830f501bf85a0b4524e83cc1d",
newApkMd5: "70ce7bd0eb77b57e6d5da3ad4d4eb57f",
type: 1,
url: "",
update_info: [
"1.android判断data/data/com.boyaa.xxx/files/ 下文件是否存在() ",
"用法： ",
"1.NativeEvent.getInstance():checkFileExists("images/card/poker-back.png"); ",
" ",
"2.注册回调监听 EventDispatcher.getInstance():register(Event.Call, LoginModule, LoginModule.onCheckFileExists); ",
"后两个参数为测试用的"
]
},
url: "http://192.168.203.14/bigfile-ws/res_apk/ipk10001/update_7_8.patch"
}
--]]
-- 请求回调
UpdateManager.onUpdateResult = function(self, data)
    Log.d(UpdateManager.s_tag, "onUpdateResult");
    local table = json.decode(data);
    mprint_table(table);
    if table ~= nil and table.info ~= nil and table.url ~= nil then
        -- 增量更新
        self.m_newVersion = tostring(table.info.ver);
        if table.info.type == 1 then
            self.m_patchMd5 = table.info.patchMd5;
            self.m_newApkMd5 = table.info.newApkMd5;
            self:downloadPatchFile(table.url);
            -- lua更新
        elseif table.info.type == 0 then
            self:downloadLuaZipFile(table.url);
        end
    else
        Log.d(UpdateManager.s_tag, "已经是最新版本，无需更新");
    end
end


-- 下载patch
UpdateManager.downloadPatchFile = function(self, url)
    Log.d(UpdateManager.s_tag, "downloadPatchFile");
    local download = new(DownloadFile, url, 10000, self:getPatchName(), self:getApkUpdatePath());
    download:setEvent(self, self.onDownloadPatchResponse);
    download:execute();
    -- deleteFile(self:getPatchPath());--不删除这个文件是为了增加断点续传功能
    -- deleteFile(self:getNewApkPath());
end

-- 下载patch回调
UpdateManager.onDownloadPatchResponse = function(self, download)
    Log.d(UpdateManager.s_tag, "onDownloadPatchResponse.. code: " .. download:getResponseCode());
    if download:getResponseCode() == 1001 then
        self:mergeNewApk();
    end
end

-- 下载luazip
UpdateManager.downloadLuaZipFile = function(self, url)
    Log.d(UpdateManager.s_tag, "downloadLuaZipFile");
    local download = new(DownloadFile, url, 5000, self:getLuaZipName(), self:getLuaZipPath());
    download:setEvent(self, self.onDownloadLuaZipResponse);
    download:execute();
    deleteFile(self:getLuaZipNamePath());
end

-- 下载luazip回调
UpdateManager.onDownloadLuaZipResponse = function(self, download)
    Log.d(UpdateManager.s_tag, "onDownloadLuaZipResponse");
    if download:getResponseCode() == 1001 then
        self:installLua();
    end
end

-- 安装apk
UpdateManager.installNewApk = function(self)
    dict_set_string("patchUpdate", "newApkPath", self:getNewApkPath());
    if System.getPlatform() == kPlatformAndroid then
        dict_set_string(kCommonEvent, kCommonEvent, "patchApkInstall");
        call_native(kCommonEvent);
    end
end

-- 安装apk的结果
function event_install_apk()
    local result = dict_get_int("patchUpdate", "install_result", -1);
    Log.d(UpdateManager.s_tag,(result == 1) and "install_result success" or "install_result failed");
end


-- isRestart 是否需要重启
UpdateManager.installLua = function(self)
    if System.getPlatform() == kPlatformAndroid then
        sys_set_string("force_update", self:getLuaZipName());
    end
    -- socket_room_close(-1);
    -- res_delete_group(-1);
    -- anim_delete_group(-1);
    -- prop_delete_group(-1);
    -- drawing_delete_all();
    -- Sound.pauseMusic();
    to_lua("main.lua");  ---重启虚拟机
end

-- 合成新的apk
UpdateManager.mergeNewApk = function(self)
    --- apk升级必须
    Log.d(UpdateManager.s_tag, "mergeNewApk");
    dict_set_string("patchUpdate", "patchPath", self:getPatchPath());
    dict_set_string("patchUpdate", "newApkPath", self:getNewApkPath())
    dict_set_string("patchUpdate", "patchMD5", self.m_patchMd5);
    dict_set_string("patchUpdate", "newApkMD5", self.m_newApkMd5);
    if System.getPlatform() == kPlatformAndroid then
        dict_set_string(kCommonEvent, kCommonEvent, "mergeNewApk");
        call_native(kCommonEvent);
    end
end

-- 合成新apk的结果
function event_merge_new_apk()
    --- apk升级必须
    local result = dict_get_int("patchUpdate", "merge_result", -1);
    Log.d(UpdateManager.s_tag,(result == 1) and "merge success" or "merge failed");
    if UpdateManager.getInstance():getPatchPath() then
        -- deleteFile(UpdateManager.getInstance():getPatchPath());
        if result ~= 1 then
        
            --deleteFile(UpdateManager.getInstance():getNewApkPath());
            return;
        end
        UpdateManager.getInstance():installNewApk();
    end
end

function deleteFile(filePath)
    dict_set_string("file_op", "src_file", filePath);
    return sys_get_int("file_delete", -1) == 0;
end


-----------------------------------全局函数-----------------------------------
KTaskType_Update_APK_Patch = 1;-- APK增量更新
KTaskType_Update_APK = 2;-- APK全量更新
KDownloadStatus_NotStart = 1;-- 未开始
KDownloadStatus_begin = 2;-- 开始
KDownloadStatus_Success = 3;-- 下载失败
KDownloadStatus_Failed = 4;-- 下载成功