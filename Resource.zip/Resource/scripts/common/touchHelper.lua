--[Comment]
--这个类用于组件Touch事件辅助,可以区分点击
TouchHelper = {};

--[Comment]
--捕获
--这个函数必须先调用才能调用其他函数
TouchHelper.catch   = function(target, finger_action, x, y)
    if finger_action == kFingerDown then
        target.__touchHelper_bMoveFar = false;
        target.__touchHelper_xDown = x;
        target.__touchHelper_yDown = y;
        TouchHelper.__reset(target);
        TouchHelper.__touchHelper_isDown = true;
    elseif finger_action == kFingerMove then
        TouchHelper.__reset(target);
        if(math.abs(x - target.__touchHelper_xDown) > 4 or math.abs(y - target.__touchHelper_yDown) > 4) then
            target.__touchHelper_bMoveFar = true;
        end
    elseif finger_action == kFingerUp then
        TouchHelper.__reset(target);
        if(not target.__touchHelper_bMoveFar) then
           target.__touchHelper_isClick   = true;
        end
    end
end

--[Comment]
--重置
TouchHelper.__reset = function(target)
    target.__touchHelper_isDown = false;
    target.__touchHelper_isUp   = false;
    target.__touchHelper_isClick   = false;
end

--[Comment]
--判断是否为点击动作
TouchHelper.isClick = function(target)
    return target.__touchHelper_isClick;
end

--[Comment]
--判断是否为按下动作
TouchHelper.isDown  = function(target)
    return target.__touchHelper_isDown;
end

--[Comment]
--判断是否为抬起动作
TouchHelper.isUp    = function(target)
    return target.__touchHelper_isUp;
end