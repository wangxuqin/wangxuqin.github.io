require("core/ex/systemEx");
require("libs/json_wrap");
require("framerate");

Log = class();
Log.s_tab = "";
Log.s_show_str = false; -- 是否把table打印为str格式

Log.setDebug = function(open)
    _DEBUG = open;
    Log.s_show_str = open;
    if (_DEBUG) then
    	show_fps();
    end
end

Log.isDebug = function()
    return (_DEBUG == true);
end

Log.v = function(tag,...)
	Log.base(0x008000,"VERBORSE--",tag,...); --绿色
end 

Log.d = function(tag,...)
	Log.base(0xffff00,"DEBUG--",tag,...); --黄色
end

Log.i = function(tag,...)
	Log.base(0x00ffff,"INFO--",tag,...); --绿青
end

Log.e = function(tag,...)
	Log.base(0xff0000,"ERROR--",tag,...); --红色
end

Log.w = function(tag,...)
	Log.base(0xff8080,"WARN--",tag,...); --粉色
end

Log.a = function(tag,...)
	Log.base(0xffffff,"ASSERT--",tag,...); --白色
end

Log.crash = function(tag,...)
	Log.errbase(0xff0000,"ERROR--",tag,...); --红色
end
-----------------------------------------
Log.vWF = function(tag,...)
	Log.v(tag,...);
	Log.writeFile(tag,...);
end

Log.dWF = function(tag,...)
	Log.d(tag,...);
	Log.writeFile(tag,...);
end

Log.iWF = function(tag,...)
	Log.i(tag,...);
	Log.writeFile(tag,...);
end

Log.eWF = function(tag,...)
	Log.e(tag,...);
	Log.writeFile(tag,...);
end

Log.wWF = function(tag,...)
	Log.w(tag,...);
	Log.writeFile(tag,...);
end

Log.aWF = function(tag,...)
	Log.a(tag,...);
	Log.writeFile(tag,...);
end
---------------------------------------------------------------------
Log.base = function(color,tagPrefix,tag,...)
	if not _DEBUG then 
		return;
	end

	System.setWin32ConsoleColor(color); 
	local strInfo = Log.getData(tagPrefix,tag,...);
	print_string(strInfo);
end

Log.errbase = function(color,tagPrefix,tag,...)
	if not _DEBUG then 
		return;
	end

	System.setWin32ConsoleColor(color); 
	local strInfo = Log.getData(tagPrefix,tag,...);
	error(strInfo);
end

Log.writeFile = function(tag,...)
	if not _DEBUG then 
		return;
	end
	local datePreFix = os.date("%Y-%m-%d %H:%M:%S") or "";
	local strInfo = string.format("%s%s%s%s",datePreFix , " : ", Log.getData(tag,...) , "\n");
	local dateFileName=os.date("%Y_%m_%d") or "";
	local fileFullPath = string.format("%s%s%s%s",System.getStorageLogPath() , "/log_" , dateFileName , ".log");
	local file = io.open(fileFullPath,"a");
	if file then
		file:write(strInfo);
		file:close();
	end
end


Log.getData = function(tagPrefix,tag,...)
	tag = tag or "";
	tagPrefix = tagPrefix or "INFO--";
	local info = "";
	for _,v in pairs({...}) do
		local tempType = type(v); 
		if tempType == "table" then
			local str = nil;
			if Log.s_show_str then
				str = json.encode(v);
			else
				str = Log.loadTable(v);
			end
			
			info = info..tostring(str);
		else
			info = info..tostring(v);
		end
		info = info .. "  ";
	end
	
	return string.format("%s%s : %s",tostring(tagPrefix),tostring(tag),tostring(info));

end

Log.loadTable = function(t)
	if type(t) ~= "table" then 
		return t;
	end 

	local tab = Log.s_tab;
	Log.s_tab = Log.s_tab.."    ";
	local temp = "";
	for k,v in pairs(t) do 
		if v ~= nil then 
			local key = Log.s_tab;
			if type(k) == "string" then
				key = key.."[\""..tostring(k).."\"] = ";
			else 
				key = key.."["..tostring(k).."] = ";
			end 
			
			if type(v) == "table" then 
				temp = temp..key..Log.loadTable(v);
			else 
				temp = temp..key..tostring(v)..";\n";
			end 
		end 
	end 
	Log.s_tab = tab;
	temp = "\n"..Log.s_tab.."{\n"..temp..Log.s_tab.."}\n";
	
	return temp;
end 
