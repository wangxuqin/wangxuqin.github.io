Formatter = {}
Formatter.m_indexArr = {1000, 1000000, 1000000000, 1000000000000};
Formatter.m_tokenArr = nil;

--[Comment]	
--格式化日期
Formatter.formatDate = function(date, pattern)
    local ret = "";
    pattern = pattern or "%Y-%m-%d";
    if date ~= nil then
		ret = os.date(pattern, date);
	end
	return ret;
end
		
--[Comment]
--大数值转换（大于3位，小数点保留一位），如12345转化为12.3K
--@param	value		转化前数字
--@return	字符串
Formatter.formatBigNumber = function(value, special)
    local ret = "";
    if special == nil then
        special = true;
    end
	if (not Formatter.m_tokenArr) then
        Formatter.m_tokenArr = STR_COMMON_BIG_NUM_TOKEN;
    end

	local tokenArr = special and STR_COMMON_BIG_NUM_TOKEN_SP or nil;
	tokenArr = (tokenArr and special) and tokenArr or Formatter.m_tokenArr;		
	if type(value) ~= "number" then
		value = 0;
	end
			
	local numStr = tostring(value);
	if string.len(numStr) < 5 then
		ret = numStr;
	else
        local index = 0;
	    if #numStr >= 5 and #numStr < 7 then
		    index = 1;
	    elseif #numStr >= 7 and #numStr < 10 then
		    index = 2;
	    elseif #numStr >= 10 and #numStr < 13 then
		    index = 3;
	    elseif #numStr >= 13 and #numStr < 16 then
		    index = 4;
	    end
			
	    numStr = (value / Formatter.m_indexArr[index])..tokenArr[index];
        local point, _ = string.find(numStr, "%.");
        if point then
            local subStr = string.sub(numStr, point, -1);
            if string.len(subStr) > 3 then
                numStr = string.sub(numStr, 1, point + 1) .. tokenArr[index];
            end
        end
	    if(LocalService.currentLocaleId() == "de_DE" or LocalService.currentLocaleId() == "es_ES") then
		    ret = string.gsub(numStr, ".", ",");
	    else
		    ret = numStr;
	    end
    end
    return ret;
end
		
--[Comment]
--数字分割（“,”或“.”）
--@param value
--@return 
Formatter.formatNumberWithSplit = function(value)
	local ret = "";
    if tonumber(value) == nil then
		value = 0;
	end

	local numStr = tostring(value);
	if string.len(numStr) < 4 then
		ret = numStr;
	else
	    numStr = StringKit.reverse(numStr);
	    local splitstr = "";
	    local strlen = string.len(numStr);		
	    for i = 1, strlen, 3 do
		    local str = string.sub(numStr,i, i + 2);
		    if string.len(str) == 3 and strlen - i >= 3 then
			    splitstr = splitstr .. (str..STR_COMMON_NUMBER_SPLIT_QUOTE);
		    else
			    splitstr = splitstr..str;
		    end
	    end
	    ret = StringKit.reverse(splitstr);
    end

    return ret;
end
		
Formatter.formatDENumber = function(value)
    --待实现
    return tostring(value);
end

--[Comment]	
--处理单行字符串过长,处理后Label的长度
Formatter.spliceSingleLineLongString = function(text, width, label, autoSize)
	--待实现
    return width;
end
		
--[Comment]
--处理多行字符串过长
--@return	Number	处理后Label的长度
Formatter.spliceMultiLineLongString = function(text, width, lineNum, label, autoSize)
	--待实现
    return width;
end
		
--Formatters.econdTo0M0S = function(value)
--	local second = math.modf(value, 60);
--	local minute = math.floor(value / 60);
--	local result = (minute < 10 and "0" or "")..minute..":"..(second < 10 and "0" or "")..second;
--	return result;
--end

--Formatters.secondTo0H0M = function(value)
--	local minute = math.floor( math.modf(value, 3600) / 60);
--	local hour = math.floor(value / 3600);
--	local result = hour..":"..(minute < 10 and "0" or "")..minute;
--	return result;
--end

--Formatters.secondTo0M = function(value)
--	local minute = math.floor(value / 60);
--	return (minute < 10 and "0" or "")..minute;
--end

--Formatters.secondTo0S = function(value)
--	return (second < 10 and "0" or "")..second;
--end

--Formatters.secondTo0H0M0S = function(value)
--    local second = math.modf(value, 60);
--    local minute = math.modf( math.floor(value / 60), 60);
--    local hour   = math.modf( math.floor(value /3600) ,60);
--    local result = (hour < 10 and "0" or "")..hour..":"..(minute < 10 and "0" or "")..minute..":"..(second < 10 and "0" or "")..second;
--    return result;
--end