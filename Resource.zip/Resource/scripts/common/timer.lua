require("common/kit/functionKit")
--[Comment]
--定时器
Timer = class();

--[Comment]
--构造函数，duration 延时的时间
-- count 为-1，则表示无限循环
Timer.ctor = function(self, delay, count)
    self.m_delay = delay;
    self.m_repeatCount = count or 1;
    self.m_curCount = 0;
end

--[Comment]
--析构函数
Timer.dtor = function(self)
   self:reset();
end

--[Comment]
--设置定时器回函数
Timer.setEvent = function(self, obj, func)
    self.m_callback = self.m_callback or {};
    self.m_callback.obj  = obj;
    self.m_callback.func = func;
end

--[Comment]
--内部回调函数
Timer.__onEvent = function(self)
    if self.m_repeatCount == -1 then
        if self.m_callback ~= nil then
            FunctionKit.call(self.m_callback.func, self.m_callback.obj);
        end
    elseif self.m_curCount < self.m_repeatCount then
        self.m_curCount = self.m_curCount + 1;
        if self.m_callback ~= nil and self.m_callback.func then
            FunctionKit.call(self.m_callback.func, self.m_callback.obj);
        end
    else
       self:reset();
    end
end

--[Comment]
--定时重置，此操作会关闭定时
Timer.reset = function(self)
     if self.m_interval ~= nil and self.m_interval > 0 then
        clearInterval(self.m_interval);
        self.m_interval = 0;
    end
    self.m_curCount = 0;
end

--[Comment]
--设置延迟函数
Timer.setDelay = function(self, delay)
    self.m_delay = delay;
end

--[Comment]
--设置重复次数
Timer.setRepeatCount = function(self, count)
    self.m_repeatCount = count or 1;
end

--[Comment]
--定时器启动
Timer.start = function(self)
    self:reset();
    self.m_interval = setInterval(self.__onEvent, self, self.m_delay or 1000);
end

Timer.stop = function(self)
    self:reset();
end