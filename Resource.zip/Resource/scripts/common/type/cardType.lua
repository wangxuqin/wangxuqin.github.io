CardType = class(Node, false);

CardType.ctor = function(self, cardScale, gap)
	super(self);

	self.m_cardScale = 1;
	self.m_gap = 0;
	self.m_cards = nil;
	self.m_pokerCardV = nil;

	self.m_cardScale = cardScale;
	self.m_gap = gap;

	self:setSize(PokerCard.CARD_WIDTH * self.m_cardScale * 5 + 4 * self.m_gap, PokerCard.CARD_HEIGHT * self.m_cardScale);
	self:initialize();
end

CardType.initialize = function(self)
	local w, h = self:getSize();
	local cardViewWidth = (w - PokerCard.CARD_WIDTH * self.m_cardScale) / 4;

	self.m_pokerCardV = {};
	for i=1,5 do
		local pokerCard = new(PokerCard);
		pokerCard:setAlign(kAlignLeft);
		pokerCard:setScale(self.m_cardScale);
		pokerCard:setPos(cardViewWidth * (i-1));
		self:addChild(pokerCard);
		self.m_pokerCardV[i] = pokerCard;
	end
end

CardType.draw = function(self)
	if(self.m_cards ~= nil) then
		for i=1,5 do
			self.m_pokerCardV[i]:setCard(self.m_cards[i]);
		end
	end
end

CardType.setCards = function(self, value)
	if(value == self.m_cards) then
		return;
	end
	self.m_cards = value;
	self:draw();
end
