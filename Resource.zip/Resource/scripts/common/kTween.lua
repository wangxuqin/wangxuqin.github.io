--[Comment]
--缓动库
KTween = {};

KTween.tran  = "tran";      --平移
KTween.alpha = "alpha";     --透明度
KTween.scale = "scale";     --缩放
KTween.rotate = "rotate";   --旋转
KTween.bezier = "bezier";   --贝塞尔曲线

KTween.propMap = {
    [KTween.tran]    =  "__ktweenTranSequence";
    [KTween.alpha]   =  "__ktweenAlphaSequence";
    [KTween.scale]   =  "__ktweenScaleSequence";
    [KTween.rotate]  =  "__ktweenRotateSequence";
    [KTween.bezier]  =  "__ktweenBezierSequence";
}

KTween.opPlusMap = {
    [KTween.tran]    =  KTween.tran;
    [KTween.rotate]  =  KTween.rotate;
    [KTween.bezier]  =  KTween.bezier;
}

KTween.to = function(target, duration, data)
    duration = duration or 1000;
    if target ~= nil and data ~= nil then
        local anim = nil;
        data.animType = data.animType or kAnimNormal;
        data.easeType = data.easeType or EaseType.Nil;
        data.delay    = data.delay or -1;
        KTween.__overloadDtor(target);
           
        anim = KTween.__translate(target, duration, data);
        anim = KTween.__alpha(target, duration, data) or anim;
        anim = KTween.__bezier(target, duration, data) or anim;
        anim = KTween.__scale(target, duration, data) or anim;
        anim = KTween.__rotate(target, duration, data) or anim;
        KTween.__onComplete(anim, data);
    end
end

KTween.__translate = function(target, duration, data)
    local anims = {};
    if data.x ~= nil or data.y ~= nil then
        local sequence = target:allowSequence();
        local animType = data.animType;
        local easeType = data.easeType;
        local delay    = data.delay;
        local startX   = data.startX or 0;
        local startY   = data.startY or 0;
        local endX     = data.x or 0;
        local endY     = data.y or 0;
        anims[1], anims[2] = target:addAtomPropTranslateEase(sequence,animType,easeType,duration,delay,startX,endX,startY,endY);
        anims[1].startValue = startX;
        anims[2].startValue = startY;
        anims[1].endValue   = endX;
        anims[2].endValue   = endY;
        KTween.addPropSequence(target, KTween.tran, sequence);
        KTween.addPropAnim(target, sequence, anims);
    end
    return anims[1];
end

KTween.__alpha = function(target, duration, data)
    local anims = {};
    if data.startAlpha ~= nil or data.alpha ~= nil then
        local sequence      = target:allowSequence();
        local animType      = data.animType;
        local easeType      = data.easeType;
        local delay         = data.delay;
        local startAlpha    = data.startAlpha or 1;
        local alpha         = data.alpha;
        local endX          = data.x or 0;
        local endY          = data.y or 0;
        anims[1] = target:addAtomPropTransparencyEase(sequence, animType,easeType, duration, delay, startAlpha, alpha)
        anims[1].startValue = startAlpha;
        anims[1].endValue   = alpha
        KTween.addPropSequence(target, KTween.alpha, sequence);
        KTween.addPropAnim(target, sequence, anims);
    end
    return anims[1];
end

KTween.__scale = function(target, duration, data)
    local anims = {};
    if data.scale ~= nil or data.scaleX ~= nil or data.scaleY ~= nil then
        local sequence      = target:allowSequence();
        local animType      = data.animType;
        local easeType      = data.easeType;
        local delay         = data.delay;
        local startScale    = data.startScale;
        local startScaleX   = startScale or (data.startScaleX or 1);
        local startScaleY   = startScale or (data.startScaleY or 1);
        local scale         = data.scale;
        local scaleX        = scale or (data.scaleX or 1);
        local scaleY        = scale or (data.scaleY or 1);
        local center        = data.center or kCenterDrawing;
        local centerX       = data.centerX or 0;
        local centerY       = data.centerY or 0;
        anims[1], anims[2] = target:addAtomPropScaleEase(sequence, animType,easeType, duration, delay, startScaleX, scaleX, startScaleY, scaleY, center, centerX, centerY)
        anims[1].startValue = startScaleX;
        anims[2].startValue = startScaleY;
        anims[1].endValue   = scaleX;
        anims[2].endValue   = scaleY;
        KTween.addPropSequence(target, KTween.scale, sequence);
        KTween.addPropAnim(target, sequence, anims);
    end
    return anims[1];
end

KTween.__rotate = function(target, duration, data)
    local anims = {};
    if data.angle ~= nil then
        local sequence      = target:allowSequence();
        local animType      = data.animType;
        local easeType      = data.easeType;
        local delay         = data.delay;
        local startAngle    = data.startAngle or 0;
        local angle         = data.angle;
        local center        = data.center or kCenterDrawing;
        local centerX       = data.centerX or 0;
        local centerY       = data.centerY or 0;
        anims[1]            = target:addAtomPropRotateEase(sequence, animType, easeType,duration, delay, startAngle, angle, center, centerX, centerY)
        anims[1].startValue = startAngle;
        anims[1].endValue   = angle;
        KTween.addPropSequence(target, KTween.rotate, sequence);
        KTween.addPropAnim(target, sequence, anims);
    end
    return anims[1];
end

KTween.__bezier = function(target, duration, data)
    local anims = {};
    if data.bezier ~= nil then
        local sequence      = target:allowSequence();
        local animType      = data.animType;
        local easeType      = data.easeType;
        local delay         = data.delay;
        local bezierArr     = data.bezier;
        local targetPoint   = new(Point, target:getPos());
        local pointArr      = {{x = targetPoint.x, y = targetPoint.y}};
        for i = 1, #bezierArr do
            table.insert(pointArr, bezierArr[i]);
        end
        anims[1]            = target:addAtomPropTranslateBezier(sequence, animType, easeType,duration, delay, pointArr, targetPoint);
        KTween.addPropSequence(target, KTween.bezier, sequence);
        KTween.addPropAnim(target, sequence, anims);
    end
    return anims[1];
end

KTween.__onComplete = function(anim, data)
    if anim ~= nil and data.onComplete ~= nil then
        anim:setEvent(nil, function()
            local obj = data.obj;
            if obj == nil then
                data.onComplete(data.onCompleteParams);
            else
                data.onComplete(obj, data.onCompleteParams);
            end
        end);
    end
end

--[Comment]
--将target目标对象的dtor加上释放动画的逻辑
KTween.__overloadDtor = function(target)
    if target ~= nil then
        if target.__ktweenDtor == nil then
            target.__ktweenDtor = target.dtor;
            target.dtor = function(self)
                KTween.remove(self);
                self:__ktweenDtor();
            end
        end
    end
end


--[Comment]
--移除掉动画
--prop为空，移除所有属性动画，prop不为空，移除指定属性动画;
KTween.remove = function(target, prop)
    if target ~= nil then
        if prop ~= nil then
            KTween.__removeProp(target, prop)
        else
            for prop,value in pairs(KTween.propMap) do
                KTween.__removeProp(target, prop);
            end
        end
    end
end

KTween.__removeProp = function(target, prop)
    if target ~= nil then
        if prop ~= nil then
            local propSequence = KTween.propMap[prop];
            if propSequence ~= nil and target[propSequence] ~= nil then
                for i = 1, #target[propSequence] do
                    local sequence  = target[propSequence][i]
                    target:removeAtomPropEase(sequence);
                    target["__ktweenSequenceAnim"][sequence] = nil;
                end
                target[propSequence] = {}
            end
        end
    end
end


KTween.addPropSequence = function(target, prop, sequence)
    if target ~= nil then
        local propSequence = KTween.propMap[prop];
        if propSequence ~= nil then
            target[propSequence] = target[propSequence] or {};
            table.insert(target[propSequence], sequence);
        end
    end
end

KTween.addPropAnim = function(target, sequence, anims)
    if target ~= nil then
        target["__ktweenSequenceAnim"] = target["__ktweenSequenceAnim"] or {};
        target["__ktweenSequenceAnim"][sequence] = anims;
    end
end

KTween.getCurValue = function(target, prop)
    local curValue = {};
    local endValue = {};
    if target ~= nil then
        local propSequence = KTween.propMap[prop];
        if propSequence ~= nil and target[propSequence] ~= nil then
            for i=1, #target[propSequence] do
                local sequence = target[propSequence][i]
                local anims = target["__ktweenSequenceAnim"][sequence];
                KTween.__curValue(curValue, endValue, anims, prop);
            end
        end
    end
    return curValue, endValue;
end

KTween.__curValue = function(curValue, endValue, anims, prop)
    if anims ~= nil then
        curValue = curValue or {};
        endValue = endValue or {};
        for i = 1, #anims do
            if KTween.opPlusMap[prop] ~= nil then
                curValue[i] = (curValue[i] or 0) + anims[i]:getCurValue();
                endValue[i] = (endValue[i] or 0) + (anims[i].endValue or 0);
            else
                curValue[i] = (curValue[i] or 0) * anims[i]:getCurValue();
                endValue[i] = (endValue[i] or 0) * (anims[i].endValue or 0);
            end
        end 
    end
end