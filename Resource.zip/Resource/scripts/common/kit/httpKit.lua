--[Comment]
--http工具类
--提供一系列简化http操作的方法
HttpKit = {};

--将表转换成http的post数据
HttpKit.httpTable2Param = function(t)
    local str = nil;
    local ret = {};
    if t ~= nil then
        for key, value in pairs(t) do
            table.insert(ret, (key .."="..HttpKit.__table2JsonString(value)));
        end  
    end
    str = table.concat(ret, "&");
    return str;
end

HttpKit.__table2JsonString = function(t)
    return t;
end