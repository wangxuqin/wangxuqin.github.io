--[Comment]
--这类用于对一些数字进行操作
NumberKit = {}

--[Comment]
--返回指定位数的浮点数函数
NumberKit.toFixed = function(value, len)
    local ret = value;
    if len == nil or len < 0 then
        len = 2;
    end
    if value ~= nil and type(value) == "number" then
        local arr = StringKit.split(tostring(value), ".");
        if arr ~= nil and #arr > 0 then
            local intValue = arr[1];
            if arr[2]~= nil then
               local decimalValue = NumberKit.__toFixed(arr[2], len);
               if decimalValue ~= nil then
                    if string.len(decimalValue) == 0 then
                        ret = tonumber(intValue);
                    elseif string.len(decimalValue) > 0 then
                        ret = tonumber(intValue.."."..decimalValue);
                    end
               end
            end
        end
    end
    return ret;
end

NumberKit.__toFixed = function(decimal, len)
    local ret = "";
    if len == 0 then
    elseif string.len(decimal) < len then
        local zeroLen = len - string.len(decimal);
        ret = decimal;
        for i = 1, zeroLen do
            ret = ret.."0";
        end
    else
        ret = string.sub(decimal, 1, len);
    end
    return ret;
end