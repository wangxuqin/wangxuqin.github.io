--[Comment]
--经验相关工具类
ExpKit = {};
ExpKit.levelXmlList = nil;
ExpKit.levelMax = nil;
		
ExpKit.initialize = function()
    ExpKit.levelXmlList = STR_XML_RESOURCE_LEVEL_LIST;
    ExpKit.levelMax = #STR_XML_RESOURCE_LEVEL_LIST;
end
		
--[Comment]
--根据经验值获得头衔
--@param exp 经验值
ExpKit.getTitleByExp = function(exp)
    if ExpKit.levelMax == nil then
        ExpKit.initialize();
    end
    local title = nil;
    local index = 0;
    for i = 1, ExpKit.levelMax do
        index = i;
	    if exp < ExpKit.levelXmlList[i].c then
		    break;
        end
    end
    if exp <= 0 then
	    index = 1;
    end
    title = levelXmlList[index].b;
    return title;
end
		
--[Comment]
--根据经验值获得等级
--@param exp 经验值
--@return 等级
ExpKit.getLevelByExp = function(exp)
    if ExpKit.levelMax == nil then
        ExpKit.initialize();
    end
	local level = 0;
	local index = 0;
    for i = 1, ExpKit.levelMax do
		index = 1;
        if exp < ExpKit.levelXmlList[i].c then
			break;
		end
	end
	level = index;
	if exp <= 0 then
		level = 1;
	end
	return level;
end

--[Comment]
--根据经验获取等级进度百分比值
--@param exp
--@return 0 - 99 的百分比值
ExpKit.getLevelProgressPercent = function(exp)
    if ExpKit.levelMax == nil then
        ExpKit.initialize();
    end
	local ret = 100;
    local level = ExpKit.getLevelByExp(exp);
    if level < ExpKit.levelMax then
	    local thisLevelExp = levelXmlList[level - 1].c;
	    local nextLevelExp = levelXmlList[level].c;
	    ret = math.floor((exp - thisLevelExp) * 100 / (nextLevelExp - thisLevelExp));
    end
    return ret;
end
		
ExpKit.getLevelProgressLabel = function(exp)
    if ExpKit.levelMax == nil then
        ExpKit.initialize();
    end
    local ret = "0/0";
    local level = ExpKit.getLevelByExp(exp);
    if level < ExpKit.levelMax then
        local thisLevelExp = levelXmlList[level - 1].c;
        local nextLevelExp = levelXmlList[level].c;
        ret = (exp - thisLevelExp).."/"..(nextLevelExp - thisLevelExp);
    end
    return ret;
end