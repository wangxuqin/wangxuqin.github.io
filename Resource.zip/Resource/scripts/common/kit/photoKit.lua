--[Comment]
--头像工具类
PhotoKit = {};

PhotoKit.__photoPath = "userinfo/imgface_";

--[Comment]
--获取默认头像url
PhotoKit.getDefaultPhotoUrl = function(url)
    url = (url and (type(url) == "string" or type(url) == "number")) and url or 0;
    return PhotoKit.__photoPath..url..".jpg";
end

--[Comment]
--获取玩家图片链接
PhotoKit.getPhotoURL = function(img)
    local url = img or "";
    if tonumber(img) ~= nil then
        url = PhotoKit.getDefaultPhotoUrl(img);
    end
    return url;
end

--[Comment]
--获取玩家本身的图片链接
PhotoKit.getSelfPhotoURL = function()
    local userData = Model.getData(ModelKeys.USER_DATA);
    local url = "";
    if userData ~= nil then
        if tonumber(userData.s_picture) ~= nil then
            url = PhotoKit.getDefaultPhotoUrl(userData.s_picture);
        else
            local loginType = CookieService.getString(CookieKeys.LOGIN_TYPE);
	        if loginType == LoginTypes.LOGIN_TYPE_FACEBOOK then
		        url = userData.s_picture .. "?width=100&height=100";
	        else
		        url = userData.b_picture;
	        end
        end
    end
    return url;
end