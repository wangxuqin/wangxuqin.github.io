--[Comment]
--这个类用于简化一些提示操作
TopTipKit = {};

TopTipKit.badNetworkHandler = function()
    EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.SHOW_TOP_TIP, STR_COMMON_BAD_NETWORK);
end