StringKit = {};

--[Comment]
--将字符串str中"{0}"替换成字符串sub
StringKit.substitute = function(str,...)
    local ret = str;
    if str ~= nil then
       for i = 1, #arg do
            ret = string.gsub(ret, "{"..(i - 1).."}", tostring(arg[i]));
        end
    end
   return ret;
end

--[Comment]
--字符串分割，默认使用"."作为分隔符
StringKit.split = function(str, sep)
    sep = sep or "."
    local t={} ; i=1
    for str in string.gmatch(str, "([^"..sep.."]+)") do
            t[i] = str
            i = i + 1
    end
    return t
end

--[Comment]
--数组拼接
StringKit.join = function(t, sep)
    sep = sep or "."
    local str = "";
    if t ~= nil then
        for i = 1, #t do
            if type(t[i]) == "table" then
                str = str .. sep .. "{" .. StringKit.join(t[i], sep) .."}";
            else
                str = str .. sep..tostring(t[i]);
            end
        end
    end
    return str;
end

--[Comment]
--字符串反转
StringKit.reverse = function(str)
    local ret = str;
    if str ~= nil then
        local arr = StringKit.toArray(str);
        for i = 1, #arr / 2 do
            arr[i], arr[#arr - i + 1] = arr[#arr - i + 1], arr[i];
        end
        ret = StringKit.join(arr, "");
    end
    return ret;
end

--[Comment]
--将字符串转化为数组
StringKit.toArray = function(str)
    local arr = {};
    if str ~= nil then
        local len = string.len(str);
        for i = 1, len do
            local sub = string.sub(str, i, i);
            if sub ~= nil then
                table.insert(arr, sub)
            end
        end
    end
    return arr;
end

--[Comment]
-- 去除string中的所有空格
-- @param s：要处理的字符串
-- return 返回处理后的string
StringKit.trim = function(s)
    if not s then
        return s;
    end
    local a = string.gsub(s," ","");
    return a;
end

--[Comment]
-- 计算中英文混合字符串的长度(空格算一个字符)，原因：由于string.len()方法，中文字符占3个长度
-- @param s: 中英文混合字符串
-- return len: 总长度，enLen: 英文(包括数字，字母，英文符号，空格)所占长度，chLen: 中文所占长度
StringKit.len = function(s)
    if s == nil then
        return 0,0,0;
    end
    local n = string.len(s);
    local a,b = string.gsub(s,"[%a%d%p%s]","");
      
    local m = string.len(a)/3;
      
    return m+b,b,m;
end

--[Comment]
-- 判断是否为邮箱
StringKit.isEmail = function (str )

    if string.len(str or "") < 6 then return false end 
     local b,e = string.find(str or "", '@') 
     local bstr = "" 
     local estr = "" 
     if b then 
         bstr = string.sub(str, 1, b-1) 
         estr = string.sub(str, e+1, -1) 
     else 
         return false 
     end 
  
     -- check the string before '@' 
     local p1,p2 = string.find(bstr, "[%w_]+") 
     if (p1 ~= 1) or (p2 ~= string.len(bstr)) then return false end 
      
     -- check the string after '@' 
     if string.find(estr, "^[%.]+") then return false end 
     if string.find(estr, "%.[%.]+") then return false end 
     if string.find(estr, "@") then return false end 
     if string.find(estr, "[%.]+$") then return false end 
  
     _,count = string.gsub(estr, "%.", "") 
     if (count < 1 ) or (count > 3) then 
         return false 
     end 
  
     return true
end

--[Comment]
--验证手机号码
StringKit.checkPhoneNumValid = function( phoneNumber )
	local beginIndex, endIndex = string.find(phoneNumber, "%D");
	local n1,n2 = string.find(phoneNumber,"1");
	local valid = true;
	if (endIndex and endIndex > 1) or (not n1 ) or n1 ~= 1 then
		valid = false;
		tips = GameString.get("str_phone_format_error");
		AlarmNotice.getInstance():setText(tips):setButtonType(AlarmNotice.S_BUTTONTYPE.NONE):show();

		return valid;	
	end

	if phoneNumber and string.len(phoneNumber) > 11 then
		phoneNumber = string.sub(phoneNumber, 1, 11);
	elseif phoneNumber and string.len(phoneNumber) < 11 then
		valid = false;
		
		tips = GameString.get("str_phone_format_error");
		AlarmNotice.getInstance():setText(tips):setButtonType(AlarmNotice.S_BUTTONTYPE.NONE):show();
		return valid;
	end

    return valid;
end