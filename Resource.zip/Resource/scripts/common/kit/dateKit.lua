--[Comment]
--日期类
--提供一系列常用的日期格式化操作
DateKit = {};

-- 将long转换成:xx年xx月xx日xx时xx分xx秒格式
DateKit.getTimeYMDHMS = function(time)
    local days = "";
    if time and tonumber(time) then
        local timeNum = tonumber(time);
        timeNum = math.abs(timeNum);
        local str = "%Y" .. GameString.get("str_tookit_yearStr") .. "%m" .. GameString.get("str_tookit_mouthStr") .. "%d" .. GameString.get("str_tookit_dayStr") .. "%H" .. string_get("hourStr") .. "%M" .. string_get("minStr") .. "%S".. string_get("secStr");
        days = os.date(str,timeNum);
    end
    return days;
end

-- 将long转换成:xx月xx日xx:xx:xx格式
DateKit.getTimeMDHMS = function(time)
    local days = "";
    if time and tonumber(time) then
        local timeNum = tonumber(time);
        timeNum = math.abs(timeNum);
        local str = "%m" .. GameString.get("str_tookit_mouthStr") .. "%d" .. GameString.get("str_tookit_dayStr") .. "%H" .. ":%M" .. ":%S";
        days = os.date(str,timeNum);
    end
    return days;
end

-- 将long转换成:xx年xx月xx日格式
DateKit.getTimeYMD = function(time)
    local days = "";
    if time and tonumber(time) then
        local timeNum = tonumber(time);
        timeNum = math.abs(timeNum);
        local str = "%Y" .. GameString.get("str_tookit_yearStr") .. "%m" .. GameString.get("str_tookit_mouthStr") .. "%d" .. GameString.get("str_tookit_dayStr");
        days = os.date(str,timeNum);
    end
    return days;
end

-- 将long转换成:xx年/xx月/xx日/格式
DateKit.getTimeYMDFormat = function(time)
    local days = "";
    if time and tonumber(time) then
        local timeNum = tonumber(time);
        timeNum = math.abs(timeNum);
        local str = "%Y" .. "/" .. "%m" .. "/" .. "%d";
        days = os.date(str,timeNum);
    end
    
    return days;
end

-- 将long转换成:xx月xx日xx年格式
DateKit.getTimeMDY = function(time)
    local days = "";
    if time and tonumber(time) then
        local timeNum = tonumber(time);
        timeNum = math.abs(timeNum);
        local str = "%m/" .. "%d/" .. "%Y";
        days = os.date(str,timeNum);
    end
    return days;

end

-- 将long转换成:xx日xx月xx年格式
DateKit.getTimeDMY = function(time)
    local days = "";
    if time and tonumber(time) then
        local timeNum = tonumber(time);
        timeNum = math.abs(timeNum);
        local str = "%d." .. "%m." .. "%Y";
        days = os.date(str,timeNum);
    end
    return days;

end

--[Comment]
--获取当前时间:时：分
DateKit.getCurrentTime = function()
    local currentTime = "";
    local hour = os.date("%H");
    local minutes = os.date("%M");
    currentTime = hour..":".. minutes;

    return currentTime;
        
end

--[Comment]
--秒转换为 时：分：秒
DateKit.secondTo0H0M0S = function (value)
    local second = value % 60;
	local minute = math.modf(value / 60)% 60;
	local hour   = math.modf(value /3600)% 60;

    local result = (hour < 10 and "0" or "") .. hour .. ":" .. (minute < 10 and "0" or "") .. minute .. ":" .. (second < 10 and "0" or "") .. second ;
    return result;

end

-- 拆分时间：00时:00分:00秒
DateKit.skipTime = function(time)
    local times = nil;
    if time then
        local timeNum = tonumber(time);
        if timeNum and timeNum > 0 then
            local hour = os.date("*t",timeNum).hour - 8;
            local min  = os.date("*t",timeNum).min;
            local sec  = os.date("*t",timeNum).sec;

            hour = string.format("%02d",hour);
            min = string.format("%02d",min);
            sec = string.format("%02d",sec);
            times = hour .. ":" .. min .. ":" .. sec;
        end
    end
    return times or string_get("initTimeStr");
end

-- 拆分时间：00:00  时:分
DateKit.skipTimeHM = function(time)
    local times = nil;
    if time then
        local timeNum = tonumber(time);
        if timeNum and timeNum > 0 then
            local hour = os.date("*t",timeNum).hour - 8;
            local min  = os.date("*t",timeNum).min;

            hour = string.format("%02d",hour);
            min = string.format("%02d",min);
            times = hour .. ":" .. min;
        end
    end
    return times or string_get("initTimeStr");
end

-- 拆分时间：00:00 (分，秒)
DateKit.skipTimeMS = function(time)
    local times = nil;
    if time then
        local timeNum = tonumber(time);
        if timeNum and timeNum > 0 then
            local sec = timeNum % 60;
            local min = (timeNum - sec) / 60;
            local hour = nil;
            
            if min > 60 then
                hour = (min - (min % 60)) / 60;
                min = min % 60;
            end

            min = string.format("%02d",min);
            sec = string.format("%02d",sec);

            times = min..":"..sec;
            if hour then
                hour = string.format("%02d",hour);
                times = hour..":"..times;
            end
        end
    end
    return times or "00:00"
end

--输入两个时间的秒数，获取两个时间差
--输出格式time = {sec=0, min=0, hour= 0, day=1, month=0, year=0}
DateKit.timeDiff = function(long_time,short_time)
    local n_short_time = os.date('*t',short_time);
    local n_long_time  = os.date('*t',long_time);
    local carry = false;
    local diff = {};

    local colMax = {60,60,24,os.date('*t',os.time{year=n_short_time.year,month=n_short_time.month+1,day=0}).day,12,0}  
    n_long_time.hour = n_long_time.hour - (n_long_time.isdst and 1 or 0) + (n_short_time.isdst and 1 or 0) -- handle dst  
    for i,v in ipairs({'sec','min','hour','day','month','year'}) do  
        diff[v] = n_long_time[v] - n_short_time[v] + (carry and -1 or 0)  
        carry = diff[v] < 0  
        if carry then  
            diff[v] = diff[v] + colMax[i]  
        end  
    end

    return diff  
end 