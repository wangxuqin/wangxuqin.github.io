--[Comment]
--����������ڰ�Button��onClickEvent
EventListKit = {};

EventListKit.addEventList = function(target, arr)
    if arr ~= nil then
        for i = 1, #arr do
            local obj       = arr[i][1];    --�¼�Դ
            local onEvent   = arr[i][2];    --�¼���������
            local onHandle  = arr[i][3];    --�¼���������
            if obj ~= nil and onEvent ~= nil and onHandle ~= nil then
                obj[onEvent](obj, target,onHandle);
            end
        end
    end
end

EventListKit.removeEventList = function(evtTarget, arr)
    if arr ~= nil then
        for i = 1, #arr do
            local obj       = arr[i][1];
            local onEvent   = arr[i][2];
            if obj ~= nil and onEvent ~= nil then
                obj[onEvent](obj, nil,nil);
            end
        end
    end
end