--[Comment]
--文件工具类
--这个类提供一系列常用的文件操作
FileKit = {};


-- 用于判断下载路径下的图片是否存在
FileKit.isImgExist = function(ImgName)
    if not ImgName then
        return;
    end

    local name = ImgName..".png";
    local imgPath = System.getStorageImagePath() .."/";
    local path = imgPath..name;

    local fp = io.open(path, "r");
    if name ~="" and fp then
        io.close(fp);
        return name;
    end
end

--[Comment]
--判断文件是否存在
--暂时只能判断图片是否存在
FileKit.isFileExist = function(file)
	local img = new(Image, file);
	local w,h = img:getSize();
	delete(img);
	return w > 0 and h > 0;
end
