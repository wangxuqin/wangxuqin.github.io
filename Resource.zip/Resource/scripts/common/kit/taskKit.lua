TaskKit = {};
TaskKit.__task = {};
TaskKit.schedule = function(delay, obj, func, times)
    times = (times == nil) and 1 or times;
    if func ~= nil then
        local anim = new(AnimDouble, kAnimRepeat, 0, 0, delay, -1);
        TaskKit.__task[anim]=anim;
        TaskKit.__task[anim]["times"] = times;
        TaskKit.__task[anim]["time"] = 0;
        TaskKit.__task[anim]:setEvent(obj, function(...)
            if TaskKit.__task[anim] ~= nil then
                TaskKit.__task[anim]["time"] = TaskKit.__task[anim]["time"] + 1;
                if  TaskKit.__task[anim]["time"] >= TaskKit.__task[anim]["times"] then
                    TaskKit.__task[anim]["times"] = nil;
                    TaskKit.__task[anim]["time"] = nil;
                    TaskKit.__task[anim]:dtor();
                    TaskKit.__task[anim] = nil;
                end
            end
            func(...);
        end);
    end
end