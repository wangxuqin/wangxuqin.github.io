TextFormatKit = {};
TextFormatKit.LARGE_FONT_SIZE = 1;
TextFormatKit.MIDDLE_FONT_SIZE = 2;
TextFormatKit.SMALL_FONT_SIZE = 3;
		
TextFormatKit.TEXT_RENDER_TYPE_TEXTFIELD = 0;
TextFormatKit.TEXT_RENDER_TYPE_BITMAP = 1;
TextFormatKit.TEXT_RENDER_TYPE_TLF = 2;
TextFormatKit.TEXT_RENDER_TYPE_BITMAP_AND_TLF = 3;
		
TextFormatKit.TEXT_DIRECTION_RTL = "rtl";
TextFormatKit.TEXT_DIRECTION_LTR = "ltr";
		
TextFormatKit.LIGHT_TEXT_COLOR = 0xf5F5F5;
TextFormatKit.DARK_TEXT_COLOR = 0x1a1a1a;
TextFormatKit.SELECTED_TEXT_COLOR = 0xff9900;
TextFormatKit.DISABLED_TEXT_COLOR = 0x999999;
TextFormatKit.fontNames = "����";--"Helvetica Neue, Helvetica, Roboto, Arial, _sans";