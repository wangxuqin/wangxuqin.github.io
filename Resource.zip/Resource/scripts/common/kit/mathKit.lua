--[Comment]
--数学工具类
MathKit = {};

--[Comment]
--取余
MathKit.mod = function(a, b)
    return a - math.floor(a/b)*b;
end

--[Comment]
--求n的阶乘
MathKit.factorial = function(n)
    if(n <= 0) then return 1; end
    if(n == 1) then return 1;
    elseif(n == 2) then return 2;
    elseif(n == 3) then return 6;
    elseif(n == 4) then return 24;
    elseif(n == 5) then return 120;
    elseif(n == 6) then return 720;
    else
        return (n-6) * MathKit.factorial(6);
    end
	return r;
end

--[Comment]
--求组合数c(m, n)
MathKit.combine = function(m, n)
	if(n > m) then return 0; end
	return MathKit.factorial(m) / (MathKit.factorial(n)*MathKit.factorial(m-n));
end


--[Comment]
--计算贝塞尔曲线的一般形式
MathKit.bezier = function(allPoints, t)
	local n = #allPoints - 1;
    local ret = {x=0,y=0};
    for i=0,n do
		local C = MathKit.combine(n, i);
		local A = math.pow(1-t, n-i) * math.pow(t, i);
		ret.x = ret.x + allPoints[i+1].x * C * A;
		ret.y = ret.y + allPoints[i+1].y * C * A;
	end
	return ret;
end