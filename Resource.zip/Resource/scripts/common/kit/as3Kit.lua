--[Comment]
--AS3工具类
--这个类提供了一些与AS3类似的函数
As3Kit = {};

--[Comment]
--模仿AS的写法
As3Kit.layoutCenter = function(srcPos, srcWidth, descWidth)
    return srcPos + math.modf((srcWidth - descWidth) * 0.5);
end

--[Comment]
--把节点大小还原成原图片大小
As3Kit.reAdjustSize  = function(img)
    local res = img.m_res;
    if(res) then
        img:setSize(res:getWidth(), res:getHeight());
    end
end


--[Comment]
--设置节点缩放比
As3Kit.setImageScale = function(img, scaleX, scaleY)
    local res = img.m_res;
    local newX = nil;
    local newY = nil;
    if(scaleX) then
        newX = res:getWidth() * scaleX;
    end
    if(scaleY) then
        newY = res:getHeight() * scaleY;
    end
    img:setSize(newX, newY);
end

--[Comment]
--获取节点的X
As3Kit.getNodeX = function(node)
    local x,y = node:getPos();
    return x;
end

--[Comment]
--获取节点的Y
As3Kit.getNodeY = function(node)
    local x,y = node:getPos();
    return y;
end

--[Comment]
--获取节点的宽
As3Kit.getNodeWidth = function(node)
    local w,h = node:getSize();
    return w;
end

--[Comment]
--获取节点的高
As3Kit.getNodeHeight = function(node) 
    local w,h = node:getSize();
    return h;
end

--[Comment]
--从一个数组中删除第i个元素
--返回该元素，余下元素往前推
As3Kit.deleteAt = function(t, i)
    local j = i;
    local ret = t[i];
    while(t[j+1]) do
        t[j] = t[j+1];
        j = j + 1;
    end
    t[j] = nil;
    return ret;
end

--[Comment]
--往数组中的位置i插入元素
--如果i<=0则插到最前面，如果i>n则插到末尾
As3Kit.insertAt = function(t, i, value)
    if(i <= 0) then
        i = 1;
    elseif(i > #t) then
        i = #t + 1;
    end
    --位置i的元素往后推
    for j=#t,i,-1 do
        t[j+1] = t[j];
    end
    t[i] = value;
end