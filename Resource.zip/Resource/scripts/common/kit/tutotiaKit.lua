--[Comment]
--新手帮助工具
TutotiaKit = {}

--[Comment]
--是否在新手教程
TutotiaKit.isTutotia = function()
    local ret = Model.getData(ModelKeys.USER_IN_TUTOTIA) ~= nil and 
                Model.getData(ModelKeys.USER_IN_TUTOTIA).isStart == true;
    return ret;
end