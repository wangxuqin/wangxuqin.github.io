require("core/constants");
require("core/object");
require("common/log");
require("libs/zzBase64");

ToolKit = {};

ToolKit.getIndex = function()
    if not ToolKit.s_index then
        ToolKit.s_index = 0;
    end
    return function() ToolKit.s_index = ToolKit.s_index + 1; return ToolKit.s_index end
end


ToolKit.setDebugName = function( obj , name)
   if obj then
        obj:setDebugName(name);
   end 
end

--[Comment]
--计算MD5码
ToolKit.md5 = function(str)
    local ret = nil;
    if str ~= nil then
        local MD5 = require 'libs/md5';
        ret = MD5.sumhexa(str)   -- returns a hex string
    end
    return ret;
end

--[Comment]
--Base64编码
ToolKit.base64_encode = function(str)
    local ret = nil;
    if str ~= nil then
        ret = ZZBase64.encode(str);
    end
    return ret;
end

--[Comment]
--Base64解码
ToolKit.base64_decode = function(str)
    local ret = nil;
    if str ~= nil then
        ret = ZZBase64.decode(str);
    end
    return ret;
end