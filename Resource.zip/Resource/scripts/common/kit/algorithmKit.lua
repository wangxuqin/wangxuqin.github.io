
AlgorithmKit = {};

--[Comment]
--��������,��������table
AlgorithmKit.quickSort = function(list, obj, func)
    return AlgorithmKit.quick_sort(list, 1, #list, obj, func);
end

--[Comment]
--��������,����left - right
AlgorithmKit.quick_sort = function (list, left, right, obj, func)
    if left < right then
        local i = left;
        local j = right;
        local pivot = list[left];
        while i < j do
        --func(list[right], pivot)) == -1 -> С��
        --func(list[right], pivot)) == 0  -> ����
        --func(list[right], pivot)) == 1  -> ����
            while i < j and (func(obj, list[j], pivot) == 1 or func(obj, list[j], pivot) == 0) do
                j = j - 1;
            end
            if i < j then
                list[i] = list[j];
                i = i + 1;
            end
            while i < j and (func(obj, list[i], pivot) == -1) do
                i = i + 1;
            end
            if i < j then
                list[j] = list[i];
                j = j - 1;
            end
        end
        list[i] = pivot;  
        AlgorithmKit.quick_sort(list, left, i - 1, obj, func); 
        AlgorithmKit.quick_sort(list, i + 1, right, obj, func);  
    end
    return list;
end