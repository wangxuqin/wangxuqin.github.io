TableKit = {};

TableKit.copy = function(t)
    if t == nil then
        return {};
    end
    if type(t) ~= "table" then
        return t;
    end

    local ret = {}; 
    for k,v in pairs(t) do
        ret[k] = TableKit.copy(v);
    end

    return ret;
end

--[Comment]
-- 打印表格
TableKit.printTable = function(data,cstring)
    if data == nil then 
        Log.d("print data is nil");
    end
    if cstring == nil then
        cstring = "";
    end
    local cs = cstring .. " ";
    Log.d(cstring .."{");
    if(type(data) == "table") then
        for k, v in pairs(data) do
            Log.d(cs .. tostring(k) .. " = "..tostring(v));
            if(type(v) == "table") then
                TableKit.printTable(v,cs);
            end
        end
    else
        Log.d(cs .. tostring(data));
    end
    Log.d(cstring .."}");
end