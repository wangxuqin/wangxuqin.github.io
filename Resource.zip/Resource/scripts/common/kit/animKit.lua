--[Comment]
--动画工具类
AnimKit = {};

--[Comment]
--对一个节点进行贝塞尔运动
AnimKit.doBezier = function(node, allPoints, duration, objOnEnd, funcOnEnd, delay)
    delay = delay or 0;
    local animValue = new(AnimDouble, kAnimNormal, 0, 1, duration, delay);
    local anim = new(AnimInt, kAnimRepeat, 0, 1, 0, delay);
    local function onFrame(node)
        local bEnd = false;
        local t = animValue:getCurValue();
        if(t >= 1) then
            t = 1;
            bEnd = true;
        end
        local pos = MathKit.bezier(allPoints, t);
        node:setPos(pos.x, pos.y);
        if(bEnd) then
            delete(anim);
            delete(animValue);
            if(funcOnEnd) then
                funcOnEnd(objOnEnd);
            end
        end
    end
    anim:setEvent(node, onFrame);
end

--[Comment]
--TweenLite.to
AnimKit.tweenTo = function(obj, duration, data)
    local delay = data.delay or 0;
    local anim = new(AnimInt, kAnimRepeat, 0, 1, 0, delay);
    local animValue = new(AnimDouble, kAnimNormal, 0, 1, duration, delay);
    local startData = {};
    for k,v in pairs(obj) do
        startData[k] = v;
    end
    local function onFrame(obj)
        local bEnd = false;
        local t = animValue:getCurValue();
        if(t >= 1) then
            t = 1;
            bEnd = true;
        end
        for k,v in pairs(data) do
            if(type(v) == "number" and obj[k] and data[k]) then
                obj[k] = startData[k] + (data[k] - startData[k]) * t;
            end
        end
        if(bEnd) then
            delete(anim);
            delete(animValue);
            if(data.onComplete) then
                data.onComplete(data.obj);
            end
        end
    end
    anim:setEvent(obj, onFrame);
end