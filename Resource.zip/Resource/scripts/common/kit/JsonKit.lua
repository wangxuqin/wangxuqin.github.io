require("libs/json");
--[Comment]
--JSON工具类，提供JSON的安全解析编码操作
JsonKit = {};

--[Comment]
--解析JSON，
--flag 是否解析成功标识
--ret 解析后的对象
JsonKit.decode = function(str)
    local ret = nil;
    flag = pcall(function() ret = json.decode(str) end);
    return flag, ret;
end

--[Comment]
--编码JSON
--flag 是否编码成功标识
--ret 编码后的JSON String
JsonKit.encode = function(t)
    local str = nil;
    flag = pcall(function() str = json.encode(t) end);
    return flag, str;
end