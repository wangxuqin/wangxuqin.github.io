GlowKit = {};

GlowKit.createStartGlowFunc = function(node)
    if typeof(node, DrawingBase) == true then
        node.startGlow = function(node)
            node.m_current = 10;
            KTween.to(node,500,{startAlpha = 1, alpha = 0.5, delay = 500, animType = kAnimLoop, obj = node, onComplete = function(target, param)
                   if not (target.m_current > 0) then
                        KTween.remove(target);
                   end
                   target.m_current = target.m_current - 1;
            end});
        end
    end
end

GlowKit.createStopGlowFunc = function(node)
    if typeof(node, DrawingBase) == true then
        node.stopGlow = function(node)
             node.m_current = 0;
        end
    end
end