--[Comment]
--互动道具工具类
PropKit = {};
PropKit.IMG_PATH    = "room/hddj/hddj_";                --图片路径
PropKit.ANIM_PATH   = "atomAnimTable/hddj/anim_hddj_";  --动画路径
PropKit.MAX = 13;   --道具类型
PropKit.getImage = function(index)
    local img = nil;
    if index > 0 and index <= PropKit.MAX then
        local path = PropKit.IMG_PATH .. index .. ".png";
        img = new(Image, path);
    end
    return img;
end

PropKit.getAnimPath = function(index)
    local path = "";
    if index > 0 and index <= PropKit.MAX then
        path = PropKit.ANIM_PATH .. index;
    end
    return path;
end

PropKit.PROP_WH_MAP = {
    [1]  = {width = 89, height = 72};
    [2]  = {width = 210,height = 109};
    [3]  = {width = 80, height = 77};
    [4]  = {width = 178,height = 108};
    [5]  = {width = 163,height = 155};
    [6]  = {width = 77, height = 76};
    [7]  = {width = 73, height = 126};
    [8]  = {width = 109,height = 109};
    [9]  = {width = 94, height = 90};
    [10] = {width = 101,height = 53};
    [11] = {width = 101,height = 106};
    [12] = {width = 145,height = 146};
    [13] = {width = 149,height = 110};
}