TableLimit = {};	

--[Comment]
--无限制 	
TableLimit.UNLIMITED        = 0;
		
--[Comment]
--限制坐下 	
TableLimit.SIT_DOWN_LIMITED = 1;
		
--[Comment]
--限制进入 		
TableLimit.ACCESS_LIMITED   = 2;

--[Comment]
--在坐下前检查是否可以坐下
TableLimit.checkPreSitdown = function(tableLevel)
    local ret = true;
    local userData = Model.getData(ModelKeys.USER_DATA);
    if tableLevel == LoginSuccData.ROOM_LEVEL_NEWER then
        if userData.CANCEL_LEVEL_LIMIT ~= nil and userData.CANCEL_LEVEL_LIMIT > 0 then
            EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, {
				["message"]=STR_ROOM_ROOM_PREVENT_STEAT_STORE_LEVEL_LIMIT, 
				["confirm"]=STR_COMMON_CONFIRM,
			});
            ret = false;				
		end
    end
    return ret;
end
		
TableLimit.check = function(tableLevel, tableType, dialog)
    local ret = TableLimit.UNLIMITED;
    local userData = Model.getData(ModelKeys.USER_DATA);
    if tableType ~= LoginSuccData.ROOM_TYPE_NORMAL then
        ret = TableLimit.UNLIMITED;
    else
        if tableLevel == LoginSuccData.ROOM_LEVEL_NEWER then
	        if userData.CANCEL_MONEY ~= nil and userData.CANCEL_MONEY < userData.totalMoney then
		        ret = TableLimit.ACCESS_LIMITED;
	        end
        elseif tableLevel == LoginSuccData.ROOM_LEVEL_PRIMARY then
	        if userData.chujichang_limit ~= nil and userData.chujichang_limit < userData.totalMoney then
		        ret = TableLimit.ACCESS_LIMITED;
	       end
        elseif tableLevel == LoginSuccData.ROOM_LEVEL_INTERMEDIATE then
        elseif tableLevel == LoginSuccData.ROOM_LEVEL_SENIOR then
	        if userData.TABLE_MONEY_LIMIT and userData.totalMoney < userData.TABLE_MONEY_LIMIT then 
		        if LocalService.currentLocaleId() == "zh_Hans" then
			        ret = TableLimit.ACCESS_LIMITED;
		        else
			        ret = TableLimit.SIT_DOWN_LIMITED;
		        end
	        end
        end
    end
    return ret;
end
		
--[Comment]
--检查是否允许进入
--@param tableType
--@return ture 允许进入	
TableLimit.checkAccess = function(tableLevel, tableType, dialog)
    tableType = tableType or LoginSuccData.ROOM_TYPE_NORMAL;
    dialog = (dialog == nil) and true or dialog;
	local result = TableLimit.check(tableLevel, tableType, dialog) ~= TableLimit.ACCESS_LIMITED;	
	if dialog and not result then
		TableLimit.openDialog(tableLevel);
	end
	return result;
end
		
--[Comment]
--检查是否允许坐下
-- @param tableType
-- @return true 允许坐下
TableLimit.checkSitDown = function(tableLevel, tableType, dialog)
    tableType = tableType or LoginSuccData.ROOM_TYPE_NORMAL;
    dialog = (dialog == nil) and true or dialog;
    local result = TableLimit.check(tableLevel, tableType, dialog) ~= TableLimit.SIT_DOWN_LIMITED;	
	if dialog and not result then
		TableLimit.openDialog(tableLevel);
	end
	return result;
end
		
TableLimit.dialogCallback = function(self, value)
	if value == DialogCallback.CONFIRM then
		--CommonFunction.playNow();
	end
end
		
TableLimit.openDialog = function(tableLevel)
    local userData = Model.getData(ModelKeys.USER_DATA);
    local message = nil;
    
    if tableLevel == LoginSuccData.ROOM_LEVEL_NEWER then
       message = StringKit.substitute(STR_COMMON_TOO_RICH, Formatter.formatBigNumber(userData.CANCEL_MONEY));
    
    elseif tableLevel == LoginSuccData.ROOM_LEVEL_PRIMARY then
       message = StringKit.substitute(STR_COMMON_TOO_RICH, Formatter.formatBigNumber(userData.chujichang_limit));
    
    elseif tableLevel == LoginSuccData.ROOM_LEVEL_INTERMEDIATE then
    elseif tableLevel == ROOM_LEVEL_SENIOR then
       message = StringKit.substitute(STR_COMMON_TOO_POOR, Formatter.formatBigNumber(userData.TABLE_MONEY_LIMIT))
    end

    if message ~= nil then
        local param = {
            ["message"] = message;
            ["confirm"] = STR_COMMON_GO_NOW;
            ["cancel"]  = STR_COMMON_CANCEL;
            ["obj"]     = TableLimit;
            ["callback"]= TableLimit.dialogCallback;
        };
        EventDispatcher.getInstance():dispatch(UIEvent.s_event, UIEvent.s_cmd.OPEN_DIALOG, param);
    end
end