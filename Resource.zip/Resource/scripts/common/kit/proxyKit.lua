require("libs/rc4");
require("libs/json")
ProxyKit = {};
ProxyKit.proxyIp = nil;
ProxyKit.proxyIp = nil;
ProxyKit.proxyArray = nil;
ProxyKit.proxyArrayIndex = 1;

ProxyKit.goProxy = function(socket, ip, port)
    if socket ~= nil then
        local packetId = socket:writeBegin4(ServerCommand.CLI_CMD_PROXY_LOGIN, ServerCommand.CLI_CMD_PROXY_LOGIN_VER); --ʹ�ô�����¼
        socket:writeString(packetId, ip);
        socket:writeInt(packetId, port);
	    socket:writeEnd(packetId);
    end
end


ProxyKit.proxyDecrypt  = function(mtkey, token, tokenArray, userData)
	local array = nil;
	local firstKey = userData.today..userData.uid;
	token = RC4.codec(token, mtkey);
	array = json.decode(token);

	proxyIp = RC4.codec(array[#array], firstKey);
	proxyPort = tonumber(RC4.codec(array[#array - 1], proxyIp));
			
	ProxyKit.proxyArray = {}
	ProxyKit.proxyArray[1] = {};
	ProxyKit.proxyArray[1].ip   = proxyIp;
	ProxyKit.proxyArray[1].port = proxyPort;
--	if tokenArray and #tokenArray > 0 then
--		for (var i:int = 0; i < tokenArray.length; ++i)
--		{
--			tokenArray[i] = RC4.decrypt(tokenArray[i], mtkey);
--			array = JSON.parse(tokenArray[i]) as Array;
--			array = array.reverse();
--			proxyArray[i + 1] = {};
--			proxyArray[i + 1].ip = RC4.decrypt(array[0], firstKey);
--			proxyArray[i + 1].port = parseInt(RC4.decrypt(array[1], proxyArray[i + 1].ip));
--		}
--	}
--	proxyArrayIndex = 0;
end

ProxyKit.proxyChange = function(self)
end