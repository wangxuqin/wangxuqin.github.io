-- NativeWin32.lua
-- nativeEvent win32平台。
require("common/native/nativeCMD");

NativeWin32 = class();

NativeWin32.closeStartScreen = function(self)

end

NativeWin32.getAuthHead = function(self,api,key,version,mid)

end

-- 显示消息toast
NativeWin32.showToast = function(self,msg)

end

NativeWin32.upLoadErrorToUmeng = function(self,errorMsg)

end

NativeWin32.updateEventToUmen = function(self,id,msg)

end

NativeWin32.getSendFeedBack = function(self)

end

NativeWin32.guestLogin = function(self)
	-- temp for login
	EventDispatcher.getInstance():dispatch(Event.Call,HallController.s_win32Call);
end

NativeWin32.qqLogin = function(self)
	-- temp for login
	EventDispatcher.getInstance():dispatch(Event.Call,HallController.s_win32Call);
end

NativeWin32.weChatLogin = function ( self )
	
end

NativeWin32.refreshGps = function(self)

end

NativeWin32.fBLogin = function(self,loginMethod,sid)

end

NativeWin32.fBLogout = function(self)

end

NativeWin32.sinaLogin = function(self,loginMethod,sid)
	-- temp for login
	EventDispatcher.getInstance():dispatch(Event.Call,HallController.s_win32Call);
end

NativeWin32.sinaLogout = function(self)

end

-- 获取Facebook好友
NativeWin32.getFacebookFriends = function(self,token)

end

--活动网络是否有效
--结果为true 网络有效
NativeWin32.getNetworkActivity = function(self) 
	return true;
end

NativeWin32.getVersion = function(self)

end

NativeWin32.openWebView = function(self,url)

end

NativeWin32.weChatShare = function(self,fileName,url,title,isCircle)
	
end

NativeWin32.sinaShare = function(self,fileName,url,title,isCircle)
	
end

--异步加载声音
NativeWin32.preloadSound = function(self,effectPath,musicPath)

end

NativeWin32.setVolume = function(self,volume)

end

-- 上传头像
-- @name 上传头像的头像名（保存图片的名称）
-- @oldName 原先头像名（需删除）
-- @url 上传url
NativeWin32.uploadImage = function(self,url,api,name)

end

-- 获得运营商
NativeWin32.getNetWorkType = function(self)
     
end

-- 获取通讯录好友
NativeWin32.getGetContacts = function(self)

end

NativeWin32.getAchievement = function(self,url)
	
end

-- 判断图片是否存在
-- imgName:图片文件名（不含路径，包含后缀）
-- ret：0：不存在；1：存在
NativeWin32.isImgExist = function(self, imgName)
	return true;
end

--判断是否能ping通某个域名
NativeWin32.canPingDnsSuccess = function ( self, url)

end

--寻找能访问的并且网络状况较好的域名来用
NativeWin32.getBestUrl = function(self, urls)

end

--此方法用于获取PHP请求api url和配置文件
NativeWin32.getDynamicDNSConfig = function(self, url, flag)

end

NativeWin32.downloadFile = function(self, url, fileType, savePath,flag)

end

-- 调用原生显示富文本
NativeWin32.showRichText = function ( self)

end

-- 调用原生隐藏富文本
NativeWin32.hideRichText = function ( self)

end

-- 显示系统消息
NativeWin32.showSysMsg = function ( self )
	
end

NativeWin32.saveGuestSitemid = function(self,sitemid)

end

-- 震动管理
NativeWin32.setVaditor = function(self,isVaditor)
	
end

-- 请求银联支付
NativeWin32.requestUnionPay = function ( self, orderId )

end

-- 请求支付宝支付
NativeWin32.requestAliPay = function ( self, chips, chipsPrice, orderId, productId, notifyUrl)
	
end

-- 检测支付宝
NativeWin32.checkAliPay = function ( self )
	
	EventDispatcher.getInstance():register(Event.Call,self,PayManager.onNativeCallDone);
end

-- debug日志记录
NativeWin32.debugLog = function ( self, msg )
	
end

-- 设置登录服务器类型
NativeWin32.setServerType = function ( self, serverType )

end

-- 获取php保存的xml 相关信息
NativeWin32.getSystemXml = function ( self, strUrl )

end

NativeWin32.screenShot = function(self, fileName)


end

NativeWin32.sendSMS = function(self, address, content)

end

NativeWin32.closeKeyBoard = function ( self )

end

NativeWin32.uploadDumpFile = function(self,json_data)

end

NativeWin32.scanQR = function(self)

end

NativeWin32.createQRcode = function(self,mid)

end

-- @param fileName 需加后缀.png
NativeWin32.saveQRcode = function(self,fileName)

end


NativeWin32.requestWeChatPay = function ( self, json_data )

end

NativeWin32.checkWeChatPay = function ( self )
	
end

NativeWin32.requestMMPay = function ( self, json_data )

end

NativeWin32.requestWoPay = function ( self, json_data )

end

NativeWin32.requestAiPay = function ( self, json_data )

end
NativeWin32.createShareQRcode = function(self,nick,mid,content,iconName, qrName, whiteName, redName)

end

NativeWin32.facebookShare = function(self,fileName,content,url)

end

NativeWin32.noticeUpdate = function(self, url)
    
end

NativeWin32.runDebugVersion = function(self)

end

NativeWin32.checkFileExists = function(self,name)

end