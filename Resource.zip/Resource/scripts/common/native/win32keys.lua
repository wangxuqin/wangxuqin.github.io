--------------------------------------------------
-- Author: GerryGuo

Win32KeyCode =
{
    KEYCODE_A = 65;
    KEYCODE_B = 66;
    KEYCODE_C = 67;
    KEYCODE_D = 68;
    KEYCODE_E = 69;
    KEYCODE_F = 70;
    KEYCODE_G = 71;
    KEYCODE_H = 72;
    KEYCODE_I = 73;
    KEYCODE_J = 74;
    KEYCODE_K = 75;
    KEYCODE_L = 76;
    KEYCODE_M = 77;
    KEYCODE_N = 78;
    KEYCODE_O = 79;
    KEYCODE_P = 80;
    KEYCODE_Q = 81;
    KEYCODE_R = 82;
    KEYCODE_S = 83;
    KEYCODE_T = 84;
    KEYCODE_U = 85;
    KEYCODE_V = 86;
    KEYCODE_W = 87;
    KEYCODE_X = 88;
    KEYCODE_Y = 89;
    KEYCODE_Z = 90;

    KEYCODE_0 = 48;
    KEYCODE_1 = 49;
    KEYCODE_2 = 50;
    KEYCODE_3 = 51;
    KEYCODE_4 = 52;
    KEYCODE_5 = 53;
    KEYCODE_6 = 54;
    KEYCODE_7 = 55;
    KEYCODE_8 = 56;
    KEYCODE_9 = 57;
};
