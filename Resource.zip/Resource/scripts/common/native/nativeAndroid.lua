-- NativeAndroid.lua
-- nativeEvent android平台。
require("common/native/nativeCMD");

NativeAndroid = class();

NativeAndroid.s_luaCallNavite = "OnLuaCall";
NativeAndroid.s_luaCallEvent = "LuaCallEvent";
NativeAndroid.s_parmPostfix = "_parm"; --参数后缀 

NativeAndroid.callNativeEvent = function(self , keyParm , data)
	if data then
		dict_set_string(keyParm,keyParm..NativeAndroid.s_parmPostfix,data);
	end
	dict_set_string(NativeAndroid.s_luaCallEvent,NativeAndroid.s_luaCallEvent,keyParm);
	call_native(NativeAndroid.s_luaCallNavite);
end

NativeAndroid.closeStartScreen = function(self)
	self:callNativeEvent(kCloseStartScreen);
end

NativeAndroid.getAuthHead = function(self,api,key,version,mid, phonePsw, context)
	if not mid or string.len(mid) < 1 then
		mid = 0;
	end

	local post_data = {};
	post_data.api = api;
	post_data.key = key;
	post_data.version = version;
	post_data.mid = mid;
	post_data.phonePsw = phonePsw or "";
	post_data.context = context or 0;
	local json_data = json.encode(post_data);
	self:callNativeEvent(kAuthHead,json_data);

end

--升级
NativeAndroid.noticeUpdate = function(self, url)
    local post_data = {};
    post_data.url = url;
    local json_data = json.encode(post_data);
	self:callNativeEvent(kUpdateAPK,json_data);
end

-- 显示消息toast
NativeAndroid.showToast = function(self,msg)
	local post_data = {};
	post_data.message = msg;
	local json_data = json.encode(post_data);

	self:callNativeEvent(kShowToast,json_data);
end

NativeAndroid.upLoadErrorToUmeng = function(self,errorMsg,key)
	local post_data = {};
	post_data.error = errorMsg or "";
	post_data.key = key or "";
	local json_data = json.encode(post_data);
	self:callNativeEvent(kUMengError, json_data);
end

NativeAndroid.updateEventToUmen = function(self,id,msg)
	local post_data = {};
	post_data.id = id;
	post_data.msg = msg;

	local json_data = json.encode(post_data);
	self:callNativeEvent(kUMengEvent,json_data);

end

NativeAndroid.getSendFeedBack = function(self)
	self:callNativeEvent(kFeedBack);

end

NativeAndroid.guestLogin = function(self)
	self:callNativeEvent(kGuestLogin);
end

NativeAndroid.qqLogin = function(self)
	self:callNativeEvent(kQQLogin);
end

NativeAndroid.weChatLogin = function ( self )
	self:callNativeEvent(kWeChatLogin);
end

-- @param fileName 截图名称
-- @param url 地址
-- @param title 标题
-- @param isCircle 是否为朋友圈
NativeAndroid.weChatShare = function(self,fileName,url,title,isCircle)
	local post_data = {};
	post_data.fileName = fileName or "";
	post_data.url = url or "";
	post_data.title = title or "";

	if isCircle then
		post_data.isCircle = 1;
	else
		post_data.isCircle = 0;
	end
	local json_data = json.encode(post_data);

	self:callNativeEvent(kWeChatShare,json_data);

end

NativeAndroid.fbLogin = function(self,loginMethod,sid)
	local post_data = {};
	post_data.loginMethod = loginMethod;
	post_data.sid = sid;
	local json_data = json.encode(post_data);
	self:callNativeEvent(kFBLogin,json_data);

end

NativeAndroid.fbLogout = function(self)
	self:callNativeEvent(kFBLogout);
end

-- Facebook分享
NativeAndroid.facebookShare = function(self,fileName,content,url)
	local post_data = {};
	post_data.fileName = fileName or "";
	post_data.content = content or "";
	post_data.url = url or "";

	local json_data = json.encode(post_data);

	self:callNativeEvent(kFacebookShare,json_data);
end

NativeAndroid.sinaLogin = function(self,loginMethod,sid)
	self:callNativeEvent(kSinaLogin);
end

NativeAndroid.sinaLogout = function(self)
	self:callNativeEvent(kSinaLogout);
end

-- @param fileName 截图名称
-- @param content 标题
NativeAndroid.sinaShare = function(self,fileName,content,url)
	local post_data = {};
	post_data.fileName = fileName or "";
	post_data.content = content or "";
	post_data.url = url or "";

	local json_data = json.encode(post_data);

	self:callNativeEvent(kSinaShare,json_data);
end

--活动网络是否有效
--结果为true 网络有效
NativeAndroid.getNetworkActivity = function(self) 
	call_native(kgetNetworkActivity);
	return dict_get_int(kgetNetworkActivity, kgetNetworkActivity, 0) == 1;
end

NativeAndroid.openWebView = function(self,url)
	local post_data = {};
	post_data.url = url;
	local json_data = json.encode(post_data);

	self:callNativeEvent(kOpenWebView,json_data);

end

--异步加载声音
NativeAndroid.preloadSound = function(self,effectPath,musicPath)
	local soundPath = {};
	soundPath.effect = effectPath;
	soundPath.music = musicPath;
	local json_data = json.encode(soundPath);

	self:callNativeEvent(kPreloadSound,json_data);
end


--判断data/data/com.boyaa.xx/files/ 里面的文件是否存在
--name 例如： images/head/male or /images/head/male 
NativeAndroid.checkFileExists = function(self,name)
	local path = {};
	path.fileExist = name;
	local json_data = json.encode(path);
	self:callNativeEvent(kFileExists,json_data);
    local ret = dict_get_int(kFileExists,kFileExists .. "_result", 0);
    return (ret == 1); --1:存在， 0：不存在
end

NativeAndroid.setVolume = function(self,volume)
	local soundMap = {};
	soundMap.bgSound__sync = volume;
	local json_data = json.encode(soundMap);

	self:callNativeEvent(kSetVolume,json_data);
end

-- 上传头像
-- @url 上传url
-- @api 上传需要传给server 的api 信息
-- @name 上传头像的头像名（保存图片的名称）默认是 UserHeadIcon + sitemid
-- @mtype 格式 0：相册 1：拍照 
NativeAndroid.uploadImage = function(self,url,api,name,mtype)
	local post_data = {};
	post_data.Url = url;
	post_data.Api = api;
	post_data.Name = name or "upLoadName";
	post_data.Type = mtype;
	local json_data = json.encode(post_data);

	self:callNativeEvent(kUpLoadImage,json_data);
end

-- 获取网络类型
NativeAndroid.getNetWorkType = function(self)
    call_native(kGetNetWorkType);

	return dict_get_int(kGetNetWorkType, kGetNetWorkType,0);       
end

-- 获取通讯录好友
NativeAndroid.getGetContacts = function(self)
	self:callNativeEvent(kGetContacts);
end

NativeAndroid.getAchievement = function(self,url)
	local post_data = {};
	post_data.url = url;
	local json_data = json.encode(post_data);

	self:callNativeEvent(kGetAchievement,json_data);
end

-- 判断图片是否存在
-- imgName:图片文件名（不含路径，包含后缀）
-- ret：0：不存在；1：存在
NativeAndroid.isImgExist = function(self, imgName)
	dict_set_string(kIsImageExist, "name", imgName);
	self:callNativeEvent(kIsImageExist);
	return dict_get_int(kIsImageExist, "ret", 0);
end

--判断是否能ping通某个域名
NativeAndroid.canPingDnsSuccess = function ( self, url)
	local post_data = {};
	post_data.url = url;
	local json_data = json.encode(post_data);

	self:callNativeEvent(kCanPingDnsSuccess, json_data);
end

--寻找能访问的并且网络状况较好的域名来用
NativeAndroid.getBestUrl = function(self, urls)
	if not urls or #urls < 1 then
		Log.e("NativeAndroid.getBestUrl : urls is null or {}");
		return;
	end

	local json_data = json.encode(urls);
	self:callNativeEvent(kChooseBestUrl,json_data);
end

--此方法用于获取PHP请求api url和配置文件
NativeAndroid.getDynamicDNSConfig = function(self, url, flag)
	local post_data = {};
	post_data.url = url;
	post_data.context = flag;
	local json_data = json.encode(post_data);
	self:callNativeEvent(kGetDynamicDNSConfig, json_data);
end

-- 此方法用于下载文件，包括xml，zip文件等
-- @param url 地址
-- @param fileType 文件类型
-- @param savePath 保存路径 (可为空)
-- @param flag 自定义参赛 (可为空)
NativeAndroid.downloadFile = function(self, url, fileType, savePath,flag)
	local post_data = {};
	post_data.url = url;
	post_data.type = fileType;
	post_data.savePath = savePath;
	post_data.flag = flag;

	local json_data = json.encode(post_data);
	self:callNativeEvent(kDownloadFile,json_data);

end

-- 调用原生显示富文本

NativeAndroid.showRichText = function ( self, msg)

	self:callNativeEvent(kShowRichText, msg);
end

-- 调用原生隐藏富文本

NativeAndroid.hideRichText = function ( self)
	
	self:callNativeEvent(kHideRichText);
end

-- 显示系统消息
NativeAndroid.showSysMsg = function ( self, msg )
	self:callNativeEvent(kShowSysMsg, msg);
end

NativeAndroid.saveGuestSitemid = function(self,sitemid)
	local post_data = {};
	post_data.sitemid = sitemid;

	local json_data = json.encode(post_data);
	self:callNativeEvent(kSaveGuid,json_data);
end

-- 震动管理
NativeAndroid.setVaditor = function(self,isVaditor)
	local post_data = {};
	post_data.isVaditor = isVaditor;

	local json_data = json.encode(post_data);
	self:callNativeEvent(kSetVaditor,json_data);
end

-- 请求银联支付
NativeAndroid.requestUnionPay = function ( self, orderId )
	local post_data = {};
	post_data.orderId = orderId;
	local json_data = json.encode(post_data);
	self:callNativeEvent(kUnionPay,json_data);
end

-- 请求支付宝支付
NativeAndroid.requestAliPay = function ( self, chips, chipsPrice, orderId, productId,notifyUrl )
	local post_data = {};
	
	post_data.chips = chips;
	post_data.chipsPrice = chipsPrice;
	post_data.orderId = orderId;
	post_data.productId = productId;
	post_data.notifyUrl = notifyUrl;

	local json_data = json.encode(post_data);
	self:callNativeEvent(kAliPay,json_data);
end

-- 检测支付宝
NativeAndroid.checkAliPay = function ( self )
	
	self:callNativeEvent(kCheckAliPay);
end

-- debug日志记录
NativeAndroid.debugLog = function ( self, msg )

	dict_set_string("debugLog", "debug_msg", msg);
	self:callNativeEvent("debugLog");

end

-- 设置登录服务器类型
NativeAndroid.setServerType = function ( self, serverType )
	local post_data = {};
	post_data.serverType = serverType;
	
	local json_data = json.encode(post_data);
	self:callNativeEvent(kSetServerType,json_data);

end

-- 获取php保存的xml 相关信息
NativeAndroid.getSystemXml = function ( self, strUrl )
	local post_data = {};
	post_data.url = strUrl;
	
	local json_data = json.encode(post_data);
	self:callNativeEvent(kSystemXml,json_data);

end

NativeAndroid.screenShot = function(self, fileName)
	local post_data = {};
	post_data.fileName = fileName;
	
	local json_data = json.encode(post_data);
	self:callNativeEvent(kScreenShot,json_data);

end

NativeAndroid.sendSMS = function(self, number, content)
	local post_data = {};
	post_data.number = number or "";
	post_data.content = content or "";
	
	local json_data = json.encode(post_data);
	self:callNativeEvent(kSendSMS,json_data);

end

NativeAndroid.closeKeyBoard = function ( self )
	self:callNativeEvent(kCloseKeyBoard);
end

NativeAndroid.uploadDumpFile = function(self,json_data)

	self:callNativeEvent(kUploadCrashDump,json_data);
end

NativeAndroid.scanQR = function(self)
	self:callNativeEvent(kScanQR);
end

-- @param fileName 需加后缀.png
NativeAndroid.createQRcode = function(self,mid,fileName,url)
	if not mid or not fileName then
		return;
	end

	local post_data = {};
	post_data.file_name = fileName or "";
	post_data.content = mid or "";
	post_data.url = url or "";
	local json_data = json.encode(post_data);
    self:callNativeEvent(kCreateQRcode,json_data);
end

NativeAndroid.createShareQRcode = function(self,nick,mid,content,iconName, qrName, whiteName, redName)
	local post_data = {};
	post_data.nick = nick or "";
	post_data.mid = mid or "";
	post_data.content = content or "";
	post_data.iconName = iconName or "";
	post_data.qrName = qrName or "";
	post_data.whiteName = whiteName or "";
	post_data.redName = redName or "";

	local json_data = json.encode(post_data);

	self:callNativeEvent(kCreateShareQRcode,json_data);
end

-- @param fileName 需加后缀.png
NativeAndroid.saveQRcode = function(self,fileName)
	if not fileName then
		return;
	end

	local post_data = {};
	post_data.file_name = fileName or "";

	local json_data = json.encode(post_data);
	self:callNativeEvent(kSaveQRcode,json_data);
	
end

NativeAndroid.refreshGps = function(self)
	self:callNativeEvent(kRefrashGPS);
end

NativeAndroid.requestWeChatPay = function ( self, json_data )
	self:callNativeEvent(kWeChatPay,json_data);
end

NativeAndroid.checkWeChatPay = function ( self )
	self:callNativeEvent(kCheckWeChatPay);
end

NativeAndroid.requestMMPay = function ( self, json_data )
	self:callNativeEvent(kMMPay,json_data);
end

NativeAndroid.requestWoPay = function ( self, json_data )
	self:callNativeEvent(kWoPay,json_data);
end

NativeAndroid.requestAiPay = function ( self, json_data )
	self:callNativeEvent(kAiPay,json_data);
end

NativeAndroid.runDebugVersion = function(self)
	call_native(kRunInDebugVersion);

end

