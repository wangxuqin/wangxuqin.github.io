-- NativeEvent.lua
require("core/object");
require("core/system");
require("core/dict");
require("common/native/nativeCMD");
require("libs/json_wrap");

NativeEvent = class();

NativeEvent.s_platform = System.getPlatform();
NativeEvent.s_callEvent = "LuaEventCall";
NativeEvent.s_callResult = "CallResult";
NativeEvent.s_resultPostfix = "_result";

NativeEvent.getInstance = function()
	if not NativeEvent.s_instance or next(NativeEvent.s_instance) == nil then 
		if NativeEvent.s_platform == kPlatformAndroid or NativeEvent.s_platform == kPlatformIOS then
			require("common/nativeAndroid");
			NativeEvent.s_instance = new(NativeAndroid);
		else
			require("common/nativeWin32");
			NativeEvent.s_instance = new(NativeWin32);
		end		
	end

	return NativeEvent.s_instance;
end

NativeEvent.onEventCall = function()

	EventDispatcher.getInstance():dispatch(Event.Call,NativeEvent.getNativeCallResult());

end

NativeEvent.onWinKeyDown = function(key)
	if key == 81 then
		EventDispatcher.getInstance():dispatch(Event.Back);
	else
		EventDispatcher.getInstance():dispatch(Event.KeyDown,key);
	end
end

-- 解析 call_native 返回值
NativeEvent.getNativeCallResult = function()
	local callParam = dict_get_string(NativeEvent.s_callEvent,NativeEvent.s_callEvent);
	local callResult = dict_get_int(callParam, NativeEvent.s_callResult,-1);

    if callResult == 1 then -- 获取数值失败
        return callParam , false;
    end
    local result = dict_get_string(callParam , callParam .. NativeEvent.s_resultPostfix);
    dict_delete(callParam);
    local json_data = json.decode_node(result);
    --返回错误json格式.
    if json_data then
        return callParam ,true, json_data;
    else
        return callParam , true;
    end
end


