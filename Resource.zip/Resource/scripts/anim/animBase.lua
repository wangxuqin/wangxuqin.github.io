require("core/object");

AnimBase = class();

AnimBase.load = function()

end

AnimBase.play = function()

end

AnimBase.stop = function()

end

AnimBase.release = function()

end
