-----------------------------------------------------------
-- Author: GerryGuo
-- Date: 2015-09-10
-- Last modification : 2015-09-17
-- Description: provide basic action like cocos2dx

local TAG = "Actions";

ActionBase = class();

ActionBase.ctor = function(self, duration)
	duration = duration or 0;
	self.m_target = nil;
	self.m_elapsedTime = 0;
	self.m_duration = duration;
	self.m_name = "ActionBase";
end

ActionBase.dtor = function(self)
	Scheduler.getInstance():unscheduleUpdate(self, self.__update);
end

ActionBase.setName = function(self, name)
	self.m_name = name;
end

ActionBase.apply = function(self, target)
	target.__ccActions = target.__ccActions or {};
	table.insert(target.__ccActions, self);
	Scheduler.getInstance():scheduleUpdate(self, self.__update);
	self:startWithTarget(target);
	--重载对象的dtor，场景切换时能删掉action
	self.__oldDtor = target.dtor;
	target.dtor = function(this)
		if(type(self.__oldDtor) == "function") then
			self.__oldDtor(this);
		end
		delete(self);
	end
end

ActionBase.stopAction = function(target, action)
	if(target.__ccActions == nil) then
		return;
	end
	for i=#target.__ccActions,1,-1 do
		if(target.__ccActions[i] == action) then
			delete(target.__ccActions[i]);
			table.remove(target.__ccActions, i);
		end
	end
end

ActionBase.stopAllActions = function(target)
	if(target.__ccActions == nil) then
		return;
	end
	for i=#target.__ccActions,1,-1 do
		delete(target.__ccActions[i]);
	end
	target.__ccActions = {};
end

ActionBase.stop = function(self)
	self.m_target = nil;
end

ActionBase.getDuration = function(self)
	return self.m_duration;
end

ActionBase.getElapsed = function(self)
	return self.m_elapsedTime;
end

ActionBase.FLT_EPSILON = 1.192092896e-07;

ActionBase.step = function(self, deltaTime)
	self.m_elapsedTime = self.m_elapsedTime + deltaTime;
	self:update(math.max(0, math.min(1, self.m_elapsedTime / math.max(self.m_duration, ActionBase.FLT_EPSILON))));
end

ActionBase.__update = function(self, deltaTime)
	self:step(deltaTime);
	if(self:isDone()) then
		ActionBase.stopAction(self.m_target, self);
	end
end

ActionBase.update = function(self, progress)
	Log.e(TAG, "implement me");
end

ActionBase.startWithTarget = function(self, target)
	self.m_target = target;
	self.m_elapsedTime = 0;
end

ActionBase.isDone = function(self)
	return self.m_elapsedTime >= self.m_duration;
end

ActionBase.ccpSub = function(p1, p2)
	return { x = p1.x - p2.x, y = p1.y - p2.y };
end

ActionBase.ccpAdd = function(p1, p2)
	return { x = p1.x + p2.x, y = p1.y + p2.y };
end

ActionBase.ccpMult = function(p1, t)
	return { x = p1.x * t, y = p1.y * t };
end

------------------------------------------------------------------------------------------
--ActionMoveBy

ActionMoveBy = class(ActionBase, false);

--[Comment]
--单位:秒
ActionMoveBy.ctor = function(self, duration, x, y)
	super(self, duration);
	x = x or 0;
	y = y or 0;
	self.m_positionDelta = {x=x,y=y};
    self.m_startPosition = {x=0,y=0};
    self.m_previousPosition = {x=0,y=0};
	self:setName("ActionMoveBy");
end

ActionMoveBy.startWithTarget = function(self, target)
	ActionBase.startWithTarget(self, target);
	local x,y = target:getPos();
	self.m_previousPosition.x = x;
	self.m_previousPosition.y = y;
	self.m_startPosition.x = x;
	self.m_startPosition.y = y;
end

ActionMoveBy.update = function(self, progress)
	local x, y = self.m_target:getPos();
	local currentPos = {x = x, y = y};
	local diff = ActionBase.ccpSub(currentPos, self.m_previousPosition);
	self.m_startPosition = ActionBase.ccpAdd(self.m_startPosition, diff);
	local newPos = ActionBase.ccpAdd(self.m_startPosition, ActionBase.ccpMult(self.m_positionDelta, progress));
	self.m_target:setPos(newPos.x, newPos.y);
	self.m_previousPosition = newPos;
end

------------------------------------------------------------------------------------------
--ActionMoveTo

ActionMoveTo = class(ActionMoveBy, false);

ActionMoveTo.ctor = function(self, duration, x, y)
	super(self, duration, x, y);
	self.m_endPosition = { x = x, y = y };
	self:setName("ActionMoveTo");
end

ActionMoveTo.startWithTarget = function(self, target)
	ActionMoveBy.startWithTarget(self, target);
	local x,y = target:getPos();
	if(self.m_endPosition.x == nil) then
		self.m_endPosition.x = x;
	end
	if(self.m_endPosition.y == nil) then
		self.m_endPosition.y = y;
	end
	self.m_positionDelta = ActionBase.ccpSub(self.m_endPosition, {x=x,y=y});
end

------------------------------------------------------------------------------------------
--ActionScaleTo

ActionScaleTo = class(ActionBase, false);

ActionScaleTo.ctor = function(self, duration, sx, sy, center, centerX, centerY)
	super(self, duration);
	self.m_fStartScaleX = 0;
	self.m_fStartScaleY = 0;
	self.m_fEndScaleX = sx;
	self.m_fEndScaleY = sy;
	self.m_fDeltaX = 0;
	self.m_fDeltaY = 0;
	self.m_ccScaleCenter = center;
	self.m_ccScaleCenterX = centerX;
	self.m_ccScaleCenterY = centerY;
	self:setName("ActionScaleTo");
end

ActionScaleTo.startWithTarget = function(self, target)
	ActionBase.startWithTarget(self, target);
	self.m_fStartScaleX,self.m_fStartScaleY = target:getScale();
	self.m_fDeltaX = self.m_fEndScaleX - self.m_fStartScaleX;
	self.m_fDeltaY = self.m_fEndScaleY - self.m_fStartScaleY;
end

ActionScaleTo.update = function(self, progress)
	local target = self.m_target;
	local scaleX = self.m_fStartScaleX + self.m_fDeltaX * progress;
	local scaleY = self.m_fStartScaleY + self.m_fDeltaY * progress;
	target:setScale(scaleX, scaleY, self.m_ccScaleCenter, self.m_ccScaleCenterX, self.m_ccScaleCenterY);
end

------------------------------------------------------------------------------------------
--ActionRotateBy

ActionRotateBy = class(ActionBase, false);

ActionRotateBy.ctor = function(self, duration, angle, center, centerX, centerY)
	super(self, duration);
	self.m_angle = angle;
	self.m_ccScaleCenter = center;
	self.m_ccScaleCenterX = centerX;
	self.m_ccScaleCenterY = centerY;
end

ActionRotateBy.startWithTarget = function(self, target)
	ActionBase.startWithTarget(self, target);
	self.m_startAngle = target:getRotate();
end

ActionRotateBy.update = function(self, progress)
	-- XXX: shall I add % 360
	if (self.m_target) then
		self.m_target:setRotate(self.m_startAngle + self.m_angle * progress, self.m_ccScaleCenter, self.m_ccScaleCenterX, self.m_ccScaleCenterY);
	end
end

------------------------------------------------------------------------------------------
--ActionSequence

ActionSequence = class(ActionBase, false);

--[Comment]
--根据两个动作创建动作序列
ActionSequence.ctor = function(self, action1, action2)
	local d = action1:getDuration() + action2:getDuration();
	super(self, d);
	self.m_actions = { action1, action2, };
	self:setName("ActionSequence");
end

ActionSequence.createWithArray = function(actions)
	if(actions == nil) then
		return nil;
	end
	local action = actions[1];
	if(#actions > 1) then
		for i=2,#actions do
			action = new(ActionSequence, action, actions[i]);
		end
	end
	return action;
end

ActionSequence.startWithTarget = function(self, target)
	ActionBase.startWithTarget(self, target);
	self.m_split = self.m_actions[1]:getDuration() / self.m_duration;
    self.m_last = -1;
end

ActionSequence.update = function(self, progress)
	local found = 0;
	local new_t = 0;

	if( progress < self.m_split ) then -- action[0]
		found = 0;
		if( self.m_split ~= 0 ) then
			new_t = progress / self.m_split;
		else
			new_t = 1;
		end
	else -- action[1]
		found = 1;
		if ( self.m_split == 1 ) then
			new_t = 1;
		else
			new_t = (progress-self.m_split) / (1 - self.m_split );
		end
	end

	if ( found==1 ) then
		if( self.m_last == -1 ) then
			-- action[0] was skipped, execute it.
			self.m_actions[1]:startWithTarget(self.m_target);
			self.m_actions[1]:update(1);
			self.m_actions[1]:stop();
		elseif( self.m_last == 0 ) then
			-- switching to action 1. stop action 0.
			self.m_actions[1]:update(1);
			self.m_actions[1]:stop();
		end
	elseif(found==0 and self.m_last==1 ) then
		-- Reverse mode ?
		-- XXX: Bug. this case doesn't contemplate when _last==-1, found=0 and in "reverse mode"
		-- since it will require a hack to know if an action is on reverse mode or not.
		-- "step" should be overriden, and the "reverseMode" value propagated to inner Sequences.
		self.m_actions[2]:update(0);
		self.m_actions[2]:stop();
	end
	-- Last action found and it is done.
	if( found == self.m_last and self.m_actions[found+1]:isDone() ) then
		return;
	end

	-- Last action found and it is done
	if( found ~= self.m_last ) then
		self.m_actions[found+1]:startWithTarget(self.m_target);
	end

	self.m_actions[found+1]:update(new_t);
	self.m_last = found;
end

------------------------------------------------------------------------------------------
--ActionSpawn

ActionSpawn = class(ActionBase, false);

ActionSpawn.ctor = function(self, action1, action2)
	local d1 = action1:getDuration();
	local d2 = action2:getDuration();
	super(self, math.max(d1, d2));
	self.m_action1 = action1;
	self.m_action2 = action2;
	self:setName("ActionSpawn");
end

ActionSpawn.createWithArray = function(actions)
	if(actions == nil) then
		return nil;
	end
	local action = actions[1];
	if(#actions > 1) then
		for i=2,#actions do
			action = new(ActionSpawn, action, actions[i]);
		end
	end
	return action;
end

ActionSpawn.startWithTarget = function(self, target)
	ActionBase.startWithTarget(self, target);
	self.m_action1:startWithTarget(target);
	self.m_action2:startWithTarget(target);
end

ActionSpawn.update = function(self, progress)
	self.m_action1:update(progress);
	self.m_action2:update(progress);
end

------------------------------------------------------------------------------------------
--ActionCallFuncN

ActionCallFuncN = class(ActionBase, false);

ActionCallFuncN.ctor = function(self, obj, func)
	super(self, 0);
	self.m_obj = obj;
	self.m_func = func;
	self:setName("ActionCallFuncN");
end

ActionCallFuncN.update = function(self, progress)
	if(type(self.m_func) == "function") then
		self.m_func(self.m_obj, self.m_target);
	end
end

------------------------------------------------------------------------------------------
--ActionDelayTime

ActionDelayTime = class(ActionBase, false);

ActionDelayTime.ctor = function(self, duration)
	super(self, duration);
	self:setName("ActionDelayTime");
end

ActionDelayTime.update = function(self, progress)
end

------------------------------------------------------------------------------------------
--ActionFadeTo

ActionFadeTo = class(ActionBase, false);

ActionFadeTo.ctor = function(self, duration, alpha)
	super(self, duration);
	alpha = alpha or 1;
	self.m_fromOpacity = 1;
	self.m_toOpacity = alpha;
	self:setName("ActionFadeTo");
end

ActionFadeTo.startWithTarget = function(self, target)
	ActionBase.startWithTarget(self, target);
	self.m_fromOpacity = target:getTransparency();
end

ActionFadeTo.update = function(self, progress)
	self.m_target:setTransparency(self.m_fromOpacity + (self.m_toOpacity - self.m_fromOpacity) * progress);
end

------------------------------------------------------------------------------------------
--ActionRepeatForever

ActionRepeatForever = class(ActionBase, false);

ActionRepeatForever.ctor = function(self, action)
	super(self, 0);
	self.m_innerAction = action;
end

ActionRepeatForever.startWithTarget = function(self, target)
	ActionBase.startWithTarget(self, target);
	self.m_innerAction:startWithTarget(target);
end

ActionRepeatForever.isDone = function(self)
	return false;
end

ActionRepeatForever.step = function(self, deltaTime)
	self.m_innerAction:step(deltaTime);
	if(self.m_innerAction:isDone()) then
		local diff = self.m_innerAction:getElapsed() - self.m_innerAction:getDuration();
		self.m_innerAction:startWithTarget(self.m_target);
		-- to prevent jerk. issue #390, 1247
		self.m_innerAction:step(0);
		self.m_innerAction:step(diff);
	end
end

------------------------------------------------------------------------------------------
--ActionCallFuncFrame: 每帧都会回调一个函数，传入进度

ActionCallFuncFrame = class(ActionBase, false);

ActionCallFuncFrame.ctor = function(self, duration, obj, func)
	super(self, duration);
	self.m_obj = obj;
	self.m_func = func;
	self:setName("ActionCallFuncFrame");
end

ActionCallFuncFrame.update = function(self, progress)
	if(type(self.m_func) == "function") then
		self.m_func(self.m_obj, progress);
	end
end
