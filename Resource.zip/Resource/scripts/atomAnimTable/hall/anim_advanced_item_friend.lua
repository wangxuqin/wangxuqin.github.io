anim_advanced_item_friend = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "friends_frame",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/friend_pin.lua",
				["path"] = "friend0001.png",
			},
			{
				["packFile"] = "pin/friend_pin.lua",
				["path"] = "friend0002.png",
			},
			{
				["packFile"] = "pin/friend_pin.lua",
				["path"] = "friend0003.png",
			},
			{
				["packFile"] = "pin/friend_pin.lua",
				["path"] = "friend0004.png",
			},
			{
				["packFile"] = "pin/friend_pin.lua",
				["path"] = "friend0005.png",
			},
			{
				["packFile"] = "pin/friend_pin.lua",
				["path"] = "friend0006.png",
			},
			{
				["packFile"] = "pin/friend_pin.lua",
				["path"] = "friend0007.png",
			},
			{
				["packFile"] = "pin/friend_pin.lua",
				["path"] = "friend0008.png",
			},
			{
				["packFile"] = "pin/friend_pin.lua",
				["path"] = "friend0009.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 9,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 1300,
		["delay"] = 0,
		["animType"] = 1,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}