anim_loading = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "8",
		["y"] = 0,
		["x"] = 0,
		["name"] = "image_group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["path"] = "loading/dots/dot0.png",
			},
			{
				["path"] = "loading/dots/dot1.png",
			},
			{
				["path"] = "loading/dots/dot2.png",
			},
			{
				["path"] = "loading/dots/dot3.png",
			},
			{
				["path"] = "loading/dots/dot4.png",
			},
			{
				["path"] = "loading/dots/dot5.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 6,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "8",
		["duration"] = 1000,
		["delay"] = 0,
		["animType"] = 2,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}