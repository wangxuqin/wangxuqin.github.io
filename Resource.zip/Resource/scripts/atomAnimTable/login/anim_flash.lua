anim_flash = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "2",
		["y"] = 0,
		["x"] = 0,
		["name"] = "cardFlash",
		["filter"] = 1,
		["height"] = 126,
		["file"] = {
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash1.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash2.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash3.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash4.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash5.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash6.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash7.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash8.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash9.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash10.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash11.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash12.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash13.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash14.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash15.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash16.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash17.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash18.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash19.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash20.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash21.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash22.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash23.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash24.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash25.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash26.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash27.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash28.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash29.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash30.png",
			},
			{
				["packFile"] = "pin/card_pin.lua",
				["path"] = "flash31.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 88,
	},
	{
		["num"] = 31,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "2",
		["duration"] = 1000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}