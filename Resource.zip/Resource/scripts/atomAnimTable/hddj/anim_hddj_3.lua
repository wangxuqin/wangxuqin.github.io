anim_hddj_3 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "2",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_3_pin.lua",
				["path"] = "hddj_3_0059.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 59,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "2",
		["duration"] = 1500,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}