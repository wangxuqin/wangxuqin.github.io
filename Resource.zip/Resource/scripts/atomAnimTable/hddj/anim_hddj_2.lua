anim_hddj_2 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0059.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0060.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0061.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0062.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0063.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0064.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0065.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0066.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0067.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0068.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0069.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0070.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0071.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0072.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0073.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0074.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0075.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0076.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0077.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0078.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0079.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0080.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0081.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0082.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0083.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0084.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_2_pin.lua",
				["path"] = "hddj_2_0085.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 85,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}