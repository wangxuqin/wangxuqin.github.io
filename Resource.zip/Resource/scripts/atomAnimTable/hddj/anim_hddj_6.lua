anim_hddj_6 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0059.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0060.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0061.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0062.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0063.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0064.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0065.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0066.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0067.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0068.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0069.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0070.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0071.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0072.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0073.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0074.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0075.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0076.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0077.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0078.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0079.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0080.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0081.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0082.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0083.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0084.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_6_pin.lua",
				["path"] = "hddj_6_0085.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 85,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}