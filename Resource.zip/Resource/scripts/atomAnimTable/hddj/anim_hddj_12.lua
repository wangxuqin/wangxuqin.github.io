anim_hddj_12 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0059.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0060.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0061.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0062.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0063.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_12_pin.lua",
				["path"] = "hddj_12_0064.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 64,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}