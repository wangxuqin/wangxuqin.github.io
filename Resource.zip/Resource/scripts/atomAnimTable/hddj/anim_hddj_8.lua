anim_hddj_8 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0059.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0060.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0061.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0062.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0063.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0064.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0065.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_8_pin.lua",
				["path"] = "hddj_8_0066.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 66,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}