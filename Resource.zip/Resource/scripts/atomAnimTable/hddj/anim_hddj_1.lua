anim_hddj_1 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "6",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0059.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0060.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0061.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0062.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0063.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0064.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0065.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0066.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0067.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0068.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0069.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0070.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0071.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0072.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0073.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0074.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0075.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0076.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0077.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0078.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0079.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0080.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0081.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0082.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0083.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0084.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0085.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0086.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0087.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0088.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0089.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0090.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0091.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0092.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0093.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0094.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0095.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0096.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_1_pin.lua",
				["path"] = "hddj_1_0097.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 97,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "6",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}