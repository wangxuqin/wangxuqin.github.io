anim_hddj_4 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_4_pin.lua",
				["path"] = "hddj_4_0059.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 59,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}