anim_hddj_5 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0059.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0060.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0061.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0062.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0063.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0064.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_5_pin.lua",
				["path"] = "hddj_5_0065.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 65,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}