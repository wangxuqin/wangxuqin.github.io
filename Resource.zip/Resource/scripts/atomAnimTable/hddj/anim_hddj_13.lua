anim_hddj_13 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0059.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0060.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0061.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0062.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0063.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0064.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0065.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0066.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0067.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0068.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0069.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0070.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0071.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0072.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0073.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0074.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0075.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0076.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0077.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0078.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0079.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0080.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_13_pin.lua",
				["path"] = "hddj_13_0081.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 81,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}