anim_hddj_10 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_10_pin.lua",
				["path"] = "hddj_10_0036.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 36,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}