anim_hddj_9 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_9_pin.lua",
				["path"] = "hddj_9_0037.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 37,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}