anim_hddj_7 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0059.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0060.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0061.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0062.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0063.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0064.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0065.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0066.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0067.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0068.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0069.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0070.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0071.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0072.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0073.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0074.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0075.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0076.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0077.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0078.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0079.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0080.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0081.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0082.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0083.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0084.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0085.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0086.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0087.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0088.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0089.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0090.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0091.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0092.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0093.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_7_pin.lua",
				["path"] = "hddj_7_0094.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 94,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}