anim_hddj_11 = {
	{
		["visible"] = 1,
		["time"] = "0",
		["xyScale"] = false,
		["origVisible"] = true,
		["resourceId"] = "1",
		["y"] = 0,
		["x"] = 0,
		["name"] = "group",
		["filter"] = 1,
		["height"] = 0,
		["file"] = {
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0001.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0002.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0003.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0004.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0005.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0006.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0007.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0008.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0009.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0010.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0011.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0012.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0013.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0014.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0015.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0016.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0017.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0018.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0019.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0020.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0021.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0022.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0023.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0024.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0025.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0026.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0027.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0028.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0029.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0030.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0031.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0032.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0033.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0034.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0035.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0036.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0037.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0038.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0039.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0040.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0041.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0042.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0043.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0044.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0045.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0046.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0047.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0048.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0049.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0050.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0051.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0052.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0053.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0054.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0055.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0056.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0057.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0058.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0059.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0060.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0061.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0062.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0063.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0064.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0065.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0066.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0067.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0068.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0069.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0070.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0071.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0072.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0073.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0074.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0075.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0076.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0077.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0078.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0079.png",
			},
			{
				["packFile"] = "pin/hddj/hddj_11_pin.lua",
				["path"] = "hddj_11_0080.png",
			},
		},
		["typeName"] = "AnimFrame",
		["width"] = 0,
	},
	{
		["num"] = 80,
		["type"] = "AtomAnimFrame",
		["period"] = 0.300,
		["easeType"] = "Nil",
		["id"] = "1",
		["duration"] = 2000,
		["delay"] = 0,
		["animType"] = 0,
	},
	["visible"] = 1,
	["fillParentWidth"] = 0,
	["width"] = 0,
	["y"] = 0,
	["x"] = 0,
	["name"] = "Aircraft",
	["fillParentHeight"] = 0,
	["height"] = 0,
	["typeName"] = "AnimNode",
	["nodeAlign"] = 8,
}