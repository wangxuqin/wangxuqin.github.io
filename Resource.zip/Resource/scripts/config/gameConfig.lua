GameConfig = {}
GameConfig.version = "2.0.0";
GameConfig.frameRate = 52;
GameConfig.supported_languages = "zh_Hant";
GameConfig.default_language = "zh_Hant";
GameConfig.supported_by = true;
GameConfig.location = "LOGIN_DOMESTIC";
GameConfig.roomFlag = "1,2,5,7,8,9";
GameConfig.PushGoogleProjectID = "451385740351";
GameConfig.FlurryAPIKey = "WXFCG9WKCN7ZXMDQ6WX7";
GameConfig.PlayStorePublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtQicpTrLevQwdCAjsEF1bEs3JHqxeP6wWQ4x9IsAyZH1ayKGnEuvFgWGvvQfSi86C9BY2bPrr4YO4TclkWuj6i3HiQoaJkKNNGZkkR/MxbgW0ewlEzRC6TYGDr1TZ1RbV9ZlvA7F23ZGcD/ynkIn6EqVO3nC4gHGtNgNW3eMkj7L+1SV4ixpYGlD5M5tTW16mRY/5IbQzzn4E1XK847KcW+EtjF4Vd9TDr5Ygz6JbtMjrLNP2LnmBs0wDyCdZL0k+6JftIn1YwTtWjTYj3nisON1QsrwvCD8yn9MsJk5kZmcGPSL4Z5BC3fDidO2mr/22KCzBMDCauGk6MRm0nZVFwIDAQAB";
GameConfig.special_cgi = "https://mvlpthik01.boyaagame.com/mobilespecial_java.php";
--GameConfig.blurDialogBackground = true; -- 是否对弹框背景增加模糊特效
GameConfig.login_config = {
		login_providers = {
		[1] = {
                id="LOGIN_TYPE_GUEST";
                nickEditable="true";
                headImageEditable="true";
				enc_key = {
                    [1] = {lang = "zh_Hant", key="abctest"}
                };
					
				login_cgi = {
                    [1] = {lang = "zh_Hant", url="https://ipk-demo-1.boyaa.com/"}
                };
				    
                play = "android";
        };
        [2] = {
                id="LOGIN_TYPE_BY";
                nickEditable=true;
                headImageEditable=true;
				enc_key = {
                    [1] = {lang = "zh_Hant", key="abctest"}
                };
					
				login_cgi = {
                    [1] = {lang = "zh_Hant", url="https://ipk-demo-1.boyaa.com/"}
                };
				    
                play = "android";
        };

        [3] = {
                id="LOGIN_TYPE_FACEBOOK";
                nickEditable=true; 
                headImageEditable=true;
			    enc_key = {
                    [1] = {lang = "zh_Hant", key="abctest"}
                };
					
			    login_cgi = {
                    [1] = {lang = "zh_Hant", url="https://ipk-demo-1.boyaa.com/"}
                };
				    
                play = "android";
            }
        
	}
};

--这里的信息为登录后才会更新
GameConfig.proxyIp = nil;
GameConfig.proxyPort = nil;
--endregion

GameConfig.getEncKey = function(currendLocaleId)
    return "abctest";
end

GameConfig.getPlay = function(currentLocaleId)
    return "android";
end
