LayerConfig = {};
LayerConfig.DIALOG_LAYER = 100;
LayerConfig.ROOM_LAYER   = 0;