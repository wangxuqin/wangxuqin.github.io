--[Comment]
--这个类是专门存放引擎组特效开关
EngineConfig = {};

--[Comment]
--Shader对话框背景模糊
EngineConfig.SHADER_DLG_BG_BLUR = false;

---
-- 消息对话框，“知道了”按钮，按下后是否要有消失动画。
EngineConfig.MsgDialogKnownButtonDisappearAnimation = true 

---
-- 是否启用大厅4个按钮的光环效果
EngineConfig.MainButtonHoloEffectAfterClick = false 