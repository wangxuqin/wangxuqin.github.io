-- HttpManager.lua
-- Author: Vicent.Gong
-- Date: 2013-01-08
-- Last modification : 2013-07-12
-- Description: Implemented a http manager,to manager all http request.

require("core/constants");
require("core/object");
require("core/http");
require("core/eventDispatcher");
require("libs/json_wrap");
require("core/anim");

HttpConfigContants = 
{
	URL = 1,
	METHOD = 2,
	TYPE = 3,
	TIMEOUT = 4,
};

HttpErrorType = 
{
	SUCCESSED    = 1,
	TIMEOUT      = 2,
	NETWORKERROR = 3,
	JSONERROR    = 4,
};

HttpManager = class();

HttpManager.TAG = "HttpManager";

HttpManager.ctor = function(self,configMap,postDataOrganizer,urlOrganizer)
	self.m_httpCommandMap = {};
	self.m_commandHttpMap = {};
	self.m_commandTimeoutAnimMap = {};
	
	HttpManager.setConfigMap(self,configMap);
	HttpManager.setPostDataOrganizer(self,postDataOrganizer);
	HttpManager.setUrlOrganizer(self,urlOrganizer);

	self.m_userEvent = EventDispatcher.getInstance():getUserEvent();

	self.m_timeout  = 10000;
end

HttpManager.getHttpManagerEvent = function(self)
	return self.m_userEvent;
end

HttpManager.getConfigMap = function(self)
	return self.m_configMap;
end

HttpManager.setConfigMap = function(self,configMap)
	HttpManager.destroyAllHttpRequests(self);
	self.m_configMap = configMap or {};
end

HttpManager.appendConfigs = function(self,configMap)
	for k,v in pairs(configMap or {}) do
		self.m_configMap[k] = v;
	end
end

HttpManager.setDefaultTimeout = function(self,time)
	self.m_timeout = time or self.m_timeout;
end

HttpManager.setPostDataOrganizer = function(self,postDataOrganizer)
	self.m_postDataOrganizer = postDataOrganizer;
end

HttpManager.setUrlOrganizer = function(self,urlOrganizer)
	self.m_urlOrganizer = urlOrganizer;
end

----------------------------------------------------以下为测试，日后删除------------------------------
HttpManager.testExecute = function(self,url,method,head,api,obj)
	self.m_obj = obj;
	local httpRequest = new(Http,kHttpPost,kHttpReserved,url);
	--httpRequest:addHeader("content-type:application/x-www-form-urlencoded");
	httpRequest:addHeader("X-API-VER:8");
	httpRequest:addHeader("api-v8:1");
	httpRequest:addHeader(head);

	httpRequest:setEvent(self,self.testResponse);
	httpRequest:setData(api);

	Log.d("url",tostring(url));
	Log.d("method",tostring(method));
	Log.d("head",tostring(head));
	Log.d("api",tostring(api));

	httpRequest:execute();

end

HttpManager.testResponse = function(self,httpRequest)
 	local data = httpRequest:getResponse();
   
    self.m_obj:onLoginResponse(1,data);
	
	self:destroyHttpRequest(httpRequest);
end

----------------------------------------以上部分为测试，需删除-------------------------------------------
HttpManager.execute = function(self,command,data,head,url)
	if not HttpManager.checkCommand(self,command) then
		return false;
	end

	HttpManager.destroyHttpRequest(self,self.m_commandHttpMap[command]);

	local config = self.m_configMap[command];
	local httpType = config[HttpConfigContants.TYPE] or kHttpPost;

	if url == nil then
		url = self.m_urlOrganizer(config[HttpConfigContants.URL],
								config[HttpConfigContants.METHOD],
								httpType);
	end
	local httpRequest = new(Http,httpType,kHttpReserved,url);
	if head ~= nil then
		httpRequest:addHeader("X-TUNNEL-VERIFY: "..head);
	end

	httpRequest:setEvent(self, self.onResponse);
	local timeout = config[HttpConfigContants.TIMEOUT] or self.m_timeout;
	httpRequest:setTimeout(timeout,timeout);
	if httpType == kHttpPost then 
		local postData =  self.m_postDataOrganizer(config[HttpConfigContants.METHOD],data);
		httpRequest:setParam(json.encode(data));
		httpRequest:setData(postData);
	end

	local timeoutAnim = HttpManager.createTimeoutAnim(self,command,config[HttpConfigContants.TIMEOUT] or self.m_timeout);

    self.m_httpCommandMap[httpRequest] = command;
    self.m_commandHttpMap[command] = httpRequest;
    self.m_commandTimeoutAnimMap[command] = timeoutAnim;
    Log.d("httpManager | url"..url);
	Log.d("httpManager | header"..tostring(head));
	if data ~= nil then
		Log.d("httpManager | data",data);
	end
	httpRequest:execute();
end

HttpManager.dtor = function (self)
	self:destroyAllHttpRequests();

    self.m_httpCommandMap = nil;
    self.m_commandHttpMap = nil;
	self.m_commandTimeoutAnimMap = nil;

	self.m_configMap = nil;
	self.m_userEvent = nil;
end

---------------------------------private functions-----------------------------------------

HttpManager.checkCommand = function(self, command)
	local errLog = nil;

	repeat 
		if not (command or self.m_configMap[command]) then
			errLog = "There is not command like this";
			break;
		end

		local config = self.m_configMap[command];

		if not config[HttpConfigContants.URL] then
			errLog = "There is not url in command";
			break;
		end

		if not config[HttpConfigContants.METHOD] then
			errLog = "There is not method in command";
			break;
		end

		local httpType = config[HttpConfigContants.TYPE];
		if httpType ~= nil and httpType ~= kHttpPost and  httpType ~= kHttpGet then
			errLog = "Not supported http request type";
			break;
		end
	until true

	if errLog then
		self:log(command,errLog);
		return false;
	end

	return true;
end

HttpManager.log = function(self, command, str)
	local prefixStr = "HttpRequest error :";
	if config then
		prefixStr = prefixStr .. " command |" .. command;
	end

	Log.d(HttpManager.TAG,prefixStr .. " | " .. str);
end

HttpManager.onResponse = function(self , httpRequest)
	local command = self.m_httpCommandMap[httpRequest];

	if not command then
		HttpManager.destroyHttpRequest(self,httpRequest);
		return;
	end

	HttpManager.destoryTimeoutAnim(self,command);
 
 	local errorCode = HttpErrorType.SUCCESSED;
 	local data = nil;
 	local httpResponseCode = nil;
 	local param = nil; -- 用户php请求的参数，原样返回给用户。

	repeat 
		
		local strParam = httpRequest:getParam();
		param = json.decode(strParam);
		
		-- 判断http请求的错误码,0--成功 ，非0--失败.
		-- 判断http请求的状态 , 200--成功 ，非200--失败.
		httpResponseCode = httpRequest:getResponseCode();
		if 0 ~= httpRequest:getError() or 200 ~= httpResponseCode then
			errorCode = HttpErrorType.NETWORKERROR;
			break;
		end
	
		-- http 请求返回值
		local resultStr =  httpRequest:getResponse();

		-- http 请求返回值的json 格式
		-- local json_data = json.decode_node(resultStr);
		local json_data = json.decode(resultStr);

		--返回错误json格式.
	    -- if not json_data:get_value() then
	    if not json_data then
	    	errorCode = HttpErrorType.JSONERROR;
			break;
	    end

	    data = json_data;
	until true;
    EventDispatcher.getInstance():dispatch(self.m_userEvent,command,errorCode,data,httpResponseCode,param);
	
	HttpManager.destroyHttpRequest(self,httpRequest);
end

HttpManager.onTimeout = function(callbackObj)
	local self = callbackObj["obj"];
	local command = callbackObj["command"];
	EventDispatcher.getInstance():dispatch(self.m_userEvent,command,HttpErrorType.TIMEOUT);

	HttpManager.destroyHttpRequest(self,self.m_commandHttpMap[command]);
end

HttpManager.createTimeoutAnim = function(self,command,timeoutTime)
	local timeoutAnim = new(AnimInt,kAnimRepeat,0,1,timeoutTime,-1);
	timeoutAnim:setDebugName("AnimInt | httpTimeoutAnim");
    timeoutAnim:setEvent({["obj"] = self,["command"] = command},self.onTimeout);

    return timeoutAnim;
end

HttpManager.destoryTimeoutAnim = function(self,command)
	local anim = self.m_commandTimeoutAnimMap[command];
	delete(anim);

	self.m_commandTimeoutAnimMap[command] = nil;
end

HttpManager.destroyHttpRequest = function(self,httpRequest)
	if not httpRequest then 
		return;
	end

	local command = self.m_httpCommandMap[httpRequest];
	
	if not command then
		delete(httpRequest);
	    return;
	end

	HttpManager.destoryTimeoutAnim(self,command);
	self.m_commandHttpMap[command] = nil;
	self.m_httpCommandMap[httpRequest] = nil;
end

HttpManager.destroyAllHttpRequests = function(self)
	for _,v in pairs(self.m_commandHttpMap)do 
		HttpManager.destroyHttpRequest(self,v);
	end
end